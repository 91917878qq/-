package androidx.compose.foundation;

import androidx.compose.foundation.layout.AbstractC0413c0;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.ui.graphics.AbstractC0851a0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0376g0 {
    public static final int $stable = 0;
    private final InterfaceC0421g0 drawPadding;
    private final long glowColor;

    public /* synthetic */ C0376g0(long j2, InterfaceC0421g0 interfaceC0421g0, AbstractC1378g abstractC1378g) {
        this(j2, interfaceC0421g0);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!C0376g0.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        kotlin.jvm.internal.o.c(obj, "null cannot be cast to non-null type androidx.compose.foundation.OverscrollConfiguration");
        C0376g0 c0376g0 = (C0376g0) obj;
        return androidx.compose.ui.graphics.Y.m3021equalsimpl0(this.glowColor, c0376g0.glowColor) && kotlin.jvm.internal.o.a(this.drawPadding, c0376g0.drawPadding);
    }

    public final InterfaceC0421g0 getDrawPadding() {
        return this.drawPadding;
    }

    /* JADX INFO: renamed from: getGlowColor-0d7_KjU, reason: not valid java name */
    public final long m756getGlowColor0d7_KjU() {
        return this.glowColor;
    }

    public int hashCode() {
        return this.drawPadding.hashCode() + (androidx.compose.ui.graphics.Y.m3027hashCodeimpl(this.glowColor) * 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("OverscrollConfiguration(glowColor=");
        D0.d.w(this.glowColor, sb, ", drawPadding=");
        sb.append(this.drawPadding);
        sb.append(')');
        return sb.toString();
    }

    private C0376g0(long j2, InterfaceC0421g0 interfaceC0421g0) {
        this.glowColor = j2;
        this.drawPadding = interfaceC0421g0;
    }

    public /* synthetic */ C0376g0(long j2, InterfaceC0421g0 interfaceC0421g0, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? AbstractC0851a0.Color(4284900966L) : j2, (i2 & 2) != 0 ? AbstractC0413c0.m954PaddingValuesYgX7TsA$default(0.0f, 0.0f, 3, null) : interfaceC0421g0, null);
    }
}
