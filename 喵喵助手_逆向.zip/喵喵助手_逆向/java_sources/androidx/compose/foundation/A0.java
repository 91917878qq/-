package androidx.compose.foundation;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import androidx.compose.ui.node.S0;
import androidx.compose.ui.semantics.C1118l;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public final class A0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M, S0 {
    public static final int $stable = 8;
    private boolean isVertical;
    private boolean reverseScrolling;
    private C0 state;

    public A0(C0 c02, boolean z2, boolean z3) {
        this.state = c02;
        this.reverseScrolling = z2;
        this.isVertical = z3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float applySemantics$lambda$2(A0 a02) {
        return a02.state.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float applySemantics$lambda$3(A0 a02) {
        return a02.state.getMaxValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$1(A0 a02, int i2, AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        int value = a02.state.getValue();
        if (value < 0) {
            value = 0;
        }
        if (value > i2) {
            value = i2;
        }
        int i3 = a02.reverseScrolling ? value - i2 : -value;
        boolean z2 = a02.isVertical;
        aVar.withMotionFrameOfReferencePlacement(new y0(abstractC0974x0, z2 ? 0 : i3, z2 ? i3 : 0, 0));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$1$lambda$0(AbstractC0974x0 abstractC0974x0, int i2, int i3, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.placeRelativeWithLayer$default(aVar, abstractC0974x0, i2, i3, 0.0f, (h1.c) null, 12, (Object) null);
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
        androidx.compose.ui.semantics.C.setTraversalGroup(e2, true);
        final int i2 = 0;
        final int i3 = 1;
        C1118l c1118l = new C1118l(new h1.a(this) { // from class: androidx.compose.foundation.z0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ A0 f2431c;

            {
                this.f2431c = this;
            }

            @Override // h1.a
            public final Object invoke() {
                switch (i2) {
                    case 0:
                        return Float.valueOf(A0.applySemantics$lambda$2(this.f2431c));
                    default:
                        return Float.valueOf(A0.applySemantics$lambda$3(this.f2431c));
                }
            }
        }, new h1.a(this) { // from class: androidx.compose.foundation.z0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ A0 f2431c;

            {
                this.f2431c = this;
            }

            @Override // h1.a
            public final Object invoke() {
                switch (i3) {
                    case 0:
                        return Float.valueOf(A0.applySemantics$lambda$2(this.f2431c));
                    default:
                        return Float.valueOf(A0.applySemantics$lambda$3(this.f2431c));
                }
            }
        }, this.reverseScrolling);
        if (this.isVertical) {
            androidx.compose.ui.semantics.C.setVerticalScrollAxisRange(e2, c1118l);
        } else {
            androidx.compose.ui.semantics.C.setHorizontalScrollAxisRange(e2, c1118l);
        }
    }

    public final boolean getReverseScrolling() {
        return this.reverseScrolling;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    public final C0 getState() {
        return this.state;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    public final boolean isVertical() {
        return this.isVertical;
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        if (!this.isVertical) {
            i2 = Integer.MAX_VALUE;
        }
        return e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        if (this.isVertical) {
            i2 = Integer.MAX_VALUE;
        }
        return e2.maxIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        AbstractC0521s.m1142checkScrollableContainerConstraintsK40F9xA(j2, this.isVertical ? androidx.compose.foundation.gestures.I.Vertical : androidx.compose.foundation.gestures.I.Horizontal);
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(C1305b.m5031copyZbe2FdA$default(j2, 0, this.isVertical ? C1305b.m5041getMaxWidthimpl(j2) : Integer.MAX_VALUE, 0, this.isVertical ? Integer.MAX_VALUE : C1305b.m5040getMaxHeightimpl(j2), 5, null));
        int width = abstractC0974x0Mo3865measureBRTryo0.getWidth();
        int iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
        int i2 = width > iM5041getMaxWidthimpl ? iM5041getMaxWidthimpl : width;
        int height = abstractC0974x0Mo3865measureBRTryo0.getHeight();
        int iM5040getMaxHeightimpl = C1305b.m5040getMaxHeightimpl(j2);
        int i3 = height > iM5040getMaxHeightimpl ? iM5040getMaxHeightimpl : height;
        int height2 = abstractC0974x0Mo3865measureBRTryo0.getHeight() - i3;
        int width2 = abstractC0974x0Mo3865measureBRTryo0.getWidth() - i2;
        if (!this.isVertical) {
            height2 = width2;
        }
        this.state.setMaxValue$foundation_release(height2);
        this.state.setViewportSize$foundation_release(this.isVertical ? i3 : i2);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, i2, i3, null, new x0(this, height2, abstractC0974x0Mo3865measureBRTryo0, 0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        if (!this.isVertical) {
            i2 = Integer.MAX_VALUE;
        }
        return e2.minIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        if (this.isVertical) {
            i2 = Integer.MAX_VALUE;
        }
        return e2.minIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setReverseScrolling(boolean z2) {
        this.reverseScrolling = z2;
    }

    public final void setState(C0 c02) {
        this.state = c02;
    }

    public final void setVertical(boolean z2) {
        this.isVertical = z2;
    }
}
