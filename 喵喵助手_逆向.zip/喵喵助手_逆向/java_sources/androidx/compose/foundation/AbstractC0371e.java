package androidx.compose.foundation;

import android.content.Context;
import androidx.compose.foundation.layout.AbstractC0413c0;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.graphics.AbstractC0851a0;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.L0;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0371e {
    private static final long DefaultGlowColor = AbstractC0851a0.Color(4284900966L);
    private static final InterfaceC0421g0 DefaultGlowPaddingValues = AbstractC0413c0.m954PaddingValuesYgX7TsA$default(0.0f, 0.0f, 3, null);
    private static final float FlingDestretchFactor = 4.0f;

    public static final j0 defaultOverscrollFactory(androidx.compose.runtime.B b2) {
        Context context = (Context) b2.getCurrentValue(AndroidCompositionLocals_androidKt.getLocalContext());
        InterfaceC1307d interfaceC1307d = (InterfaceC1307d) b2.getCurrentValue(L0.getLocalDensity());
        C0376g0 c0376g0 = (C0376g0) b2.getCurrentValue(AbstractC0403h0.getLocalOverscrollConfiguration());
        if (c0376g0 == null) {
            return null;
        }
        return new C0369d(context, interfaceC1307d, c0376g0.m756getGlowColor0d7_KjU(), c0376g0.getDrawPadding(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: destretchMultiplier-GyEprt8, reason: not valid java name */
    public static final float m752destretchMultiplierGyEprt8(int i2) {
        return androidx.compose.ui.input.nestedscroll.f.m3624equalsimpl0(i2, androidx.compose.ui.input.nestedscroll.f.Companion.m3635getSideEffectWNlRxjI()) ? 4.0f : 1.0f;
    }

    public static final i0 rememberPlatformOverscrollEffect(InterfaceC0768p interfaceC0768p, int i2) {
        C0367c c0367c;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1569526143, i2, -1, "androidx.compose.foundation.rememberPlatformOverscrollEffect (AndroidOverscroll.android.kt:107)");
        }
        Context context = (Context) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalContext());
        InterfaceC1307d interfaceC1307d = (InterfaceC1307d) interfaceC0768p.consume(L0.getLocalDensity());
        C0376g0 c0376g0 = (C0376g0) interfaceC0768p.consume(AbstractC0403h0.getLocalOverscrollConfiguration());
        if (c0376g0 == null) {
            interfaceC0768p.startReplaceGroup(-1555310353);
            interfaceC0768p.endReplaceGroup();
            c0367c = null;
        } else {
            interfaceC0768p.startReplaceGroup(-1555277648);
            boolean zChanged = interfaceC0768p.changed(context) | interfaceC0768p.changed(interfaceC1307d) | interfaceC0768p.changed(c0376g0);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                Object c0367c2 = new C0367c(context, interfaceC1307d, c0376g0.m756getGlowColor0d7_KjU(), c0376g0.getDrawPadding(), null);
                interfaceC0768p.updateRememberedValue(c0367c2);
                objRememberedValue = c0367c2;
            }
            interfaceC0768p.endReplaceGroup();
            c0367c = (C0367c) objRememberedValue;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return c0367c;
    }

    /* JADX INFO: renamed from: rememberPlatformOverscrollFactory-3J-VO9M, reason: not valid java name */
    public static final j0 m753rememberPlatformOverscrollFactory3JVO9M(long j2, InterfaceC0421g0 interfaceC0421g0, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 1) != 0) {
            j2 = DefaultGlowColor;
        }
        long j3 = j2;
        if ((i3 & 2) != 0) {
            interfaceC0421g0 = DefaultGlowPaddingValues;
        }
        InterfaceC0421g0 interfaceC0421g02 = interfaceC0421g0;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-2017030679, i2, -1, "androidx.compose.foundation.rememberPlatformOverscrollFactory (AndroidOverscroll.android.kt:85)");
        }
        C0369d c0369d = new C0369d((Context) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalContext()), (InterfaceC1307d) interfaceC0768p.consume(L0.getLocalDensity()), j3, interfaceC0421g02, null);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return c0369d;
    }
}
