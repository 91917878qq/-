package androidx.compose.foundation;

import androidx.compose.ui.node.InterfaceC1007o;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends androidx.compose.ui.node.r {
    private InterfaceC1007o overscrollNode;

    public l0(InterfaceC1007o interfaceC1007o) {
        this.overscrollNode = interfaceC1007o;
    }

    private final void attachIfNeeded() {
        InterfaceC1007o interfaceC1007oDelegate;
        androidx.compose.ui.w node;
        InterfaceC1007o interfaceC1007o = this.overscrollNode;
        if (interfaceC1007o == null || (node = interfaceC1007o.getNode()) == null || node.isAttached()) {
            interfaceC1007oDelegate = null;
        } else {
            InterfaceC1007o interfaceC1007o2 = this.overscrollNode;
            kotlin.jvm.internal.o.b(interfaceC1007o2);
            interfaceC1007oDelegate = delegate(interfaceC1007o2);
        }
        this.overscrollNode = interfaceC1007oDelegate;
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        attachIfNeeded();
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w
    public void onDetach() {
        InterfaceC1007o interfaceC1007o = this.overscrollNode;
        if (interfaceC1007o != null) {
            undelegate(interfaceC1007o);
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void update(InterfaceC1007o interfaceC1007o) {
        InterfaceC1007o interfaceC1007o2 = this.overscrollNode;
        if (interfaceC1007o2 != null) {
            undelegate(interfaceC1007o2);
        }
        this.overscrollNode = interfaceC1007o;
        attachIfNeeded();
    }
}
