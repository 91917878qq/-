package androidx.compose.foundation;

import androidx.compose.ui.graphics.a1;
import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.node.InterfaceC1029z0;
import androidx.compose.ui.node.S0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0402h extends androidx.compose.ui.w implements androidx.compose.ui.node.A, InterfaceC1029z0, S0 {
    private float alpha;
    private androidx.compose.ui.graphics.P brush;
    private long color;
    private final boolean isImportantForBounds;
    private e0.u lastLayoutDirection;
    private androidx.compose.ui.graphics.E0 lastOutline;
    private j1 lastShape;
    private long lastSize;
    private j1 shape;
    private final boolean shouldAutoInvalidate;
    private androidx.compose.ui.graphics.E0 tmpOutline;

    public /* synthetic */ C0402h(long j2, androidx.compose.ui.graphics.P p2, float f2, j1 j1Var, AbstractC1378g abstractC1378g) {
        this(j2, p2, f2, j1Var);
    }

    private final void drawOutline(androidx.compose.ui.graphics.drawscope.c cVar) {
        androidx.compose.ui.graphics.E0 outline = getOutline(cVar);
        if (!androidx.compose.ui.graphics.Y.m3021equalsimpl0(this.color, androidx.compose.ui.graphics.Y.Companion.m3056getUnspecified0d7_KjU())) {
            androidx.compose.ui.graphics.F0.m2843drawOutlinewDX37Ww(cVar, outline, this.color, (60 & 4) != 0 ? 1.0f : 0.0f, (60 & 8) != 0 ? androidx.compose.ui.graphics.drawscope.k.INSTANCE : null, (60 & 16) != 0 ? null : null, (60 & 32) != 0 ? androidx.compose.ui.graphics.drawscope.g.Companion.m3204getDefaultBlendMode0nO6VwU() : 0);
        }
        androidx.compose.ui.graphics.P p2 = this.brush;
        if (p2 != null) {
            androidx.compose.ui.graphics.F0.m2842drawOutlinehn5TExg$default(cVar, outline, p2, this.alpha, null, null, 0, 56, null);
        }
    }

    private final void drawRect(androidx.compose.ui.graphics.drawscope.c cVar) {
        if (!androidx.compose.ui.graphics.Y.m3021equalsimpl0(this.color, androidx.compose.ui.graphics.Y.Companion.m3056getUnspecified0d7_KjU())) {
            androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(cVar, this.color, 0L, 0L, 0.0f, null, null, 0, 126, null);
        }
        androidx.compose.ui.graphics.P p2 = this.brush;
        if (p2 != null) {
            androidx.compose.ui.graphics.drawscope.g.m3237drawRectAsUm42w$default(cVar, p2, 0L, 0L, this.alpha, null, null, 0, 118, null);
        }
    }

    private final androidx.compose.ui.graphics.E0 getOutline(androidx.compose.ui.graphics.drawscope.c cVar) {
        androidx.compose.ui.graphics.E0 e02;
        if (J.l.m115equalsimpl0(cVar.mo3172getSizeNHjbRc(), this.lastSize) && cVar.getLayoutDirection() == this.lastLayoutDirection && kotlin.jvm.internal.o.a(this.lastShape, this.shape)) {
            e02 = this.lastOutline;
            kotlin.jvm.internal.o.b(e02);
        } else {
            androidx.compose.ui.node.A0.observeReads(this, new I.g(2, this, cVar));
            e02 = this.tmpOutline;
            this.tmpOutline = null;
        }
        this.lastOutline = e02;
        this.lastSize = cVar.mo3172getSizeNHjbRc();
        this.lastLayoutDirection = cVar.getLayoutDirection();
        this.lastShape = this.shape;
        kotlin.jvm.internal.o.b(e02);
        return e02;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n getOutline$lambda$2(C0402h c0402h, androidx.compose.ui.graphics.drawscope.c cVar) {
        c0402h.tmpOutline = c0402h.shape.mo693createOutlinePq9zytI(cVar.mo3172getSizeNHjbRc(), cVar.getLayoutDirection(), cVar);
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
    }

    @Override // androidx.compose.ui.node.A
    public void draw(androidx.compose.ui.graphics.drawscope.c cVar) {
        if (this.shape == a1.getRectangleShape()) {
            drawRect(cVar);
        } else {
            drawOutline(cVar);
        }
        cVar.drawContent();
    }

    public final float getAlpha() {
        return this.alpha;
    }

    public final androidx.compose.ui.graphics.P getBrush() {
        return this.brush;
    }

    /* JADX INFO: renamed from: getColor-0d7_KjU, reason: not valid java name */
    public final long m884getColor0d7_KjU() {
        return this.color;
    }

    public final j1 getShape() {
        return this.shape;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public boolean isImportantForBounds() {
        return this.isImportantForBounds;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.A
    public /* bridge */ /* synthetic */ void onMeasureResultChanged() {
        super.onMeasureResultChanged();
    }

    @Override // androidx.compose.ui.node.InterfaceC1029z0
    public void onObservedReadsChanged() {
        this.lastSize = J.l.Companion.m127getUnspecifiedNHjbRc();
        this.lastLayoutDirection = null;
        this.lastOutline = null;
        this.lastShape = null;
        androidx.compose.ui.node.B.invalidateDraw(this);
    }

    public final void setAlpha(float f2) {
        this.alpha = f2;
    }

    public final void setBrush(androidx.compose.ui.graphics.P p2) {
        this.brush = p2;
    }

    /* JADX INFO: renamed from: setColor-8_81llA, reason: not valid java name */
    public final void m885setColor8_81llA(long j2) {
        this.color = j2;
    }

    public final void setShape(j1 j1Var) {
        this.shape = j1Var;
    }

    private C0402h(long j2, androidx.compose.ui.graphics.P p2, float f2, j1 j1Var) {
        this.color = j2;
        this.brush = p2;
        this.alpha = f2;
        this.shape = j1Var;
        this.lastSize = J.l.Companion.m127getUnspecifiedNHjbRc();
    }
}
