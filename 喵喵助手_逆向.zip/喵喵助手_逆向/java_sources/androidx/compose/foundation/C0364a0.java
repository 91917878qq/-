package androidx.compose.foundation;

import android.view.View;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.node.AbstractC1011q;
import androidx.compose.ui.node.InterfaceC1029z0;
import androidx.compose.ui.node.S0;
import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.EnumC1475y;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0364a0 extends androidx.compose.ui.w implements androidx.compose.ui.node.C, androidx.compose.ui.node.A, S0, InterfaceC1029z0 {
    public static final int $stable = 8;
    private d2 anchorPositionInRootState;
    private boolean clippingEnabled;
    private float cornerRadius;
    private InterfaceC1307d density;
    private t1.g drawSignalChannel;
    private float elevation;
    private final androidx.compose.runtime.B0 layoutCoordinates$delegate;
    private m0 magnifier;
    private h1.c magnifierCenter;
    private h1.c onSizeChanged;
    private o0 platformMagnifierFactory;
    private e0.s previousSize;
    private long size;
    private h1.c sourceCenter;
    private long sourceCenterInRoot;
    private boolean useTextDefault;
    private View view;
    private float zoom;

    /* JADX INFO: renamed from: androidx.compose.foundation.a0$a */
    public static final class a extends a1.j implements h1.e {
        int label;

        public a(Y0.c cVar) {
            super(2, cVar);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(long j2) {
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return C0364a0.this.new a(cVar);
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0027  */
        /* JADX WARN: Removed duplicated region for block: B:18:0x0038  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x004f  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0036 -> B:11:0x001f). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x0044 -> B:21:0x0047). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r5) {
            /*
                r4 = this;
                Z0.a r0 = Z0.a.f1616b
                int r1 = r4.label
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L1c
                if (r1 == r3) goto L18
                if (r1 != r2) goto L10
                a.AbstractC0292a.H(r5)
                goto L47
            L10:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r5.<init>(r0)
                throw r5
            L18:
                a.AbstractC0292a.H(r5)
                goto L30
            L1c:
                a.AbstractC0292a.H(r5)
            L1f:
                androidx.compose.foundation.a0 r5 = androidx.compose.foundation.C0364a0.this
                t1.g r5 = androidx.compose.foundation.C0364a0.access$getDrawSignalChannel$p(r5)
                if (r5 == 0) goto L30
                r4.label = r3
                java.lang.Object r5 = r5.a(r4)
                if (r5 != r0) goto L30
                return r0
            L30:
                androidx.compose.foundation.a0 r5 = androidx.compose.foundation.C0364a0.this
                androidx.compose.foundation.m0 r5 = androidx.compose.foundation.C0364a0.access$getMagnifier$p(r5)
                if (r5 == 0) goto L1f
                androidx.compose.animation.core.D0 r5 = new androidx.compose.animation.core.D0
                r1 = 7
                r5.<init>(r1)
                r4.label = r2
                java.lang.Object r5 = androidx.compose.runtime.AbstractC0801u0.withFrameMillis(r5, r4)
                if (r5 != r0) goto L47
                return r0
            L47:
                androidx.compose.foundation.a0 r5 = androidx.compose.foundation.C0364a0.this
                androidx.compose.foundation.m0 r5 = androidx.compose.foundation.C0364a0.access$getMagnifier$p(r5)
                if (r5 == 0) goto L1f
                r5.updateContent()
                goto L1f
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.C0364a0.a.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public /* synthetic */ C0364a0(h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, boolean z2, long j2, float f3, float f4, boolean z3, o0 o0Var, AbstractC1378g abstractC1378g) {
        this(cVar, cVar2, cVar3, f2, z2, j2, f3, f4, z3, o0Var);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.f applySemantics$lambda$8(C0364a0 c0364a0) {
        return J.f.m39boximpl(c0364a0.sourceCenterInRoot);
    }

    /* JADX INFO: renamed from: getAnchorPositionInRoot-F1C5BW0, reason: not valid java name */
    private final long m700getAnchorPositionInRootF1C5BW0() {
        if (this.anchorPositionInRootState == null) {
            this.anchorPositionInRootState = Q1.derivedStateOf(new Z(this, 2));
        }
        d2 d2Var = this.anchorPositionInRootState;
        return d2Var != null ? ((J.f) d2Var.getValue()).m60unboximpl() : J.f.Companion.m65getUnspecifiedF1C5BW0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.f getAnchorPositionInRoot_F1C5BW0$lambda$0(C0364a0 c0364a0) {
        androidx.compose.ui.layout.J layoutCoordinates = c0364a0.getLayoutCoordinates();
        return J.f.m39boximpl(layoutCoordinates != null ? androidx.compose.ui.layout.K.positionInRoot(layoutCoordinates) : J.f.Companion.m65getUnspecifiedF1C5BW0());
    }

    private final androidx.compose.ui.layout.J getLayoutCoordinates() {
        return (androidx.compose.ui.layout.J) this.layoutCoordinates$delegate.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n onObservedReadsChanged$lambda$1(C0364a0 c0364a0) {
        c0364a0.updateMagnifier();
        return U0.n.f1521a;
    }

    private final void recreateMagnifier() {
        m0 m0Var = this.magnifier;
        if (m0Var != null) {
            m0Var.dismiss();
        }
        View viewRequireView = this.view;
        if (viewRequireView == null) {
            viewRequireView = AbstractC1011q.requireView(this);
        }
        View view = viewRequireView;
        this.view = view;
        InterfaceC1307d interfaceC1307dRequireDensity = this.density;
        if (interfaceC1307dRequireDensity == null) {
            interfaceC1307dRequireDensity = AbstractC1009p.requireDensity(this);
        }
        InterfaceC1307d interfaceC1307d = interfaceC1307dRequireDensity;
        this.density = interfaceC1307d;
        this.magnifier = this.platformMagnifierFactory.mo1121createnHHXs2Y(view, this.useTextDefault, this.size, this.cornerRadius, this.elevation, this.clippingEnabled, interfaceC1307d, this.zoom);
        updateSizeIfNecessary();
    }

    private final void setLayoutCoordinates(androidx.compose.ui.layout.J j2) {
        this.layoutCoordinates$delegate.setValue(j2);
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0066  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void updateMagnifier() {
        /*
            r9 = this;
            e0.d r0 = r9.density
            if (r0 != 0) goto La
            e0.d r0 = androidx.compose.ui.node.AbstractC1009p.requireDensity(r9)
            r9.density = r0
        La:
            h1.c r1 = r9.sourceCenter
            java.lang.Object r1 = r1.invoke(r0)
            J.f r1 = (J.f) r1
            long r1 = r1.m60unboximpl()
            r3 = 9223372034707292159(0x7fffffff7fffffff, double:NaN)
            long r5 = r1 & r3
            r7 = 9205357640488583168(0x7fc000007fc00000, double:2.247117487993712E307)
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 == 0) goto L83
            long r5 = r9.m700getAnchorPositionInRootF1C5BW0()
            long r5 = r5 & r3
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 == 0) goto L83
            long r5 = r9.m700getAnchorPositionInRootF1C5BW0()
            long r1 = J.f.m55plusMKHz9U(r5, r1)
            r9.sourceCenterInRoot = r1
            h1.c r1 = r9.magnifierCenter
            if (r1 == 0) goto L66
            java.lang.Object r0 = r1.invoke(r0)
            J.f r0 = (J.f) r0
            long r0 = r0.m60unboximpl()
            J.f r0 = J.f.m39boximpl(r0)
            long r1 = r0.m60unboximpl()
            long r1 = r1 & r3
            int r1 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r1 == 0) goto L55
            goto L56
        L55:
            r0 = 0
        L56:
            if (r0 == 0) goto L66
            long r0 = r0.m60unboximpl()
            long r2 = r9.m700getAnchorPositionInRootF1C5BW0()
            long r0 = J.f.m55plusMKHz9U(r2, r0)
        L64:
            r5 = r0
            goto L6d
        L66:
            J.f$a r0 = J.f.Companion
            long r0 = r0.m65getUnspecifiedF1C5BW0()
            goto L64
        L6d:
            androidx.compose.foundation.m0 r0 = r9.magnifier
            if (r0 != 0) goto L74
            r9.recreateMagnifier()
        L74:
            androidx.compose.foundation.m0 r2 = r9.magnifier
            if (r2 == 0) goto L7f
            long r3 = r9.sourceCenterInRoot
            float r7 = r9.zoom
            r2.mo1114updateWko1d7g(r3, r5, r7)
        L7f:
            r9.updateSizeIfNecessary()
            return
        L83:
            J.f$a r0 = J.f.Companion
            long r0 = r0.m65getUnspecifiedF1C5BW0()
            r9.sourceCenterInRoot = r0
            androidx.compose.foundation.m0 r0 = r9.magnifier
            if (r0 == 0) goto L92
            r0.dismiss()
        L92:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.C0364a0.updateMagnifier():void");
    }

    private final void updateSizeIfNecessary() {
        InterfaceC1307d interfaceC1307d;
        m0 m0Var = this.magnifier;
        if (m0Var == null || (interfaceC1307d = this.density) == null || e0.s.m5236equalsimpl(m0Var.mo1113getSizeYbymL2g(), this.previousSize)) {
            return;
        }
        h1.c cVar = this.onSizeChanged;
        if (cVar != null) {
            cVar.invoke(e0.l.m5162boximpl(interfaceC1307d.mo786toDpSizekrfVVM(e0.t.m5251toSizeozmzZPI(m0Var.mo1113getSizeYbymL2g()))));
        }
        this.previousSize = e0.s.m5231boximpl(m0Var.mo1113getSizeYbymL2g());
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
        e2.set(AbstractC0366b0.getMagnifierPositionInRoot(), new Z(this, 1));
    }

    @Override // androidx.compose.ui.node.A
    public void draw(androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        t1.g gVar = this.drawSignalChannel;
        if (gVar != null) {
            gVar.l(U0.n.f1521a);
        }
    }

    public final boolean getClippingEnabled() {
        return this.clippingEnabled;
    }

    /* JADX INFO: renamed from: getCornerRadius-D9Ej5fM, reason: not valid java name */
    public final float m701getCornerRadiusD9Ej5fM() {
        return this.cornerRadius;
    }

    /* JADX INFO: renamed from: getElevation-D9Ej5fM, reason: not valid java name */
    public final float m702getElevationD9Ej5fM() {
        return this.elevation;
    }

    public final h1.c getMagnifierCenter() {
        return this.magnifierCenter;
    }

    public final h1.c getOnSizeChanged() {
        return this.onSizeChanged;
    }

    public final o0 getPlatformMagnifierFactory() {
        return this.platformMagnifierFactory;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    /* JADX INFO: renamed from: getSize-MYxV2XQ, reason: not valid java name */
    public final long m703getSizeMYxV2XQ() {
        return this.size;
    }

    public final h1.c getSourceCenter() {
        return this.sourceCenter;
    }

    public final boolean getUseTextDefault() {
        return this.useTextDefault;
    }

    public final float getZoom() {
        return this.zoom;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        onObservedReadsChanged();
        this.drawSignalChannel = t1.j.a(0, 7, null);
        AbstractC1476z.s(getCoroutineScope(), null, EnumC1475y.f3408e, new a(null), 1);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w
    public void onDetach() {
        m0 m0Var = this.magnifier;
        if (m0Var != null) {
            m0Var.dismiss();
        }
        this.magnifier = null;
    }

    @Override // androidx.compose.ui.node.C
    public void onGloballyPositioned(androidx.compose.ui.layout.J j2) {
        setLayoutCoordinates(j2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.A
    public /* bridge */ /* synthetic */ void onMeasureResultChanged() {
        super.onMeasureResultChanged();
    }

    @Override // androidx.compose.ui.node.InterfaceC1029z0
    public void onObservedReadsChanged() {
        androidx.compose.ui.node.A0.observeReads(this, new Z(this, 0));
    }

    public final void setClippingEnabled(boolean z2) {
        this.clippingEnabled = z2;
    }

    /* JADX INFO: renamed from: setCornerRadius-0680j_4, reason: not valid java name */
    public final void m704setCornerRadius0680j_4(float f2) {
        this.cornerRadius = f2;
    }

    /* JADX INFO: renamed from: setElevation-0680j_4, reason: not valid java name */
    public final void m705setElevation0680j_4(float f2) {
        this.elevation = f2;
    }

    public final void setMagnifierCenter(h1.c cVar) {
        this.magnifierCenter = cVar;
    }

    public final void setOnSizeChanged(h1.c cVar) {
        this.onSizeChanged = cVar;
    }

    public final void setPlatformMagnifierFactory(o0 o0Var) {
        this.platformMagnifierFactory = o0Var;
    }

    /* JADX INFO: renamed from: setSize-EaSLcWc, reason: not valid java name */
    public final void m706setSizeEaSLcWc(long j2) {
        this.size = j2;
    }

    public final void setSourceCenter(h1.c cVar) {
        this.sourceCenter = cVar;
    }

    public final void setUseTextDefault(boolean z2) {
        this.useTextDefault = z2;
    }

    public final void setZoom(float f2) {
        this.zoom = f2;
    }

    /* JADX INFO: renamed from: update-5F03MCQ, reason: not valid java name */
    public final void m707update5F03MCQ(h1.c cVar, h1.c cVar2, float f2, boolean z2, long j2, float f3, float f4, boolean z3, h1.c cVar3, o0 o0Var) {
        float f5 = this.zoom;
        long j3 = this.size;
        float f6 = this.cornerRadius;
        boolean z4 = this.useTextDefault;
        float f7 = this.elevation;
        boolean z5 = this.clippingEnabled;
        o0 o0Var2 = this.platformMagnifierFactory;
        View view = this.view;
        InterfaceC1307d interfaceC1307d = this.density;
        this.sourceCenter = cVar;
        this.magnifierCenter = cVar2;
        this.zoom = f2;
        this.useTextDefault = z2;
        this.size = j2;
        this.cornerRadius = f3;
        this.elevation = f4;
        this.clippingEnabled = z3;
        this.onSizeChanged = cVar3;
        this.platformMagnifierFactory = o0Var;
        View viewRequireView = AbstractC1011q.requireView(this);
        InterfaceC1307d interfaceC1307dRequireDensity = AbstractC1009p.requireDensity(this);
        if (this.magnifier != null && ((!AbstractC0366b0.equalsIncludingNaN(f2, f5) && !o0Var.getCanUpdateZoom()) || !e0.l.m5171equalsimpl0(j2, j3) || !C1311h.m5081equalsimpl0(f3, f6) || !C1311h.m5081equalsimpl0(f4, f7) || z2 != z4 || z3 != z5 || !kotlin.jvm.internal.o.a(o0Var, o0Var2) || !kotlin.jvm.internal.o.a(viewRequireView, view) || !kotlin.jvm.internal.o.a(interfaceC1307dRequireDensity, interfaceC1307d))) {
            recreateMagnifier();
        }
        updateMagnifier();
    }

    public /* synthetic */ C0364a0(h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, boolean z2, long j2, float f3, float f4, boolean z3, o0 o0Var, int i2, AbstractC1378g abstractC1378g) {
        this(cVar, (i2 & 2) != 0 ? null : cVar2, (i2 & 4) != 0 ? null : cVar3, (i2 & 8) != 0 ? Float.NaN : f2, (i2 & 16) != 0 ? false : z2, (i2 & 32) != 0 ? e0.l.Companion.m5183getUnspecifiedMYxV2XQ() : j2, (i2 & 64) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, (i2 & 128) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f4, (i2 & 256) != 0 ? true : z3, (i2 & 512) != 0 ? o0.Companion.getForCurrentPlatform() : o0Var, null);
    }

    private C0364a0(h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, boolean z2, long j2, float f3, float f4, boolean z3, o0 o0Var) {
        this.sourceCenter = cVar;
        this.magnifierCenter = cVar2;
        this.onSizeChanged = cVar3;
        this.zoom = f2;
        this.useTextDefault = z2;
        this.size = j2;
        this.cornerRadius = f3;
        this.elevation = f4;
        this.clippingEnabled = z3;
        this.platformMagnifierFactory = o0Var;
        this.layoutCoordinates$delegate = Q1.mutableStateOf(null, Q1.neverEqualPolicy());
        this.sourceCenterInRoot = J.f.Companion.m65getUnspecifiedF1C5BW0();
    }
}
