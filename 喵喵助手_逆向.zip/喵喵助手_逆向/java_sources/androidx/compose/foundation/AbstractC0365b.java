package androidx.compose.foundation;

import a.AbstractC0292a;
import android.view.KeyEvent;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.C0921t;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.InterfaceC1001l;
import androidx.compose.ui.node.InterfaceC1007o;
import androidx.compose.ui.node.InterfaceC1029z0;
import androidx.compose.ui.node.N0;
import androidx.compose.ui.node.S0;
import androidx.compose.ui.node.T0;
import androidx.compose.ui.node.a1;
import androidx.compose.ui.semantics.C1116j;
import j.AbstractC1361t;
import j.C1336G;
import kotlin.jvm.internal.AbstractC1378g;
import o.AbstractC1403e;
import r1.AbstractC1476z;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0365b extends androidx.compose.ui.node.r implements N0, P.e, S0, a1, InterfaceC1001l, InterfaceC1029z0 {
    private long centerOffset;
    private final C1336G currentKeyPressInteractions;
    private InterfaceC1451b0 delayJob;
    private boolean enabled;
    private final J focusableNode;
    private androidx.compose.foundation.interaction.h hoverInteraction;
    private InterfaceC1007o indicationNode;
    private Y indicationNodeFactory;
    private androidx.compose.foundation.interaction.n interactionSource;
    private boolean lazilyCreateIndication;
    private Y localIndicationNodeFactory;
    private h1.a onClick;
    private String onClickLabel;
    private androidx.compose.ui.input.pointer.Z pointerInputNode;
    private androidx.compose.foundation.interaction.q pressInteraction;
    private C1116j role;
    private final boolean shouldAutoInvalidate;
    private final Object traverseKey;
    private boolean useLocalIndication;
    private androidx.compose.foundation.interaction.n userProvidedInteractionSource;
    public static final a TraverseKey = new a(null);
    public static final int $stable = 8;

    /* JADX INFO: renamed from: androidx.compose.foundation.b$a */
    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        private a() {
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$b, reason: collision with other inner class name */
    public static final class C0023b extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.h $interaction;
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0023b(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.h hVar, Y0.c cVar) {
            super(2, cVar);
            this.$interactionSource = nVar;
            this.$interaction = hVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new C0023b(this.$interactionSource, this.$interaction, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                androidx.compose.foundation.interaction.h hVar = this.$interaction;
                this.label = 1;
                if (nVar.emit(hVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((C0023b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$c */
    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.i $interaction;
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.i iVar, Y0.c cVar) {
            super(2, cVar);
            this.$interactionSource = nVar;
            this.$interaction = iVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new c(this.$interactionSource, this.$interaction, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                androidx.compose.foundation.interaction.i iVar = this.$interaction;
                this.label = 1;
                if (nVar.emit(iVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$d */
    public /* synthetic */ class d extends kotlin.jvm.internal.l implements h1.c {
        public d(Object obj) {
            super(1, obj, AbstractC0365b.class, "onFocusChange", "onFocusChange(Z)V", 0);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke(((Boolean) obj).booleanValue());
            return U0.n.f1521a;
        }

        public final void invoke(boolean z2) {
            ((AbstractC0365b) this.receiver).onFocusChange(z2);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$e */
    public static final class e extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ long $offset;
        final /* synthetic */ androidx.compose.foundation.gestures.J $this_handlePressInteraction;
        private /* synthetic */ Object L$0;
        boolean Z$0;
        int label;
        final /* synthetic */ AbstractC0365b this$0;

        /* JADX INFO: renamed from: androidx.compose.foundation.b$e$a */
        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
            final /* synthetic */ long $offset;
            Object L$0;
            int label;
            final /* synthetic */ AbstractC0365b this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(AbstractC0365b abstractC0365b, long j2, androidx.compose.foundation.interaction.n nVar, Y0.c cVar) {
                super(2, cVar);
                this.this$0 = abstractC0365b;
                this.$offset = j2;
                this.$interactionSource = nVar;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                return new a(this.this$0, this.$offset, this.$interactionSource, cVar);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                androidx.compose.foundation.interaction.q qVar;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    if (this.this$0.delayPressInteraction()) {
                        long tapIndicationDelay = AbstractC0643w.getTapIndicationDelay();
                        this.label = 1;
                        if (AbstractC1476z.f(tapIndicationDelay, this) == aVar) {
                            return aVar;
                        }
                    }
                } else {
                    if (i2 != 1) {
                        if (i2 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        qVar = (androidx.compose.foundation.interaction.q) this.L$0;
                        AbstractC0292a.H(obj);
                        this.this$0.pressInteraction = qVar;
                        return U0.n.f1521a;
                    }
                    AbstractC0292a.H(obj);
                }
                androidx.compose.foundation.interaction.q qVar2 = new androidx.compose.foundation.interaction.q(this.$offset, null);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                this.L$0 = qVar2;
                this.label = 2;
                if (nVar.emit(qVar2, this) == aVar) {
                    return aVar;
                }
                qVar = qVar2;
                this.this$0.pressInteraction = qVar;
                return U0.n.f1521a;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(androidx.compose.foundation.gestures.J j2, long j3, androidx.compose.foundation.interaction.n nVar, AbstractC0365b abstractC0365b, Y0.c cVar) {
            super(2, cVar);
            this.$this_handlePressInteraction = j2;
            this.$offset = j3;
            this.$interactionSource = nVar;
            this.this$0 = abstractC0365b;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            e eVar = new e(this.$this_handlePressInteraction, this.$offset, this.$interactionSource, this.this$0, cVar);
            eVar.L$0 = obj;
            return eVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:26:0x007b  */
        /* JADX WARN: Removed duplicated region for block: B:31:0x00a0 A[RETURN] */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC1451b0 interfaceC1451b0S;
            boolean z2;
            androidx.compose.foundation.interaction.r rVar;
            androidx.compose.foundation.interaction.n nVar;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            AbstractC1378g abstractC1378g = null;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                interfaceC1451b0S = AbstractC1476z.s((InterfaceC1474x) this.L$0, null, null, new a(this.this$0, this.$offset, this.$interactionSource, null), 3);
                androidx.compose.foundation.gestures.J j2 = this.$this_handlePressInteraction;
                this.L$0 = interfaceC1451b0S;
                this.label = 1;
                obj = j2.tryAwaitRelease(this);
                if (obj == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            if (i2 != 4 && i2 != 5) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            AbstractC0292a.H(obj);
                            this.this$0.pressInteraction = null;
                            return U0.n.f1521a;
                        }
                        rVar = (androidx.compose.foundation.interaction.r) this.L$0;
                        AbstractC0292a.H(obj);
                        nVar = this.$interactionSource;
                        this.L$0 = null;
                        this.label = 4;
                        if (nVar.emit(rVar, this) == aVar) {
                            return aVar;
                        }
                        this.this$0.pressInteraction = null;
                        return U0.n.f1521a;
                    }
                    z2 = this.Z$0;
                    AbstractC0292a.H(obj);
                    if (z2) {
                        androidx.compose.foundation.interaction.q qVar = new androidx.compose.foundation.interaction.q(this.$offset, abstractC1378g);
                        rVar = new androidx.compose.foundation.interaction.r(qVar);
                        androidx.compose.foundation.interaction.n nVar2 = this.$interactionSource;
                        this.L$0 = rVar;
                        this.label = 3;
                        if (nVar2.emit(qVar, this) == aVar) {
                            return aVar;
                        }
                        nVar = this.$interactionSource;
                        this.L$0 = null;
                        this.label = 4;
                        if (nVar.emit(rVar, this) == aVar) {
                        }
                    }
                    this.this$0.pressInteraction = null;
                    return U0.n.f1521a;
                }
                interfaceC1451b0S = (InterfaceC1451b0) this.L$0;
                AbstractC0292a.H(obj);
            }
            boolean zBooleanValue = ((Boolean) obj).booleanValue();
            if (interfaceC1451b0S.isActive()) {
                this.L$0 = null;
                this.Z$0 = zBooleanValue;
                this.label = 2;
                if (AbstractC1476z.d(interfaceC1451b0S, this) == aVar) {
                    return aVar;
                }
                z2 = zBooleanValue;
                if (z2) {
                }
                this.this$0.pressInteraction = null;
                return U0.n.f1521a;
            }
            androidx.compose.foundation.interaction.q qVar2 = this.this$0.pressInteraction;
            if (qVar2 != null) {
                androidx.compose.foundation.interaction.n nVar3 = this.$interactionSource;
                androidx.compose.foundation.interaction.k rVar2 = zBooleanValue ? new androidx.compose.foundation.interaction.r(qVar2) : new androidx.compose.foundation.interaction.p(qVar2);
                this.L$0 = null;
                this.label = 5;
                if (nVar3.emit(rVar2, this) == aVar) {
                    return aVar;
                }
            }
            this.this$0.pressInteraction = null;
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$f */
    public static final class f extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ androidx.compose.foundation.interaction.q $pressInteraction;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(androidx.compose.foundation.interaction.q qVar, androidx.compose.foundation.interaction.n nVar, Y0.c cVar) {
            super(2, cVar);
            this.$pressInteraction = qVar;
            this.$interactionSource = nVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new f(this.$pressInteraction, this.$interactionSource, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.p pVar = new androidx.compose.foundation.interaction.p(this.$pressInteraction);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                this.label = 1;
                if (nVar.emit(pVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((f) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$g */
    public static final class g extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ long $offset;
        Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(long j2, androidx.compose.foundation.interaction.n nVar, Y0.c cVar) {
            super(2, cVar);
            this.$offset = j2;
            this.$interactionSource = nVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new g(this.$offset, this.$interactionSource, cVar);
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0061 A[RETURN] */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            androidx.compose.foundation.interaction.r rVar;
            androidx.compose.foundation.interaction.n nVar;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            AbstractC1378g abstractC1378g = null;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1451b0 interfaceC1451b0 = AbstractC0365b.this.delayJob;
                if (interfaceC1451b0 != null) {
                    this.label = 1;
                    if (AbstractC1476z.d(interfaceC1451b0, this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                        return U0.n.f1521a;
                    }
                    rVar = (androidx.compose.foundation.interaction.r) this.L$0;
                    AbstractC0292a.H(obj);
                    nVar = this.$interactionSource;
                    this.L$0 = null;
                    this.label = 3;
                    if (nVar.emit(rVar, this) == aVar) {
                        return aVar;
                    }
                    return U0.n.f1521a;
                }
                AbstractC0292a.H(obj);
            }
            androidx.compose.foundation.interaction.q qVar = new androidx.compose.foundation.interaction.q(this.$offset, abstractC1378g);
            rVar = new androidx.compose.foundation.interaction.r(qVar);
            androidx.compose.foundation.interaction.n nVar2 = this.$interactionSource;
            this.L$0 = rVar;
            this.label = 2;
            if (nVar2.emit(qVar, this) == aVar) {
                return aVar;
            }
            nVar = this.$interactionSource;
            this.L$0 = null;
            this.label = 3;
            if (nVar.emit(rVar, this) == aVar) {
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((g) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$h */
    public static final class h extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ androidx.compose.foundation.interaction.q $pressInteraction;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(androidx.compose.foundation.interaction.q qVar, androidx.compose.foundation.interaction.n nVar, Y0.c cVar) {
            super(2, cVar);
            this.$pressInteraction = qVar;
            this.$interactionSource = nVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new h(this.$pressInteraction, this.$interactionSource, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.r rVar = new androidx.compose.foundation.interaction.r(this.$pressInteraction);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                this.label = 1;
                if (nVar.emit(rVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((h) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$i */
    public static final class i extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ androidx.compose.foundation.interaction.q $press;
        int label;
        final /* synthetic */ AbstractC0365b this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.q qVar, AbstractC0365b abstractC0365b, Y0.c cVar) {
            super(2, cVar);
            this.$interactionSource = nVar;
            this.$press = qVar;
            this.this$0 = abstractC0365b;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new i(this.$interactionSource, this.$press, this.this$0, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                long tapIndicationDelay = AbstractC0643w.getTapIndicationDelay();
                this.label = 1;
                if (AbstractC1476z.f(tapIndicationDelay, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.this$0.pressInteraction = this.$press;
                    return U0.n.f1521a;
                }
                AbstractC0292a.H(obj);
            }
            androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
            androidx.compose.foundation.interaction.q qVar = this.$press;
            this.label = 2;
            if (nVar.emit(qVar, this) == aVar) {
                return aVar;
            }
            this.this$0.pressInteraction = this.$press;
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((i) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$j */
    public static final class j extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ androidx.compose.foundation.interaction.q $press;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.q qVar, Y0.c cVar) {
            super(2, cVar);
            this.$interactionSource = nVar;
            this.$press = qVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new j(this.$interactionSource, this.$press, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
                androidx.compose.foundation.interaction.q qVar = this.$press;
                this.label = 1;
                if (nVar.emit(qVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((j) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$k */
    public static final class k extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.q $it;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public k(androidx.compose.foundation.interaction.q qVar, Y0.c cVar) {
            super(2, cVar);
            this.$it = qVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new k(this.$it, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = AbstractC0365b.this.interactionSource;
                if (nVar != null) {
                    androidx.compose.foundation.interaction.p pVar = new androidx.compose.foundation.interaction.p(this.$it);
                    this.label = 1;
                    if (nVar.emit(pVar, this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((k) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$l */
    public static final class l extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.q $press;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public l(androidx.compose.foundation.interaction.q qVar, Y0.c cVar) {
            super(2, cVar);
            this.$press = qVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new l(this.$press, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = AbstractC0365b.this.interactionSource;
                if (nVar != null) {
                    androidx.compose.foundation.interaction.q qVar = this.$press;
                    this.label = 1;
                    if (nVar.emit(qVar, this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((l) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$m */
    public static final class m extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.foundation.interaction.q $press;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public m(androidx.compose.foundation.interaction.q qVar, Y0.c cVar) {
            super(2, cVar);
            this.$press = qVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new m(this.$press, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = AbstractC0365b.this.interactionSource;
                if (nVar != null) {
                    androidx.compose.foundation.interaction.r rVar = new androidx.compose.foundation.interaction.r(this.$press);
                    this.label = 1;
                    if (nVar.emit(rVar, this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((m) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$n */
    public static final class n extends a1.j implements h1.e {
        int label;

        public n(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new n(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            AbstractC0365b.this.emitHoverEnter();
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((n) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.b$o */
    public static final class o extends a1.j implements h1.e {
        int label;

        public o(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return AbstractC0365b.this.new o(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            AbstractC0365b.this.emitHoverExit();
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((o) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public /* synthetic */ AbstractC0365b(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar, AbstractC1378g abstractC1378g) {
        this(nVar, y2, z2, z3, str, c1116j, aVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean applySemantics$lambda$12(AbstractC0365b abstractC0365b) {
        abstractC0365b.onClick.invoke();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean delayPressInteraction() {
        return AbstractC0641u.hasScrollableContainer(this) || AbstractC0643w.isComposeRootInScrollableContainer(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void emitHoverEnter() {
        if (this.hoverInteraction == null) {
            androidx.compose.foundation.interaction.h hVar = new androidx.compose.foundation.interaction.h();
            androidx.compose.foundation.interaction.n nVar = this.interactionSource;
            if (nVar != null) {
                AbstractC1476z.s(getCoroutineScope(), null, null, new C0023b(nVar, hVar, null), 3);
            }
            this.hoverInteraction = hVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void emitHoverExit() {
        androidx.compose.foundation.interaction.h hVar = this.hoverInteraction;
        if (hVar != null) {
            androidx.compose.foundation.interaction.i iVar = new androidx.compose.foundation.interaction.i(hVar);
            androidx.compose.foundation.interaction.n nVar = this.interactionSource;
            if (nVar != null) {
                AbstractC1476z.s(getCoroutineScope(), null, null, new c(nVar, iVar, null), 3);
            }
            this.hoverInteraction = null;
        }
    }

    private final void initializeIndicationAndInteractionSourceIfNeeded() {
        if (this.indicationNode != null) {
            return;
        }
        Y y2 = this.useLocalIndication ? this.localIndicationNodeFactory : this.indicationNodeFactory;
        if (y2 != null) {
            if (this.interactionSource == null) {
                this.interactionSource = androidx.compose.foundation.interaction.m.MutableInteractionSource();
            }
            this.focusableNode.update(this.interactionSource);
            androidx.compose.foundation.interaction.n nVar = this.interactionSource;
            kotlin.jvm.internal.o.b(nVar);
            InterfaceC1007o interfaceC1007oCreate = y2.create(nVar);
            delegate(interfaceC1007oCreate);
            this.indicationNode = interfaceC1007oCreate;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0057  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onFocusChange(boolean z2) {
        if (z2) {
            initializeIndicationAndInteractionSourceIfNeeded();
            return;
        }
        if (this.interactionSource != null) {
            C1336G c1336g = this.currentKeyPressInteractions;
            Object[] objArr = c1336g.f3080c;
            long[] jArr = c1336g.f3078a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i2 = 0;
                while (true) {
                    long j2 = jArr[i2];
                    if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i3 = 8 - ((~(i2 - length)) >>> 31);
                        for (int i4 = 0; i4 < i3; i4++) {
                            if ((255 & j2) < 128) {
                                AbstractC1476z.s(getCoroutineScope(), null, null, new k((androidx.compose.foundation.interaction.q) objArr[(i2 << 3) + i4], null), 3);
                            }
                            j2 >>= 8;
                        }
                        if (i3 != 8) {
                            break;
                        } else if (i2 == length) {
                            break;
                        } else {
                            i2++;
                        }
                    }
                }
            }
        }
        this.currentKeyPressInteractions.c();
        onCancelKeyInput();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n onObservedReadsChanged$lambda$1(AbstractC0365b abstractC0365b) {
        T t2 = (T) AbstractC1003m.currentValueOf(abstractC0365b, V.getLocalIndication());
        if (!(t2 instanceof Y)) {
            AbstractC1403e.throwIllegalArgumentException(AbstractC0641u.unsupportedIndicationExceptionMessage(t2));
        }
        Y y2 = abstractC0365b.localIndicationNodeFactory;
        Y y3 = (Y) t2;
        abstractC0365b.localIndicationNodeFactory = y3;
        if (y2 != null && !kotlin.jvm.internal.o.a(y3, y2)) {
            abstractC0365b.recreateIndicationIfNeeded();
        }
        return U0.n.f1521a;
    }

    private final void recreateIndicationIfNeeded() {
        InterfaceC1007o interfaceC1007o = this.indicationNode;
        if (interfaceC1007o == null && this.lazilyCreateIndication) {
            return;
        }
        if (interfaceC1007o != null) {
            undelegate(interfaceC1007o);
        }
        this.indicationNode = null;
        initializeIndicationAndInteractionSourceIfNeeded();
    }

    private final boolean shouldLazilyCreateIndication() {
        return this.userProvidedInteractionSource == null;
    }

    public void applyAdditionalSemantics(androidx.compose.ui.semantics.E e2) {
    }

    @Override // androidx.compose.ui.node.S0
    public final void applySemantics(androidx.compose.ui.semantics.E e2) {
        C1116j c1116j = this.role;
        if (c1116j != null) {
            androidx.compose.ui.semantics.C.m4274setRolekuIjeqM(e2, c1116j.m4291unboximpl());
        }
        androidx.compose.ui.semantics.C.onClick(e2, this.onClickLabel, new C0363a(this, 1));
        if (this.enabled) {
            this.focusableNode.applySemantics(e2);
        } else {
            androidx.compose.ui.semantics.C.disabled(e2);
        }
        applyAdditionalSemantics(e2);
    }

    public abstract androidx.compose.ui.input.pointer.Z createPointerInputNodeIfNeeded();

    /* JADX WARN: Removed duplicated region for block: B:22:0x0063  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void disposeInteractions() {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null) {
            androidx.compose.foundation.interaction.q qVar = this.pressInteraction;
            if (qVar != null) {
                nVar.tryEmit(new androidx.compose.foundation.interaction.p(qVar));
            }
            androidx.compose.foundation.interaction.h hVar = this.hoverInteraction;
            if (hVar != null) {
                nVar.tryEmit(new androidx.compose.foundation.interaction.i(hVar));
            }
            C1336G c1336g = this.currentKeyPressInteractions;
            Object[] objArr = c1336g.f3080c;
            long[] jArr = c1336g.f3078a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i2 = 0;
                while (true) {
                    long j2 = jArr[i2];
                    if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i3 = 8 - ((~(i2 - length)) >>> 31);
                        for (int i4 = 0; i4 < i3; i4++) {
                            if ((255 & j2) < 128) {
                                nVar.tryEmit(new androidx.compose.foundation.interaction.p((androidx.compose.foundation.interaction.q) objArr[(i2 << 3) + i4]));
                            }
                            j2 >>= 8;
                        }
                        if (i3 != 8) {
                            break;
                        } else if (i2 == length) {
                            break;
                        } else {
                            i2++;
                        }
                    }
                }
            }
        }
        this.pressInteraction = null;
        this.hoverInteraction = null;
        this.currentKeyPressInteractions.c();
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final h1.a getOnClick() {
        return this.onClick;
    }

    @Override // androidx.compose.ui.w
    public final boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public final boolean getShouldMergeDescendantSemantics() {
        return true;
    }

    @Override // androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    @Override // androidx.compose.ui.node.a1
    public Object getTraverseKey() {
        return this.traverseKey;
    }

    /* JADX INFO: renamed from: handlePressInteraction-d-4ec7I, reason: not valid java name */
    public final Object m708handlePressInteractiond4ec7I(androidx.compose.foundation.gestures.J j2, long j3, Y0.c cVar) {
        Object objE;
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        return (nVar == null || (objE = AbstractC1476z.e(new e(j2, j3, nVar, this, null), cVar)) != Z0.a.f1616b) ? U0.n.f1521a : objE;
    }

    public final void handlePressInteractionCancel() {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null) {
            InterfaceC1451b0 interfaceC1451b0 = this.delayJob;
            if (interfaceC1451b0 == null || !interfaceC1451b0.isActive()) {
                androidx.compose.foundation.interaction.q qVar = this.pressInteraction;
                if (qVar != null) {
                    AbstractC1476z.s(getCoroutineScope(), null, null, new f(qVar, nVar, null), 3);
                }
            } else {
                InterfaceC1451b0 interfaceC1451b02 = this.delayJob;
                if (interfaceC1451b02 != null) {
                    interfaceC1451b02.cancel(null);
                }
            }
            this.pressInteraction = null;
        }
    }

    /* JADX INFO: renamed from: handlePressInteractionRelease-k-4lQ0M, reason: not valid java name */
    public final void m709handlePressInteractionReleasek4lQ0M(long j2) {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null) {
            InterfaceC1451b0 interfaceC1451b0 = this.delayJob;
            if (interfaceC1451b0 == null || !interfaceC1451b0.isActive()) {
                androidx.compose.foundation.interaction.q qVar = this.pressInteraction;
                if (qVar != null) {
                    AbstractC1476z.s(getCoroutineScope(), null, null, new h(qVar, nVar, null), 3);
                }
            } else {
                AbstractC1476z.s(getCoroutineScope(), null, null, new g(j2, nVar, null), 3);
            }
            this.pressInteraction = null;
        }
    }

    /* JADX INFO: renamed from: handlePressInteractionStart-k-4lQ0M, reason: not valid java name */
    public final void m710handlePressInteractionStartk4lQ0M(long j2) {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null) {
            androidx.compose.foundation.interaction.q qVar = new androidx.compose.foundation.interaction.q(j2, null);
            if (delayPressInteraction()) {
                this.delayJob = AbstractC1476z.s(getCoroutineScope(), null, null, new i(nVar, qVar, this, null), 3);
            } else {
                this.pressInteraction = qVar;
                AbstractC1476z.s(getCoroutineScope(), null, null, new j(nVar, qVar, null), 3);
            }
        }
    }

    @Override // androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.ui.w
    public final void onAttach() {
        onObservedReadsChanged();
        if (!this.lazilyCreateIndication) {
            initializeIndicationAndInteractionSourceIfNeeded();
        }
        if (this.enabled) {
            delegate(this.focusableNode);
        }
    }

    public void onCancelKeyInput() {
    }

    @Override // androidx.compose.ui.node.N0
    public void onCancelPointerInput() {
        androidx.compose.foundation.interaction.h hVar;
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null && (hVar = this.hoverInteraction) != null) {
            nVar.tryEmit(new androidx.compose.foundation.interaction.i(hVar));
        }
        this.hoverInteraction = null;
        androidx.compose.ui.input.pointer.Z z2 = this.pointerInputNode;
        if (z2 != null) {
            z2.onCancelPointerInput();
        }
    }

    /* JADX INFO: renamed from: onClickKeyDownEvent-ZmokQxo, reason: not valid java name */
    public abstract boolean mo711onClickKeyDownEventZmokQxo(KeyEvent keyEvent);

    /* JADX INFO: renamed from: onClickKeyUpEvent-ZmokQxo, reason: not valid java name */
    public abstract boolean mo712onClickKeyUpEventZmokQxo(KeyEvent keyEvent);

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w
    public final void onDetach() {
        disposeInteractions();
        if (this.userProvidedInteractionSource == null) {
            this.interactionSource = null;
        }
        InterfaceC1007o interfaceC1007o = this.indicationNode;
        if (interfaceC1007o != null) {
            undelegate(interfaceC1007o);
        }
        this.indicationNode = null;
    }

    @Override // P.e
    /* JADX INFO: renamed from: onKeyEvent-ZmokQxo */
    public final boolean mo522onKeyEventZmokQxo(KeyEvent keyEvent) {
        boolean z2;
        initializeIndicationAndInteractionSourceIfNeeded();
        long jM515getKeyZmokQxo = P.d.m515getKeyZmokQxo(keyEvent);
        AbstractC1378g abstractC1378g = null;
        if (this.enabled && AbstractC0641u.m1662isPressZmokQxo(keyEvent)) {
            if (this.currentKeyPressInteractions.a(jM515getKeyZmokQxo)) {
                z2 = false;
            } else {
                androidx.compose.foundation.interaction.q qVar = new androidx.compose.foundation.interaction.q(this.centerOffset, abstractC1378g);
                this.currentKeyPressInteractions.h(jM515getKeyZmokQxo, qVar);
                if (this.interactionSource != null) {
                    AbstractC1476z.s(getCoroutineScope(), null, null, new l(qVar, null), 3);
                }
                z2 = true;
            }
            if (mo711onClickKeyDownEventZmokQxo(keyEvent) || z2) {
                return true;
            }
        } else if (this.enabled && AbstractC0641u.m1660isClickZmokQxo(keyEvent)) {
            androidx.compose.foundation.interaction.q qVar2 = (androidx.compose.foundation.interaction.q) this.currentKeyPressInteractions.g(jM515getKeyZmokQxo);
            if (qVar2 != null) {
                if (this.interactionSource != null) {
                    AbstractC1476z.s(getCoroutineScope(), null, null, new m(qVar2, null), 3);
                }
                mo712onClickKeyUpEventZmokQxo(keyEvent);
            }
            if (qVar2 != null) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.InterfaceC1029z0
    public void onObservedReadsChanged() {
        if (this.useLocalIndication) {
            androidx.compose.ui.node.A0.observeReads(this, new C0363a(this, 0));
        }
    }

    @Override // androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: onPointerEvent-H0pRuoY */
    public void mo698onPointerEventH0pRuoY(C0918p c0918p, androidx.compose.ui.input.pointer.r rVar, long j2) {
        androidx.compose.ui.input.pointer.Z zCreatePointerInputNodeIfNeeded;
        long jM5245getCenterozmzZPI = e0.t.m5245getCenterozmzZPI(j2);
        this.centerOffset = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(e0.o.m5196getXimpl(jM5245getCenterozmzZPI))) << 32) | (((long) Float.floatToRawIntBits(e0.o.m5197getYimpl(jM5245getCenterozmzZPI))) & 4294967295L));
        initializeIndicationAndInteractionSourceIfNeeded();
        if (this.enabled && rVar == androidx.compose.ui.input.pointer.r.Main) {
            int iM3767getType7fucELk = c0918p.m3767getType7fucELk();
            C0921t.a aVar = C0921t.Companion;
            if (C0921t.m3774equalsimpl0(iM3767getType7fucELk, aVar.m3778getEnter7fucELk())) {
                AbstractC1476z.s(getCoroutineScope(), null, null, new n(null), 3);
            } else if (C0921t.m3774equalsimpl0(iM3767getType7fucELk, aVar.m3779getExit7fucELk())) {
                AbstractC1476z.s(getCoroutineScope(), null, null, new o(null), 3);
            }
        }
        if (this.pointerInputNode == null && (zCreatePointerInputNodeIfNeeded = createPointerInputNodeIfNeeded()) != null) {
            this.pointerInputNode = (androidx.compose.ui.input.pointer.Z) delegate(zCreatePointerInputNodeIfNeeded);
        }
        androidx.compose.ui.input.pointer.Z z2 = this.pointerInputNode;
        if (z2 != null) {
            z2.mo698onPointerEventH0pRuoY(c0918p, rVar, j2);
        }
    }

    @Override // P.e
    /* JADX INFO: renamed from: onPreKeyEvent-ZmokQxo */
    public final boolean mo523onPreKeyEventZmokQxo(KeyEvent keyEvent) {
        return false;
    }

    @Override // androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    public final U0.n resetPointerInputHandler() {
        androidx.compose.ui.input.pointer.Z z2 = this.pointerInputNode;
        if (z2 == null) {
            return null;
        }
        z2.resetPointerInputHandler();
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0074  */
    /* JADX INFO: renamed from: updateCommon-O2vRcR0, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void m713updateCommonO2vRcR0(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar) {
        boolean z4;
        boolean z5;
        if (kotlin.jvm.internal.o.a(this.userProvidedInteractionSource, nVar)) {
            z4 = false;
        } else {
            disposeInteractions();
            this.userProvidedInteractionSource = nVar;
            this.interactionSource = nVar;
            z4 = true;
        }
        if (!kotlin.jvm.internal.o.a(this.indicationNodeFactory, y2)) {
            this.indicationNodeFactory = y2;
            z4 = true;
        }
        if (this.useLocalIndication != z2) {
            this.useLocalIndication = z2;
            if (z2) {
                onObservedReadsChanged();
            }
            z4 = true;
        }
        if (this.enabled != z3) {
            if (z3) {
                delegate(this.focusableNode);
            } else {
                undelegate(this.focusableNode);
                disposeInteractions();
            }
            T0.invalidateSemantics(this);
            this.enabled = z3;
        }
        if (!kotlin.jvm.internal.o.a(this.onClickLabel, str)) {
            this.onClickLabel = str;
            T0.invalidateSemantics(this);
        }
        if (!kotlin.jvm.internal.o.a(this.role, c1116j)) {
            this.role = c1116j;
            T0.invalidateSemantics(this);
        }
        this.onClick = aVar;
        if (this.lazilyCreateIndication != shouldLazilyCreateIndication()) {
            boolean zShouldLazilyCreateIndication = shouldLazilyCreateIndication();
            this.lazilyCreateIndication = zShouldLazilyCreateIndication;
            z5 = (zShouldLazilyCreateIndication || this.indicationNode != null) ? z4 : true;
        }
        if (z5) {
            recreateIndicationIfNeeded();
        }
        this.focusableNode.update(this.interactionSource);
    }

    private AbstractC0365b(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar) {
        this.interactionSource = nVar;
        this.indicationNodeFactory = y2;
        this.useLocalIndication = z2;
        this.onClickLabel = str;
        this.role = c1116j;
        this.enabled = z3;
        this.onClick = aVar;
        this.focusableNode = new J(this.interactionSource, androidx.compose.ui.focus.V.Companion.m2764getSystemDefinedLCbbffg(), new d(this), null);
        C1336G c1336g = AbstractC1361t.f3083a;
        this.currentKeyPressInteractions = new C1336G();
        this.centerOffset = J.f.Companion.m66getZeroF1C5BW0();
        this.userProvidedInteractionSource = this.interactionSource;
        this.lazilyCreateIndication = shouldLazilyCreateIndication();
        this.traverseKey = TraverseKey;
    }
}
