package androidx.compose.foundation;

import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class BackgroundElement extends AbstractC1000k0 {
    private final float alpha;
    private final androidx.compose.ui.graphics.P brush;
    private final long color;
    private final h1.c inspectorInfo;
    private final j1 shape;

    public /* synthetic */ BackgroundElement(long j2, androidx.compose.ui.graphics.P p2, float f2, j1 j1Var, h1.c cVar, AbstractC1378g abstractC1378g) {
        this(j2, p2, f2, j1Var, cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        BackgroundElement backgroundElement = obj instanceof BackgroundElement ? (BackgroundElement) obj : null;
        return backgroundElement != null && androidx.compose.ui.graphics.Y.m3021equalsimpl0(this.color, backgroundElement.color) && kotlin.jvm.internal.o.a(this.brush, backgroundElement.brush) && this.alpha == backgroundElement.alpha && kotlin.jvm.internal.o.a(this.shape, backgroundElement.shape);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        int iM3027hashCodeimpl = androidx.compose.ui.graphics.Y.m3027hashCodeimpl(this.color) * 31;
        androidx.compose.ui.graphics.P p2 = this.brush;
        return this.shape.hashCode() + D0.d.a(this.alpha, (iM3027hashCodeimpl + (p2 != null ? p2.hashCode() : 0)) * 31, 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public /* synthetic */ BackgroundElement(long j2, androidx.compose.ui.graphics.P p2, float f2, j1 j1Var, h1.c cVar, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? androidx.compose.ui.graphics.Y.Companion.m3056getUnspecified0d7_KjU() : j2, (i2 & 2) != 0 ? null : p2, f2, j1Var, cVar, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0402h create() {
        return new C0402h(this.color, this.brush, this.alpha, this.shape, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0402h c0402h) {
        c0402h.m885setColor8_81llA(this.color);
        c0402h.setBrush(this.brush);
        c0402h.setAlpha(this.alpha);
        c0402h.setShape(this.shape);
        androidx.compose.ui.node.B.invalidateDraw(c0402h);
    }

    private BackgroundElement(long j2, androidx.compose.ui.graphics.P p2, float f2, j1 j1Var, h1.c cVar) {
        this.color = j2;
        this.brush = p2;
        this.alpha = f2;
        this.shape = j1Var;
        this.inspectorInfo = cVar;
    }
}
