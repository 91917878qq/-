package androidx.compose.foundation;

import O0.C0218m;
import androidx.compose.ui.graphics.AbstractC0897x0;
import androidx.compose.ui.graphics.C0895w0;
import androidx.compose.ui.graphics.E0;
import androidx.compose.ui.graphics.InterfaceC0892v0;
import androidx.compose.ui.graphics.K;
import androidx.compose.ui.graphics.K0;
import androidx.compose.ui.graphics.R0;
import androidx.compose.ui.graphics.Z;
import androidx.compose.ui.graphics.drawscope.a;
import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.graphics.l1;
import androidx.compose.ui.node.S0;
import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0501n extends androidx.compose.ui.node.r implements S0 {
    public static final int $stable = 8;
    private C0404i borderCache;
    private androidx.compose.ui.graphics.P brush;
    private final androidx.compose.ui.draw.e drawWithCacheModifierNode;
    private final boolean isImportantForBounds;
    private j1 shape;
    private final boolean shouldAutoInvalidate;
    private float width;

    public /* synthetic */ C0501n(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var, AbstractC1378g abstractC1378g) {
        this(f2, p2, j1Var);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0104  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final androidx.compose.ui.draw.l drawGenericBorder(androidx.compose.ui.draw.g gVar, androidx.compose.ui.graphics.P p2, E0.a aVar, boolean z2, float f2) throws Throwable {
        int iM3601getArgb8888_sVssgQ;
        androidx.compose.ui.graphics.Z zM3061tintxETnrds$default;
        androidx.compose.ui.graphics.S s2;
        InterfaceC0892v0 interfaceC0892v0;
        float f3;
        long j2;
        androidx.compose.ui.graphics.drawscope.d dVar;
        if (z2) {
            return gVar.onDrawWithContent(new M0.m(12, aVar, p2));
        }
        if (p2 instanceof l1) {
            iM3601getArgb8888_sVssgQ = C0895w0.Companion.m3600getAlpha8_sVssgQ();
            zM3061tintxETnrds$default = Z.a.m3061tintxETnrds$default(androidx.compose.ui.graphics.Z.Companion, androidx.compose.ui.graphics.Y.m3019copywmQWz5c$default(((l1) p2).m3309getValue0d7_KjU(), 1.0f, 0.0f, 0.0f, 0.0f, 14, null), 0, 2, null);
        } else {
            iM3601getArgb8888_sVssgQ = C0895w0.Companion.m3601getArgb8888_sVssgQ();
            zM3061tintxETnrds$default = null;
        }
        J.h bounds = aVar.getPath().getBounds();
        if (this.borderCache == null) {
            this.borderCache = new C0404i(null, null, null, null, 15, null);
        }
        C0404i c0404i = this.borderCache;
        kotlin.jvm.internal.o.b(c0404i);
        K0 k0ObtainPath = c0404i.obtainPath();
        k0ObtainPath.reset();
        K0.addRect$default(k0ObtainPath, bounds, null, 2, null);
        k0ObtainPath.mo2921opN5in7k0(k0ObtainPath, aVar.getPath(), R0.Companion.m2969getDifferenceb3I0S0c());
        kotlin.jvm.internal.E e2 = new kotlin.jvm.internal.E();
        long jM5234constructorimpl = e0.s.m5234constructorimpl((((long) ((int) Math.ceil(bounds.getBottom() - bounds.getTop()))) & 4294967295L) | (((long) ((int) Math.ceil(bounds.getRight() - bounds.getLeft()))) << 32));
        C0404i c0404i2 = this.borderCache;
        kotlin.jvm.internal.o.b(c0404i2);
        InterfaceC0892v0 interfaceC0892v02 = c0404i2.imageBitmap;
        androidx.compose.ui.graphics.S s3 = c0404i2.canvas;
        C0895w0 c0895w0M3593boximpl = interfaceC0892v02 != null ? C0895w0.m3593boximpl(interfaceC0892v02.mo3286getConfig_sVssgQ()) : null;
        boolean z3 = false;
        if (c0895w0M3593boximpl == null ? false : C0895w0.m3596equalsimpl0(c0895w0M3593boximpl.m3599unboximpl(), C0895w0.Companion.m3601getArgb8888_sVssgQ())) {
            z3 = true;
        } else {
            if (C0895w0.m3595equalsimpl(iM3601getArgb8888_sVssgQ, interfaceC0892v02 != null ? C0895w0.m3593boximpl(interfaceC0892v02.mo3286getConfig_sVssgQ()) : null)) {
            }
        }
        if (interfaceC0892v02 == null || s3 == null || Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() >> 32)) > interfaceC0892v02.getWidth() || Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() & 4294967295L)) > interfaceC0892v02.getHeight() || !z3) {
            InterfaceC0892v0 interfaceC0892v0M3607ImageBitmapx__hDU$default = AbstractC0897x0.m3607ImageBitmapx__hDU$default((int) (jM5234constructorimpl >> 32), (int) (jM5234constructorimpl & 4294967295L), iM3601getArgb8888_sVssgQ, false, null, 24, null);
            c0404i2.imageBitmap = interfaceC0892v0M3607ImageBitmapx__hDU$default;
            androidx.compose.ui.graphics.S sCanvas = androidx.compose.ui.graphics.U.Canvas(interfaceC0892v0M3607ImageBitmapx__hDU$default);
            c0404i2.canvas = sCanvas;
            s2 = sCanvas;
            interfaceC0892v0 = interfaceC0892v0M3607ImageBitmapx__hDU$default;
        } else {
            interfaceC0892v0 = interfaceC0892v02;
            s2 = s3;
        }
        androidx.compose.ui.graphics.drawscope.a aVar2 = c0404i2.canvasDrawScope;
        if (aVar2 == null) {
            aVar2 = new androidx.compose.ui.graphics.drawscope.a();
            c0404i2.canvasDrawScope = aVar2;
        }
        androidx.compose.ui.graphics.drawscope.a aVar3 = aVar2;
        long jM5251toSizeozmzZPI = e0.t.m5251toSizeozmzZPI(jM5234constructorimpl);
        e0.u layoutDirection = gVar.getLayoutDirection();
        a.C0130a drawParams = aVar3.getDrawParams();
        InterfaceC1307d interfaceC1307dComponent1 = drawParams.component1();
        e0.u uVarComponent2 = drawParams.component2();
        androidx.compose.ui.graphics.S sComponent3 = drawParams.component3();
        long jM3175component4NHjbRc = drawParams.m3175component4NHjbRc();
        a.C0130a drawParams2 = aVar3.getDrawParams();
        drawParams2.setDensity(gVar);
        drawParams2.setLayoutDirection(layoutDirection);
        drawParams2.setCanvas(s2);
        drawParams2.m3178setSizeuvyYCjk(jM5251toSizeozmzZPI);
        s2.save();
        long jM3046getBlack0d7_KjU = androidx.compose.ui.graphics.Y.Companion.m3046getBlack0d7_KjU();
        K.a aVar4 = androidx.compose.ui.graphics.K.Companion;
        androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(aVar3, jM3046getBlack0d7_KjU, 0L, jM5251toSizeozmzZPI, 0.0f, null, null, aVar4.m2888getClear0nO6VwU(), 58, null);
        float f4 = -bounds.getLeft();
        float f5 = -bounds.getTop();
        aVar3.getDrawContext().getTransform().translate(f4, f5);
        try {
            try {
                androidx.compose.ui.graphics.drawscope.g.m3233drawPathGBMwjPU$default(aVar3, aVar.getPath(), p2, 0.0f, new androidx.compose.ui.graphics.drawscope.l(f2 * 2, 0.0f, 0, 0, null, 30, null), null, 0, 52, null);
                float f6 = 1;
                float fIntBitsToFloat = (Float.intBitsToFloat((int) (aVar3.mo3172getSizeNHjbRc() >> 32)) + f6) / Float.intBitsToFloat((int) (aVar3.mo3172getSizeNHjbRc() >> 32));
                float fIntBitsToFloat2 = (Float.intBitsToFloat((int) (aVar3.mo3172getSizeNHjbRc() & 4294967295L)) + f6) / Float.intBitsToFloat((int) (aVar3.mo3172getSizeNHjbRc() & 4294967295L));
                long jMo3171getCenterF1C5BW0 = aVar3.mo3171getCenterF1C5BW0();
                androidx.compose.ui.graphics.drawscope.d drawContext = aVar3.getDrawContext();
                long jMo3179getSizeNHjbRc = drawContext.mo3179getSizeNHjbRc();
                drawContext.getCanvas().save();
                try {
                    drawContext.getTransform().mo3186scale0AR0LA0(fIntBitsToFloat, fIntBitsToFloat2, jMo3171getCenterF1C5BW0);
                    dVar = drawContext;
                } catch (Throwable th) {
                    th = th;
                    j2 = jMo3179getSizeNHjbRc;
                    dVar = drawContext;
                    f5 = f5;
                    f3 = f4;
                }
                try {
                    androidx.compose.ui.graphics.drawscope.g.m3233drawPathGBMwjPU$default(aVar3, k0ObtainPath, p2, 0.0f, null, null, aVar4.m2888getClear0nO6VwU(), 28, null);
                    dVar.getCanvas().restore();
                    dVar.mo3180setSizeuvyYCjk(jMo3179getSizeNHjbRc);
                    aVar3.getDrawContext().getTransform().translate(-f4, -f5);
                    s2.restore();
                    a.C0130a drawParams3 = aVar3.getDrawParams();
                    drawParams3.setDensity(interfaceC1307dComponent1);
                    drawParams3.setLayoutDirection(uVarComponent2);
                    drawParams3.setCanvas(sComponent3);
                    drawParams3.m3178setSizeuvyYCjk(jM3175component4NHjbRc);
                    interfaceC0892v0.prepareToDraw();
                    e2.f3118b = interfaceC0892v0;
                    return gVar.onDrawWithContent(new C0500m(bounds, e2, jM5234constructorimpl, zM3061tintxETnrds$default));
                } catch (Throwable th2) {
                    th = th2;
                    f5 = f5;
                    f3 = f4;
                    j2 = jMo3179getSizeNHjbRc;
                    try {
                        dVar.getCanvas().restore();
                        dVar.mo3180setSizeuvyYCjk(j2);
                        throw th;
                    } catch (Throwable th3) {
                        th = th3;
                        aVar3.getDrawContext().getTransform().translate(-f3, -f5);
                        throw th;
                    }
                }
            } catch (Throwable th4) {
                th = th4;
                f5 = f5;
                f3 = f4;
            }
        } catch (Throwable th5) {
            th = th5;
            f3 = f4;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawGenericBorder$lambda$1(E0.a aVar, androidx.compose.ui.graphics.P p2, androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        androidx.compose.ui.graphics.drawscope.g.m3233drawPathGBMwjPU$default(cVar, aVar.getPath(), p2, 0.0f, null, null, 0, 60, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawGenericBorder$lambda$8(J.h hVar, kotlin.jvm.internal.E e2, long j2, androidx.compose.ui.graphics.Z z2, androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        float left = hVar.getLeft();
        float top = hVar.getTop();
        cVar.getDrawContext().getTransform().translate(left, top);
        try {
            androidx.compose.ui.graphics.drawscope.g.m3227drawImageAZ2fEMs$default(cVar, (InterfaceC0892v0) e2.f3118b, 0L, j2, 0L, 0L, 0.0f, null, z2, 0, 0, 890, null);
            cVar.getDrawContext().getTransform().translate(-left, -top);
            return U0.n.f1521a;
        } catch (Throwable th) {
            cVar.getDrawContext().getTransform().translate(-left, -top);
            throw th;
        }
    }

    /* JADX INFO: renamed from: drawRoundRectBorder-JqoCqck, reason: not valid java name */
    private final androidx.compose.ui.draw.l m1115drawRoundRectBorderJqoCqck(androidx.compose.ui.draw.g gVar, final androidx.compose.ui.graphics.P p2, E0.c cVar, final long j2, final long j3, final boolean z2, final float f2) {
        if (J.k.isSimple(cVar.getRoundRect())) {
            final long jM100getTopLeftCornerRadiuskKHJgLs = cVar.getRoundRect().m100getTopLeftCornerRadiuskKHJgLs();
            final float f3 = f2 / 2;
            final androidx.compose.ui.graphics.drawscope.l lVar = new androidx.compose.ui.graphics.drawscope.l(f2, 0.0f, 0, 0, null, 30, null);
            return gVar.onDrawWithContent(new h1.c() { // from class: androidx.compose.foundation.l
                @Override // h1.c
                public final Object invoke(Object obj) {
                    long j4 = j2;
                    long j5 = j3;
                    return C0501n.drawRoundRectBorder_JqoCqck$lambda$10(z2, p2, jM100getTopLeftCornerRadiuskKHJgLs, f3, f2, j4, j5, lVar, (androidx.compose.ui.graphics.drawscope.c) obj);
                }
            });
        }
        if (this.borderCache == null) {
            this.borderCache = new C0404i(null, null, null, null, 15, null);
        }
        C0404i c0404i = this.borderCache;
        kotlin.jvm.internal.o.b(c0404i);
        return gVar.onDrawWithContent(new M0.m(11, AbstractC0406k.createRoundRectPath(c0404i.obtainPath(), cVar.getRoundRect(), f2, z2), p2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawRoundRectBorder_JqoCqck$lambda$10(boolean z2, androidx.compose.ui.graphics.P p2, long j2, float f2, float f3, long j3, long j4, androidx.compose.ui.graphics.drawscope.l lVar, androidx.compose.ui.graphics.drawscope.c cVar) throws Throwable {
        long j5;
        cVar.drawContent();
        if (z2) {
            androidx.compose.ui.graphics.drawscope.g.m3239drawRoundRectZuiqVtQ$default(cVar, p2, 0L, 0L, j2, 0.0f, null, null, 0, 246, null);
        } else if (Float.intBitsToFloat((int) (j2 >> 32)) < f2) {
            float fIntBitsToFloat = Float.intBitsToFloat((int) (cVar.mo3172getSizeNHjbRc() >> 32)) - f3;
            float fIntBitsToFloat2 = Float.intBitsToFloat((int) (cVar.mo3172getSizeNHjbRc() & 4294967295L)) - f3;
            int iM3008getDifferencertfAjoo = androidx.compose.ui.graphics.X.Companion.m3008getDifferencertfAjoo();
            androidx.compose.ui.graphics.drawscope.d drawContext = cVar.getDrawContext();
            long jMo3179getSizeNHjbRc = drawContext.mo3179getSizeNHjbRc();
            drawContext.getCanvas().save();
            try {
                drawContext.getTransform().mo3182clipRectN_I0leg(f3, f3, fIntBitsToFloat, fIntBitsToFloat2, iM3008getDifferencertfAjoo);
                try {
                    androidx.compose.ui.graphics.drawscope.g.m3239drawRoundRectZuiqVtQ$default(cVar, p2, 0L, 0L, j2, 0.0f, null, null, 0, 246, null);
                    D0.d.y(drawContext, jMo3179getSizeNHjbRc);
                } catch (Throwable th) {
                    th = th;
                    j5 = jMo3179getSizeNHjbRc;
                    D0.d.y(drawContext, j5);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                j5 = jMo3179getSizeNHjbRc;
            }
        } else {
            androidx.compose.ui.graphics.drawscope.g.m3239drawRoundRectZuiqVtQ$default(cVar, p2, j3, j4, AbstractC0406k.m894shrinkKibmq7A(j2, f2), 0.0f, lVar, null, 0, 208, null);
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawRoundRectBorder_JqoCqck$lambda$11(K0 k0, androidx.compose.ui.graphics.P p2, androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        androidx.compose.ui.graphics.drawscope.g.m3233drawPathGBMwjPU$default(cVar, k0, p2, 0.0f, null, null, 0, 60, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.ui.draw.l drawWithCacheModifierNode$lambda$0(C0501n c0501n, androidx.compose.ui.draw.g gVar) {
        if (gVar.mo788toPx0680j_4(c0501n.width) < 0.0f || J.l.m118getMinDimensionimpl(gVar.m2677getSizeNHjbRc()) <= 0.0f) {
            return AbstractC0406k.drawContentWithoutBorder(gVar);
        }
        float f2 = 2;
        float fMin = Math.min(C1311h.m5081equalsimpl0(c0501n.width, C1311h.Companion.m5094getHairlineD9Ej5fM()) ? 1.0f : (float) Math.ceil(gVar.mo788toPx0680j_4(c0501n.width)), (float) Math.ceil(J.l.m118getMinDimensionimpl(gVar.m2677getSizeNHjbRc()) / f2));
        float f3 = fMin / f2;
        long jM42constructorimpl = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(f3)) << 32) | (((long) Float.floatToRawIntBits(f3)) & 4294967295L));
        long jM110constructorimpl = J.l.m110constructorimpl((((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() & 4294967295L)) - fMin)) & 4294967295L) | (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() >> 32)) - fMin)) << 32));
        boolean z2 = f2 * fMin > J.l.m118getMinDimensionimpl(gVar.m2677getSizeNHjbRc());
        androidx.compose.ui.graphics.E0 e0Mo693createOutlinePq9zytI = c0501n.shape.mo693createOutlinePq9zytI(gVar.m2677getSizeNHjbRc(), gVar.getLayoutDirection(), gVar);
        if (e0Mo693createOutlinePq9zytI instanceof E0.a) {
            return c0501n.drawGenericBorder(gVar, c0501n.brush, (E0.a) e0Mo693createOutlinePq9zytI, z2, fMin);
        }
        if (e0Mo693createOutlinePq9zytI instanceof E0.c) {
            return c0501n.m1115drawRoundRectBorderJqoCqck(gVar, c0501n.brush, (E0.c) e0Mo693createOutlinePq9zytI, jM42constructorimpl, jM110constructorimpl, z2, fMin);
        }
        if (e0Mo693createOutlinePq9zytI instanceof E0.b) {
            return AbstractC0406k.m893drawRectBorderNsqcLGU(gVar, c0501n.brush, jM42constructorimpl, jM110constructorimpl, z2, fMin);
        }
        throw new H0.c();
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
    }

    public final androidx.compose.ui.graphics.P getBrush() {
        return this.brush;
    }

    public final j1 getShape() {
        return this.shape;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    /* JADX INFO: renamed from: getWidth-D9Ej5fM, reason: not valid java name */
    public final float m1116getWidthD9Ej5fM() {
        return this.width;
    }

    @Override // androidx.compose.ui.node.S0
    public boolean isImportantForBounds() {
        return this.isImportantForBounds;
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setBrush(androidx.compose.ui.graphics.P p2) {
        if (kotlin.jvm.internal.o.a(this.brush, p2)) {
            return;
        }
        this.brush = p2;
        this.drawWithCacheModifierNode.invalidateDrawCache();
    }

    public final void setShape(j1 j1Var) {
        if (kotlin.jvm.internal.o.a(this.shape, j1Var)) {
            return;
        }
        this.shape = j1Var;
        this.drawWithCacheModifierNode.invalidateDrawCache();
    }

    /* JADX INFO: renamed from: setWidth-0680j_4, reason: not valid java name */
    public final void m1117setWidth0680j_4(float f2) {
        if (C1311h.m5081equalsimpl0(this.width, f2)) {
            return;
        }
        this.width = f2;
        this.drawWithCacheModifierNode.invalidateDrawCache();
    }

    private C0501n(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var) {
        this.width = f2;
        this.brush = p2;
        this.shape = j1Var;
        this.drawWithCacheModifierNode = (androidx.compose.ui.draw.e) delegate(androidx.compose.ui.draw.k.CacheDrawModifierNode(new C0218m(this, 4)));
    }
}
