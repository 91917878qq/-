package androidx.compose.foundation;

import J.f;
import a.AbstractC0292a;
import android.content.Context;
import android.os.Build;
import android.widget.EdgeEffect;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.runtime.Q1;
import androidx.compose.ui.graphics.AbstractC0851a0;
import androidx.compose.ui.input.pointer.InterfaceC0905c;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.node.InterfaceC1007o;
import e0.AbstractC1303A;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0367c implements i0 {
    public static final int $stable = 0;
    private long containerSize;
    private final InterfaceC1307d density;
    private final G edgeEffectWrapper;
    private boolean invalidationEnabled;
    private final InterfaceC1007o node;
    private long pointerId;
    private final androidx.compose.ui.input.pointer.Z pointerInputNode;
    private long pointerPosition;
    private final androidx.compose.runtime.B0 redrawSignal;
    private boolean scrollCycleInProgress;

    /* JADX INFO: renamed from: androidx.compose.foundation.c$a */
    public static final class a extends a1.c {
        long J$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return C0367c.this.mo694applyToFlingBMRW4eQ(0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.c$b */
    public static final class b implements PointerInputEventHandler {

        /* JADX INFO: renamed from: androidx.compose.foundation.c$b$a */
        public static final class a extends a1.i implements h1.e {
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0367c this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(C0367c c0367c, Y0.c cVar) {
                super(cVar);
                this.this$0 = c0367c;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.this$0, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
                return ((a) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
            }

            /* JADX WARN: Removed duplicated region for block: B:16:0x005c A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:19:0x0074  */
            /* JADX WARN: Removed duplicated region for block: B:25:0x008f  */
            /* JADX WARN: Removed duplicated region for block: B:32:0x00ad  */
            /* JADX WARN: Removed duplicated region for block: B:34:0x00b6  */
            /* JADX WARN: Removed duplicated region for block: B:37:0x00ce  */
            /* JADX WARN: Removed duplicated region for block: B:42:0x00a8 A[SYNTHETIC] */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:15:0x005a -> B:17:0x005d). Please report as a decompilation issue!!! */
            /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
                	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r14) {
                /*
                    Method dump skipped, instruction units count: 220
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.C0367c.b.a.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        public b() {
        }

        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
        public final Object invoke(androidx.compose.ui.input.pointer.L l2, Y0.c cVar) {
            Object objAwaitEachGesture = androidx.compose.foundation.gestures.A.awaitEachGesture(l2, new a(C0367c.this, null), cVar);
            return objAwaitEachGesture == Z0.a.f1616b ? objAwaitEachGesture : U0.n.f1521a;
        }
    }

    public /* synthetic */ C0367c(Context context, InterfaceC1307d interfaceC1307d, long j2, InterfaceC0421g0 interfaceC0421g0, AbstractC1378g abstractC1378g) {
        this(context, interfaceC1307d, j2, interfaceC0421g0);
    }

    private final void animateToReleaseIfNeeded() {
        boolean z2;
        G g2 = this.edgeEffectWrapper;
        EdgeEffect edgeEffect = g2.topEffect;
        boolean z3 = true;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = !edgeEffect.isFinished();
        } else {
            z2 = false;
        }
        EdgeEffect edgeEffect2 = g2.bottomEffect;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 = !edgeEffect2.isFinished() || z2;
        }
        EdgeEffect edgeEffect3 = g2.leftEffect;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 = !edgeEffect3.isFinished() || z2;
        }
        EdgeEffect edgeEffect4 = g2.rightEffect;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            if (edgeEffect4.isFinished() && !z2) {
                z3 = false;
            }
            z2 = z3;
        }
        if (z2) {
            invalidateOverscroll$foundation_release();
        }
    }

    public static /* synthetic */ void getInvalidationEnabled$foundation_release$annotations() {
    }

    /* JADX INFO: renamed from: pullBottom-k-4lQ0M, reason: not valid java name */
    private final float m718pullBottomk4lQ0M(long j2) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (m723displacementF1C5BW0$foundation_release() >> 32));
        int i2 = (int) (j2 & 4294967295L);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i2) / Float.intBitsToFloat((int) (this.containerSize & 4294967295L));
        EdgeEffect orCreateBottomEffect = this.edgeEffectWrapper.getOrCreateBottomEffect();
        E e2 = E.INSTANCE;
        return e2.getDistanceCompat(orCreateBottomEffect) == 0.0f ? Float.intBitsToFloat((int) (this.containerSize & 4294967295L)) * (-e2.onPullDistanceCompat(orCreateBottomEffect, -fIntBitsToFloat2, 1 - fIntBitsToFloat)) : Float.intBitsToFloat(i2);
    }

    /* JADX INFO: renamed from: pullLeft-k-4lQ0M, reason: not valid java name */
    private final float m719pullLeftk4lQ0M(long j2) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (m723displacementF1C5BW0$foundation_release() & 4294967295L));
        int i2 = (int) (j2 >> 32);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i2) / Float.intBitsToFloat((int) (this.containerSize >> 32));
        EdgeEffect orCreateLeftEffect = this.edgeEffectWrapper.getOrCreateLeftEffect();
        E e2 = E.INSTANCE;
        return e2.getDistanceCompat(orCreateLeftEffect) == 0.0f ? Float.intBitsToFloat((int) (this.containerSize >> 32)) * e2.onPullDistanceCompat(orCreateLeftEffect, fIntBitsToFloat2, 1 - fIntBitsToFloat) : Float.intBitsToFloat(i2);
    }

    /* JADX INFO: renamed from: pullRight-k-4lQ0M, reason: not valid java name */
    private final float m720pullRightk4lQ0M(long j2) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (m723displacementF1C5BW0$foundation_release() & 4294967295L));
        int i2 = (int) (j2 >> 32);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i2) / Float.intBitsToFloat((int) (this.containerSize >> 32));
        EdgeEffect orCreateRightEffect = this.edgeEffectWrapper.getOrCreateRightEffect();
        E e2 = E.INSTANCE;
        return e2.getDistanceCompat(orCreateRightEffect) == 0.0f ? Float.intBitsToFloat((int) (this.containerSize >> 32)) * (-e2.onPullDistanceCompat(orCreateRightEffect, -fIntBitsToFloat2, fIntBitsToFloat)) : Float.intBitsToFloat(i2);
    }

    /* JADX INFO: renamed from: pullTop-k-4lQ0M, reason: not valid java name */
    private final float m721pullTopk4lQ0M(long j2) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (m723displacementF1C5BW0$foundation_release() >> 32));
        int i2 = (int) (j2 & 4294967295L);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i2) / Float.intBitsToFloat((int) (this.containerSize & 4294967295L));
        EdgeEffect orCreateTopEffect = this.edgeEffectWrapper.getOrCreateTopEffect();
        E e2 = E.INSTANCE;
        return e2.getDistanceCompat(orCreateTopEffect) == 0.0f ? Float.intBitsToFloat((int) (this.containerSize & 4294967295L)) * e2.onPullDistanceCompat(orCreateTopEffect, fIntBitsToFloat2, fIntBitsToFloat) : Float.intBitsToFloat(i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x002d  */
    /* JADX INFO: renamed from: releaseOppositeOverscroll-k-4lQ0M, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final boolean m722releaseOppositeOverscrollk4lQ0M(long j2) {
        boolean zIsLeftAnimating;
        if (this.edgeEffectWrapper.isLeftAnimating()) {
            int i2 = (int) (j2 >> 32);
            if (Float.intBitsToFloat(i2) < 0.0f) {
                E.INSTANCE.onReleaseWithOppositeDelta(this.edgeEffectWrapper.getOrCreateLeftEffect(), Float.intBitsToFloat(i2));
                zIsLeftAnimating = this.edgeEffectWrapper.isLeftAnimating();
            } else {
                zIsLeftAnimating = false;
            }
        }
        if (this.edgeEffectWrapper.isRightAnimating()) {
            int i3 = (int) (j2 >> 32);
            if (Float.intBitsToFloat(i3) > 0.0f) {
                E.INSTANCE.onReleaseWithOppositeDelta(this.edgeEffectWrapper.getOrCreateRightEffect(), Float.intBitsToFloat(i3));
                zIsLeftAnimating = zIsLeftAnimating || this.edgeEffectWrapper.isRightAnimating();
            }
        }
        if (this.edgeEffectWrapper.isTopAnimating()) {
            int i4 = (int) (j2 & 4294967295L);
            if (Float.intBitsToFloat(i4) < 0.0f) {
                E.INSTANCE.onReleaseWithOppositeDelta(this.edgeEffectWrapper.getOrCreateTopEffect(), Float.intBitsToFloat(i4));
                zIsLeftAnimating = zIsLeftAnimating || this.edgeEffectWrapper.isTopAnimating();
            }
        }
        if (!this.edgeEffectWrapper.isBottomAnimating()) {
            return zIsLeftAnimating;
        }
        int i5 = (int) (j2 & 4294967295L);
        if (Float.intBitsToFloat(i5) <= 0.0f) {
            return zIsLeftAnimating;
        }
        E.INSTANCE.onReleaseWithOppositeDelta(this.edgeEffectWrapper.getOrCreateBottomEffect(), Float.intBitsToFloat(i5));
        return zIsLeftAnimating || this.edgeEffectWrapper.isBottomAnimating();
    }

    /* JADX WARN: Removed duplicated region for block: B:53:0x0151  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0189  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0018  */
    @Override // androidx.compose.foundation.i0
    /* JADX INFO: renamed from: applyToFling-BMRW4eQ */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object mo694applyToFlingBMRW4eQ(long j2, h1.e eVar, Y0.c cVar) {
        a aVar;
        long j3;
        long jM5309minusAH228Gc;
        if (cVar instanceof a) {
            aVar = (a) cVar;
            int i2 = aVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                aVar.label = i2 - Integer.MIN_VALUE;
            } else {
                aVar = new a(cVar);
            }
        }
        Object objInvoke = aVar.result;
        Object obj = Z0.a.f1616b;
        int i3 = aVar.label;
        U0.n nVar = U0.n.f1521a;
        if (i3 != 0) {
            if (i3 == 1) {
                AbstractC0292a.H(objInvoke);
            }
            if (i3 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            j3 = aVar.J$0;
            AbstractC0292a.H(objInvoke);
            jM5309minusAH228Gc = e0.z.m5309minusAH228Gc(j3, ((e0.z) objInvoke).m5315unboximpl());
            this.scrollCycleInProgress = false;
            if (e0.z.m5306getXimpl(jM5309minusAH228Gc) <= 0.0f) {
                E.INSTANCE.onAbsorbCompat(this.edgeEffectWrapper.getOrCreateLeftEffect(), j1.a.T(e0.z.m5306getXimpl(jM5309minusAH228Gc)));
            } else if (e0.z.m5306getXimpl(jM5309minusAH228Gc) < 0.0f) {
                E.INSTANCE.onAbsorbCompat(this.edgeEffectWrapper.getOrCreateRightEffect(), -j1.a.T(e0.z.m5306getXimpl(jM5309minusAH228Gc)));
            }
            if (e0.z.m5307getYimpl(jM5309minusAH228Gc) <= 0.0f) {
                E.INSTANCE.onAbsorbCompat(this.edgeEffectWrapper.getOrCreateTopEffect(), j1.a.T(e0.z.m5307getYimpl(jM5309minusAH228Gc)));
            } else if (e0.z.m5307getYimpl(jM5309minusAH228Gc) < 0.0f) {
                E.INSTANCE.onAbsorbCompat(this.edgeEffectWrapper.getOrCreateBottomEffect(), -j1.a.T(e0.z.m5307getYimpl(jM5309minusAH228Gc)));
            }
            animateToReleaseIfNeeded();
            return nVar;
        }
        AbstractC0292a.H(objInvoke);
        if (J.l.m121isEmptyimpl(this.containerSize)) {
            Object objM5297boximpl = e0.z.m5297boximpl(j2);
            aVar.label = 1;
            return eVar.invoke(objM5297boximpl, aVar) == obj ? obj : nVar;
        }
        long jVelocity = AbstractC1303A.Velocity((!this.edgeEffectWrapper.isLeftStretched() || e0.z.m5306getXimpl(j2) >= 0.0f) ? (!this.edgeEffectWrapper.isRightStretched() || e0.z.m5306getXimpl(j2) <= 0.0f) ? 0.0f : -E.INSTANCE.absorbToRelaxIfNeeded(this.edgeEffectWrapper.getOrCreateRightEffect(), -e0.z.m5306getXimpl(j2), Float.intBitsToFloat((int) (this.containerSize >> 32)), this.density) : E.INSTANCE.absorbToRelaxIfNeeded(this.edgeEffectWrapper.getOrCreateLeftEffect(), e0.z.m5306getXimpl(j2), Float.intBitsToFloat((int) (this.containerSize >> 32)), this.density), (!this.edgeEffectWrapper.isTopStretched() || e0.z.m5307getYimpl(j2) >= 0.0f) ? (!this.edgeEffectWrapper.isBottomStretched() || e0.z.m5307getYimpl(j2) <= 0.0f) ? 0.0f : -E.INSTANCE.absorbToRelaxIfNeeded(this.edgeEffectWrapper.getOrCreateBottomEffect(), -e0.z.m5307getYimpl(j2), Float.intBitsToFloat((int) (4294967295L & this.containerSize)), this.density) : E.INSTANCE.absorbToRelaxIfNeeded(this.edgeEffectWrapper.getOrCreateTopEffect(), e0.z.m5307getYimpl(j2), Float.intBitsToFloat((int) (4294967295L & this.containerSize)), this.density));
        if (!e0.z.m5305equalsimpl0(jVelocity, e0.z.Companion.m5317getZero9UxMQ8M())) {
            invalidateOverscroll$foundation_release();
        }
        long jM5309minusAH228Gc2 = e0.z.m5309minusAH228Gc(j2, jVelocity);
        Object objM5297boximpl2 = e0.z.m5297boximpl(jM5309minusAH228Gc2);
        aVar.J$0 = jM5309minusAH228Gc2;
        aVar.label = 2;
        objInvoke = eVar.invoke(objM5297boximpl2, aVar);
        if (objInvoke == obj) {
            return obj;
        }
        j3 = jM5309minusAH228Gc2;
        jM5309minusAH228Gc = e0.z.m5309minusAH228Gc(j3, ((e0.z) objInvoke).m5315unboximpl());
        this.scrollCycleInProgress = false;
        if (e0.z.m5306getXimpl(jM5309minusAH228Gc) <= 0.0f) {
        }
        if (e0.z.m5307getYimpl(jM5309minusAH228Gc) <= 0.0f) {
        }
        animateToReleaseIfNeeded();
        return nVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:106:0x023a  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x023f  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x024e A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0252  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x025d  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x0269  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00b8 A[PHI: r11
  0x00b8: PHI (r11v9 float) = (r11v8 float), (r11v12 float) binds: [B:43:0x00e9, B:32:0x00b1] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0132 A[PHI: r14
  0x0132: PHI (r14v9 float) = (r14v8 float), (r14v12 float) binds: [B:67:0x0162, B:56:0x012b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0207  */
    @Override // androidx.compose.foundation.i0
    /* JADX INFO: renamed from: applyToScroll-Rhakbz0 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public long mo695applyToScrollRhakbz0(long j2, int i2, h1.c cVar) {
        float fM718pullBottomk4lQ0M;
        float fIntBitsToFloat;
        float fM720pullRightk4lQ0M;
        float fIntBitsToFloat2;
        char c2;
        boolean z2;
        boolean z3;
        int i3;
        boolean z4;
        if (J.l.m121isEmptyimpl(this.containerSize)) {
            return ((J.f) cVar.invoke(J.f.m39boximpl(j2))).m60unboximpl();
        }
        if (!this.scrollCycleInProgress) {
            if (this.edgeEffectWrapper.isLeftStretched()) {
                m719pullLeftk4lQ0M(J.f.Companion.m66getZeroF1C5BW0());
            }
            if (this.edgeEffectWrapper.isRightStretched()) {
                m720pullRightk4lQ0M(J.f.Companion.m66getZeroF1C5BW0());
            }
            if (this.edgeEffectWrapper.isTopStretched()) {
                m721pullTopk4lQ0M(J.f.Companion.m66getZeroF1C5BW0());
            }
            if (this.edgeEffectWrapper.isBottomStretched()) {
                m718pullBottomk4lQ0M(J.f.Companion.m66getZeroF1C5BW0());
            }
            this.scrollCycleInProgress = true;
        }
        float fM752destretchMultiplierGyEprt8 = AbstractC0371e.m752destretchMultiplierGyEprt8(i2);
        long jM57timestuRUvjQ = J.f.m57timestuRUvjQ(j2, fM752destretchMultiplierGyEprt8);
        int i4 = (int) (j2 & 4294967295L);
        if (Float.intBitsToFloat(i4) != 0.0f) {
            if (this.edgeEffectWrapper.isTopStretched() && Float.intBitsToFloat(i4) < 0.0f) {
                fM718pullBottomk4lQ0M = m721pullTopk4lQ0M(jM57timestuRUvjQ);
                if (!this.edgeEffectWrapper.isTopStretched()) {
                    this.edgeEffectWrapper.getOrCreateTopEffect().finish();
                }
                if (fM718pullBottomk4lQ0M == Float.intBitsToFloat((int) (jM57timestuRUvjQ & 4294967295L))) {
                    fIntBitsToFloat = Float.intBitsToFloat(i4);
                }
            } else if (!this.edgeEffectWrapper.isBottomStretched() || Float.intBitsToFloat(i4) <= 0.0f) {
                fIntBitsToFloat = 0.0f;
            } else {
                fM718pullBottomk4lQ0M = m718pullBottomk4lQ0M(jM57timestuRUvjQ);
                if (!this.edgeEffectWrapper.isBottomStretched()) {
                    this.edgeEffectWrapper.getOrCreateBottomEffect().finish();
                }
                fIntBitsToFloat = fM718pullBottomk4lQ0M == Float.intBitsToFloat((int) (jM57timestuRUvjQ & 4294967295L)) ? Float.intBitsToFloat(i4) : fM718pullBottomk4lQ0M / fM752destretchMultiplierGyEprt8;
            }
        }
        int i5 = (int) (j2 >> 32);
        if (Float.intBitsToFloat(i5) != 0.0f) {
            if (this.edgeEffectWrapper.isLeftStretched() && Float.intBitsToFloat(i5) < 0.0f) {
                fM720pullRightk4lQ0M = m719pullLeftk4lQ0M(jM57timestuRUvjQ);
                if (!this.edgeEffectWrapper.isLeftStretched()) {
                    this.edgeEffectWrapper.getOrCreateLeftEffect().finish();
                }
                if (fM720pullRightk4lQ0M == Float.intBitsToFloat((int) (jM57timestuRUvjQ >> 32))) {
                    fIntBitsToFloat2 = Float.intBitsToFloat(i5);
                }
            } else if (!this.edgeEffectWrapper.isRightStretched() || Float.intBitsToFloat(i5) <= 0.0f) {
                fIntBitsToFloat2 = 0.0f;
            } else {
                fM720pullRightk4lQ0M = m720pullRightk4lQ0M(jM57timestuRUvjQ);
                if (!this.edgeEffectWrapper.isRightStretched()) {
                    this.edgeEffectWrapper.getOrCreateRightEffect().finish();
                }
                fIntBitsToFloat2 = fM720pullRightk4lQ0M == Float.intBitsToFloat((int) (jM57timestuRUvjQ >> 32)) ? Float.intBitsToFloat(i5) : fM720pullRightk4lQ0M / fM752destretchMultiplierGyEprt8;
            }
        }
        long jM42constructorimpl = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L));
        f.a aVar = J.f.Companion;
        if (!J.f.m47equalsimpl0(jM42constructorimpl, aVar.m66getZeroF1C5BW0())) {
            invalidateOverscroll$foundation_release();
        }
        long jM54minusMKHz9U = J.f.m54minusMKHz9U(j2, jM42constructorimpl);
        long jM60unboximpl = ((J.f) cVar.invoke(J.f.m39boximpl(jM54minusMKHz9U))).m60unboximpl();
        long jM54minusMKHz9U2 = J.f.m54minusMKHz9U(jM54minusMKHz9U, jM60unboximpl);
        if (Float.intBitsToFloat((int) (jM54minusMKHz9U >> 32)) == 0.0f) {
            if (Float.intBitsToFloat((int) (jM54minusMKHz9U & 4294967295L)) != 0.0f) {
                c2 = ' ';
            }
            if (!androidx.compose.ui.input.nestedscroll.f.m3624equalsimpl0(i2, androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI())) {
                int i6 = (int) (jM54minusMKHz9U2 >> 32);
                if (Float.intBitsToFloat(i6) > 0.5f) {
                    m719pullLeftk4lQ0M(jM54minusMKHz9U2);
                } else if (Float.intBitsToFloat(i6) < -0.5f) {
                    m720pullRightk4lQ0M(jM54minusMKHz9U2);
                } else {
                    z3 = false;
                    i3 = (int) (4294967295L & jM54minusMKHz9U2);
                    if (Float.intBitsToFloat(i3) <= 0.5f) {
                        m721pullTopk4lQ0M(jM54minusMKHz9U2);
                    } else if (Float.intBitsToFloat(i3) < -0.5f) {
                        m718pullBottomk4lQ0M(jM54minusMKHz9U2);
                    } else {
                        z4 = false;
                        z2 = !z3 || z4;
                    }
                    z4 = true;
                    if (z3) {
                    }
                }
                z3 = true;
                i3 = (int) (4294967295L & jM54minusMKHz9U2);
                if (Float.intBitsToFloat(i3) <= 0.5f) {
                }
                z4 = true;
                if (z3) {
                }
            }
            if (!J.f.m47equalsimpl0(jM54minusMKHz9U, aVar.m66getZeroF1C5BW0())) {
                z2 = m722releaseOppositeOverscrollk4lQ0M(j2) || z2;
            }
            if (z2) {
                invalidateOverscroll$foundation_release();
            }
            return J.f.m55plusMKHz9U(jM42constructorimpl, jM60unboximpl);
        }
        c2 = ' ';
        if (Float.intBitsToFloat((int) (jM60unboximpl >> c2)) != 0.0f || Float.intBitsToFloat((int) (jM60unboximpl & 4294967295L)) != 0.0f) {
            G g2 = this.edgeEffectWrapper;
            if (g2.isLeftStretched() || g2.isTopStretched() || g2.isRightStretched() || g2.isBottomStretched()) {
                animateToReleaseIfNeeded();
            }
        }
        if (!androidx.compose.ui.input.nestedscroll.f.m3624equalsimpl0(i2, androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI())) {
        }
        if (!J.f.m47equalsimpl0(jM54minusMKHz9U, aVar.m66getZeroF1C5BW0())) {
        }
        if (z2) {
        }
        return J.f.m55plusMKHz9U(jM42constructorimpl, jM60unboximpl);
    }

    /* JADX INFO: renamed from: displacement-F1C5BW0$foundation_release, reason: not valid java name */
    public final long m723displacementF1C5BW0$foundation_release() {
        long jM129getCenteruvyYCjk = this.pointerPosition;
        if ((9223372034707292159L & jM129getCenteruvyYCjk) == 9205357640488583168L) {
            jM129getCenteruvyYCjk = J.m.m129getCenteruvyYCjk(this.containerSize);
        }
        float fIntBitsToFloat = Float.intBitsToFloat((int) (jM129getCenteruvyYCjk >> 32)) / Float.intBitsToFloat((int) (this.containerSize >> 32));
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (jM129getCenteruvyYCjk & 4294967295L)) / Float.intBitsToFloat((int) (this.containerSize & 4294967295L)))) & 4294967295L) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32));
    }

    @Override // androidx.compose.foundation.i0
    public /* bridge */ /* synthetic */ androidx.compose.ui.x getEffectModifier() {
        return super.getEffectModifier();
    }

    public final boolean getInvalidationEnabled$foundation_release() {
        return this.invalidationEnabled;
    }

    @Override // androidx.compose.foundation.i0
    public InterfaceC1007o getNode() {
        return this.node;
    }

    public final androidx.compose.runtime.B0 getRedrawSignal$foundation_release() {
        return this.redrawSignal;
    }

    public final void invalidateOverscroll$foundation_release() {
        if (this.invalidationEnabled) {
            this.redrawSignal.setValue(U0.n.f1521a);
        }
    }

    @Override // androidx.compose.foundation.i0
    public boolean isInProgress() {
        G g2 = this.edgeEffectWrapper;
        EdgeEffect edgeEffect = g2.topEffect;
        if (edgeEffect != null && E.INSTANCE.getDistanceCompat(edgeEffect) != 0.0f) {
            return true;
        }
        EdgeEffect edgeEffect2 = g2.bottomEffect;
        if (edgeEffect2 != null && E.INSTANCE.getDistanceCompat(edgeEffect2) != 0.0f) {
            return true;
        }
        EdgeEffect edgeEffect3 = g2.leftEffect;
        if (edgeEffect3 != null && E.INSTANCE.getDistanceCompat(edgeEffect3) != 0.0f) {
            return true;
        }
        EdgeEffect edgeEffect4 = g2.rightEffect;
        return (edgeEffect4 == null || E.INSTANCE.getDistanceCompat(edgeEffect4) == 0.0f) ? false : true;
    }

    public final void setInvalidationEnabled$foundation_release(boolean z2) {
        this.invalidationEnabled = z2;
    }

    /* JADX INFO: renamed from: updateSize-uvyYCjk$foundation_release, reason: not valid java name */
    public final void m724updateSizeuvyYCjk$foundation_release(long j2) {
        boolean zM115equalsimpl0 = J.l.m115equalsimpl0(this.containerSize, J.l.Companion.m128getZeroNHjbRc());
        boolean zM115equalsimpl02 = J.l.m115equalsimpl0(j2, this.containerSize);
        this.containerSize = j2;
        if (!zM115equalsimpl02) {
            G g2 = this.edgeEffectWrapper;
            int iT = j1.a.T(Float.intBitsToFloat((int) (j2 >> 32)));
            g2.m692updateSizeozmzZPI(e0.s.m5234constructorimpl((((long) j1.a.T(Float.intBitsToFloat((int) (j2 & 4294967295L)))) & 4294967295L) | (((long) iT) << 32)));
        }
        if (zM115equalsimpl0 || zM115equalsimpl02) {
            return;
        }
        animateToReleaseIfNeeded();
    }

    private C0367c(Context context, InterfaceC1307d interfaceC1307d, long j2, InterfaceC0421g0 interfaceC0421g0) {
        this.density = interfaceC1307d;
        this.pointerPosition = J.f.Companion.m65getUnspecifiedF1C5BW0();
        G g2 = new G(context, AbstractC0851a0.m3074toArgb8_81llA(j2));
        this.edgeEffectWrapper = g2;
        this.redrawSignal = Q1.mutableStateOf(U0.n.f1521a, Q1.neverEqualPolicy());
        this.invalidationEnabled = true;
        this.containerSize = J.l.Companion.m128getZeroNHjbRc();
        this.pointerId = androidx.compose.ui.input.pointer.B.m3639constructorimpl(-1L);
        androidx.compose.ui.input.pointer.Z zSuspendingPointerInputModifierNode = androidx.compose.ui.input.pointer.X.SuspendingPointerInputModifierNode(new b());
        this.pointerInputNode = zSuspendingPointerInputModifierNode;
        this.node = Build.VERSION.SDK_INT >= 31 ? new F0(zSuspendingPointerInputModifierNode, this, g2) : new M(zSuspendingPointerInputModifierNode, this, g2, interfaceC0421g0);
    }
}
