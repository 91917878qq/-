package androidx.compose.foundation;

import a.AbstractC0292a;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.node.InterfaceC1007o;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;
import u1.InterfaceC1491d;
import u1.InterfaceC1492e;

/* JADX INFO: loaded from: classes.dex */
public final class D implements Y {
    public static final D INSTANCE = new D();

    public static final class a extends androidx.compose.ui.w implements androidx.compose.ui.node.A {
        private final androidx.compose.foundation.interaction.l interactionSource;
        private boolean isFocused;
        private boolean isHovered;
        private boolean isPressed;

        /* JADX INFO: renamed from: androidx.compose.foundation.D$a$a, reason: collision with other inner class name */
        public static final class C0021a extends a1.j implements h1.e {
            int label;

            /* JADX INFO: renamed from: androidx.compose.foundation.D$a$a$a, reason: collision with other inner class name */
            public static final class C0022a implements InterfaceC1492e {
                final /* synthetic */ kotlin.jvm.internal.C $focusCount;
                final /* synthetic */ kotlin.jvm.internal.C $hoverCount;
                final /* synthetic */ kotlin.jvm.internal.C $pressCount;
                final /* synthetic */ a this$0;

                public C0022a(kotlin.jvm.internal.C c2, kotlin.jvm.internal.C c3, kotlin.jvm.internal.C c4, a aVar) {
                    this.$pressCount = c2;
                    this.$hoverCount = c3;
                    this.$focusCount = c4;
                    this.this$0 = aVar;
                }

                @Override // u1.InterfaceC1492e
                public final Object emit(androidx.compose.foundation.interaction.k kVar, Y0.c cVar) {
                    boolean z2 = true;
                    if (kVar instanceof androidx.compose.foundation.interaction.q) {
                        this.$pressCount.f3116b++;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.r) {
                        kotlin.jvm.internal.C c2 = this.$pressCount;
                        c2.f3116b--;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.p) {
                        kotlin.jvm.internal.C c3 = this.$pressCount;
                        c3.f3116b--;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.h) {
                        this.$hoverCount.f3116b++;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.i) {
                        kotlin.jvm.internal.C c4 = this.$hoverCount;
                        c4.f3116b--;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.e) {
                        this.$focusCount.f3116b++;
                    } else if (kVar instanceof androidx.compose.foundation.interaction.f) {
                        kotlin.jvm.internal.C c5 = this.$focusCount;
                        c5.f3116b--;
                    }
                    boolean z3 = false;
                    boolean z4 = this.$pressCount.f3116b > 0;
                    boolean z5 = this.$hoverCount.f3116b > 0;
                    boolean z6 = this.$focusCount.f3116b > 0;
                    if (this.this$0.isPressed != z4) {
                        this.this$0.isPressed = z4;
                        z3 = true;
                    }
                    if (this.this$0.isHovered != z5) {
                        this.this$0.isHovered = z5;
                        z3 = true;
                    }
                    if (this.this$0.isFocused != z6) {
                        this.this$0.isFocused = z6;
                    } else {
                        z2 = z3;
                    }
                    if (z2) {
                        androidx.compose.ui.node.B.invalidateDraw(this.this$0);
                    }
                    return U0.n.f1521a;
                }
            }

            public C0021a(Y0.c cVar) {
                super(2, cVar);
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                return a.this.new C0021a(cVar);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    kotlin.jvm.internal.C c2 = new kotlin.jvm.internal.C();
                    kotlin.jvm.internal.C c3 = new kotlin.jvm.internal.C();
                    kotlin.jvm.internal.C c4 = new kotlin.jvm.internal.C();
                    InterfaceC1491d interactions = a.this.interactionSource.getInteractions();
                    C0022a c0022a = new C0022a(c2, c3, c4, a.this);
                    this.label = 1;
                    if (interactions.b(c0022a, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                }
                return U0.n.f1521a;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((C0021a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        public a(androidx.compose.foundation.interaction.l lVar) {
            this.interactionSource = lVar;
        }

        @Override // androidx.compose.ui.node.A
        public void draw(androidx.compose.ui.graphics.drawscope.c cVar) {
            cVar.drawContent();
            if (this.isPressed) {
                androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(cVar, androidx.compose.ui.graphics.Y.m3019copywmQWz5c$default(androidx.compose.ui.graphics.Y.Companion.m3046getBlack0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, null), 0L, cVar.mo3172getSizeNHjbRc(), 0.0f, null, null, 0, 122, null);
            } else if (this.isHovered || this.isFocused) {
                androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(cVar, androidx.compose.ui.graphics.Y.m3019copywmQWz5c$default(androidx.compose.ui.graphics.Y.Companion.m3046getBlack0d7_KjU(), 0.1f, 0.0f, 0.0f, 0.0f, 14, null), 0L, cVar.mo3172getSizeNHjbRc(), 0.0f, null, null, 0, 122, null);
            }
        }

        @Override // androidx.compose.ui.w
        public void onAttach() {
            AbstractC1476z.s(getCoroutineScope(), null, null, new C0021a(null), 3);
        }

        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }

        @Override // androidx.compose.ui.node.A
        public /* bridge */ /* synthetic */ void onMeasureResultChanged() {
            super.onMeasureResultChanged();
        }
    }

    private D() {
    }

    @Override // androidx.compose.foundation.Y
    public InterfaceC1007o create(androidx.compose.foundation.interaction.l lVar) {
        return new a(lVar);
    }

    @Override // androidx.compose.foundation.Y
    public boolean equals(Object obj) {
        return obj == this;
    }

    @Override // androidx.compose.foundation.Y
    public int hashCode() {
        return -1;
    }

    @Override // androidx.compose.foundation.Y, androidx.compose.foundation.T
    @U0.a
    public /* bridge */ /* synthetic */ U rememberUpdatedInstance(androidx.compose.foundation.interaction.l lVar, InterfaceC0768p interfaceC0768p, int i2) {
        return super.rememberUpdatedInstance(lVar, interfaceC0768p, i2);
    }
}
