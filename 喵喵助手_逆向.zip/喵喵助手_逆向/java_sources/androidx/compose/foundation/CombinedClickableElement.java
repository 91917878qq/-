package androidx.compose.foundation;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import androidx.compose.ui.semantics.C1116j;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class CombinedClickableElement extends AbstractC1000k0 {
    private final boolean enabled;
    private final boolean hapticFeedbackEnabled;
    private final Y indicationNodeFactory;
    private final androidx.compose.foundation.interaction.n interactionSource;
    private final h1.a onClick;
    private final String onClickLabel;
    private final h1.a onDoubleClick;
    private final h1.a onLongClick;
    private final String onLongClickLabel;
    private final C1116j role;
    private final boolean useLocalIndication;

    public /* synthetic */ CombinedClickableElement(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar, String str2, h1.a aVar2, h1.a aVar3, boolean z4, AbstractC1378g abstractC1378g) {
        this(nVar, y2, z2, z3, str, c1116j, aVar, str2, aVar2, aVar3, z4);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || CombinedClickableElement.class != obj.getClass()) {
            return false;
        }
        CombinedClickableElement combinedClickableElement = (CombinedClickableElement) obj;
        return kotlin.jvm.internal.o.a(this.interactionSource, combinedClickableElement.interactionSource) && kotlin.jvm.internal.o.a(this.indicationNodeFactory, combinedClickableElement.indicationNodeFactory) && this.useLocalIndication == combinedClickableElement.useLocalIndication && this.enabled == combinedClickableElement.enabled && kotlin.jvm.internal.o.a(this.onClickLabel, combinedClickableElement.onClickLabel) && kotlin.jvm.internal.o.a(this.role, combinedClickableElement.role) && this.onClick == combinedClickableElement.onClick && kotlin.jvm.internal.o.a(this.onLongClickLabel, combinedClickableElement.onLongClickLabel) && this.onLongClick == combinedClickableElement.onLongClick && this.onDoubleClick == combinedClickableElement.onDoubleClick && this.hapticFeedbackEnabled == combinedClickableElement.hapticFeedbackEnabled;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        int iHashCode = (nVar != null ? nVar.hashCode() : 0) * 31;
        Y y2 = this.indicationNodeFactory;
        int iC = D0.d.c(D0.d.c((iHashCode + (y2 != null ? y2.hashCode() : 0)) * 31, 31, this.useLocalIndication), 31, this.enabled);
        String str = this.onClickLabel;
        int iHashCode2 = (iC + (str != null ? str.hashCode() : 0)) * 31;
        C1116j c1116j = this.role;
        int iHashCode3 = (this.onClick.hashCode() + ((iHashCode2 + (c1116j != null ? C1116j.m4289hashCodeimpl(c1116j.m4291unboximpl()) : 0)) * 31)) * 31;
        String str2 = this.onLongClickLabel;
        int iHashCode4 = (iHashCode3 + (str2 != null ? str2.hashCode() : 0)) * 31;
        h1.a aVar = this.onLongClick;
        int iHashCode5 = (iHashCode4 + (aVar != null ? aVar.hashCode() : 0)) * 31;
        h1.a aVar2 = this.onDoubleClick;
        return Boolean.hashCode(this.hapticFeedbackEnabled) + ((iHashCode5 + (aVar2 != null ? aVar2.hashCode() : 0)) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("combinedClickable");
        c1065l1.getProperties().set("indicationNodeFactory", this.indicationNodeFactory);
        c1065l1.getProperties().set("interactionSource", this.interactionSource);
        D0.d.l(this.enabled, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.onClickLabel);
        c1065l1.getProperties().set("role", this.role);
        c1065l1.getProperties().set("onClick", this.onClick);
        c1065l1.getProperties().set("onDoubleClick", this.onDoubleClick);
        c1065l1.getProperties().set("onLongClick", this.onLongClick);
        c1065l1.getProperties().set("onLongClickLabel", this.onLongClickLabel);
        c1065l1.getProperties().set("hapticFeedbackEnabled", Boolean.valueOf(this.hapticFeedbackEnabled));
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    private CombinedClickableElement(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar, String str2, h1.a aVar2, h1.a aVar3, boolean z4) {
        this.interactionSource = nVar;
        this.indicationNodeFactory = y2;
        this.useLocalIndication = z2;
        this.enabled = z3;
        this.onClickLabel = str;
        this.role = c1116j;
        this.onClick = aVar;
        this.onLongClickLabel = str2;
        this.onLongClick = aVar2;
        this.onDoubleClick = aVar3;
        this.hapticFeedbackEnabled = z4;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0645y create() {
        return new C0645y(this.onClick, this.onLongClickLabel, this.onLongClick, this.onDoubleClick, this.hapticFeedbackEnabled, this.interactionSource, this.indicationNodeFactory, this.useLocalIndication, this.enabled, this.onClickLabel, this.role, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0645y c0645y) {
        c0645y.setHapticFeedbackEnabled(this.hapticFeedbackEnabled);
        c0645y.m1666update2tQrsxU(this.onClick, this.onLongClickLabel, this.onLongClick, this.onDoubleClick, this.interactionSource, this.indicationNodeFactory, this.useLocalIndication, this.enabled, this.onClickLabel, this.role);
    }
}
