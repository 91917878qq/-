package androidx.compose.foundation;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.compose.foundation.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0368c0 {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ EnumC0368c0[] $VALUES;
    public static final EnumC0368c0 Default = new EnumC0368c0("Default", 0);
    public static final EnumC0368c0 UserInput = new EnumC0368c0("UserInput", 1);
    public static final EnumC0368c0 PreventUserInput = new EnumC0368c0("PreventUserInput", 2);

    private static final /* synthetic */ EnumC0368c0[] $values() {
        return new EnumC0368c0[]{Default, UserInput, PreventUserInput};
    }

    static {
        EnumC0368c0[] enumC0368c0Arr$values = $values();
        $VALUES = enumC0368c0Arr$values;
        $ENTRIES = AbstractC0292a.q(enumC0368c0Arr$values);
    }

    private EnumC0368c0(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static EnumC0368c0 valueOf(String str) {
        return (EnumC0368c0) Enum.valueOf(EnumC0368c0.class, str);
    }

    public static EnumC0368c0[] values() {
        return (EnumC0368c0[]) $VALUES.clone();
    }
}
