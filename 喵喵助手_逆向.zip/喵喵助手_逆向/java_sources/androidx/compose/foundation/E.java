package androidx.compose.foundation;

import android.content.Context;
import android.os.Build;
import android.widget.EdgeEffect;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class E {
    public static final int $stable = 0;
    public static final E INSTANCE = new E();

    private E() {
    }

    public final float absorbToRelaxIfNeeded(EdgeEffect edgeEffect, float f2, float f3, InterfaceC1307d interfaceC1307d) {
        if (F.flingDistance(interfaceC1307d, f2) > getDistanceCompat(edgeEffect) * f3) {
            return 0.0f;
        }
        onAbsorbCompat(edgeEffect, j1.a.T(f2));
        return f2;
    }

    public final EdgeEffect create(Context context) {
        return Build.VERSION.SDK_INT >= 31 ? C0373f.INSTANCE.create(context, null) : new L(context);
    }

    public final float getDistanceCompat(EdgeEffect edgeEffect) {
        if (Build.VERSION.SDK_INT >= 31) {
            return C0373f.INSTANCE.getDistance(edgeEffect);
        }
        return 0.0f;
    }

    public final void onAbsorbCompat(EdgeEffect edgeEffect, int i2) {
        if (Build.VERSION.SDK_INT >= 31) {
            edgeEffect.onAbsorb(i2);
        } else if (edgeEffect.isFinished()) {
            edgeEffect.onAbsorb(i2);
        }
    }

    public final float onPullDistanceCompat(EdgeEffect edgeEffect, float f2, float f3) {
        if (Build.VERSION.SDK_INT >= 31) {
            return C0373f.INSTANCE.onPullDistance(edgeEffect, f2, f3);
        }
        edgeEffect.onPull(f2, f3);
        return f2;
    }

    public final void onReleaseWithOppositeDelta(EdgeEffect edgeEffect, float f2) {
        if (edgeEffect instanceof L) {
            ((L) edgeEffect).releaseWithOppositeDelta(f2);
        } else {
            edgeEffect.onRelease();
        }
    }
}
