package androidx.compose.foundation;

import androidx.compose.ui.node.a1;
import androidx.compose.ui.node.b1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class K extends androidx.compose.ui.w implements a1 {
    private h1.c onPositioned;
    private final Object traverseKey = TraverseKey;
    public static final a TraverseKey = new a(null);
    public static final int $stable = 8;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        private a() {
        }
    }

    public K(h1.c cVar) {
        this.onPositioned = cVar;
    }

    public final h1.c getOnPositioned() {
        return this.onPositioned;
    }

    @Override // androidx.compose.ui.node.a1
    public Object getTraverseKey() {
        return this.traverseKey;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    public final void onFocusBoundsChanged(androidx.compose.ui.layout.J j2) {
        this.onPositioned.invoke(j2);
        K k2 = (K) b1.findNearestAncestor(this);
        if (k2 != null) {
            k2.onFocusBoundsChanged(j2);
        }
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setOnPositioned(h1.c cVar) {
        this.onPositioned = cVar;
    }
}
