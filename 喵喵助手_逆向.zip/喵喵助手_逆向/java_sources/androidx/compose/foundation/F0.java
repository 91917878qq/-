package androidx.compose.foundation;

import android.graphics.Canvas;
import android.graphics.RecordingCanvas;
import android.graphics.RenderNode;
import android.widget.EdgeEffect;
import androidx.compose.ui.graphics.AbstractC0858e;
import androidx.compose.ui.node.InterfaceC1007o;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class F0 extends androidx.compose.ui.node.r implements androidx.compose.ui.node.A {
    private RenderNode _renderNode;
    private final G edgeEffectWrapper;
    private final C0367c overscrollEffect;

    public F0(InterfaceC1007o interfaceC1007o, C0367c c0367c, G g2) {
        this.overscrollEffect = c0367c;
        this.edgeEffectWrapper = g2;
        delegate(interfaceC1007o);
    }

    private final boolean drawBottomStretch(EdgeEffect edgeEffect, Canvas canvas) {
        return drawWithRotation(180.0f, edgeEffect, canvas);
    }

    private final boolean drawLeftStretch(EdgeEffect edgeEffect, Canvas canvas) {
        return drawWithRotation(270.0f, edgeEffect, canvas);
    }

    private final boolean drawRightStretch(EdgeEffect edgeEffect, Canvas canvas) {
        return drawWithRotation(90.0f, edgeEffect, canvas);
    }

    private final boolean drawTopStretch(EdgeEffect edgeEffect, Canvas canvas) {
        return drawWithRotation(0.0f, edgeEffect, canvas);
    }

    private final boolean drawWithRotation(float f2, EdgeEffect edgeEffect, Canvas canvas) {
        if (f2 == 0.0f) {
            return edgeEffect.draw(canvas);
        }
        int iSave = canvas.save();
        canvas.rotate(f2);
        boolean zDraw = edgeEffect.draw(canvas);
        canvas.restoreToCount(iSave);
        return zDraw;
    }

    private final RenderNode getRenderNode() {
        RenderNode renderNode = this._renderNode;
        if (renderNode != null) {
            return renderNode;
        }
        RenderNode renderNodeD = N0.j.d();
        this._renderNode = renderNodeD;
        return renderNodeD;
    }

    private final boolean shouldDrawHorizontalStretch() {
        G g2 = this.edgeEffectWrapper;
        return g2.isLeftAnimating() || g2.isLeftNegationStretched() || g2.isRightAnimating() || g2.isRightNegationStretched();
    }

    private final boolean shouldDrawVerticalStretch() {
        G g2 = this.edgeEffectWrapper;
        return g2.isTopAnimating() || g2.isTopNegationStretched() || g2.isBottomAnimating() || g2.isBottomNegationStretched();
    }

    @Override // androidx.compose.ui.node.A
    public void draw(androidx.compose.ui.graphics.drawscope.c cVar) {
        boolean zDrawLeftStretch;
        this.overscrollEffect.m724updateSizeuvyYCjk$foundation_release(cVar.mo3172getSizeNHjbRc());
        Canvas nativeCanvas = AbstractC0858e.getNativeCanvas(cVar.getDrawContext().getCanvas());
        this.overscrollEffect.getRedrawSignal$foundation_release().getValue();
        if (J.l.m121isEmptyimpl(cVar.mo3172getSizeNHjbRc())) {
            cVar.drawContent();
            return;
        }
        if (!nativeCanvas.isHardwareAccelerated()) {
            this.edgeEffectWrapper.finishAll();
            cVar.drawContent();
            return;
        }
        float fMo788toPx0680j_4 = cVar.mo788toPx0680j_4(AbstractC0644x.getMaxSupportedElevation());
        G g2 = this.edgeEffectWrapper;
        boolean zShouldDrawVerticalStretch = shouldDrawVerticalStretch();
        boolean zShouldDrawHorizontalStretch = shouldDrawHorizontalStretch();
        if (zShouldDrawVerticalStretch && zShouldDrawHorizontalStretch) {
            getRenderNode().setPosition(0, 0, nativeCanvas.getWidth(), nativeCanvas.getHeight());
        } else if (zShouldDrawVerticalStretch) {
            getRenderNode().setPosition(0, 0, (j1.a.T(fMo788toPx0680j_4) * 2) + nativeCanvas.getWidth(), nativeCanvas.getHeight());
        } else {
            if (!zShouldDrawHorizontalStretch) {
                cVar.drawContent();
                return;
            }
            getRenderNode().setPosition(0, 0, nativeCanvas.getWidth(), (j1.a.T(fMo788toPx0680j_4) * 2) + nativeCanvas.getHeight());
        }
        RecordingCanvas recordingCanvasBeginRecording = getRenderNode().beginRecording();
        if (g2.isLeftNegationStretched()) {
            EdgeEffect orCreateLeftEffectNegation = g2.getOrCreateLeftEffectNegation();
            drawRightStretch(orCreateLeftEffectNegation, recordingCanvasBeginRecording);
            orCreateLeftEffectNegation.finish();
        }
        if (g2.isLeftAnimating()) {
            EdgeEffect orCreateLeftEffect = g2.getOrCreateLeftEffect();
            zDrawLeftStretch = drawLeftStretch(orCreateLeftEffect, recordingCanvasBeginRecording);
            if (g2.isLeftStretched()) {
                float fIntBitsToFloat = Float.intBitsToFloat((int) (this.overscrollEffect.m723displacementF1C5BW0$foundation_release() & 4294967295L));
                E e2 = E.INSTANCE;
                e2.onPullDistanceCompat(g2.getOrCreateLeftEffectNegation(), e2.getDistanceCompat(orCreateLeftEffect), 1 - fIntBitsToFloat);
            }
        } else {
            zDrawLeftStretch = false;
        }
        if (g2.isTopNegationStretched()) {
            EdgeEffect orCreateTopEffectNegation = g2.getOrCreateTopEffectNegation();
            drawBottomStretch(orCreateTopEffectNegation, recordingCanvasBeginRecording);
            orCreateTopEffectNegation.finish();
        }
        if (g2.isTopAnimating()) {
            EdgeEffect orCreateTopEffect = g2.getOrCreateTopEffect();
            zDrawLeftStretch = drawTopStretch(orCreateTopEffect, recordingCanvasBeginRecording) || zDrawLeftStretch;
            if (g2.isTopStretched()) {
                float fIntBitsToFloat2 = Float.intBitsToFloat((int) (this.overscrollEffect.m723displacementF1C5BW0$foundation_release() >> 32));
                E e3 = E.INSTANCE;
                e3.onPullDistanceCompat(g2.getOrCreateTopEffectNegation(), e3.getDistanceCompat(orCreateTopEffect), fIntBitsToFloat2);
            }
        }
        if (g2.isRightNegationStretched()) {
            EdgeEffect orCreateRightEffectNegation = g2.getOrCreateRightEffectNegation();
            drawLeftStretch(orCreateRightEffectNegation, recordingCanvasBeginRecording);
            orCreateRightEffectNegation.finish();
        }
        if (g2.isRightAnimating()) {
            EdgeEffect orCreateRightEffect = g2.getOrCreateRightEffect();
            zDrawLeftStretch = drawRightStretch(orCreateRightEffect, recordingCanvasBeginRecording) || zDrawLeftStretch;
            if (g2.isRightStretched()) {
                float fIntBitsToFloat3 = Float.intBitsToFloat((int) (this.overscrollEffect.m723displacementF1C5BW0$foundation_release() & 4294967295L));
                E e4 = E.INSTANCE;
                e4.onPullDistanceCompat(g2.getOrCreateRightEffectNegation(), e4.getDistanceCompat(orCreateRightEffect), fIntBitsToFloat3);
            }
        }
        if (g2.isBottomNegationStretched()) {
            EdgeEffect orCreateBottomEffectNegation = g2.getOrCreateBottomEffectNegation();
            drawTopStretch(orCreateBottomEffectNegation, recordingCanvasBeginRecording);
            orCreateBottomEffectNegation.finish();
        }
        if (g2.isBottomAnimating()) {
            EdgeEffect orCreateBottomEffect = g2.getOrCreateBottomEffect();
            boolean z2 = drawBottomStretch(orCreateBottomEffect, recordingCanvasBeginRecording) || zDrawLeftStretch;
            if (g2.isBottomStretched()) {
                float fIntBitsToFloat4 = Float.intBitsToFloat((int) (this.overscrollEffect.m723displacementF1C5BW0$foundation_release() >> 32));
                E e5 = E.INSTANCE;
                e5.onPullDistanceCompat(g2.getOrCreateBottomEffectNegation(), e5.getDistanceCompat(orCreateBottomEffect), 1 - fIntBitsToFloat4);
            }
            zDrawLeftStretch = z2;
        }
        if (zDrawLeftStretch) {
            this.overscrollEffect.invalidateOverscroll$foundation_release();
        }
        float f2 = zShouldDrawHorizontalStretch ? 0.0f : fMo788toPx0680j_4;
        if (zShouldDrawVerticalStretch) {
            fMo788toPx0680j_4 = 0.0f;
        }
        e0.u layoutDirection = cVar.getLayoutDirection();
        androidx.compose.ui.graphics.S sCanvas = AbstractC0858e.Canvas(recordingCanvasBeginRecording);
        long jMo3172getSizeNHjbRc = cVar.mo3172getSizeNHjbRc();
        InterfaceC1307d density = cVar.getDrawContext().getDensity();
        e0.u layoutDirection2 = cVar.getDrawContext().getLayoutDirection();
        androidx.compose.ui.graphics.S canvas = cVar.getDrawContext().getCanvas();
        long jMo3179getSizeNHjbRc = cVar.getDrawContext().mo3179getSizeNHjbRc();
        androidx.compose.ui.graphics.layer.c graphicsLayer = cVar.getDrawContext().getGraphicsLayer();
        androidx.compose.ui.graphics.drawscope.d drawContext = cVar.getDrawContext();
        drawContext.setDensity(cVar);
        drawContext.setLayoutDirection(layoutDirection);
        drawContext.setCanvas(sCanvas);
        drawContext.mo3180setSizeuvyYCjk(jMo3172getSizeNHjbRc);
        drawContext.setGraphicsLayer(null);
        sCanvas.save();
        try {
            cVar.getDrawContext().getTransform().translate(f2, fMo788toPx0680j_4);
            try {
                cVar.drawContent();
                float f3 = -f2;
                float f4 = -fMo788toPx0680j_4;
                cVar.getDrawContext().getTransform().translate(f3, f4);
                sCanvas.restore();
                androidx.compose.ui.graphics.drawscope.d drawContext2 = cVar.getDrawContext();
                drawContext2.setDensity(density);
                drawContext2.setLayoutDirection(layoutDirection2);
                drawContext2.setCanvas(canvas);
                drawContext2.mo3180setSizeuvyYCjk(jMo3179getSizeNHjbRc);
                drawContext2.setGraphicsLayer(graphicsLayer);
                getRenderNode().endRecording();
                int iSave = nativeCanvas.save();
                nativeCanvas.translate(f3, f4);
                nativeCanvas.drawRenderNode(getRenderNode());
                nativeCanvas.restoreToCount(iSave);
            } catch (Throwable th) {
                cVar.getDrawContext().getTransform().translate(-f2, -fMo788toPx0680j_4);
                throw th;
            }
        } catch (Throwable th2) {
            sCanvas.restore();
            androidx.compose.ui.graphics.drawscope.d drawContext3 = cVar.getDrawContext();
            drawContext3.setDensity(density);
            drawContext3.setLayoutDirection(layoutDirection2);
            drawContext3.setCanvas(canvas);
            drawContext3.mo3180setSizeuvyYCjk(jMo3179getSizeNHjbRc);
            drawContext3.setGraphicsLayer(graphicsLayer);
            throw th2;
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.A
    public /* bridge */ /* synthetic */ void onMeasureResultChanged() {
        super.onMeasureResultChanged();
    }
}
