package androidx.compose.foundation;

/* JADX INFO: loaded from: classes.dex */
public abstract class I {
    public static final androidx.compose.ui.x focusGroup(androidx.compose.ui.x xVar) {
        return xVar.then(FocusGroupElement.INSTANCE);
    }

    public static final androidx.compose.ui.x focusable(androidx.compose.ui.x xVar, boolean z2, androidx.compose.foundation.interaction.n nVar) {
        return xVar.then(z2 ? new FocusableElement(nVar) : androidx.compose.ui.x.Companion);
    }

    public static /* synthetic */ androidx.compose.ui.x focusable$default(androidx.compose.ui.x xVar, boolean z2, androidx.compose.foundation.interaction.n nVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        if ((i2 & 2) != 0) {
            nVar = null;
        }
        return focusable(xVar, z2, nVar);
    }
}
