package androidx.compose.foundation;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import androidx.compose.ui.semantics.C1116j;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class ClickableElement extends AbstractC1000k0 {
    private final boolean enabled;
    private final Y indicationNodeFactory;
    private final androidx.compose.foundation.interaction.n interactionSource;
    private final h1.a onClick;
    private final String onClickLabel;
    private final C1116j role;
    private final boolean useLocalIndication;

    public /* synthetic */ ClickableElement(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar, AbstractC1378g abstractC1378g) {
        this(nVar, y2, z2, z3, str, c1116j, aVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ClickableElement.class != obj.getClass()) {
            return false;
        }
        ClickableElement clickableElement = (ClickableElement) obj;
        return kotlin.jvm.internal.o.a(this.interactionSource, clickableElement.interactionSource) && kotlin.jvm.internal.o.a(this.indicationNodeFactory, clickableElement.indicationNodeFactory) && this.useLocalIndication == clickableElement.useLocalIndication && this.enabled == clickableElement.enabled && kotlin.jvm.internal.o.a(this.onClickLabel, clickableElement.onClickLabel) && kotlin.jvm.internal.o.a(this.role, clickableElement.role) && this.onClick == clickableElement.onClick;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        int iHashCode = (nVar != null ? nVar.hashCode() : 0) * 31;
        Y y2 = this.indicationNodeFactory;
        int iC = D0.d.c(D0.d.c((iHashCode + (y2 != null ? y2.hashCode() : 0)) * 31, 31, this.useLocalIndication), 31, this.enabled);
        String str = this.onClickLabel;
        int iHashCode2 = (iC + (str != null ? str.hashCode() : 0)) * 31;
        C1116j c1116j = this.role;
        return this.onClick.hashCode() + ((iHashCode2 + (c1116j != null ? C1116j.m4289hashCodeimpl(c1116j.m4291unboximpl()) : 0)) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("clickable");
        D0.d.l(this.enabled, c1065l1.getProperties(), "enabled", c1065l1).set("onClick", this.onClick);
        c1065l1.getProperties().set("onClickLabel", this.onClickLabel);
        c1065l1.getProperties().set("role", this.role);
        c1065l1.getProperties().set("interactionSource", this.interactionSource);
        c1065l1.getProperties().set("indicationNodeFactory", this.indicationNodeFactory);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    private ClickableElement(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar) {
        this.interactionSource = nVar;
        this.indicationNodeFactory = y2;
        this.useLocalIndication = z2;
        this.enabled = z3;
        this.onClickLabel = str;
        this.role = c1116j;
        this.onClick = aVar;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0642v create() {
        return new C0642v(this.interactionSource, this.indicationNodeFactory, this.useLocalIndication, this.enabled, this.onClickLabel, this.role, this.onClick, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0642v c0642v) {
        c0642v.m1664updateO2vRcR0(this.interactionSource, this.indicationNodeFactory, this.useLocalIndication, this.enabled, this.onClickLabel, this.role, this.onClick);
    }
}
