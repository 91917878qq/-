package androidx.compose.foundation;

import P.a;
import android.view.KeyEvent;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.node.a1;
import androidx.compose.ui.node.b1;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;
import androidx.compose.ui.semantics.C1116j;

/* JADX INFO: renamed from: androidx.compose.foundation.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0641u {

    /* JADX INFO: renamed from: androidx.compose.foundation.u$a */
    public static final class a implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ h1.a $onClick;
        final /* synthetic */ String $onClickLabel;
        final /* synthetic */ C1116j $role;

        public a(boolean z2, String str, C1116j c1116j, h1.a aVar) {
            this.$enabled = z2;
            this.$onClickLabel = str;
            this.$role = c1116j;
            this.$onClick = aVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            androidx.compose.foundation.interaction.n nVar;
            interfaceC0768p.startReplaceGroup(-756081143);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-756081143, i2, -1, "androidx.compose.foundation.clickable.<anonymous> (Clickable.kt:137)");
            }
            T t2 = (T) interfaceC0768p.consume(V.getLocalIndication());
            if (t2 instanceof Y) {
                interfaceC0768p.startReplaceGroup(-1604682242);
                interfaceC0768p.endReplaceGroup();
                nVar = null;
            } else {
                interfaceC0768p.startReplaceGroup(-1604549624);
                Object objRememberedValue = interfaceC0768p.rememberedValue();
                if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                    interfaceC0768p.updateRememberedValue(objRememberedValue);
                }
                nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
                interfaceC0768p.endReplaceGroup();
            }
            androidx.compose.ui.x xVarM1644clickableO2vRcR0 = AbstractC0641u.m1644clickableO2vRcR0(androidx.compose.ui.x.Companion, nVar, t2, this.$enabled, this.$onClickLabel, this.$role, this.$onClick);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarM1644clickableO2vRcR0;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$b */
    public static final class b implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ h1.a $onClick;
        final /* synthetic */ String $onClickLabel;
        final /* synthetic */ C1116j $role;

        public b(androidx.compose.foundation.interaction.n nVar, boolean z2, String str, C1116j c1116j, h1.a aVar) {
            this.$interactionSource = nVar;
            this.$enabled = z2;
            this.$onClickLabel = str;
            this.$role = c1116j;
            this.$onClick = aVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-691633986);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-691633986, i2, -1, "androidx.compose.foundation.clickable.<anonymous> (Clickable.kt:229)");
            }
            T t2 = (T) interfaceC0768p.consume(V.getLocalIndication());
            androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
            if (nVar == null) {
                if (t2 instanceof Y) {
                    interfaceC0768p.startReplaceGroup(-1509763983);
                    interfaceC0768p.endReplaceGroup();
                    nVar = null;
                } else {
                    interfaceC0768p.startReplaceGroup(-1509607061);
                    Object objRememberedValue = interfaceC0768p.rememberedValue();
                    if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                        interfaceC0768p.updateRememberedValue(objRememberedValue);
                    }
                    nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
                    interfaceC0768p.endReplaceGroup();
                }
            }
            androidx.compose.ui.x xVarM1644clickableO2vRcR0 = AbstractC0641u.m1644clickableO2vRcR0(androidx.compose.ui.x.Companion, nVar, t2, this.$enabled, this.$onClickLabel, this.$role, this.$onClick);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarM1644clickableO2vRcR0;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$c */
    public static final class c implements h1.f {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ T $indication;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        public c(T t2, boolean z2, String str, C1116j c1116j, h1.a aVar) {
            this.$indication = t2;
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1525724089);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1525724089, i2, -1, "androidx.compose.foundation.clickableWithIndicationIfNeeded.<anonymous> (Clickable.kt:708)");
            }
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.foundation.interaction.n nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
            androidx.compose.ui.x xVarThen = V.indication(androidx.compose.ui.x.Companion, nVar, this.$indication).then(new ClickableElement(nVar, null, false, this.$enabled$inlined, this.$onClickLabel$inlined, this.$role$inlined, this.$onClick$inlined, null));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarThen;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$d */
    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(boolean z2, String str, C1116j c1116j, h1.a aVar) {
            super(1);
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("clickable");
            D0.d.l(this.$enabled$inlined, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.$onClickLabel$inlined);
            c1065l1.getProperties().set("role", this.$role$inlined);
            c1065l1.getProperties().set("onClick", this.$onClick$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$e */
    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource$inlined;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(boolean z2, String str, C1116j c1116j, androidx.compose.foundation.interaction.n nVar, h1.a aVar) {
            super(1);
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$interactionSource$inlined = nVar;
            this.$onClick$inlined = aVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("clickable");
            D0.d.l(this.$enabled$inlined, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.$onClickLabel$inlined);
            c1065l1.getProperties().set("role", this.$role$inlined);
            c1065l1.getProperties().set("interactionSource", this.$interactionSource$inlined);
            c1065l1.getProperties().set("onClick", this.$onClick$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$f */
    public static final class f implements h1.f {
        final /* synthetic */ h1.e $createClickable;
        final /* synthetic */ T $indication;

        public f(T t2, h1.e eVar) {
            this.$indication = t2;
            this.$createClickable = eVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1525724089);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1525724089, i2, -1, "androidx.compose.foundation.clickableWithIndicationIfNeeded.<anonymous> (Clickable.kt:708)");
            }
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.foundation.interaction.n nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
            androidx.compose.ui.x xVarThen = V.indication(androidx.compose.ui.x.Companion, nVar, this.$indication).then((androidx.compose.ui.x) this.$createClickable.invoke(nVar, null));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarThen;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$g */
    public static final class g implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ boolean $hapticFeedbackEnabled;
        final /* synthetic */ h1.a $onClick;
        final /* synthetic */ String $onClickLabel;
        final /* synthetic */ h1.a $onDoubleClick;
        final /* synthetic */ h1.a $onLongClick;
        final /* synthetic */ String $onLongClickLabel;
        final /* synthetic */ C1116j $role;

        public g(boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, boolean z3, h1.a aVar3) {
            this.$enabled = z2;
            this.$onClickLabel = str;
            this.$role = c1116j;
            this.$onLongClickLabel = str2;
            this.$onLongClick = aVar;
            this.$onDoubleClick = aVar2;
            this.$hapticFeedbackEnabled = z3;
            this.$onClick = aVar3;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            androidx.compose.foundation.interaction.n nVar;
            interfaceC0768p.startReplaceGroup(-1534186401);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1534186401, i2, -1, "androidx.compose.foundation.combinedClickable.<anonymous> (Clickable.kt:382)");
            }
            T t2 = (T) interfaceC0768p.consume(V.getLocalIndication());
            if (t2 instanceof Y) {
                interfaceC0768p.startReplaceGroup(2095040488);
                interfaceC0768p.endReplaceGroup();
                nVar = null;
            } else {
                interfaceC0768p.startReplaceGroup(2095173106);
                Object objRememberedValue = interfaceC0768p.rememberedValue();
                if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                    interfaceC0768p.updateRememberedValue(objRememberedValue);
                }
                nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
                interfaceC0768p.endReplaceGroup();
            }
            androidx.compose.ui.x xVarM1652combinedClickableauXiCPI = AbstractC0641u.m1652combinedClickableauXiCPI(androidx.compose.ui.x.Companion, nVar, t2, this.$enabled, this.$onClickLabel, this.$role, this.$onLongClickLabel, this.$onLongClick, this.$onDoubleClick, this.$hapticFeedbackEnabled, this.$onClick);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarM1652combinedClickableauXiCPI;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$h */
    public static final class h implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ boolean $hapticFeedbackEnabled;
        final /* synthetic */ androidx.compose.foundation.interaction.n $interactionSource;
        final /* synthetic */ h1.a $onClick;
        final /* synthetic */ String $onClickLabel;
        final /* synthetic */ h1.a $onDoubleClick;
        final /* synthetic */ h1.a $onLongClick;
        final /* synthetic */ String $onLongClickLabel;
        final /* synthetic */ C1116j $role;

        public h(androidx.compose.foundation.interaction.n nVar, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, boolean z3, h1.a aVar3) {
            this.$interactionSource = nVar;
            this.$enabled = z2;
            this.$onClickLabel = str;
            this.$role = c1116j;
            this.$onLongClickLabel = str2;
            this.$onLongClick = aVar;
            this.$onDoubleClick = aVar2;
            this.$hapticFeedbackEnabled = z3;
            this.$onClick = aVar3;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-769426448);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-769426448, i2, -1, "androidx.compose.foundation.combinedClickable.<anonymous> (Clickable.kt:495)");
            }
            T t2 = (T) interfaceC0768p.consume(V.getLocalIndication());
            androidx.compose.foundation.interaction.n nVar = this.$interactionSource;
            if (nVar == null) {
                if (t2 instanceof Y) {
                    interfaceC0768p.startReplaceGroup(257340415);
                    interfaceC0768p.endReplaceGroup();
                    nVar = null;
                } else {
                    interfaceC0768p.startReplaceGroup(257497337);
                    Object objRememberedValue = interfaceC0768p.rememberedValue();
                    if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                        interfaceC0768p.updateRememberedValue(objRememberedValue);
                    }
                    nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
                    interfaceC0768p.endReplaceGroup();
                }
            }
            androidx.compose.ui.x xVarM1652combinedClickableauXiCPI = AbstractC0641u.m1652combinedClickableauXiCPI(androidx.compose.ui.x.Companion, nVar, t2, this.$enabled, this.$onClickLabel, this.$role, this.$onLongClickLabel, this.$onLongClick, this.$onDoubleClick, this.$hapticFeedbackEnabled, this.$onClick);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarM1652combinedClickableauXiCPI;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$i */
    public static final class i implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ h1.a $onClick;
        final /* synthetic */ String $onClickLabel;
        final /* synthetic */ h1.a $onDoubleClick;
        final /* synthetic */ h1.a $onLongClick;
        final /* synthetic */ String $onLongClickLabel;
        final /* synthetic */ C1116j $role;

        public i(boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, h1.a aVar3) {
            this.$enabled = z2;
            this.$onClickLabel = str;
            this.$role = c1116j;
            this.$onLongClickLabel = str2;
            this.$onLongClick = aVar;
            this.$onDoubleClick = aVar2;
            this.$onClick = aVar3;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            androidx.compose.foundation.interaction.n nVar;
            interfaceC0768p.startReplaceGroup(1969174843);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1969174843, i2, -1, "androidx.compose.foundation.combinedClickable.<anonymous> (Clickable.kt:545)");
            }
            T t2 = (T) interfaceC0768p.consume(V.getLocalIndication());
            if (t2 instanceof Y) {
                interfaceC0768p.startReplaceGroup(-1270399604);
                interfaceC0768p.endReplaceGroup();
                nVar = null;
            } else {
                interfaceC0768p.startReplaceGroup(-1270266986);
                Object objRememberedValue = interfaceC0768p.rememberedValue();
                if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                    interfaceC0768p.updateRememberedValue(objRememberedValue);
                }
                nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
                interfaceC0768p.endReplaceGroup();
            }
            androidx.compose.ui.x xVarM1652combinedClickableauXiCPI = AbstractC0641u.m1652combinedClickableauXiCPI(androidx.compose.ui.x.Companion, nVar, t2, this.$enabled, this.$onClickLabel, this.$role, this.$onLongClickLabel, this.$onLongClick, this.$onDoubleClick, true, this.$onClick);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarM1652combinedClickableauXiCPI;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$j */
    public static final class j implements h1.f {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ T $indication;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ h1.a $onDoubleClick$inlined;
        final /* synthetic */ h1.a $onLongClick$inlined;
        final /* synthetic */ String $onLongClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        public j(T t2, boolean z2, String str, C1116j c1116j, h1.a aVar, String str2, h1.a aVar2, h1.a aVar3) {
            this.$indication = t2;
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
            this.$onLongClickLabel$inlined = str2;
            this.$onLongClick$inlined = aVar2;
            this.$onDoubleClick$inlined = aVar3;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1525724089);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1525724089, i2, -1, "androidx.compose.foundation.clickableWithIndicationIfNeeded.<anonymous> (Clickable.kt:708)");
            }
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.foundation.interaction.n nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
            androidx.compose.ui.x xVarThen = V.indication(androidx.compose.ui.x.Companion, nVar, this.$indication).then(new CombinedClickableElement(nVar, null, false, this.$enabled$inlined, this.$onClickLabel$inlined, this.$role$inlined, this.$onClick$inlined, this.$onLongClickLabel$inlined, this.$onLongClick$inlined, this.$onDoubleClick$inlined, true, null));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarThen;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$k */
    public static final class k implements h1.f {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ boolean $hapticFeedbackEnabled$inlined;
        final /* synthetic */ T $indication;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ h1.a $onDoubleClick$inlined;
        final /* synthetic */ h1.a $onLongClick$inlined;
        final /* synthetic */ String $onLongClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        public k(T t2, boolean z2, String str, C1116j c1116j, h1.a aVar, String str2, h1.a aVar2, h1.a aVar3, boolean z3) {
            this.$indication = t2;
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
            this.$onLongClickLabel$inlined = str2;
            this.$onLongClick$inlined = aVar2;
            this.$onDoubleClick$inlined = aVar3;
            this.$hapticFeedbackEnabled$inlined = z3;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1525724089);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1525724089, i2, -1, "androidx.compose.foundation.clickableWithIndicationIfNeeded.<anonymous> (Clickable.kt:708)");
            }
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = androidx.compose.foundation.interaction.m.MutableInteractionSource();
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.foundation.interaction.n nVar = (androidx.compose.foundation.interaction.n) objRememberedValue;
            androidx.compose.ui.x xVarThen = V.indication(androidx.compose.ui.x.Companion, nVar, this.$indication).then(new CombinedClickableElement(nVar, null, false, this.$enabled$inlined, this.$onClickLabel$inlined, this.$role$inlined, this.$onClick$inlined, this.$onLongClickLabel$inlined, this.$onLongClick$inlined, this.$onDoubleClick$inlined, this.$hapticFeedbackEnabled$inlined, null));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarThen;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$l */
    public static final class l extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ h1.a $onDoubleClick$inlined;
        final /* synthetic */ h1.a $onLongClick$inlined;
        final /* synthetic */ String $onLongClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public l(boolean z2, String str, C1116j c1116j, h1.a aVar, h1.a aVar2, h1.a aVar3, String str2) {
            super(1);
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
            this.$onDoubleClick$inlined = aVar2;
            this.$onLongClick$inlined = aVar3;
            this.$onLongClickLabel$inlined = str2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("combinedClickable");
            D0.d.l(this.$enabled$inlined, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.$onClickLabel$inlined);
            c1065l1.getProperties().set("role", this.$role$inlined);
            c1065l1.getProperties().set("onClick", this.$onClick$inlined);
            c1065l1.getProperties().set("onDoubleClick", this.$onDoubleClick$inlined);
            c1065l1.getProperties().set("onLongClick", this.$onLongClick$inlined);
            c1065l1.getProperties().set("onLongClickLabel", this.$onLongClickLabel$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$m */
    public static final class m extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ boolean $hapticFeedbackEnabled$inlined;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ h1.a $onDoubleClick$inlined;
        final /* synthetic */ h1.a $onLongClick$inlined;
        final /* synthetic */ String $onLongClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public m(boolean z2, String str, C1116j c1116j, h1.a aVar, h1.a aVar2, h1.a aVar3, String str2, boolean z3) {
            super(1);
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
            this.$onDoubleClick$inlined = aVar2;
            this.$onLongClick$inlined = aVar3;
            this.$onLongClickLabel$inlined = str2;
            this.$hapticFeedbackEnabled$inlined = z3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("combinedClickable");
            D0.d.l(this.$enabled$inlined, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.$onClickLabel$inlined);
            c1065l1.getProperties().set("role", this.$role$inlined);
            c1065l1.getProperties().set("onClick", this.$onClick$inlined);
            c1065l1.getProperties().set("onDoubleClick", this.$onDoubleClick$inlined);
            c1065l1.getProperties().set("onLongClick", this.$onLongClick$inlined);
            c1065l1.getProperties().set("onLongClickLabel", this.$onLongClickLabel$inlined);
            c1065l1.getProperties().set("hapticFeedbackEnabled", Boolean.valueOf(this.$hapticFeedbackEnabled$inlined));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.u$n */
    public static final class n extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $enabled$inlined;
        final /* synthetic */ boolean $hapticFeedbackEnabled$inlined;
        final /* synthetic */ h1.a $onClick$inlined;
        final /* synthetic */ String $onClickLabel$inlined;
        final /* synthetic */ h1.a $onDoubleClick$inlined;
        final /* synthetic */ h1.a $onLongClick$inlined;
        final /* synthetic */ String $onLongClickLabel$inlined;
        final /* synthetic */ C1116j $role$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public n(boolean z2, String str, C1116j c1116j, h1.a aVar, h1.a aVar2, h1.a aVar3, String str2, boolean z3) {
            super(1);
            this.$enabled$inlined = z2;
            this.$onClickLabel$inlined = str;
            this.$role$inlined = c1116j;
            this.$onClick$inlined = aVar;
            this.$onDoubleClick$inlined = aVar2;
            this.$onLongClick$inlined = aVar3;
            this.$onLongClickLabel$inlined = str2;
            this.$hapticFeedbackEnabled$inlined = z3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("combinedClickable");
            D0.d.l(this.$enabled$inlined, c1065l1.getProperties(), "enabled", c1065l1).set("onClickLabel", this.$onClickLabel$inlined);
            c1065l1.getProperties().set("role", this.$role$inlined);
            c1065l1.getProperties().set("onClick", this.$onClick$inlined);
            c1065l1.getProperties().set("onDoubleClick", this.$onDoubleClick$inlined);
            c1065l1.getProperties().set("onLongClick", this.$onLongClick$inlined);
            c1065l1.getProperties().set("onLongClickLabel", this.$onLongClickLabel$inlined);
            c1065l1.getProperties().set("hapticFeedbackEnabled", Boolean.valueOf(this.$hapticFeedbackEnabled$inlined));
        }
    }

    /* JADX INFO: renamed from: clickable-O2vRcR0, reason: not valid java name */
    public static final androidx.compose.ui.x m1644clickableO2vRcR0(androidx.compose.ui.x xVar, androidx.compose.foundation.interaction.n nVar, T t2, boolean z2, String str, C1116j c1116j, h1.a aVar) {
        androidx.compose.ui.x xVarComposed$default;
        if (t2 instanceof Y) {
            xVarComposed$default = new ClickableElement(nVar, (Y) t2, false, z2, str, c1116j, aVar, null);
        } else if (t2 == null) {
            xVarComposed$default = new ClickableElement(nVar, null, false, z2, str, c1116j, aVar, null);
        } else if (nVar != null) {
            xVarComposed$default = V.indication(androidx.compose.ui.x.Companion, nVar, t2).then(new ClickableElement(nVar, null, false, z2, str, c1116j, aVar, null));
        } else {
            xVarComposed$default = androidx.compose.ui.n.composed$default(androidx.compose.ui.x.Companion, null, new c(t2, z2, str, c1116j, aVar), 1, null);
        }
        return xVar.then(xVarComposed$default);
    }

    /* JADX INFO: renamed from: clickable-O2vRcR0$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1645clickableO2vRcR0$default(androidx.compose.ui.x xVar, androidx.compose.foundation.interaction.n nVar, T t2, boolean z2, String str, C1116j c1116j, h1.a aVar, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        return m1644clickableO2vRcR0(xVar, nVar, t2, z2, (i2 & 8) != 0 ? null : str, (i2 & 16) != 0 ? null : c1116j, aVar);
    }

    @U0.a
    /* JADX INFO: renamed from: clickable-XHw0xAI, reason: not valid java name */
    public static final /* synthetic */ androidx.compose.ui.x m1646clickableXHw0xAI(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, h1.a aVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new d(z2, str, c1116j, aVar) : AbstractC1056i1.getNoInspectorInfo(), new a(z2, str, c1116j, aVar));
    }

    /* JADX INFO: renamed from: clickable-XHw0xAI$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1647clickableXHw0xAI$default(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, h1.a aVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        if ((i2 & 2) != 0) {
            str = null;
        }
        if ((i2 & 4) != 0) {
            c1116j = null;
        }
        return m1646clickableXHw0xAI(xVar, z2, str, c1116j, aVar);
    }

    /* JADX INFO: renamed from: clickable-oSLSa3U, reason: not valid java name */
    public static final androidx.compose.ui.x m1648clickableoSLSa3U(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, androidx.compose.foundation.interaction.n nVar, h1.a aVar) {
        if (A.isNonComposedClickableEnabled) {
            return xVar.then(new ClickableElement(nVar, null, true, z2, str, c1116j, aVar, null));
        }
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new e(z2, str, c1116j, nVar, aVar) : AbstractC1056i1.getNoInspectorInfo(), new b(nVar, z2, str, c1116j, aVar));
    }

    /* JADX INFO: renamed from: clickable-oSLSa3U$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1649clickableoSLSa3U$default(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, androidx.compose.foundation.interaction.n nVar, h1.a aVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        return m1648clickableoSLSa3U(xVar, z2, (i2 & 2) != 0 ? null : str, (i2 & 4) != 0 ? null : c1116j, (i2 & 8) != 0 ? null : nVar, aVar);
    }

    public static final androidx.compose.ui.x clickableWithIndicationIfNeeded(androidx.compose.ui.x xVar, androidx.compose.foundation.interaction.n nVar, T t2, h1.e eVar) {
        return xVar.then(t2 instanceof Y ? (androidx.compose.ui.x) eVar.invoke(nVar, t2) : t2 == null ? (androidx.compose.ui.x) eVar.invoke(nVar, null) : nVar != null ? V.indication(androidx.compose.ui.x.Companion, nVar, t2).then((androidx.compose.ui.x) eVar.invoke(nVar, null)) : androidx.compose.ui.n.composed$default(androidx.compose.ui.x.Companion, null, new f(t2, eVar), 1, null));
    }

    @U0.a
    /* JADX INFO: renamed from: combinedClickable-XVZzFYc, reason: not valid java name */
    public static final /* synthetic */ androidx.compose.ui.x m1650combinedClickableXVZzFYc(androidx.compose.ui.x xVar, androidx.compose.foundation.interaction.n nVar, T t2, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, h1.a aVar3) {
        androidx.compose.ui.x xVarComposed$default;
        if (t2 instanceof Y) {
            xVarComposed$default = new CombinedClickableElement(nVar, (Y) t2, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, true, null);
        } else if (t2 == null) {
            xVarComposed$default = new CombinedClickableElement(nVar, null, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, true, null);
        } else if (nVar != null) {
            xVarComposed$default = V.indication(androidx.compose.ui.x.Companion, nVar, t2).then(new CombinedClickableElement(nVar, null, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, true, null));
        } else {
            xVarComposed$default = androidx.compose.ui.n.composed$default(androidx.compose.ui.x.Companion, null, new j(t2, z2, str, c1116j, aVar3, str2, aVar, aVar2), 1, null);
        }
        return xVar.then(xVarComposed$default);
    }

    /* JADX INFO: renamed from: combinedClickable-auXiCPI, reason: not valid java name */
    public static final androidx.compose.ui.x m1652combinedClickableauXiCPI(androidx.compose.ui.x xVar, androidx.compose.foundation.interaction.n nVar, T t2, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, boolean z3, h1.a aVar3) {
        androidx.compose.ui.x xVarComposed$default;
        if (t2 instanceof Y) {
            xVarComposed$default = new CombinedClickableElement(nVar, (Y) t2, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, z3, null);
        } else if (t2 == null) {
            xVarComposed$default = new CombinedClickableElement(nVar, null, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, z3, null);
        } else if (nVar != null) {
            xVarComposed$default = V.indication(androidx.compose.ui.x.Companion, nVar, t2).then(new CombinedClickableElement(nVar, null, false, z2, str, c1116j, aVar3, str2, aVar, aVar2, z3, null));
        } else {
            xVarComposed$default = androidx.compose.ui.n.composed$default(androidx.compose.ui.x.Companion, null, new k(t2, z2, str, c1116j, aVar3, str2, aVar, aVar2, z3), 1, null);
        }
        return xVar.then(xVarComposed$default);
    }

    @U0.a
    /* JADX INFO: renamed from: combinedClickable-cJG_KMw, reason: not valid java name */
    public static final /* synthetic */ androidx.compose.ui.x m1654combinedClickablecJG_KMw(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, h1.a aVar3) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new l(z2, str, c1116j, aVar3, aVar2, aVar, str2) : AbstractC1056i1.getNoInspectorInfo(), new i(z2, str, c1116j, str2, aVar, aVar2, aVar3));
    }

    @U0.a
    /* JADX INFO: renamed from: combinedClickable-f5TDLPQ, reason: not valid java name */
    public static final /* synthetic */ androidx.compose.ui.x m1656combinedClickablef5TDLPQ(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, boolean z3, h1.a aVar3) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new m(z2, str, c1116j, aVar3, aVar2, aVar, str2, z3) : AbstractC1056i1.getNoInspectorInfo(), new g(z2, str, c1116j, str2, aVar, aVar2, z3, aVar3));
    }

    /* JADX INFO: renamed from: combinedClickable-hoGz1lA, reason: not valid java name */
    public static final androidx.compose.ui.x m1658combinedClickablehoGz1lA(androidx.compose.ui.x xVar, boolean z2, String str, C1116j c1116j, String str2, h1.a aVar, h1.a aVar2, boolean z3, androidx.compose.foundation.interaction.n nVar, h1.a aVar3) {
        if (A.isNonComposedClickableEnabled) {
            return xVar.then(new CombinedClickableElement(nVar, null, true, z2, str, c1116j, aVar3, str2, aVar, aVar2, z3, null));
        }
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new n(z2, str, c1116j, aVar3, aVar2, aVar, str2, z3) : AbstractC1056i1.getNoInspectorInfo(), new h(nVar, z2, str, c1116j, str2, aVar, aVar2, z3, aVar3));
    }

    public static final boolean hasScrollableContainer(a1 a1Var) {
        kotlin.jvm.internal.A a2 = new kotlin.jvm.internal.A();
        b1.traverseAncestors(a1Var, androidx.compose.foundation.gestures.T.TraverseKey, new C0522t(a2, 0));
        return a2.f3114b;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final boolean hasScrollableContainer$lambda$8(kotlin.jvm.internal.A r2, androidx.compose.ui.node.a1 r3) {
        /*
            boolean r0 = r2.f3114b
            r1 = 1
            if (r0 != 0) goto L15
            java.lang.String r0 = "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableContainerNode"
            kotlin.jvm.internal.o.c(r3, r0)
            androidx.compose.foundation.gestures.T r3 = (androidx.compose.foundation.gestures.T) r3
            boolean r3 = r3.getEnabled()
            if (r3 == 0) goto L13
            goto L15
        L13:
            r3 = 0
            goto L16
        L15:
            r3 = r1
        L16:
            r2.f3114b = r3
            r2 = r3 ^ 1
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.AbstractC0641u.hasScrollableContainer$lambda$8(kotlin.jvm.internal.A, androidx.compose.ui.node.a1):boolean");
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: isClick-ZmokQxo, reason: not valid java name */
    public static final boolean m1660isClickZmokQxo(KeyEvent keyEvent) {
        return P.c.m508equalsimpl0(P.d.m516getTypeZmokQxo(keyEvent), P.c.Companion.m513getKeyUpCS__XNY()) && m1661isEnterZmokQxo(keyEvent);
    }

    /* JADX INFO: renamed from: isEnter-ZmokQxo, reason: not valid java name */
    private static final boolean m1661isEnterZmokQxo(KeyEvent keyEvent) {
        long jM515getKeyZmokQxo = P.d.m515getKeyZmokQxo(keyEvent);
        a.C0003a c0003a = P.a.Companion;
        return P.a.m207equalsimpl0(jM515getKeyZmokQxo, c0003a.m279getDirectionCenterEK5gGoQ()) || P.a.m207equalsimpl0(jM515getKeyZmokQxo, c0003a.m293getEnterEK5gGoQ()) || P.a.m207equalsimpl0(jM515getKeyZmokQxo, c0003a.m385getNumPadEnterEK5gGoQ()) || P.a.m207equalsimpl0(jM515getKeyZmokQxo, c0003a.m431getSpacebarEK5gGoQ());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: isPress-ZmokQxo, reason: not valid java name */
    public static final boolean m1662isPressZmokQxo(KeyEvent keyEvent) {
        return P.c.m508equalsimpl0(P.d.m516getTypeZmokQxo(keyEvent), P.c.Companion.m512getKeyDownCS__XNY()) && m1661isEnterZmokQxo(keyEvent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String unsupportedIndicationExceptionMessage(T t2) {
        return "clickable only supports IndicationNodeFactory instances provided to LocalIndication, but Indication was provided instead. Either migrate the Indication implementation to implement IndicationNodeFactory, or use the other clickable overload that takes an Indication parameter, and explicitly pass LocalIndication.current there. You can also use ComposeFoundationFlags.isNonComposedClickableEnabled to temporarily opt-out; note that this flag will be removed in a future release and is only intended to be a temporary migration aid. The Indication instance provided here was: " + t2;
    }
}
