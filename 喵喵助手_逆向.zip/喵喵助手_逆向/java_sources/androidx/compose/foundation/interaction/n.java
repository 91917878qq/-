package androidx.compose.foundation.interaction;

import u1.InterfaceC1491d;

/* JADX INFO: loaded from: classes.dex */
public interface n extends l {
    Object emit(k kVar, Y0.c cVar);

    @Override // androidx.compose.foundation.interaction.l
    /* synthetic */ InterfaceC1491d getInteractions();

    boolean tryEmit(k kVar);
}
