package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {
    public static final n MutableInteractionSource() {
        return new o();
    }
}
