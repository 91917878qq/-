package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class f implements k {
    public static final int $stable = 0;
    private final e focus;

    public f(e eVar) {
        this.focus = eVar;
    }

    public final e getFocus() {
        return this.focus;
    }
}
