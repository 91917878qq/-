package androidx.compose.foundation.interaction;

import u1.InterfaceC1491d;

/* JADX INFO: loaded from: classes.dex */
public interface l {
    InterfaceC1491d getInteractions();
}
