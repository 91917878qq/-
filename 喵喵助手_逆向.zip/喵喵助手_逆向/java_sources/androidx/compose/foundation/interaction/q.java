package androidx.compose.foundation.interaction;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class q implements s {
    public static final int $stable = 0;
    private final long pressPosition;

    public /* synthetic */ q(long j2, AbstractC1378g abstractC1378g) {
        this(j2);
    }

    /* JADX INFO: renamed from: getPressPosition-F1C5BW0, reason: not valid java name */
    public final long m887getPressPositionF1C5BW0() {
        return this.pressPosition;
    }

    private q(long j2) {
        this.pressPosition = j2;
    }
}
