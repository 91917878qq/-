package androidx.compose.foundation.interaction;

import a.AbstractC0292a;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.Z;
import androidx.compose.runtime.d2;
import java.util.ArrayList;
import java.util.List;
import r1.InterfaceC1474x;
import u1.InterfaceC1491d;
import u1.InterfaceC1492e;

/* JADX INFO: loaded from: classes.dex */
public abstract class t {

    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ B0 $isPressed;
        final /* synthetic */ l $this_collectIsPressedAsState;
        int label;

        /* JADX INFO: renamed from: androidx.compose.foundation.interaction.t$a$a, reason: collision with other inner class name */
        public static final class C0035a implements InterfaceC1492e {
            final /* synthetic */ B0 $isPressed;
            final /* synthetic */ List<q> $pressInteractions;

            public C0035a(List<q> list, B0 b02) {
                this.$pressInteractions = list;
                this.$isPressed = b02;
            }

            @Override // u1.InterfaceC1492e
            public final Object emit(k kVar, Y0.c cVar) {
                if (kVar instanceof q) {
                    this.$pressInteractions.add(kVar);
                } else if (kVar instanceof r) {
                    this.$pressInteractions.remove(((r) kVar).getPress());
                } else if (kVar instanceof p) {
                    this.$pressInteractions.remove(((p) kVar).getPress());
                }
                this.$isPressed.setValue(Boolean.valueOf(!this.$pressInteractions.isEmpty()));
                return U0.n.f1521a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(l lVar, B0 b02, Y0.c cVar) {
            super(2, cVar);
            this.$this_collectIsPressedAsState = lVar;
            this.$isPressed = b02;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new a(this.$this_collectIsPressedAsState, this.$isPressed, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                ArrayList arrayList = new ArrayList();
                InterfaceC1491d interactions = this.$this_collectIsPressedAsState.getInteractions();
                C0035a c0035a = new C0035a(arrayList, this.$isPressed);
                this.label = 1;
                if (interactions.b(c0035a, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final d2 collectIsPressedAsState(l lVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1692965168, i2, -1, "androidx.compose.foundation.interaction.collectIsPressedAsState (PressInteraction.kt:80)");
        }
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        C0765o c0765o = InterfaceC0768p.Companion;
        if (objRememberedValue == c0765o.getEmpty()) {
            objRememberedValue = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        B0 b02 = (B0) objRememberedValue;
        int i3 = i2 & 14;
        boolean z2 = ((i3 ^ 6) > 4 && interfaceC0768p.changed(lVar)) || (i2 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue2 == c0765o.getEmpty()) {
            objRememberedValue2 = new a(lVar, b02, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        Z.LaunchedEffect(lVar, (h1.e) objRememberedValue2, interfaceC0768p, i3);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return b02;
    }
}
