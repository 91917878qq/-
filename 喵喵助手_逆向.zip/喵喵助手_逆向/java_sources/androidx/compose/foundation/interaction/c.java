package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class c implements d {
    public static final int $stable = 0;
    private final b start;

    public c(b bVar) {
        this.start = bVar;
    }

    public final b getStart() {
        return this.start;
    }
}
