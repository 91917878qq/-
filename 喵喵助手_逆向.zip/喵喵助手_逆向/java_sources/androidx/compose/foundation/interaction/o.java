package androidx.compose.foundation.interaction;

import u1.D;
import u1.x;

/* JADX INFO: loaded from: classes.dex */
public final class o implements n {
    private final x interactions = D.a(0, 16, t1.a.f3434c, 1);

    @Override // androidx.compose.foundation.interaction.n
    public Object emit(k kVar, Y0.c cVar) {
        Object objEmit = getInteractions().emit(kVar, cVar);
        return objEmit == Z0.a.f1616b ? objEmit : U0.n.f1521a;
    }

    @Override // androidx.compose.foundation.interaction.n
    public boolean tryEmit(k kVar) {
        return getInteractions().g(kVar);
    }

    @Override // androidx.compose.foundation.interaction.n, androidx.compose.foundation.interaction.l
    public x getInteractions() {
        return this.interactions;
    }
}
