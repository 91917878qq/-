package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class i implements k {
    public static final int $stable = 0;
    private final h enter;

    public i(h hVar) {
        this.enter = hVar;
    }

    public final h getEnter() {
        return this.enter;
    }
}
