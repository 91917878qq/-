package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class r implements s {
    public static final int $stable = 0;
    private final q press;

    public r(q qVar) {
        this.press = qVar;
    }

    public final q getPress() {
        return this.press;
    }
}
