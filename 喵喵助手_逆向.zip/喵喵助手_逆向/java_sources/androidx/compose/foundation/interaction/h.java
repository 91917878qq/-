package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class h implements k {
    public static final int $stable = 0;
}
