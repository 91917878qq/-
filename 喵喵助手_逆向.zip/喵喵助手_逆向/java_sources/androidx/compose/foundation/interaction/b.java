package androidx.compose.foundation.interaction;

/* JADX INFO: loaded from: classes.dex */
public final class b implements d {
    public static final int $stable = 0;
}
