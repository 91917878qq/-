package androidx.compose.foundation;

import a.AbstractC0292a;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReference;
import r1.AbstractC1476z;
import r1.C1449a0;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.e0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0372e0 {
    public static final int $stable = 0;
    private final AtomicReference<a> currentMutator = new AtomicReference<>(null);
    private final z1.a mutex = z1.e.a();

    /* JADX INFO: renamed from: androidx.compose.foundation.e0$a */
    public static final class a {
        private final InterfaceC1451b0 job;
        private final EnumC0368c0 priority;

        public a(EnumC0368c0 enumC0368c0, InterfaceC1451b0 interfaceC1451b0) {
            this.priority = enumC0368c0;
            this.job = interfaceC1451b0;
        }

        public final boolean canInterrupt(a aVar) {
            return this.priority.compareTo(aVar.priority) >= 0;
        }

        public final void cancel() {
            this.job.cancel(new C0370d0());
        }

        public final InterfaceC1451b0 getJob() {
            return this.job;
        }

        public final EnumC0368c0 getPriority() {
            return this.priority;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.e0$b */
    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ h1.c $block;
        final /* synthetic */ EnumC0368c0 $priority;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        final /* synthetic */ C0372e0 this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(EnumC0368c0 enumC0368c0, C0372e0 c0372e0, h1.c cVar, Y0.c cVar2) {
            super(2, cVar2);
            this.$priority = enumC0368c0;
            this.this$0 = c0372e0;
            this.$block = cVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = new b(this.$priority, this.this$0, this.$block, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        /* JADX WARN: Type inference failed for: r1v0, types: [int] */
        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            h1.c cVar;
            a aVar;
            C0372e0 c0372e0;
            z1.a aVar2;
            a aVar3;
            Throwable th;
            C0372e0 c0372e02;
            z1.a aVar4;
            AtomicReference atomicReference;
            AtomicReference atomicReference2;
            Z0.a aVar5 = Z0.a.f1616b;
            ?? r12 = this.label;
            try {
                try {
                    if (r12 == 0) {
                        AbstractC0292a.H(obj);
                        InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                        EnumC0368c0 enumC0368c0 = this.$priority;
                        Y0.f fVar = interfaceC1474x.getCoroutineContext().get(C1449a0.f3342b);
                        kotlin.jvm.internal.o.b(fVar);
                        a aVar6 = new a(enumC0368c0, (InterfaceC1451b0) fVar);
                        this.this$0.tryMutateOrCancel(aVar6);
                        z1.a aVar7 = this.this$0.mutex;
                        h1.c cVar2 = this.$block;
                        C0372e0 c0372e03 = this.this$0;
                        this.L$0 = aVar6;
                        this.L$1 = aVar7;
                        this.L$2 = cVar2;
                        this.L$3 = c0372e03;
                        this.label = 1;
                        z1.d dVar = (z1.d) aVar7;
                        if (dVar.d(null, this) == aVar5) {
                            return aVar5;
                        }
                        cVar = cVar2;
                        aVar = aVar6;
                        c0372e0 = c0372e03;
                        aVar2 = dVar;
                    } else {
                        if (r12 != 1) {
                            if (r12 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            c0372e02 = (C0372e0) this.L$2;
                            z1.a aVar8 = (z1.a) this.L$1;
                            aVar3 = (a) this.L$0;
                            try {
                                AbstractC0292a.H(obj);
                                aVar4 = aVar8;
                                atomicReference2 = c0372e02.currentMutator;
                                while (!atomicReference2.compareAndSet(aVar3, null) && atomicReference2.get() == aVar3) {
                                }
                                ((z1.d) aVar4).f(null);
                                return obj;
                            } catch (Throwable th2) {
                                th = th2;
                                atomicReference = c0372e02.currentMutator;
                                while (!atomicReference.compareAndSet(aVar3, null) && atomicReference.get() == aVar3) {
                                }
                                throw th;
                            }
                        }
                        c0372e0 = (C0372e0) this.L$3;
                        cVar = (h1.c) this.L$2;
                        z1.a aVar9 = (z1.a) this.L$1;
                        aVar = (a) this.L$0;
                        AbstractC0292a.H(obj);
                        aVar2 = aVar9;
                    }
                    this.L$0 = aVar;
                    this.L$1 = aVar2;
                    this.L$2 = c0372e0;
                    this.L$3 = null;
                    this.label = 2;
                    Object objInvoke = cVar.invoke(this);
                    if (objInvoke == aVar5) {
                        return aVar5;
                    }
                    c0372e02 = c0372e0;
                    aVar4 = aVar2;
                    obj = objInvoke;
                    aVar3 = aVar;
                    atomicReference2 = c0372e02.currentMutator;
                    while (!atomicReference2.compareAndSet(aVar3, null)) {
                    }
                    ((z1.d) aVar4).f(null);
                    return obj;
                } catch (Throwable th3) {
                    aVar3 = aVar;
                    th = th3;
                    c0372e02 = c0372e0;
                    atomicReference = c0372e02.currentMutator;
                    while (!atomicReference.compareAndSet(aVar3, null)) {
                    }
                    throw th;
                }
            } catch (Throwable th4) {
                ((z1.d) r12).f(null);
                throw th4;
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.e0$c */
    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ EnumC0368c0 $priority;
        final /* synthetic */ T $receiver;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        final /* synthetic */ C0372e0 this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(EnumC0368c0 enumC0368c0, C0372e0 c0372e0, h1.e eVar, T t2, Y0.c cVar) {
            super(2, cVar);
            this.$priority = enumC0368c0;
            this.this$0 = c0372e0;
            this.$block = eVar;
            this.$receiver = t2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            c cVar2 = new c(this.$priority, this.this$0, this.$block, this.$receiver, cVar);
            cVar2.L$0 = obj;
            return cVar2;
        }

        /* JADX WARN: Type inference failed for: r1v0, types: [int] */
        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            h1.e eVar;
            Object obj2;
            a aVar;
            C0372e0 c0372e0;
            z1.a aVar2;
            a aVar3;
            Throwable th;
            C0372e0 c0372e02;
            z1.a aVar4;
            AtomicReference atomicReference;
            AtomicReference atomicReference2;
            Z0.a aVar5 = Z0.a.f1616b;
            ?? r12 = this.label;
            try {
                try {
                    if (r12 == 0) {
                        AbstractC0292a.H(obj);
                        InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                        EnumC0368c0 enumC0368c0 = this.$priority;
                        Y0.f fVar = interfaceC1474x.getCoroutineContext().get(C1449a0.f3342b);
                        kotlin.jvm.internal.o.b(fVar);
                        a aVar6 = new a(enumC0368c0, (InterfaceC1451b0) fVar);
                        this.this$0.tryMutateOrCancel(aVar6);
                        z1.a aVar7 = this.this$0.mutex;
                        eVar = this.$block;
                        Object obj3 = this.$receiver;
                        C0372e0 c0372e03 = this.this$0;
                        this.L$0 = aVar6;
                        this.L$1 = aVar7;
                        this.L$2 = eVar;
                        this.L$3 = obj3;
                        this.L$4 = c0372e03;
                        this.label = 1;
                        z1.d dVar = (z1.d) aVar7;
                        if (dVar.d(null, this) == aVar5) {
                            return aVar5;
                        }
                        obj2 = obj3;
                        aVar = aVar6;
                        c0372e0 = c0372e03;
                        aVar2 = dVar;
                    } else {
                        if (r12 != 1) {
                            if (r12 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            c0372e02 = (C0372e0) this.L$2;
                            z1.a aVar8 = (z1.a) this.L$1;
                            aVar3 = (a) this.L$0;
                            try {
                                AbstractC0292a.H(obj);
                                aVar4 = aVar8;
                                atomicReference2 = c0372e02.currentMutator;
                                while (!atomicReference2.compareAndSet(aVar3, null) && atomicReference2.get() == aVar3) {
                                }
                                ((z1.d) aVar4).f(null);
                                return obj;
                            } catch (Throwable th2) {
                                th = th2;
                                atomicReference = c0372e02.currentMutator;
                                while (!atomicReference.compareAndSet(aVar3, null)) {
                                }
                                throw th;
                            }
                        }
                        c0372e0 = (C0372e0) this.L$4;
                        obj2 = this.L$3;
                        eVar = (h1.e) this.L$2;
                        z1.a aVar9 = (z1.a) this.L$1;
                        aVar = (a) this.L$0;
                        AbstractC0292a.H(obj);
                        aVar2 = aVar9;
                    }
                    this.L$0 = aVar;
                    this.L$1 = aVar2;
                    this.L$2 = c0372e0;
                    this.L$3 = null;
                    this.L$4 = null;
                    this.label = 2;
                    Object objInvoke = eVar.invoke(obj2, this);
                    if (objInvoke == aVar5) {
                        return aVar5;
                    }
                    c0372e02 = c0372e0;
                    aVar4 = aVar2;
                    obj = objInvoke;
                    aVar3 = aVar;
                    atomicReference2 = c0372e02.currentMutator;
                    while (!atomicReference2.compareAndSet(aVar3, null)) {
                    }
                    ((z1.d) aVar4).f(null);
                    return obj;
                } catch (Throwable th3) {
                    aVar3 = aVar;
                    th = th3;
                    c0372e02 = c0372e0;
                    atomicReference = c0372e02.currentMutator;
                    while (!atomicReference.compareAndSet(aVar3, null) && atomicReference.get() == aVar3) {
                    }
                    throw th;
                }
            } catch (Throwable th4) {
                ((z1.d) r12).f(null);
                throw th4;
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static /* synthetic */ Object mutate$default(C0372e0 c0372e0, EnumC0368c0 enumC0368c0, h1.c cVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return c0372e0.mutate(enumC0368c0, cVar, cVar2);
    }

    public static /* synthetic */ Object mutateWith$default(C0372e0 c0372e0, Object obj, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar, int i2, Object obj2) {
        if ((i2 & 2) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return c0372e0.mutateWith(obj, enumC0368c0, eVar, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void tryMutateOrCancel(a aVar) {
        while (true) {
            a aVar2 = this.currentMutator.get();
            if (aVar2 != null && !aVar.canInterrupt(aVar2)) {
                throw new CancellationException("Current mutation had a higher priority");
            }
            AtomicReference<a> atomicReference = this.currentMutator;
            while (!atomicReference.compareAndSet(aVar2, aVar)) {
                if (atomicReference.get() != aVar2) {
                    break;
                }
            }
            if (aVar2 != null) {
                aVar2.cancel();
                return;
            }
            return;
        }
    }

    public final <R> Object mutate(EnumC0368c0 enumC0368c0, h1.c cVar, Y0.c cVar2) {
        return AbstractC1476z.e(new b(enumC0368c0, this, cVar, null), cVar2);
    }

    public final <T, R> Object mutateWith(T t2, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
        return AbstractC1476z.e(new c(enumC0368c0, this, eVar, t2, null), cVar);
    }

    public final boolean tryLock() {
        return ((z1.d) this.mutex).e(null);
    }

    public final boolean tryMutate(h1.a aVar) {
        boolean zTryLock = tryLock();
        if (zTryLock) {
            try {
                aVar.invoke();
            } finally {
                unlock();
            }
        }
        return zTryLock;
    }

    public final void unlock() {
        ((z1.d) this.mutex).f(null);
    }
}
