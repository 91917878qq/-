package androidx.compose.foundation;

import androidx.compose.ui.node.InterfaceC1007o;

/* JADX INFO: loaded from: classes.dex */
public interface i0 {

    public static final class a extends androidx.compose.ui.w {
        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }
    }

    @U0.a
    static /* synthetic */ void getEffectModifier$annotations() {
    }

    /* JADX INFO: renamed from: applyToFling-BMRW4eQ */
    Object mo694applyToFlingBMRW4eQ(long j2, h1.e eVar, Y0.c cVar);

    /* JADX INFO: renamed from: applyToScroll-Rhakbz0 */
    long mo695applyToScrollRhakbz0(long j2, int i2, h1.c cVar);

    default androidx.compose.ui.x getEffectModifier() {
        return androidx.compose.ui.x.Companion;
    }

    default InterfaceC1007o getNode() {
        return new a();
    }

    boolean isInProgress();
}
