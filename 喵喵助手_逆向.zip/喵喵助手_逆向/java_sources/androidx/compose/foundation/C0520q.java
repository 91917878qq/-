package androidx.compose.foundation;

/* JADX INFO: renamed from: androidx.compose.foundation.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0520q implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1992b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f1993c;

    public /* synthetic */ C0520q(String str, int i2) {
        this.f1992b = i2;
        this.f1993c = str;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1992b) {
            case 0:
                return r.Canvas$lambda$2$lambda$1(this.f1993c, (androidx.compose.ui.semantics.E) obj);
            default:
                return S.Image$lambda$2$lambda$1(this.f1993c, (androidx.compose.ui.semantics.E) obj);
        }
    }
}
