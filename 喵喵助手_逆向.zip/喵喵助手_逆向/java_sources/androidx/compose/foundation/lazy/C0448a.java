package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.X;
import androidx.compose.foundation.lazy.layout.q0;
import androidx.compose.foundation.lazy.layout.x0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0448a implements H {
    private X currentPrefetchHandle;
    private int indexToPrefetch;
    private final int initialNestedPrefetchItemCount;
    private float previousPassDelta;
    private int previousPassItemCount;
    private boolean wasScrollingForward;

    public C0448a() {
        this(0, 1, null);
    }

    private final int calculateIndexToPrefetch(y yVar, boolean z2) {
        return z2 ? ((InterfaceC0494p) V0.t.z0(yVar.getVisibleItemsInfo())).getIndex() + 1 : ((InterfaceC0494p) V0.t.u0(yVar.getVisibleItemsInfo())).getIndex() - 1;
    }

    private final void evaluatePrefetchForCancellation(y yVar, int i2, boolean z2) {
        if (i2 == -1 || yVar.getVisibleItemsInfo().isEmpty() || i2 == calculateIndexToPrefetch(yVar, z2)) {
            return;
        }
        resetPrefetchState();
    }

    private final void resetPrefetchState() {
        this.indexToPrefetch = -1;
        X x2 = this.currentPrefetchHandle;
        if (x2 != null) {
            x2.cancel();
        }
        this.currentPrefetchHandle = null;
    }

    @Override // androidx.compose.foundation.lazy.H
    public /* bridge */ /* synthetic */ x0 getPrefetchScheduler() {
        return super.getPrefetchScheduler();
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onNestedPrefetch(q0 q0Var, int i2) {
        int nestedPrefetchItemCount = q0Var.getNestedPrefetchItemCount() == -1 ? this.initialNestedPrefetchItemCount : q0Var.getNestedPrefetchItemCount();
        for (int i3 = 0; i3 < nestedPrefetchItemCount; i3++) {
            q0Var.schedulePrecomposition(i2 + i3);
        }
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onScroll(G g2, float f2, y yVar) {
        X x2;
        X x3;
        if (!yVar.getVisibleItemsInfo().isEmpty()) {
            boolean z2 = f2 < 0.0f;
            int iCalculateIndexToPrefetch = calculateIndexToPrefetch(yVar, z2);
            if (iCalculateIndexToPrefetch >= 0 && iCalculateIndexToPrefetch < yVar.getTotalItemsCount()) {
                if (iCalculateIndexToPrefetch != this.indexToPrefetch) {
                    if (this.wasScrollingForward != z2) {
                        resetPrefetchState();
                    }
                    this.wasScrollingForward = z2;
                    this.indexToPrefetch = iCalculateIndexToPrefetch;
                    this.currentPrefetchHandle = G.schedulePrefetch$default(g2, iCalculateIndexToPrefetch, null, 2, null);
                }
                if (z2) {
                    InterfaceC0494p interfaceC0494p = (InterfaceC0494p) V0.t.z0(yVar.getVisibleItemsInfo());
                    if (((interfaceC0494p.getSize() + interfaceC0494p.getOffset()) + yVar.getMainAxisItemSpacing()) - yVar.getViewportEndOffset() < (-f2) && (x3 = this.currentPrefetchHandle) != null) {
                        x3.markAsUrgent();
                    }
                } else if (yVar.getViewportStartOffset() - ((InterfaceC0494p) V0.t.u0(yVar.getVisibleItemsInfo())).getOffset() < f2 && (x2 = this.currentPrefetchHandle) != null) {
                    x2.markAsUrgent();
                }
            }
        }
        this.previousPassDelta = f2;
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onVisibleItemsUpdated(G g2, y yVar) {
        evaluatePrefetchForCancellation(yVar, this.indexToPrefetch, this.wasScrollingForward);
        int totalItemsCount = yVar.getTotalItemsCount();
        int i2 = this.previousPassItemCount;
        if (i2 != -1 && this.previousPassDelta != 0.0f && i2 != totalItemsCount && !yVar.getVisibleItemsInfo().isEmpty()) {
            int iCalculateIndexToPrefetch = calculateIndexToPrefetch(yVar, this.previousPassDelta < 0.0f);
            if (iCalculateIndexToPrefetch >= 0 && iCalculateIndexToPrefetch < totalItemsCount) {
                this.indexToPrefetch = iCalculateIndexToPrefetch;
                this.currentPrefetchHandle = G.schedulePrefetch$default(g2, iCalculateIndexToPrefetch, null, 2, null);
            }
        }
        this.previousPassItemCount = totalItemsCount;
    }

    public C0448a(int i2) {
        this.initialNestedPrefetchItemCount = i2;
        this.indexToPrefetch = -1;
        this.previousPassItemCount = -1;
    }

    public /* synthetic */ C0448a(int i2, int i3, AbstractC1378g abstractC1378g) {
        this((i3 & 1) != 0 ? 2 : i2);
    }
}
