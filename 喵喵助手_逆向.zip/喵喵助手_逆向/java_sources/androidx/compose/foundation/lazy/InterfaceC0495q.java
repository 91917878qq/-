package androidx.compose.foundation.lazy;

import androidx.compose.runtime.InterfaceC0768p;
import j.AbstractC1353k;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0495q extends androidx.compose.foundation.lazy.layout.D {
    @Override // androidx.compose.foundation.lazy.layout.D
    /* synthetic */ void Item(int i2, Object obj, InterfaceC0768p interfaceC0768p, int i3);

    @Override // androidx.compose.foundation.lazy.layout.D
    /* bridge */ /* synthetic */ default Object getContentType(int i2) {
        return super.getContentType(i2);
    }

    AbstractC1353k getHeaderIndexes();

    @Override // androidx.compose.foundation.lazy.layout.D
    /* bridge */ /* synthetic */ default int getIndex(Object obj) {
        return super.getIndex(obj);
    }

    @Override // androidx.compose.foundation.lazy.layout.D
    /* synthetic */ int getItemCount();

    C0454g getItemScope();

    @Override // androidx.compose.foundation.lazy.layout.D
    /* bridge */ /* synthetic */ default Object getKey(int i2) {
        return super.getKey(i2);
    }

    androidx.compose.foundation.lazy.layout.H getKeyIndexMap();
}
