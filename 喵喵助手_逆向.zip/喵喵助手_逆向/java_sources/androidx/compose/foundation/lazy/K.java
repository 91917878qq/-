package androidx.compose.foundation.lazy;

import androidx.compose.runtime.F1;
import androidx.compose.runtime.InterfaceC0816z0;
import kotlin.jvm.internal.AbstractC1378g;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public final class K {
    public static final int $stable = 8;
    private boolean hadFirstNotEmptyLayout;
    private final InterfaceC0816z0 index$delegate;
    private Object lastKnownFirstItemKey;
    private final androidx.compose.foundation.lazy.layout.Q nearestRangeState;
    private final InterfaceC0816z0 scrollOffset$delegate;

    /* JADX WARN: Illegal instructions before constructor call */
    public K() {
        int i2 = 0;
        this(i2, i2, 3, null);
    }

    private final void setScrollOffset(int i2) {
        this.scrollOffset$delegate.setIntValue(i2);
    }

    private final void update(int i2, int i3) {
        if (!(((float) i2) >= 0.0f)) {
            AbstractC1403e.throwIllegalArgumentException("Index should be non-negative (" + i2 + ')');
        }
        setIndex(i2);
        this.nearestRangeState.update(i2);
        setScrollOffset(i3);
    }

    public final int getIndex() {
        return this.index$delegate.getIntValue();
    }

    public final androidx.compose.foundation.lazy.layout.Q getNearestRangeState() {
        return this.nearestRangeState;
    }

    public final int getScrollOffset() {
        return this.scrollOffset$delegate.getIntValue();
    }

    public final void requestPositionAndForgetLastKnownKey(int i2, int i3) {
        update(i2, i3);
        this.lastKnownFirstItemKey = null;
    }

    public final void setIndex(int i2) {
        this.index$delegate.setIntValue(i2);
    }

    public final void updateFromMeasureResult(B b2) {
        C firstVisibleItem = b2.getFirstVisibleItem();
        this.lastKnownFirstItemKey = firstVisibleItem != null ? firstVisibleItem.getKey() : null;
        if (this.hadFirstNotEmptyLayout || b2.getTotalItemsCount() > 0) {
            this.hadFirstNotEmptyLayout = true;
            int firstVisibleItemScrollOffset = b2.getFirstVisibleItemScrollOffset();
            if (!(((float) firstVisibleItemScrollOffset) >= 0.0f)) {
                AbstractC1403e.throwIllegalStateException("scrollOffset should be non-negative");
            }
            C firstVisibleItem2 = b2.getFirstVisibleItem();
            update(firstVisibleItem2 != null ? firstVisibleItem2.getIndex() : 0, firstVisibleItemScrollOffset);
        }
    }

    public final void updateScrollOffset(int i2) {
        if (!(((float) i2) >= 0.0f)) {
            AbstractC1403e.throwIllegalStateException("scrollOffset should be non-negative");
        }
        setScrollOffset(i2);
    }

    public final int updateScrollPositionIfTheFirstItemWasMoved(InterfaceC0495q interfaceC0495q, int i2) {
        int iFindIndexByKey = androidx.compose.foundation.lazy.layout.E.findIndexByKey(interfaceC0495q, this.lastKnownFirstItemKey, i2);
        if (i2 != iFindIndexByKey) {
            setIndex(iFindIndexByKey);
            this.nearestRangeState.update(i2);
        }
        return iFindIndexByKey;
    }

    public K(int i2, int i3) {
        this.index$delegate = F1.mutableIntStateOf(i2);
        this.scrollOffset$delegate = F1.mutableIntStateOf(i3);
        this.nearestRangeState = new androidx.compose.foundation.lazy.layout.Q(i2, 30, 100);
    }

    public /* synthetic */ K(int i2, int i3, int i4, AbstractC1378g abstractC1378g) {
        this((i4 & 1) != 0 ? 0 : i2, (i4 & 2) != 0 ? 0 : i3);
    }
}
