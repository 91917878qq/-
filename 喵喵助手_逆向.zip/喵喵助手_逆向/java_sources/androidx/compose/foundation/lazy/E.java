package androidx.compose.foundation.lazy;

/* JADX INFO: loaded from: classes.dex */
public interface E {
    int getIndex();

    int getMainAxisSize();
}
