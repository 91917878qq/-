package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.q0;
import androidx.compose.foundation.lazy.layout.x0;

/* JADX INFO: loaded from: classes.dex */
public interface H {
    @U0.a
    static /* synthetic */ void getPrefetchScheduler$annotations() {
    }

    default x0 getPrefetchScheduler() {
        return null;
    }

    void onNestedPrefetch(q0 q0Var, int i2);

    void onScroll(G g2, float f2, y yVar);

    void onVisibleItemsUpdated(G g2, y yVar);
}
