package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.AbstractC0486v;
import androidx.compose.foundation.lazy.layout.o0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import j.AbstractC1353k;
import j.AbstractC1354l;
import j.C1331B;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0493o extends AbstractC0486v implements J {
    public static final int $stable = 8;
    private C1331B _headerIndexes;
    private final o0 intervals = new o0();

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.o$a */
    public static final class a implements h1.g {
        final /* synthetic */ h1.f $content;

        public a(h1.f fVar) {
            this.$content = fVar;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            if ((i3 & 6) == 0) {
                i3 |= interfaceC0768p.changed(interfaceC0453f) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i3 & 131) != 130, i3 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-857469575, i3, -1, "androidx.compose.foundation.lazy.LazyListIntervalContent.item.<anonymous> (LazyListIntervalContent.kt:56)");
            }
            this.$content.invoke(interfaceC0453f, interfaceC0768p, Integer.valueOf(i3 & 14));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.o$b */
    public static final class b implements h1.f {
        final /* synthetic */ h1.g $content;
        final /* synthetic */ int $headerIndex;

        public b(h1.g gVar, int i2) {
            this.$content = gVar;
            this.$headerIndex = i2;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            invoke((InterfaceC0453f) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, InterfaceC0768p interfaceC0768p, int i2) {
            if ((i2 & 6) == 0) {
                i2 |= interfaceC0768p.changed(interfaceC0453f) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i2 & 19) != 18, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1588696110, i2, -1, "androidx.compose.foundation.lazy.LazyListIntervalContent.stickyHeader.<anonymous> (LazyListIntervalContent.kt:70)");
            }
            this.$content.invoke(interfaceC0453f, Integer.valueOf(this.$headerIndex), interfaceC0768p, Integer.valueOf(i2 & 14));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    public C0493o(h1.c cVar) {
        cVar.invoke(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object item$lambda$0(Object obj, int i2) {
        return obj;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object item$lambda$1(Object obj, int i2) {
        return obj;
    }

    public final AbstractC1353k getHeaderIndexes() {
        C1331B c1331b = this._headerIndexes;
        return c1331b != null ? c1331b : AbstractC1354l.f3022a;
    }

    @Override // androidx.compose.foundation.lazy.J
    @U0.a
    public /* bridge */ /* synthetic */ void item(Object obj, h1.f fVar) {
        super.item(obj, fVar);
    }

    @Override // androidx.compose.foundation.lazy.J
    @U0.a
    public /* bridge */ /* synthetic */ void items(int i2, h1.c cVar, h1.g gVar) {
        super.items(i2, cVar, gVar);
    }

    @Override // androidx.compose.foundation.lazy.J
    @U0.a
    public /* bridge */ /* synthetic */ void stickyHeader(Object obj, Object obj2, h1.f fVar) {
        super.stickyHeader(obj, obj2, fVar);
    }

    @Override // androidx.compose.foundation.lazy.layout.AbstractC0486v
    public o0 getIntervals() {
        return this.intervals;
    }

    @Override // androidx.compose.foundation.lazy.J
    public void item(Object obj, Object obj2, h1.f fVar) {
        getIntervals().addInterval(1, new C0491m(obj != null ? new C0492n(obj, 0) : null, new C0492n(obj2, 1), G.v.composableLambdaInstance(-857469575, true, new a(fVar))));
    }

    @Override // androidx.compose.foundation.lazy.J
    public void items(int i2, h1.c cVar, h1.c cVar2, h1.g gVar) {
        getIntervals().addInterval(i2, new C0491m(cVar, cVar2, gVar));
    }

    @Override // androidx.compose.foundation.lazy.J
    public void stickyHeader(Object obj, Object obj2, h1.g gVar) {
        C1331B c1331b = this._headerIndexes;
        if (c1331b == null) {
            c1331b = new C1331B();
            this._headerIndexes = c1331b;
        }
        c1331b.d(getIntervals().getSize());
        item(obj, obj2, G.v.composableLambdaInstance(-1588696110, true, new b(gVar, getIntervals().getSize())));
    }
}
