package androidx.compose.foundation.lazy;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0457j implements androidx.compose.foundation.lazy.layout.r {
    public static final int $stable = 0;
    private final int beyondBoundsItemCount;
    private final O state;

    public C0457j(O o2, int i2) {
        this.state = o2;
        this.beyondBoundsItemCount = i2;
    }

    public final int getBeyondBoundsItemCount() {
        return this.beyondBoundsItemCount;
    }

    @Override // androidx.compose.foundation.lazy.layout.r
    public int getFirstPlacedIndex() {
        return Math.max(0, this.state.getFirstVisibleItemIndex() - this.beyondBoundsItemCount);
    }

    @Override // androidx.compose.foundation.lazy.layout.r
    public boolean getHasVisibleItems() {
        return !this.state.getLayoutInfo().getVisibleItemsInfo().isEmpty();
    }

    @Override // androidx.compose.foundation.lazy.layout.r
    public int getItemCount() {
        return this.state.getLayoutInfo().getTotalItemsCount();
    }

    @Override // androidx.compose.foundation.lazy.layout.r
    public int getLastPlacedIndex() {
        return Math.min(getItemCount() - 1, ((InterfaceC0494p) V0.t.z0(this.state.getLayoutInfo().getVisibleItemsInfo())).getIndex() + this.beyondBoundsItemCount);
    }

    public final O getState() {
        return this.state;
    }

    @Override // androidx.compose.foundation.lazy.layout.r
    public int itemsPerViewport() {
        int i2;
        if (this.state.getLayoutInfo().getVisibleItemsInfo().isEmpty()) {
            return 0;
        }
        int singleAxisViewportSize = androidx.compose.foundation.gestures.snapping.e.getSingleAxisViewportSize(this.state.getLayoutInfo());
        int iVisibleItemsAverageSize = z.visibleItemsAverageSize(this.state.getLayoutInfo());
        if (iVisibleItemsAverageSize != 0 && (i2 = singleAxisViewportSize / iVisibleItemsAverageSize) >= 1) {
            return i2;
        }
        return 1;
    }
}
