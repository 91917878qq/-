package androidx.compose.foundation.lazy;

import androidx.compose.animation.core.D0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;

/* JADX INFO: loaded from: classes.dex */
public interface J {

    public static final class a implements h1.c {
        public static final a INSTANCE = new a();

        public final Void invoke(int i2) {
            return null;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    public static final class b implements h1.g {
        final /* synthetic */ h1.f $content;

        public b(h1.f fVar) {
            this.$content = fVar;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            if ((i3 & 6) == 0) {
                i3 |= interfaceC0768p.changed(interfaceC0453f) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i3 & 131) != 130, i3 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-764088514, i3, -1, "androidx.compose.foundation.lazy.LazyListScope.stickyHeader.<anonymous> (LazyDsl.kt:122)");
            }
            this.$content.invoke(interfaceC0453f, interfaceC0768p, Integer.valueOf(i3 & 14));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    public static final class c implements h1.f {
        final /* synthetic */ h1.g $content;

        public c(h1.g gVar) {
            this.$content = gVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            invoke((InterfaceC0453f) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, InterfaceC0768p interfaceC0768p, int i2) {
            if ((i2 & 6) == 0) {
                i2 |= interfaceC0768p.changed(interfaceC0453f) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i2 & 19) != 18, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1691919627, i2, -1, "androidx.compose.foundation.lazy.LazyListScope.stickyHeader.<anonymous> (LazyDsl.kt:148)");
            }
            this.$content.invoke(interfaceC0453f, 0, interfaceC0768p, Integer.valueOf((i2 & 14) | 48));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    static /* synthetic */ void item$default(J j2, Object obj, Object obj2, h1.f fVar, int i2, Object obj3) {
        if (obj3 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: item");
        }
        if ((i2 & 1) != 0) {
            obj = null;
        }
        if ((i2 & 2) != 0) {
            obj2 = null;
        }
        j2.item(obj, obj2, fVar);
    }

    static /* synthetic */ void items$default(J j2, int i2, h1.c cVar, h1.c cVar2, h1.g gVar, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: items");
        }
        if ((i3 & 2) != 0) {
            cVar = null;
        }
        if ((i3 & 4) != 0) {
            cVar2 = a.INSTANCE;
        }
        j2.items(i2, cVar, cVar2, gVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    static Object items$lambda$0(int i2) {
        return null;
    }

    static /* synthetic */ void stickyHeader$default(J j2, Object obj, Object obj2, h1.f fVar, int i2, Object obj3) {
        if (obj3 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: stickyHeader");
        }
        if ((i2 & 1) != 0) {
            obj = null;
        }
        if ((i2 & 2) != 0) {
            obj2 = null;
        }
        j2.stickyHeader(obj, obj2, fVar);
    }

    default void item(Object obj, Object obj2, h1.f fVar) {
        throw new IllegalStateException("The method is not implemented");
    }

    default void items(int i2, h1.c cVar, h1.c cVar2, h1.g gVar) {
        throw new IllegalStateException("The method is not implemented");
    }

    @U0.a
    /* synthetic */ default void stickyHeader(Object obj, Object obj2, h1.f fVar) {
        stickyHeader(obj, obj2, (h1.g) G.v.composableLambdaInstance(-764088514, true, new b(fVar)));
    }

    static /* synthetic */ void item$default(J j2, Object obj, h1.f fVar, int i2, Object obj2) {
        if (obj2 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: item");
        }
        if ((i2 & 1) != 0) {
            obj = null;
        }
        j2.item(obj, fVar);
    }

    static /* synthetic */ void stickyHeader$default(J j2, Object obj, Object obj2, h1.g gVar, int i2, Object obj3) {
        if (obj3 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: stickyHeader");
        }
        if ((i2 & 1) != 0) {
            obj = null;
        }
        if ((i2 & 2) != 0) {
            obj2 = null;
        }
        j2.stickyHeader(obj, obj2, gVar);
    }

    @U0.a
    /* synthetic */ default void item(Object obj, h1.f fVar) {
        item(obj, null, fVar);
    }

    @U0.a
    /* synthetic */ default void items(int i2, h1.c cVar, h1.g gVar) {
        items(i2, cVar, new D0(25), gVar);
    }

    default void stickyHeader(Object obj, Object obj2, h1.g gVar) {
        item(obj, obj2, G.v.composableLambdaInstance(1691919627, true, new c(gVar)));
    }

    static /* synthetic */ void items$default(J j2, int i2, h1.c cVar, h1.g gVar, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: items");
        }
        if ((i3 & 2) != 0) {
            cVar = null;
        }
        j2.items(i2, cVar, gVar);
    }
}
