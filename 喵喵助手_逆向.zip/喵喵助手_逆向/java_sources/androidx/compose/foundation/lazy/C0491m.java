package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.InterfaceC0485u;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0491m implements InterfaceC0485u {
    public static final int $stable = 0;
    private final h1.g item;
    private final h1.c key;
    private final h1.c type;

    public C0491m(h1.c cVar, h1.c cVar2, h1.g gVar) {
        this.key = cVar;
        this.type = cVar2;
        this.item = gVar;
    }

    public final h1.g getItem() {
        return this.item;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0485u
    public h1.c getKey() {
        return this.key;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0485u
    public h1.c getType() {
        return this.type;
    }
}
