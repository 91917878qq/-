package androidx.compose.foundation.lazy;

import androidx.compose.animation.core.C0331r0;
import androidx.compose.foundation.lazy.layout.InterfaceC0470f;
import androidx.compose.foundation.lazy.layout.X;
import e0.InterfaceC1307d;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0458k implements InterfaceC0470f {
    public static final int $stable = 8;
    public y layoutInfo;
    public G prefetchScope;

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n schedulePrefetch$lambda$0(h1.e eVar, E e2) {
        eVar.invoke(Integer.valueOf(e2.getIndex()), Integer.valueOf(e2.getMainAxisSize()));
        return U0.n.f1521a;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public InterfaceC1307d getDensity() {
        y layoutInfo = getLayoutInfo();
        B b2 = layoutInfo instanceof B ? (B) layoutInfo : null;
        if (b2 != null) {
            return b2.getDensity();
        }
        return null;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getFirstVisibleLineIndex() {
        return ((InterfaceC0494p) V0.t.u0(getLayoutInfo().getVisibleItemsInfo())).getIndex();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public boolean getHasVisibleItems() {
        return !getLayoutInfo().getVisibleItemsInfo().isEmpty();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getLastIndexInLine(int i2) {
        return i2;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getLastLineIndex() {
        if (getTotalItemsCount() == 0) {
            return -1;
        }
        return getTotalItemsCount() - 1;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getLastVisibleLineIndex() {
        return ((InterfaceC0494p) V0.t.z0(getLayoutInfo().getVisibleItemsInfo())).getIndex();
    }

    public final y getLayoutInfo() {
        y yVar = this.layoutInfo;
        if (yVar != null) {
            return yVar;
        }
        kotlin.jvm.internal.o.k("layoutInfo");
        throw null;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getMainAxisExtraSpaceEnd() {
        InterfaceC0494p interfaceC0494p = (InterfaceC0494p) V0.t.z0(getLayoutInfo().getVisibleItemsInfo());
        return Math.abs((getLayoutInfo().getMainAxisItemSpacing() + (interfaceC0494p.getSize() + interfaceC0494p.getOffset())) - getLayoutInfo().getViewportEndOffset());
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getMainAxisExtraSpaceStart() {
        int beforeContentPadding = getLayoutInfo().getBeforeContentPadding() + ((InterfaceC0494p) V0.t.u0(getLayoutInfo().getVisibleItemsInfo())).getOffset();
        if (beforeContentPadding > 0) {
            beforeContentPadding = 0;
        }
        return Math.abs(beforeContentPadding);
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getMainAxisViewportSize() {
        return androidx.compose.foundation.gestures.snapping.e.getSingleAxisViewportSize(getLayoutInfo());
    }

    public final G getPrefetchScope() {
        G g2 = this.prefetchScope;
        if (g2 != null) {
            return g2;
        }
        kotlin.jvm.internal.o.k("prefetchScope");
        throw null;
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getTotalItemsCount() {
        return getLayoutInfo().getTotalItemsCount();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getVisibleItemLine(int i2) {
        return getLayoutInfo().getVisibleItemsInfo().get(i2).getIndex();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getVisibleItemSize(int i2) {
        return getLayoutInfo().getVisibleItemsInfo().get(i2).getSize();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public int getVisibleLineCount() {
        return getLayoutInfo().getVisibleItemsInfo().size();
    }

    @Override // androidx.compose.foundation.lazy.layout.InterfaceC0470f
    public List<X> schedulePrefetch(int i2, h1.e eVar) {
        return j1.a.M(getPrefetchScope().schedulePrefetch(i2, new C0331r0(4, eVar)));
    }

    public final void setLayoutInfo(y yVar) {
        this.layoutInfo = yVar;
    }

    public final void setPrefetchScope(G g2) {
        this.prefetchScope = g2;
    }
}
