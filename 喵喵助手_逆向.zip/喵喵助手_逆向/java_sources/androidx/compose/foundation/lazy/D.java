package androidx.compose.foundation.lazy;

import androidx.compose.ui.layout.AbstractC0974x0;
import e0.AbstractC1306c;
import e0.C1305b;
import j.AbstractC1353k;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class D extends androidx.compose.foundation.lazy.layout.P {
    public static final int $stable = 8;
    private final long childConstraints;
    private final InterfaceC0495q itemProvider;
    private final androidx.compose.foundation.lazy.layout.L measureScope;

    public /* synthetic */ D(long j2, boolean z2, InterfaceC0495q interfaceC0495q, androidx.compose.foundation.lazy.layout.L l2, AbstractC1378g abstractC1378g) {
        this(j2, z2, interfaceC0495q, l2);
    }

    /* JADX INFO: renamed from: getAndMeasure-0kLqBqw$default, reason: not valid java name */
    public static /* synthetic */ C m1051getAndMeasure0kLqBqw$default(D d2, int i2, long j2, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: getAndMeasure-0kLqBqw");
        }
        if ((i3 & 2) != 0) {
            j2 = d2.childConstraints;
        }
        return d2.m1054getAndMeasure0kLqBqw(i2, j2);
    }

    /* JADX INFO: renamed from: createItem-X9ElhV4, reason: not valid java name */
    public abstract C mo1052createItemX9ElhV4(int i2, Object obj, Object obj2, List<? extends AbstractC0974x0> list, long j2);

    /* JADX INFO: renamed from: getAndMeasure-0kLqBqw, reason: not valid java name */
    public final C m1054getAndMeasure0kLqBqw(int i2, long j2) {
        return mo1052createItemX9ElhV4(i2, this.itemProvider.getKey(i2), this.itemProvider.getContentType(i2), m1072getPlaceables3p2s80s(this.measureScope, i2, j2), j2);
    }

    /* JADX INFO: renamed from: getChildConstraints-msEJaDk, reason: not valid java name */
    public final long m1055getChildConstraintsmsEJaDk() {
        return this.childConstraints;
    }

    public final AbstractC1353k getHeaderIndexes() {
        return this.itemProvider.getHeaderIndexes();
    }

    public final androidx.compose.foundation.lazy.layout.H getKeyIndexMap() {
        return this.itemProvider.getKeyIndexMap();
    }

    public final void keepAround(int i2) {
        this.measureScope.compose(i2);
    }

    private D(long j2, boolean z2, InterfaceC0495q interfaceC0495q, androidx.compose.foundation.lazy.layout.L l2) {
        this.itemProvider = interfaceC0495q;
        this.measureScope = l2;
        this.childConstraints = AbstractC1306c.Constraints$default(0, z2 ? C1305b.m5041getMaxWidthimpl(j2) : Integer.MAX_VALUE, 0, z2 ? Integer.MAX_VALUE : C1305b.m5040getMaxHeightimpl(j2), 5, null);
    }

    @Override // androidx.compose.foundation.lazy.layout.P
    /* JADX INFO: renamed from: getAndMeasure--hBUhpc, reason: not valid java name */
    public C mo1053getAndMeasurehBUhpc(int i2, int i3, int i4, long j2) {
        return m1054getAndMeasure0kLqBqw(i2, j2);
    }
}
