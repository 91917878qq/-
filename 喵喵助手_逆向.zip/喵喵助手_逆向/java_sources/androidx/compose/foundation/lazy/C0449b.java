package androidx.compose.foundation.lazy;

import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.foundation.i0;
import androidx.compose.foundation.layout.InterfaceC0420g;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.foundation.layout.InterfaceC0424i;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0449b implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1817b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ androidx.compose.ui.x f1818c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ O f1819d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0421g0 f1820e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ boolean f1821f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0400y f1822g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ boolean f1823h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ i0 f1824i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ h1.c f1825j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ int f1826k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f1827l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f1828m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f1829n;

    public /* synthetic */ C0449b(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, Object obj, Object obj2, InterfaceC0400y interfaceC0400y, boolean z3, i0 i0Var, h1.c cVar, int i2, int i3, int i4) {
        this.f1817b = i4;
        this.f1818c = xVar;
        this.f1819d = o2;
        this.f1820e = interfaceC0421g0;
        this.f1821f = z2;
        this.f1828m = obj;
        this.f1829n = obj2;
        this.f1822g = interfaceC0400y;
        this.f1823h = z3;
        this.f1824i = i0Var;
        this.f1825j = cVar;
        this.f1826k = i2;
        this.f1827l = i3;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        InterfaceC0768p interfaceC0768p = (InterfaceC0768p) obj;
        switch (this.f1817b) {
            case 0:
                int iIntValue = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyColumn$lambda$1(this.f1818c, this.f1819d, this.f1820e, this.f1821f, (InterfaceC0424i) this.f1828m, (InterfaceC0822e) this.f1829n, this.f1822g, this.f1823h, this.f1824i, this.f1825j, this.f1826k, this.f1827l, interfaceC0768p, iIntValue);
            default:
                int iIntValue2 = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyRow$lambda$0(this.f1818c, this.f1819d, this.f1820e, this.f1821f, (InterfaceC0420g) this.f1828m, (InterfaceC0823f) this.f1829n, this.f1822g, this.f1823h, this.f1824i, this.f1825j, this.f1826k, this.f1827l, interfaceC0768p, iIntValue2);
        }
    }
}
