package androidx.compose.foundation.lazy;

import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.foundation.i0;
import androidx.compose.foundation.k0;
import androidx.compose.foundation.layout.AbstractC0413c0;
import androidx.compose.foundation.layout.C0418f;
import androidx.compose.foundation.layout.InterfaceC0420g;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.foundation.layout.InterfaceC0424i;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import e0.C1311h;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0452e {

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$a */
    public static final class a implements h1.c {
        public static final a INSTANCE = new a();

        @Override // h1.c
        public final Void invoke(Object obj) {
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$b */
    public static final class b implements h1.c {
        final /* synthetic */ List<T> $items;
        final /* synthetic */ h1.c $key;

        /* JADX WARN: Multi-variable type inference failed */
        public b(h1.c cVar, List<? extends T> list) {
            this.$key = cVar;
            this.$items = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$key.invoke(this.$items.get(i2));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$c */
    public static final class c implements h1.c {
        final /* synthetic */ h1.c $contentType;
        final /* synthetic */ List<T> $items;

        /* JADX WARN: Multi-variable type inference failed */
        public c(h1.c cVar, List<? extends T> list) {
            this.$contentType = cVar;
            this.$items = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$contentType.invoke(this.$items.get(i2));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$d */
    public static final class d implements h1.g {
        final /* synthetic */ h1.g $itemContent;
        final /* synthetic */ List<T> $items;

        /* JADX WARN: Multi-variable type inference failed */
        public d(h1.g gVar, List<? extends T> list) {
            this.$itemContent = gVar;
            this.$items = list;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            int i4;
            if ((i3 & 6) == 0) {
                i4 = (interfaceC0768p.changed(interfaceC0453f) ? 4 : 2) | i3;
            } else {
                i4 = i3;
            }
            if ((i3 & 48) == 0) {
                i4 |= interfaceC0768p.changed(i2) ? 32 : 16;
            }
            if (!interfaceC0768p.shouldExecute((i4 & 147) != 146, i4 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(802480018, i4, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
            }
            this.$itemContent.invoke(interfaceC0453f, this.$items.get(i2), interfaceC0768p, Integer.valueOf(i4 & 14));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$e, reason: collision with other inner class name */
    public static final class C0041e implements h1.c {
        public static final C0041e INSTANCE = new C0041e();

        @Override // h1.c
        public final Void invoke(Object obj) {
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$f */
    public static final class f implements h1.c {
        final /* synthetic */ T[] $items;
        final /* synthetic */ h1.c $key;

        public f(h1.c cVar, T[] tArr) {
            this.$key = cVar;
            this.$items = tArr;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$key.invoke(this.$items[i2]);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$g */
    public static final class g implements h1.c {
        final /* synthetic */ h1.c $contentType;
        final /* synthetic */ T[] $items;

        public g(h1.c cVar, T[] tArr) {
            this.$contentType = cVar;
            this.$items = tArr;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$contentType.invoke(this.$items[i2]);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$h */
    public static final class h implements h1.g {
        final /* synthetic */ h1.g $itemContent;
        final /* synthetic */ T[] $items;

        public h(h1.g gVar, T[] tArr) {
            this.$itemContent = gVar;
            this.$items = tArr;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            int i4;
            if ((i3 & 6) == 0) {
                i4 = (interfaceC0768p.changed(interfaceC0453f) ? 4 : 2) | i3;
            } else {
                i4 = i3;
            }
            if ((i3 & 48) == 0) {
                i4 |= interfaceC0768p.changed(i2) ? 32 : 16;
            }
            if (!interfaceC0768p.shouldExecute((i4 & 147) != 146, i4 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1781742563, i4, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:250)");
            }
            this.$itemContent.invoke(interfaceC0453f, this.$items[i2], interfaceC0768p, Integer.valueOf(i4 & 14));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$i */
    public static final class i implements h1.c {
        final /* synthetic */ List $items;

        public i(List list) {
            this.$items = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            this.$items.get(i2);
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$j */
    public static final class j implements h1.c {
        final /* synthetic */ Object[] $items;

        public j(Object[] objArr) {
            this.$items = objArr;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            Object obj = this.$items[i2];
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$k */
    public static final class k implements h1.e {
        public static final k INSTANCE = new k();

        public final Void invoke(int i2, Object obj) {
            return null;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return invoke(((Number) obj).intValue(), obj2);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$l */
    public static final class l implements h1.c {
        final /* synthetic */ List<T> $items;
        final /* synthetic */ h1.e $key;

        /* JADX WARN: Multi-variable type inference failed */
        public l(h1.e eVar, List<? extends T> list) {
            this.$key = eVar;
            this.$items = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$key.invoke(Integer.valueOf(i2), this.$items.get(i2));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$m */
    public static final class m implements h1.c {
        final /* synthetic */ h1.e $contentType;
        final /* synthetic */ List<T> $items;

        /* JADX WARN: Multi-variable type inference failed */
        public m(h1.e eVar, List<? extends T> list) {
            this.$contentType = eVar;
            this.$items = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$contentType.invoke(Integer.valueOf(i2), this.$items.get(i2));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$n */
    public static final class n implements h1.g {
        final /* synthetic */ h1.h $itemContent;
        final /* synthetic */ List<T> $items;

        /* JADX WARN: Multi-variable type inference failed */
        public n(h1.h hVar, List<? extends T> list) {
            this.$itemContent = hVar;
            this.$items = list;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            int i4;
            if ((i3 & 6) == 0) {
                i4 = (interfaceC0768p.changed(interfaceC0453f) ? 4 : 2) | i3;
            } else {
                i4 = i3;
            }
            if ((i3 & 48) == 0) {
                i4 |= interfaceC0768p.changed(i2) ? 32 : 16;
            }
            if (!interfaceC0768p.shouldExecute((i4 & 147) != 146, i4 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(2039820996, i4, -1, "androidx.compose.foundation.lazy.itemsIndexed.<anonymous> (LazyDsl.kt:214)");
            }
            this.$itemContent.invoke(interfaceC0453f, Integer.valueOf(i2), this.$items.get(i2), interfaceC0768p, Integer.valueOf(i4 & 126));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$o */
    public static final class o implements h1.e {
        public static final o INSTANCE = new o();

        public final Void invoke(int i2, Object obj) {
            return null;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return invoke(((Number) obj).intValue(), obj2);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$p */
    public static final class p implements h1.c {
        final /* synthetic */ T[] $items;
        final /* synthetic */ h1.e $key;

        public p(h1.e eVar, T[] tArr) {
            this.$key = eVar;
            this.$items = tArr;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$key.invoke(Integer.valueOf(i2), this.$items[i2]);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$q */
    public static final class q implements h1.c {
        final /* synthetic */ h1.e $contentType;
        final /* synthetic */ T[] $items;

        public q(h1.e eVar, T[] tArr) {
            this.$contentType = eVar;
            this.$items = tArr;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Object invoke(int i2) {
            return this.$contentType.invoke(Integer.valueOf(i2), this.$items[i2]);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.e$r */
    public static final class r implements h1.g {
        final /* synthetic */ h1.h $itemContent;
        final /* synthetic */ T[] $items;

        public r(h1.h hVar, T[] tArr) {
            this.$itemContent = hVar;
            this.$items = tArr;
        }

        @Override // h1.g
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            invoke((InterfaceC0453f) obj, ((Number) obj2).intValue(), (InterfaceC0768p) obj3, ((Number) obj4).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0453f interfaceC0453f, int i2, InterfaceC0768p interfaceC0768p, int i3) {
            int i4;
            if ((i3 & 6) == 0) {
                i4 = (interfaceC0768p.changed(interfaceC0453f) ? 4 : 2) | i3;
            } else {
                i4 = i3;
            }
            if ((i3 & 48) == 0) {
                i4 |= interfaceC0768p.changed(i2) ? 32 : 16;
            }
            if (!interfaceC0768p.shouldExecute((i4 & 147) != 146, i4 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1763000017, i4, -1, "androidx.compose.foundation.lazy.itemsIndexed.<anonymous> (LazyDsl.kt:286)");
            }
            this.$itemContent.invoke(interfaceC0453f, Integer.valueOf(i2), this.$items[i2], interfaceC0768p, Integer.valueOf(i4 & 126));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0116  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0136  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0142  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x025e  */
    /* JADX WARN: Removed duplicated region for block: B:180:0x0275  */
    /* JADX WARN: Removed duplicated region for block: B:182:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0109  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void LazyColumn(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, boolean z3, i0 i0Var, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        boolean z4;
        InterfaceC0424i interfaceC0424i2;
        int i6;
        InterfaceC0822e interfaceC0822e2;
        InterfaceC0400y interfaceC0400y2;
        int i7;
        androidx.compose.ui.x xVar2;
        O oRememberLazyListState;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z5;
        boolean z6;
        InterfaceC0424i interfaceC0424i3;
        InterfaceC0822e start;
        InterfaceC0400y interfaceC0400y3;
        i0 i0Var2;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0424i top;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        i0 i0VarRememberOverscrollEffect;
        int i8;
        InterfaceC0400y interfaceC0400y4;
        boolean z7;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(53695811);
        int i9 = i3 & 1;
        if (i9 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i10 = i3 & 4;
        if (i10 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g0) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z4 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z4) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0424i2 = interfaceC0424i;
                        int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0424i2) ? 16384 : 8192;
                        i4 |= i11;
                    } else {
                        interfaceC0424i2 = interfaceC0424i;
                    }
                    i4 |= i11;
                } else {
                    interfaceC0424i2 = interfaceC0424i;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0822e2 = interfaceC0822e;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0822e2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i12 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i12;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i12;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    i7 = i3 & 128;
                    if (i7 == 0) {
                        i4 |= 12582912;
                    } else if ((i2 & 12582912) == 0) {
                        i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 8388608 : 4194304;
                    }
                    if ((i2 & 100663296) == 0) {
                        i4 |= ((i3 & 256) == 0 && interfaceC0768pStartRestartGroup.changed(i0Var)) ? 67108864 : 33554432;
                    }
                    if ((i3 & 512) != 0) {
                        if ((i2 & 805306368) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 536870912 : 268435456;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) == 0 || interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                xVar2 = i9 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i10 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g0;
                                if (i5 != 0) {
                                    z4 = false;
                                }
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    top = !z4 ? c0418f.getTop() : c0418f.getBottom();
                                    i4 &= -57345;
                                } else {
                                    top = interfaceC0424i2;
                                }
                                start = i6 != 0 ? InterfaceC0849g.Companion.getStart() : interfaceC0822e2;
                                if ((i3 & 64) != 0) {
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                    i4 &= -3670017;
                                } else {
                                    interfaceC0400yFlingBehavior = interfaceC0400y2;
                                }
                                boolean z8 = i7 == 0 ? z3 : true;
                                if ((i3 & 256) != 0) {
                                    i4 &= -234881025;
                                    i0VarRememberOverscrollEffect = k0.rememberOverscrollEffect(interfaceC0768pStartRestartGroup, 0);
                                } else {
                                    i0VarRememberOverscrollEffect = i0Var;
                                }
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400yFlingBehavior;
                                z7 = z8;
                            } else {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                if ((i3 & 256) != 0) {
                                    i4 &= -234881025;
                                }
                                xVar2 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                                i0VarRememberOverscrollEffect = i0Var;
                                i8 = i4;
                                top = interfaceC0424i2;
                                start = interfaceC0822e2;
                                interfaceC0400y4 = interfaceC0400y2;
                                z7 = z3;
                            }
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(53695811, i8, -1, "androidx.compose.foundation.lazy.LazyColumn (LazyDsl.kt:399)");
                            }
                            int i13 = i8 >> 3;
                            x.LazyList(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z4, true, interfaceC0400y4, z7, i0VarRememberOverscrollEffect, 0, start, top, null, null, cVar, interfaceC0768pStartRestartGroup, (i8 & 14) | 24576 | (i8 & 112) | (i8 & 896) | (i8 & 7168) | (458752 & i13) | (3670016 & i13) | (i13 & 29360128) | ((i8 << 12) & 1879048192), ((i8 >> 12) & 14) | ((i8 >> 18) & 7168), 6400);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            interfaceC0400y3 = interfaceC0400y4;
                            InterfaceC0424i interfaceC0424i4 = top;
                            z5 = z7;
                            z6 = z4;
                            i0Var2 = i0VarRememberOverscrollEffect;
                            interfaceC0424i3 = interfaceC0424i4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            oRememberLazyListState = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                            z5 = z3;
                            z6 = z4;
                            interfaceC0424i3 = interfaceC0424i2;
                            start = interfaceC0822e2;
                            interfaceC0400y3 = interfaceC0400y2;
                            i0Var2 = i0Var;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0449b(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z6, interfaceC0424i3, start, interfaceC0400y3, z5, i0Var2, cVar, i2, i3, 0));
                            return;
                        }
                        return;
                    }
                    i4 |= 805306368;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0822e2 = interfaceC0822e;
                if ((1572864 & i2) != 0) {
                }
                i7 = i3 & 128;
                if (i7 == 0) {
                }
                if ((i2 & 100663296) == 0) {
                }
                if ((i3 & 512) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z4 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0822e2 = interfaceC0822e;
            if ((1572864 & i2) != 0) {
            }
            i7 = i3 & 128;
            if (i7 == 0) {
            }
            if ((i2 & 100663296) == 0) {
            }
            if ((i3 & 512) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z4 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0822e2 = interfaceC0822e;
        if ((1572864 & i2) != 0) {
        }
        i7 = i3 & 128;
        if (i7 == 0) {
        }
        if ((i2 & 100663296) == 0) {
        }
        if ((i3 & 512) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyColumn$lambda$1(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, boolean z3, i0 i0Var, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyColumn(xVar, o2, interfaceC0421g0, z2, interfaceC0424i, interfaceC0822e, interfaceC0400y, z3, i0Var, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyColumn$lambda$2(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, boolean z3, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyColumn(xVar, o2, interfaceC0421g0, z2, interfaceC0424i, interfaceC0822e, interfaceC0400y, z3, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyColumn$lambda$3(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyColumn(xVar, o2, interfaceC0421g0, z2, interfaceC0424i, interfaceC0822e, interfaceC0400y, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0116  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0136  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0142  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x025d  */
    /* JADX WARN: Removed duplicated region for block: B:180:0x0274  */
    /* JADX WARN: Removed duplicated region for block: B:182:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0109  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void LazyRow(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, boolean z3, i0 i0Var, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        boolean z4;
        InterfaceC0420g interfaceC0420g2;
        int i6;
        InterfaceC0823f interfaceC0823f2;
        InterfaceC0400y interfaceC0400y2;
        int i7;
        androidx.compose.ui.x xVar2;
        O oRememberLazyListState;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z5;
        boolean z6;
        InterfaceC0420g interfaceC0420g3;
        InterfaceC0823f top;
        InterfaceC0400y interfaceC0400y3;
        i0 i0Var2;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0420g start;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        i0 i0VarRememberOverscrollEffect;
        int i8;
        InterfaceC0400y interfaceC0400y4;
        boolean z7;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1884325601);
        int i9 = i3 & 1;
        if (i9 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i10 = i3 & 4;
        if (i10 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g0) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z4 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z4) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0420g2 = interfaceC0420g;
                        int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0420g2) ? 16384 : 8192;
                        i4 |= i11;
                    } else {
                        interfaceC0420g2 = interfaceC0420g;
                    }
                    i4 |= i11;
                } else {
                    interfaceC0420g2 = interfaceC0420g;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0823f2 = interfaceC0823f;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0823f2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i12 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i12;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i12;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    i7 = i3 & 128;
                    if (i7 == 0) {
                        i4 |= 12582912;
                    } else if ((i2 & 12582912) == 0) {
                        i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 8388608 : 4194304;
                    }
                    if ((i2 & 100663296) == 0) {
                        i4 |= ((i3 & 256) == 0 && interfaceC0768pStartRestartGroup.changed(i0Var)) ? 67108864 : 33554432;
                    }
                    if ((i3 & 512) != 0) {
                        if ((i2 & 805306368) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 536870912 : 268435456;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) == 0 || interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                xVar2 = i9 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i10 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g0;
                                if (i5 != 0) {
                                    z4 = false;
                                }
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    start = !z4 ? c0418f.getStart() : c0418f.getEnd();
                                    i4 &= -57345;
                                } else {
                                    start = interfaceC0420g2;
                                }
                                top = i6 != 0 ? InterfaceC0849g.Companion.getTop() : interfaceC0823f2;
                                if ((i3 & 64) != 0) {
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                    i4 &= -3670017;
                                } else {
                                    interfaceC0400yFlingBehavior = interfaceC0400y2;
                                }
                                boolean z8 = i7 == 0 ? z3 : true;
                                if ((i3 & 256) != 0) {
                                    i4 &= -234881025;
                                    i0VarRememberOverscrollEffect = k0.rememberOverscrollEffect(interfaceC0768pStartRestartGroup, 0);
                                } else {
                                    i0VarRememberOverscrollEffect = i0Var;
                                }
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400yFlingBehavior;
                                z7 = z8;
                            } else {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                if ((i3 & 256) != 0) {
                                    i4 &= -234881025;
                                }
                                xVar2 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                                i0VarRememberOverscrollEffect = i0Var;
                                i8 = i4;
                                start = interfaceC0420g2;
                                top = interfaceC0823f2;
                                interfaceC0400y4 = interfaceC0400y2;
                                z7 = z3;
                            }
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-1884325601, i8, -1, "androidx.compose.foundation.lazy.LazyRow (LazyDsl.kt:339)");
                            }
                            int i13 = i8 >> 3;
                            x.LazyList(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z4, false, interfaceC0400y4, z7, i0VarRememberOverscrollEffect, 0, null, null, top, start, cVar, interfaceC0768pStartRestartGroup, (i8 & 14) | 24576 | (i8 & 112) | (i8 & 896) | (i8 & 7168) | (458752 & i13) | (3670016 & i13) | (i13 & 29360128), ((i8 >> 12) & 112) | ((i8 >> 6) & 896) | ((i8 >> 18) & 7168), 1792);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            interfaceC0400y3 = interfaceC0400y4;
                            InterfaceC0420g interfaceC0420g4 = start;
                            z5 = z7;
                            z6 = z4;
                            i0Var2 = i0VarRememberOverscrollEffect;
                            interfaceC0420g3 = interfaceC0420g4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            oRememberLazyListState = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                            z5 = z3;
                            z6 = z4;
                            interfaceC0420g3 = interfaceC0420g2;
                            top = interfaceC0823f2;
                            interfaceC0400y3 = interfaceC0400y2;
                            i0Var2 = i0Var;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0449b(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z6, interfaceC0420g3, top, interfaceC0400y3, z5, i0Var2, cVar, i2, i3, 1));
                            return;
                        }
                        return;
                    }
                    i4 |= 805306368;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0823f2 = interfaceC0823f;
                if ((1572864 & i2) != 0) {
                }
                i7 = i3 & 128;
                if (i7 == 0) {
                }
                if ((i2 & 100663296) == 0) {
                }
                if ((i3 & 512) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z4 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0823f2 = interfaceC0823f;
            if ((1572864 & i2) != 0) {
            }
            i7 = i3 & 128;
            if (i7 == 0) {
            }
            if ((i2 & 100663296) == 0) {
            }
            if ((i3 & 512) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z4 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0823f2 = interfaceC0823f;
        if ((1572864 & i2) != 0) {
        }
        i7 = i3 & 128;
        if (i7 == 0) {
        }
        if ((i2 & 100663296) == 0) {
        }
        if ((i3 & 512) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 306783379) != 306783378, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyRow$lambda$0(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, boolean z3, i0 i0Var, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyRow(xVar, o2, interfaceC0421g0, z2, interfaceC0420g, interfaceC0823f, interfaceC0400y, z3, i0Var, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyRow$lambda$4(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, boolean z3, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyRow(xVar, o2, interfaceC0421g0, z2, interfaceC0420g, interfaceC0823f, interfaceC0400y, z3, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n LazyRow$lambda$5(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        LazyRow(xVar, o2, interfaceC0421g0, z2, interfaceC0420g, interfaceC0823f, interfaceC0400y, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    public static final <T> void items(J j2, List<? extends T> list, h1.c cVar, h1.c cVar2, h1.g gVar) {
        j2.items(list.size(), cVar != null ? new b(cVar, list) : null, new c(cVar2, list), G.v.composableLambdaInstance(802480018, true, new d(gVar, list)));
    }

    public static /* synthetic */ void items$default(J j2, List list, h1.c cVar, h1.c cVar2, h1.g gVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            cVar = null;
        }
        if ((i2 & 4) != 0) {
            cVar2 = a.INSTANCE;
        }
        j2.items(list.size(), cVar != null ? new b(cVar, list) : null, new c(cVar2, list), G.v.composableLambdaInstance(802480018, true, new d(gVar, list)));
    }

    public static final <T> void itemsIndexed(J j2, List<? extends T> list, h1.e eVar, h1.e eVar2, h1.h hVar) {
        j2.items(list.size(), eVar != null ? new l(eVar, list) : null, new m(eVar2, list), G.v.composableLambdaInstance(2039820996, true, new n(hVar, list)));
    }

    public static /* synthetic */ void itemsIndexed$default(J j2, List list, h1.e eVar, h1.e eVar2, h1.h hVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            eVar = null;
        }
        if ((i2 & 4) != 0) {
            eVar2 = k.INSTANCE;
        }
        j2.items(list.size(), eVar != null ? new l(eVar, list) : null, new m(eVar2, list), G.v.composableLambdaInstance(2039820996, true, new n(hVar, list)));
    }

    public static final <T> void items(J j2, T[] tArr, h1.c cVar, h1.c cVar2, h1.g gVar) {
        j2.items(tArr.length, cVar != null ? new f(cVar, tArr) : null, new g(cVar2, tArr), G.v.composableLambdaInstance(-1781742563, true, new h(gVar, tArr)));
    }

    public static final <T> void itemsIndexed(J j2, T[] tArr, h1.e eVar, h1.e eVar2, h1.h hVar) {
        j2.items(tArr.length, eVar != null ? new p(eVar, tArr) : null, new q(eVar2, tArr), G.v.composableLambdaInstance(1763000017, true, new r(hVar, tArr)));
    }

    public static /* synthetic */ void items$default(J j2, Object[] objArr, h1.c cVar, h1.c cVar2, h1.g gVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            cVar = null;
        }
        if ((i2 & 4) != 0) {
            cVar2 = C0041e.INSTANCE;
        }
        j2.items(objArr.length, cVar != null ? new f(cVar, objArr) : null, new g(cVar2, objArr), G.v.composableLambdaInstance(-1781742563, true, new h(gVar, objArr)));
    }

    public static /* synthetic */ void itemsIndexed$default(J j2, Object[] objArr, h1.e eVar, h1.e eVar2, h1.h hVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            eVar = null;
        }
        if ((i2 & 4) != 0) {
            eVar2 = o.INSTANCE;
        }
        j2.items(objArr.length, eVar != null ? new p(eVar, objArr) : null, new q(eVar2, objArr), G.v.composableLambdaInstance(1763000017, true, new r(hVar, objArr)));
    }

    public static /* synthetic */ void items$default(J j2, List list, h1.c cVar, h1.g gVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            cVar = null;
        }
        j2.items(list.size(), cVar != null ? new b(cVar, list) : null, new c(a.INSTANCE, list), G.v.composableLambdaInstance(802480018, true, new d(gVar, list)));
    }

    public static /* synthetic */ void itemsIndexed$default(J j2, List list, h1.e eVar, h1.h hVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            eVar = null;
        }
        j2.items(list.size(), eVar != null ? new l(eVar, list) : null, new i(list), G.v.composableLambdaInstance(2039820996, true, new n(hVar, list)));
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0118  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0124  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x0201  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x0215  */
    /* JADX WARN: Removed duplicated region for block: B:164:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x00f8  */
    @U0.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final /* synthetic */ void LazyColumn(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, boolean z3, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        boolean z4;
        InterfaceC0424i interfaceC0424i2;
        int i6;
        InterfaceC0822e interfaceC0822e2;
        InterfaceC0400y interfaceC0400y2;
        int i7;
        androidx.compose.ui.x xVar2;
        O oRememberLazyListState;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z5;
        boolean z6;
        InterfaceC0424i interfaceC0424i3;
        InterfaceC0400y interfaceC0400y3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0424i top;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        boolean z7;
        InterfaceC0822e interfaceC0822e3;
        int i8;
        InterfaceC0400y interfaceC0400y4;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-740714857);
        int i9 = i3 & 1;
        if (i9 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i10 = i3 & 4;
        if (i10 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g0) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z4 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z4) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0424i2 = interfaceC0424i;
                        int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0424i2) ? 16384 : 8192;
                        i4 |= i11;
                    } else {
                        interfaceC0424i2 = interfaceC0424i;
                    }
                    i4 |= i11;
                } else {
                    interfaceC0424i2 = interfaceC0424i;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0822e2 = interfaceC0822e;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0822e2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i12 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i12;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i12;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    i7 = i3 & 128;
                    if (i7 == 0) {
                        i4 |= 12582912;
                    } else if ((i2 & 12582912) == 0) {
                        i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 8388608 : 4194304;
                    }
                    if ((i3 & 256) != 0) {
                        if ((i2 & 100663296) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 67108864 : 33554432;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) != 0 && !interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                xVar2 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                                z7 = z3;
                                top = interfaceC0424i2;
                                interfaceC0822e3 = interfaceC0822e2;
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400y2;
                            } else {
                                xVar2 = i9 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i10 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g0;
                                if (i5 != 0) {
                                    z4 = false;
                                }
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    top = !z4 ? c0418f.getTop() : c0418f.getBottom();
                                    i4 &= -57345;
                                } else {
                                    top = interfaceC0424i2;
                                }
                                InterfaceC0822e start = i6 != 0 ? InterfaceC0849g.Companion.getStart() : interfaceC0822e2;
                                if ((i3 & 64) != 0) {
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                    i4 &= -3670017;
                                } else {
                                    interfaceC0400yFlingBehavior = interfaceC0400y2;
                                }
                                if (i7 != 0) {
                                    interfaceC0822e3 = start;
                                    z7 = true;
                                } else {
                                    z7 = z3;
                                    interfaceC0822e3 = start;
                                }
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400yFlingBehavior;
                            }
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-740714857, i8, -1, "androidx.compose.foundation.lazy.LazyColumn (LazyDsl.kt:428)");
                            }
                            LazyColumn(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z4, top, interfaceC0822e3, interfaceC0400y4, z7, k0.rememberOverscrollEffect(interfaceC0768pStartRestartGroup, 0), cVar, interfaceC0768pStartRestartGroup, (33554430 & i8) | ((i8 << 3) & 1879048192), 0);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            interfaceC0822e2 = interfaceC0822e3;
                            interfaceC0400y3 = interfaceC0400y4;
                            interfaceC0424i3 = top;
                            z6 = z4;
                            z5 = z7;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            oRememberLazyListState = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                            z5 = z3;
                            z6 = z4;
                            interfaceC0424i3 = interfaceC0424i2;
                            interfaceC0400y3 = interfaceC0400y2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0451d(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z6, interfaceC0424i3, interfaceC0822e2, interfaceC0400y3, z5, cVar, i2, i3, 0));
                            return;
                        }
                        return;
                    }
                    i4 |= 100663296;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0822e2 = interfaceC0822e;
                if ((1572864 & i2) != 0) {
                }
                i7 = i3 & 128;
                if (i7 == 0) {
                }
                if ((i3 & 256) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z4 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0822e2 = interfaceC0822e;
            if ((1572864 & i2) != 0) {
            }
            i7 = i3 & 128;
            if (i7 == 0) {
            }
            if ((i3 & 256) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z4 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0822e2 = interfaceC0822e;
        if ((1572864 & i2) != 0) {
        }
        i7 = i3 & 128;
        if (i7 == 0) {
        }
        if ((i3 & 256) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0118  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0124  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x0201  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x0215  */
    /* JADX WARN: Removed duplicated region for block: B:164:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x00f8  */
    @U0.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final /* synthetic */ void LazyRow(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, boolean z3, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        boolean z4;
        InterfaceC0420g interfaceC0420g2;
        int i6;
        InterfaceC0823f interfaceC0823f2;
        InterfaceC0400y interfaceC0400y2;
        int i7;
        androidx.compose.ui.x xVar2;
        O oRememberLazyListState;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z5;
        boolean z6;
        InterfaceC0420g interfaceC0420g3;
        InterfaceC0400y interfaceC0400y3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0420g start;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        boolean z7;
        InterfaceC0823f interfaceC0823f3;
        int i8;
        InterfaceC0400y interfaceC0400y4;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1724297413);
        int i9 = i3 & 1;
        if (i9 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i10 = i3 & 4;
        if (i10 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g0) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z4 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z4) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0420g2 = interfaceC0420g;
                        int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0420g2) ? 16384 : 8192;
                        i4 |= i11;
                    } else {
                        interfaceC0420g2 = interfaceC0420g;
                    }
                    i4 |= i11;
                } else {
                    interfaceC0420g2 = interfaceC0420g;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0823f2 = interfaceC0823f;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0823f2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i12 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i12;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i12;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    i7 = i3 & 128;
                    if (i7 == 0) {
                        i4 |= 12582912;
                    } else if ((i2 & 12582912) == 0) {
                        i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 8388608 : 4194304;
                    }
                    if ((i3 & 256) != 0) {
                        if ((i2 & 100663296) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 67108864 : 33554432;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) != 0 && !interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                xVar2 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                                z7 = z3;
                                start = interfaceC0420g2;
                                interfaceC0823f3 = interfaceC0823f2;
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400y2;
                            } else {
                                xVar2 = i9 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i10 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g0;
                                if (i5 != 0) {
                                    z4 = false;
                                }
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    start = !z4 ? c0418f.getStart() : c0418f.getEnd();
                                    i4 &= -57345;
                                } else {
                                    start = interfaceC0420g2;
                                }
                                InterfaceC0823f top = i6 != 0 ? InterfaceC0849g.Companion.getTop() : interfaceC0823f2;
                                if ((i3 & 64) != 0) {
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                    i4 &= -3670017;
                                } else {
                                    interfaceC0400yFlingBehavior = interfaceC0400y2;
                                }
                                if (i7 != 0) {
                                    interfaceC0823f3 = top;
                                    z7 = true;
                                } else {
                                    z7 = z3;
                                    interfaceC0823f3 = top;
                                }
                                i8 = i4;
                                interfaceC0400y4 = interfaceC0400yFlingBehavior;
                            }
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-1724297413, i8, -1, "androidx.compose.foundation.lazy.LazyRow (LazyDsl.kt:482)");
                            }
                            LazyRow(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z4, start, interfaceC0823f3, interfaceC0400y4, z7, k0.rememberOverscrollEffect(interfaceC0768pStartRestartGroup, 0), cVar, interfaceC0768pStartRestartGroup, (33554430 & i8) | ((i8 << 3) & 1879048192), 0);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            interfaceC0823f2 = interfaceC0823f3;
                            interfaceC0400y3 = interfaceC0400y4;
                            interfaceC0420g3 = start;
                            z6 = z4;
                            z5 = z7;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            oRememberLazyListState = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g0;
                            z5 = z3;
                            z6 = z4;
                            interfaceC0420g3 = interfaceC0420g2;
                            interfaceC0400y3 = interfaceC0400y2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0451d(xVar2, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z6, interfaceC0420g3, interfaceC0823f2, interfaceC0400y3, z5, cVar, i2, i3, 1));
                            return;
                        }
                        return;
                    }
                    i4 |= 100663296;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0823f2 = interfaceC0823f;
                if ((1572864 & i2) != 0) {
                }
                i7 = i3 & 128;
                if (i7 == 0) {
                }
                if ((i3 & 256) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z4 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0823f2 = interfaceC0823f;
            if ((1572864 & i2) != 0) {
            }
            i7 = i3 & 128;
            if (i7 == 0) {
            }
            if ((i3 & 256) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z4 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0823f2 = interfaceC0823f;
        if ((1572864 & i2) != 0) {
        }
        i7 = i3 & 128;
        if (i7 == 0) {
        }
        if ((i3 & 256) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 38347923) != 38347922, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    public static /* synthetic */ void itemsIndexed$default(J j2, Object[] objArr, h1.e eVar, h1.h hVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            eVar = null;
        }
        j2.items(objArr.length, eVar != null ? new p(eVar, objArr) : null, new j(objArr), G.v.composableLambdaInstance(1763000017, true, new r(hVar, objArr)));
    }

    public static /* synthetic */ void items$default(J j2, Object[] objArr, h1.c cVar, h1.g gVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            cVar = null;
        }
        j2.items(objArr.length, cVar != null ? new f(cVar, objArr) : null, new g(C0041e.INSTANCE, objArr), G.v.composableLambdaInstance(-1781742563, true, new h(gVar, objArr)));
    }

    /* JADX WARN: Removed duplicated region for block: B:141:0x0197  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x01dd  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x01fb  */
    /* JADX WARN: Removed duplicated region for block: B:151:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x00fa  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0103  */
    @U0.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final /* synthetic */ void LazyColumn(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0400y interfaceC0400y, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        InterfaceC0421g0 interfaceC0421g02;
        int i5;
        boolean z3;
        InterfaceC0424i interfaceC0424i2;
        int i6;
        InterfaceC0822e interfaceC0822e2;
        InterfaceC0400y interfaceC0400y2;
        androidx.compose.ui.x xVar2;
        O o3;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z4;
        InterfaceC0424i interfaceC0424i3;
        InterfaceC0822e start;
        InterfaceC0400y interfaceC0400y3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        androidx.compose.ui.x xVar3;
        O oRememberLazyListState;
        boolean z5;
        InterfaceC0424i top;
        int i7;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-563353797);
        int i8 = i3 & 1;
        if (i8 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i9 = i3 & 4;
        if (i9 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                interfaceC0421g02 = interfaceC0421g0;
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g02) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z3 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0424i2 = interfaceC0424i;
                        int i10 = interfaceC0768pStartRestartGroup.changed(interfaceC0424i2) ? 16384 : 8192;
                        i4 |= i10;
                    } else {
                        interfaceC0424i2 = interfaceC0424i;
                    }
                    i4 |= i10;
                } else {
                    interfaceC0424i2 = interfaceC0424i;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0822e2 = interfaceC0822e;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0822e2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i11;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i11;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    if ((i3 & 128) != 0) {
                        if ((i2 & 12582912) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 8388608 : 4194304;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) != 0 && !interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                xVar3 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g02;
                                z5 = z3;
                                top = interfaceC0424i2;
                                start = interfaceC0822e2;
                            } else {
                                xVar3 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i9 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g02;
                                z5 = i5 == 0 ? z3 : false;
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    top = !z5 ? c0418f.getTop() : c0418f.getBottom();
                                    i4 &= -57345;
                                } else {
                                    top = interfaceC0424i2;
                                }
                                start = i6 != 0 ? InterfaceC0849g.Companion.getStart() : interfaceC0822e2;
                                if ((i3 & 64) != 0) {
                                    i7 = i4 & (-3670017);
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                }
                                interfaceC0768pStartRestartGroup.endDefaults();
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventStart(-563353797, i7, -1, "androidx.compose.foundation.lazy.LazyColumn (LazyDsl.kt:455)");
                                }
                                LazyColumn(xVar3, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z5, top, start, interfaceC0400yFlingBehavior, true, null, cVar, interfaceC0768pStartRestartGroup, (i7 & 14) | 12582912 | (i7 & 112) | (i7 & 896) | (i7 & 7168) | (57344 & i7) | (458752 & i7) | (3670016 & i7) | ((i7 << 6) & 1879048192), 256);
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventEnd();
                                }
                                o3 = oRememberLazyListState;
                                xVar2 = xVar3;
                                InterfaceC0424i interfaceC0424i4 = top;
                                interfaceC0400y3 = interfaceC0400yFlingBehavior;
                                z4 = z5;
                                interfaceC0424i3 = interfaceC0424i4;
                            }
                            i7 = i4;
                            interfaceC0400yFlingBehavior = interfaceC0400y2;
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                            }
                            LazyColumn(xVar3, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z5, top, start, interfaceC0400yFlingBehavior, true, null, cVar, interfaceC0768pStartRestartGroup, (i7 & 14) | 12582912 | (i7 & 112) | (i7 & 896) | (i7 & 7168) | (57344 & i7) | (458752 & i7) | (3670016 & i7) | ((i7 << 6) & 1879048192), 256);
                            if (AbstractC0776s.isTraceInProgress()) {
                            }
                            o3 = oRememberLazyListState;
                            xVar2 = xVar3;
                            InterfaceC0424i interfaceC0424i42 = top;
                            interfaceC0400y3 = interfaceC0400yFlingBehavior;
                            z4 = z5;
                            interfaceC0424i3 = interfaceC0424i42;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            o3 = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g02;
                            z4 = z3;
                            interfaceC0424i3 = interfaceC0424i2;
                            start = interfaceC0822e2;
                            interfaceC0400y3 = interfaceC0400y2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0450c(xVar2, o3, interfaceC0421g0M952PaddingValues0680j_4, z4, interfaceC0424i3, start, interfaceC0400y3, cVar, i2, i3, 0));
                            return;
                        }
                        return;
                    }
                    i4 |= 12582912;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0822e2 = interfaceC0822e;
                if ((1572864 & i2) != 0) {
                }
                if ((i3 & 128) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z3 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0822e2 = interfaceC0822e;
            if ((1572864 & i2) != 0) {
            }
            if ((i3 & 128) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        interfaceC0421g02 = interfaceC0421g0;
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z3 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0822e2 = interfaceC0822e;
        if ((1572864 & i2) != 0) {
        }
        if ((i3 & 128) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:141:0x0197  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x01dd  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x01fb  */
    /* JADX WARN: Removed duplicated region for block: B:151:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x00fa  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0103  */
    @U0.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final /* synthetic */ void LazyRow(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0400y interfaceC0400y, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        InterfaceC0421g0 interfaceC0421g02;
        int i5;
        boolean z3;
        InterfaceC0420g interfaceC0420g2;
        int i6;
        InterfaceC0823f interfaceC0823f2;
        InterfaceC0400y interfaceC0400y2;
        androidx.compose.ui.x xVar2;
        O o3;
        InterfaceC0421g0 interfaceC0421g0M952PaddingValues0680j_4;
        boolean z4;
        InterfaceC0420g interfaceC0420g3;
        InterfaceC0823f top;
        InterfaceC0400y interfaceC0400y3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        androidx.compose.ui.x xVar3;
        O oRememberLazyListState;
        boolean z5;
        InterfaceC0420g start;
        int i7;
        InterfaceC0400y interfaceC0400yFlingBehavior;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(407929823);
        int i8 = i3 & 1;
        if (i8 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= ((i3 & 2) == 0 && interfaceC0768pStartRestartGroup.changed(o2)) ? 32 : 16;
        }
        int i9 = i3 & 4;
        if (i9 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                interfaceC0421g02 = interfaceC0421g0;
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0421g02) ? 256 : 128;
            }
            i5 = i3 & 8;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    z3 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 2048 : 1024;
                }
                if ((i2 & 24576) == 0) {
                    if ((i3 & 16) == 0) {
                        interfaceC0420g2 = interfaceC0420g;
                        int i10 = interfaceC0768pStartRestartGroup.changed(interfaceC0420g2) ? 16384 : 8192;
                        i4 |= i10;
                    } else {
                        interfaceC0420g2 = interfaceC0420g;
                    }
                    i4 |= i10;
                } else {
                    interfaceC0420g2 = interfaceC0420g;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                } else {
                    if ((196608 & i2) == 0) {
                        interfaceC0823f2 = interfaceC0823f;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0823f2) ? 131072 : 65536;
                    }
                    if ((1572864 & i2) != 0) {
                        if ((i3 & 64) == 0) {
                            interfaceC0400y2 = interfaceC0400y;
                            int i11 = interfaceC0768pStartRestartGroup.changed(interfaceC0400y2) ? 1048576 : 524288;
                            i4 |= i11;
                        } else {
                            interfaceC0400y2 = interfaceC0400y;
                        }
                        i4 |= i11;
                    } else {
                        interfaceC0400y2 = interfaceC0400y;
                    }
                    if ((i3 & 128) != 0) {
                        if ((i2 & 12582912) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 8388608 : 4194304;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                            interfaceC0768pStartRestartGroup.startDefaults();
                            if ((i2 & 1) != 0 && !interfaceC0768pStartRestartGroup.getDefaultsInvalid()) {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 2) != 0) {
                                    i4 &= -113;
                                }
                                if ((i3 & 16) != 0) {
                                    i4 &= -57345;
                                }
                                if ((i3 & 64) != 0) {
                                    i4 &= -3670017;
                                }
                                xVar3 = xVar;
                                oRememberLazyListState = o2;
                                interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g02;
                                z5 = z3;
                                start = interfaceC0420g2;
                                top = interfaceC0823f2;
                            } else {
                                xVar3 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                if ((i3 & 2) != 0) {
                                    oRememberLazyListState = T.rememberLazyListState(0, 0, interfaceC0768pStartRestartGroup, 0, 3);
                                    i4 &= -113;
                                } else {
                                    oRememberLazyListState = o2;
                                }
                                interfaceC0421g0M952PaddingValues0680j_4 = i9 != 0 ? AbstractC0413c0.m952PaddingValues0680j_4(C1311h.m5076constructorimpl(0)) : interfaceC0421g02;
                                z5 = i5 == 0 ? z3 : false;
                                if ((i3 & 16) != 0) {
                                    C0418f c0418f = C0418f.INSTANCE;
                                    start = !z5 ? c0418f.getStart() : c0418f.getEnd();
                                    i4 &= -57345;
                                } else {
                                    start = interfaceC0420g2;
                                }
                                top = i6 != 0 ? InterfaceC0849g.Companion.getTop() : interfaceC0823f2;
                                if ((i3 & 64) != 0) {
                                    i7 = i4 & (-3670017);
                                    interfaceC0400yFlingBehavior = androidx.compose.foundation.gestures.V.INSTANCE.flingBehavior(interfaceC0768pStartRestartGroup, 6);
                                }
                                interfaceC0768pStartRestartGroup.endDefaults();
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventStart(407929823, i7, -1, "androidx.compose.foundation.lazy.LazyRow (LazyDsl.kt:509)");
                                }
                                LazyRow(xVar3, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z5, start, top, interfaceC0400yFlingBehavior, true, null, cVar, interfaceC0768pStartRestartGroup, (i7 & 14) | 12582912 | (i7 & 112) | (i7 & 896) | (i7 & 7168) | (57344 & i7) | (458752 & i7) | (3670016 & i7) | ((i7 << 6) & 1879048192), 256);
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventEnd();
                                }
                                o3 = oRememberLazyListState;
                                xVar2 = xVar3;
                                InterfaceC0420g interfaceC0420g4 = start;
                                interfaceC0400y3 = interfaceC0400yFlingBehavior;
                                z4 = z5;
                                interfaceC0420g3 = interfaceC0420g4;
                            }
                            i7 = i4;
                            interfaceC0400yFlingBehavior = interfaceC0400y2;
                            interfaceC0768pStartRestartGroup.endDefaults();
                            if (AbstractC0776s.isTraceInProgress()) {
                            }
                            LazyRow(xVar3, oRememberLazyListState, interfaceC0421g0M952PaddingValues0680j_4, z5, start, top, interfaceC0400yFlingBehavior, true, null, cVar, interfaceC0768pStartRestartGroup, (i7 & 14) | 12582912 | (i7 & 112) | (i7 & 896) | (i7 & 7168) | (57344 & i7) | (458752 & i7) | (3670016 & i7) | ((i7 << 6) & 1879048192), 256);
                            if (AbstractC0776s.isTraceInProgress()) {
                            }
                            o3 = oRememberLazyListState;
                            xVar2 = xVar3;
                            InterfaceC0420g interfaceC0420g42 = start;
                            interfaceC0400y3 = interfaceC0400yFlingBehavior;
                            z4 = z5;
                            interfaceC0420g3 = interfaceC0420g42;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar2 = xVar;
                            o3 = o2;
                            interfaceC0421g0M952PaddingValues0680j_4 = interfaceC0421g02;
                            z4 = z3;
                            interfaceC0420g3 = interfaceC0420g2;
                            top = interfaceC0823f2;
                            interfaceC0400y3 = interfaceC0400y2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0450c(xVar2, o3, interfaceC0421g0M952PaddingValues0680j_4, z4, interfaceC0420g3, top, interfaceC0400y3, cVar, i2, i3, 1));
                            return;
                        }
                        return;
                    }
                    i4 |= 12582912;
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0823f2 = interfaceC0823f;
                if ((1572864 & i2) != 0) {
                }
                if ((i3 & 128) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            z3 = z2;
            if ((i2 & 24576) == 0) {
            }
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            interfaceC0823f2 = interfaceC0823f;
            if ((1572864 & i2) != 0) {
            }
            if ((i3 & 128) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        interfaceC0421g02 = interfaceC0421g0;
        i5 = i3 & 8;
        if (i5 == 0) {
        }
        z3 = z2;
        if ((i2 & 24576) == 0) {
        }
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        interfaceC0823f2 = interfaceC0823f;
        if ((1572864 & i2) != 0) {
        }
        if ((i3 & 128) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 4793491) != 4793490, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }
}
