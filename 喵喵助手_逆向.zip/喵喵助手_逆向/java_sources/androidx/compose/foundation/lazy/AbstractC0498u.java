package androidx.compose.foundation.lazy;

import O0.C0227q0;
import androidx.compose.foundation.lazy.layout.p0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0498u {
    public static final h1.a rememberLazyListItemProviderLambda(O o2, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-343736148, i2, -1, "androidx.compose.foundation.lazy.rememberLazyListItemProviderLambda (LazyListItemProvider.kt:41)");
        }
        d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(cVar, interfaceC0768p, (i2 >> 3) & 14);
        boolean z2 = (((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(o2)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = new kotlin.jvm.internal.w(Q1.derivedStateOf(Q1.referentialEqualityPolicy(), new C0227q0(Q1.derivedStateOf(Q1.referentialEqualityPolicy(), new C0497t(d2VarRememberUpdatedState, 0)), o2, new C0454g(), 3))) { // from class: androidx.compose.foundation.lazy.u.a
                @Override // n1.l
                public Object get() {
                    return ((d2) this.receiver).getValue();
                }
            };
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        n1.l lVar = (n1.l) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return lVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0493o rememberLazyListItemProviderLambda$lambda$2$lambda$0(d2 d2Var) {
        return new C0493o((h1.c) d2Var.getValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0496s rememberLazyListItemProviderLambda$lambda$2$lambda$1(d2 d2Var, O o2, C0454g c0454g) {
        C0493o c0493o = (C0493o) d2Var.getValue();
        return new C0496s(o2, c0493o, c0454g, new p0(o2.getNearestRange$foundation_release(), c0493o));
    }
}
