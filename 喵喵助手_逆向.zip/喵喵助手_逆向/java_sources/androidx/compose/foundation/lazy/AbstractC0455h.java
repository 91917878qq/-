package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.InterfaceC0471f0;
import androidx.compose.foundation.lazy.layout.g0;
import androidx.compose.ui.semantics.C1108b;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0455h {

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.h$a */
    public static final class a implements InterfaceC0471f0 {
        final /* synthetic */ boolean $isVertical;
        final /* synthetic */ O $state;

        public a(O o2, boolean z2) {
            this.$state = o2;
            this.$isVertical = z2;
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public C1108b collectionInfo() {
            return this.$isVertical ? new C1108b(this.$state.getLayoutInfo().getTotalItemsCount(), 1) : new C1108b(1, this.$state.getLayoutInfo().getTotalItemsCount());
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public int getContentPadding() {
            return this.$state.getLayoutInfo().getAfterContentPadding() + this.$state.getLayoutInfo().getBeforeContentPadding();
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public float getMaxScrollOffset() {
            return g0.estimatedLazyMaxScrollOffset(this.$state.getFirstVisibleItemIndex(), this.$state.getFirstVisibleItemScrollOffset(), this.$state.getCanScrollForward());
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public float getScrollOffset() {
            return g0.estimatedLazyScrollOffset(this.$state.getFirstVisibleItemIndex(), this.$state.getFirstVisibleItemScrollOffset());
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public int getViewport() {
            return (int) (this.$state.getLayoutInfo().getOrientation() == androidx.compose.foundation.gestures.I.Vertical ? this.$state.getLayoutInfo().mo1046getViewportSizeYbymL2g() & 4294967295L : this.$state.getLayoutInfo().mo1046getViewportSizeYbymL2g() >> 32);
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0471f0
        public Object scrollToItem(int i2, Y0.c cVar) {
            Object objScrollToItem$default = O.scrollToItem$default(this.$state, i2, 0, cVar, 2, null);
            return objScrollToItem$default == Z0.a.f1616b ? objScrollToItem$default : U0.n.f1521a;
        }
    }

    public static final InterfaceC0471f0 LazyLayoutSemanticState(O o2, boolean z2) {
        return new a(o2, z2);
    }
}
