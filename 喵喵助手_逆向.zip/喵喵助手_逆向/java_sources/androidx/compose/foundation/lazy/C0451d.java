package androidx.compose.foundation.lazy;

import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.foundation.layout.InterfaceC0420g;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.foundation.layout.InterfaceC0424i;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0451d implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1841b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ androidx.compose.ui.x f1842c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ O f1843d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0421g0 f1844e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ boolean f1845f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0400y f1846g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ boolean f1847h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ h1.c f1848i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1849j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ int f1850k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Object f1851l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f1852m;

    public /* synthetic */ C0451d(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, Object obj, Object obj2, InterfaceC0400y interfaceC0400y, boolean z3, h1.c cVar, int i2, int i3, int i4) {
        this.f1841b = i4;
        this.f1842c = xVar;
        this.f1843d = o2;
        this.f1844e = interfaceC0421g0;
        this.f1845f = z2;
        this.f1851l = obj;
        this.f1852m = obj2;
        this.f1846g = interfaceC0400y;
        this.f1847h = z3;
        this.f1848i = cVar;
        this.f1849j = i2;
        this.f1850k = i3;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        InterfaceC0768p interfaceC0768p = (InterfaceC0768p) obj;
        switch (this.f1841b) {
            case 0:
                int iIntValue = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyColumn$lambda$2(this.f1842c, this.f1843d, this.f1844e, this.f1845f, (InterfaceC0424i) this.f1851l, (InterfaceC0822e) this.f1852m, this.f1846g, this.f1847h, this.f1848i, this.f1849j, this.f1850k, interfaceC0768p, iIntValue);
            default:
                int iIntValue2 = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyRow$lambda$4(this.f1842c, this.f1843d, this.f1844e, this.f1845f, (InterfaceC0420g) this.f1851l, (InterfaceC0823f) this.f1852m, this.f1846g, this.f1847h, this.f1848i, this.f1849j, this.f1850k, interfaceC0768p, iIntValue2);
        }
    }
}
