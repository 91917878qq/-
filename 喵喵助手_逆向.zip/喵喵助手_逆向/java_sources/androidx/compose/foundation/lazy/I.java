package androidx.compose.foundation.lazy;

/* JADX INFO: loaded from: classes.dex */
public abstract class I {
    private static final int UnsetItemCount = -1;

    public static final H LazyListPrefetchStrategy(int i2) {
        return new C0448a(i2);
    }

    public static /* synthetic */ H LazyListPrefetchStrategy$default(int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i2 = 2;
        }
        return LazyListPrefetchStrategy(i2);
    }
}
