package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.C0474i;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import j.AbstractC1353k;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0496s implements InterfaceC0495q {
    private final C0493o intervalContent;
    private final C0454g itemScope;
    private final androidx.compose.foundation.lazy.layout.H keyIndexMap;
    private final O state;

    /* JADX INFO: renamed from: androidx.compose.foundation.lazy.s$a */
    public static final class a implements h1.e {
        final /* synthetic */ int $index;

        public a(int i2) {
            this.$index = i2;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            if (!interfaceC0768p.shouldExecute((i2 & 3) != 2, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-824725566, i2, -1, "androidx.compose.foundation.lazy.LazyListItemProviderImpl.Item.<anonymous> (LazyListItemProvider.kt:78)");
            }
            C0493o c0493o = C0496s.this.intervalContent;
            int i3 = this.$index;
            C0496s c0496s = C0496s.this;
            C0474i c0474i = c0493o.getIntervals().get(i3);
            ((C0491m) c0474i.getValue()).getItem().invoke(c0496s.getItemScope(), Integer.valueOf(i3 - c0474i.getStartIndex()), interfaceC0768p, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    public C0496s(O o2, C0493o c0493o, C0454g c0454g, androidx.compose.foundation.lazy.layout.H h2) {
        this.state = o2;
        this.intervalContent = c0493o;
        this.itemScope = c0454g;
        this.keyIndexMap = h2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n Item$lambda$0(C0496s c0496s, int i2, Object obj, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        c0496s.Item(i2, obj, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i3 | 1));
        return U0.n.f1521a;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q, androidx.compose.foundation.lazy.layout.D
    public void Item(int i2, Object obj, InterfaceC0768p interfaceC0768p, int i3) {
        int i4;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-462424778);
        if ((i3 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(i2) ? 4 : 2) | i3;
        } else {
            i4 = i3;
        }
        if ((i3 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(obj) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(this) ? 256 : 128;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 147) != 146, i4 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-462424778, i4, -1, "androidx.compose.foundation.lazy.LazyListItemProviderImpl.Item (LazyListItemProvider.kt:76)");
            }
            androidx.compose.foundation.lazy.layout.T.LazyLayoutPinnableItem(obj, i2, this.state.getPinnedItems$foundation_release(), G.v.rememberComposableLambda(-824725566, true, new a(i2), interfaceC0768pStartRestartGroup, 54), interfaceC0768pStartRestartGroup, ((i4 >> 3) & 14) | 3072 | ((i4 << 3) & 112));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new r(this, i2, obj, i3, 0));
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0496s) {
            return kotlin.jvm.internal.o.a(this.intervalContent, ((C0496s) obj).intervalContent);
        }
        return false;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q, androidx.compose.foundation.lazy.layout.D
    public Object getContentType(int i2) {
        return this.intervalContent.getContentType(i2);
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q
    public AbstractC1353k getHeaderIndexes() {
        return this.intervalContent.getHeaderIndexes();
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q, androidx.compose.foundation.lazy.layout.D
    public int getIndex(Object obj) {
        return getKeyIndexMap().getIndex(obj);
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q, androidx.compose.foundation.lazy.layout.D
    public int getItemCount() {
        return this.intervalContent.getItemCount();
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q
    public C0454g getItemScope() {
        return this.itemScope;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q, androidx.compose.foundation.lazy.layout.D
    public Object getKey(int i2) {
        Object key = getKeyIndexMap().getKey(i2);
        return key == null ? this.intervalContent.getKey(i2) : key;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0495q
    public androidx.compose.foundation.lazy.layout.H getKeyIndexMap() {
        return this.keyIndexMap;
    }

    public int hashCode() {
        return this.intervalContent.hashCode();
    }
}
