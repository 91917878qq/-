package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.C0487w;
import androidx.compose.foundation.lazy.layout.LazyLayoutItemAnimator;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.layout.AbstractC0974x0;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public final class C implements InterfaceC0494p, androidx.compose.foundation.lazy.layout.N {
    public static final int $stable = 8;
    private final int afterContentPadding;
    private final LazyLayoutItemAnimator animator;
    private final int beforeContentPadding;
    private final long constraints;
    private final Object contentType;
    private final int crossAxisSize;
    private final InterfaceC0822e horizontalAlignment;
    private final int index;
    private final boolean isVertical;
    private final Object key;
    private final int lane;
    private final e0.u layoutDirection;
    private int mainAxisLayoutSize;
    private final int mainAxisSizeWithSpacings;
    private int maxMainAxisOffset;
    private int minMainAxisOffset;
    private boolean nonScrollableItem;
    private int offset;
    private final int[] placeableOffsets;
    private final List<AbstractC0974x0> placeables;
    private final boolean reverseLayout;
    private final int size;
    private final int spacing;
    private final int span;
    private final InterfaceC0823f verticalAlignment;
    private final long visualOffset;

    public /* synthetic */ C(int i2, List list, boolean z2, InterfaceC0822e interfaceC0822e, InterfaceC0823f interfaceC0823f, e0.u uVar, boolean z3, int i3, int i4, int i5, long j2, Object obj, Object obj2, LazyLayoutItemAnimator lazyLayoutItemAnimator, long j3, AbstractC1378g abstractC1378g) {
        this(i2, list, z2, interfaceC0822e, interfaceC0823f, uVar, z3, i3, i4, i5, j2, obj, obj2, lazyLayoutItemAnimator, j3);
    }

    /* JADX INFO: renamed from: copy-4Tuh3kE, reason: not valid java name */
    private final long m1047copy4Tuh3kE(long j2, h1.c cVar) {
        int iM5197getYimpl;
        long j3;
        if (isVertical()) {
            int iM5196getXimpl = e0.o.m5196getXimpl(j2);
            iM5197getYimpl = ((Number) cVar.invoke(Integer.valueOf(e0.o.m5197getYimpl(j2)))).intValue();
            j3 = iM5196getXimpl;
        } else {
            int iIntValue = ((Number) cVar.invoke(Integer.valueOf(e0.o.m5196getXimpl(j2)))).intValue();
            iM5197getYimpl = e0.o.m5197getYimpl(j2);
            j3 = iIntValue;
        }
        return e0.o.m5190constructorimpl((j3 << 32) | (((long) iM5197getYimpl) & 4294967295L));
    }

    /* JADX INFO: renamed from: getMainAxis--gyyYBs, reason: not valid java name */
    private final int m1048getMainAxisgyyYBs(long j2) {
        return isVertical() ? e0.o.m5197getYimpl(j2) : e0.o.m5196getXimpl(j2);
    }

    private final int getMainAxisSize(AbstractC0974x0 abstractC0974x0) {
        return isVertical() ? abstractC0974x0.getHeight() : abstractC0974x0.getWidth();
    }

    public final void applyScrollDelta(int i2, boolean z2) {
        int iIntValue;
        int iM5197getYimpl;
        if (getNonScrollableItem()) {
            return;
        }
        this.offset = getOffset() + i2;
        int length = this.placeableOffsets.length;
        for (int i3 = 0; i3 < length; i3++) {
            int i4 = i3 & 1;
            if ((isVertical() && i4 != 0) || (!isVertical() && i4 == 0)) {
                int[] iArr = this.placeableOffsets;
                iArr[i3] = iArr[i3] + i2;
            }
        }
        if (z2) {
            int placeablesCount = getPlaceablesCount();
            for (int i5 = 0; i5 < placeablesCount; i5++) {
                C0487w animation = this.animator.getAnimation(getKey(), i5);
                if (animation != null) {
                    long jM1107getRawOffsetnOccac = animation.m1107getRawOffsetnOccac();
                    if (isVertical()) {
                        iIntValue = e0.o.m5196getXimpl(jM1107getRawOffsetnOccac);
                        iM5197getYimpl = Integer.valueOf(e0.o.m5197getYimpl(jM1107getRawOffsetnOccac) + i2).intValue();
                    } else {
                        iIntValue = Integer.valueOf(e0.o.m5196getXimpl(jM1107getRawOffsetnOccac) + i2).intValue();
                        iM5197getYimpl = e0.o.m5197getYimpl(jM1107getRawOffsetnOccac);
                    }
                    animation.m1110setRawOffsetgyyYBs(e0.o.m5190constructorimpl((((long) iIntValue) << 32) | (4294967295L & ((long) iM5197getYimpl))));
                }
            }
        }
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    /* JADX INFO: renamed from: getConstraints-msEJaDk, reason: not valid java name */
    public long mo1049getConstraintsmsEJaDk() {
        return this.constraints;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0494p
    public Object getContentType() {
        return this.contentType;
    }

    public final int getCrossAxisSize() {
        return this.crossAxisSize;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0494p, androidx.compose.foundation.lazy.layout.N
    public int getIndex() {
        return this.index;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0494p, androidx.compose.foundation.lazy.layout.N
    public Object getKey() {
        return this.key;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public int getLane() {
        return this.lane;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public int getMainAxisSizeWithSpacings() {
        return this.mainAxisSizeWithSpacings;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public boolean getNonScrollableItem() {
        return this.nonScrollableItem;
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0494p
    public int getOffset() {
        return this.offset;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    /* JADX INFO: renamed from: getOffset-Bjo55l4, reason: not valid java name */
    public long mo1050getOffsetBjo55l4(int i2) {
        long offset;
        if (i2 == 0 && getPlaceablesCount() == 0) {
            if (isVertical()) {
                offset = (4294967295L & ((long) getOffset())) | (((long) 0) << 32);
            } else {
                offset = (4294967295L & ((long) 0)) | (((long) getOffset()) << 32);
            }
            return e0.o.m5190constructorimpl(offset);
        }
        int[] iArr = this.placeableOffsets;
        int i3 = i2 * 2;
        int i4 = iArr[i3];
        return e0.o.m5190constructorimpl((4294967295L & ((long) iArr[i3 + 1])) | (((long) i4) << 32));
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public Object getParentData(int i2) {
        return this.placeables.get(i2).getParentData();
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public int getPlaceablesCount() {
        return this.placeables.size();
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0494p
    public int getSize() {
        return this.size;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public int getSpan() {
        return this.span;
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public boolean isVertical() {
        return this.isVertical;
    }

    public final void place(AbstractC0974x0.a aVar, boolean z2) {
        androidx.compose.ui.graphics.layer.c layer;
        if (!(this.mainAxisLayoutSize != Integer.MIN_VALUE)) {
            AbstractC1403e.throwIllegalArgumentException("position() should be called first");
        }
        int placeablesCount = getPlaceablesCount();
        for (int i2 = 0; i2 < placeablesCount; i2++) {
            AbstractC0974x0 abstractC0974x0 = this.placeables.get(i2);
            int mainAxisSize = this.minMainAxisOffset - getMainAxisSize(abstractC0974x0);
            int i3 = this.maxMainAxisOffset;
            long jMo1050getOffsetBjo55l4 = mo1050getOffsetBjo55l4(i2);
            C0487w animation = this.animator.getAnimation(getKey(), i2);
            if (animation != null) {
                if (z2) {
                    animation.m1109setLookaheadOffsetgyyYBs(jMo1050getOffsetBjo55l4);
                } else {
                    if (!e0.o.m5195equalsimpl0(animation.m1105getLookaheadOffsetnOccac(), C0487w.Companion.m1111getNotInitializednOccac())) {
                        jMo1050getOffsetBjo55l4 = animation.m1105getLookaheadOffsetnOccac();
                    }
                    long jM5200plusqkQi6aY = e0.o.m5200plusqkQi6aY(jMo1050getOffsetBjo55l4, animation.m1106getPlacementDeltanOccac());
                    if ((m1048getMainAxisgyyYBs(jMo1050getOffsetBjo55l4) <= mainAxisSize && m1048getMainAxisgyyYBs(jM5200plusqkQi6aY) <= mainAxisSize) || (m1048getMainAxisgyyYBs(jMo1050getOffsetBjo55l4) >= i3 && m1048getMainAxisgyyYBs(jM5200plusqkQi6aY) >= i3)) {
                        animation.cancelPlacementAnimation();
                    }
                    jMo1050getOffsetBjo55l4 = jM5200plusqkQi6aY;
                }
                layer = animation.getLayer();
            } else {
                layer = null;
            }
            if (this.reverseLayout) {
                jMo1050getOffsetBjo55l4 = e0.o.m5190constructorimpl(isVertical() ? (((long) ((this.mainAxisLayoutSize - e0.o.m5197getYimpl(jMo1050getOffsetBjo55l4)) - getMainAxisSize(abstractC0974x0))) & 4294967295L) | (((long) e0.o.m5196getXimpl(jMo1050getOffsetBjo55l4)) << 32) : (((long) ((this.mainAxisLayoutSize - e0.o.m5196getXimpl(jMo1050getOffsetBjo55l4)) - getMainAxisSize(abstractC0974x0))) << 32) | (4294967295L & ((long) e0.o.m5197getYimpl(jMo1050getOffsetBjo55l4))));
            }
            long jM5200plusqkQi6aY2 = e0.o.m5200plusqkQi6aY(jMo1050getOffsetBjo55l4, this.visualOffset);
            if (!z2 && animation != null) {
                animation.m1108setFinalOffsetgyyYBs(jM5200plusqkQi6aY2);
            }
            if (isVertical()) {
                if (layer != null) {
                    AbstractC0974x0.a.m3928placeWithLayeraW9wM$default(aVar, abstractC0974x0, jM5200plusqkQi6aY2, layer, 0.0f, 4, (Object) null);
                } else {
                    AbstractC0974x0.a.m3927placeWithLayeraW9wM$default(aVar, abstractC0974x0, jM5200plusqkQi6aY2, 0.0f, (h1.c) null, 6, (Object) null);
                }
            } else if (layer != null) {
                AbstractC0974x0.a.m3926placeRelativeWithLayeraW9wM$default(aVar, abstractC0974x0, jM5200plusqkQi6aY2, layer, 0.0f, 4, (Object) null);
            } else {
                AbstractC0974x0.a.m3925placeRelativeWithLayeraW9wM$default(aVar, abstractC0974x0, jM5200plusqkQi6aY2, 0.0f, (h1.c) null, 6, (Object) null);
            }
        }
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public void position(int i2, int i3, int i4, int i5) {
        position(i2, i4, i5);
    }

    @Override // androidx.compose.foundation.lazy.layout.N
    public void setNonScrollableItem(boolean z2) {
        this.nonScrollableItem = z2;
    }

    public final void updateMainAxisLayoutSize(int i2) {
        this.mainAxisLayoutSize = i2;
        this.maxMainAxisOffset = i2 + this.afterContentPadding;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private C(int i2, List<? extends AbstractC0974x0> list, boolean z2, InterfaceC0822e interfaceC0822e, InterfaceC0823f interfaceC0823f, e0.u uVar, boolean z3, int i3, int i4, int i5, long j2, Object obj, Object obj2, LazyLayoutItemAnimator lazyLayoutItemAnimator, long j3) {
        this.index = i2;
        this.placeables = list;
        this.isVertical = z2;
        this.horizontalAlignment = interfaceC0822e;
        this.verticalAlignment = interfaceC0823f;
        this.layoutDirection = uVar;
        this.reverseLayout = z3;
        this.beforeContentPadding = i3;
        this.afterContentPadding = i4;
        this.spacing = i5;
        this.visualOffset = j2;
        this.key = obj;
        this.contentType = obj2;
        this.animator = lazyLayoutItemAnimator;
        this.constraints = j3;
        this.span = 1;
        this.mainAxisLayoutSize = Integer.MIN_VALUE;
        int size = list.size();
        int height = 0;
        int iMax = 0;
        for (int i6 = 0; i6 < size; i6++) {
            AbstractC0974x0 abstractC0974x0 = (AbstractC0974x0) list.get(i6);
            height += isVertical() ? abstractC0974x0.getHeight() : abstractC0974x0.getWidth();
            iMax = Math.max(iMax, !isVertical() ? abstractC0974x0.getHeight() : abstractC0974x0.getWidth());
        }
        this.size = height;
        int size2 = getSize() + this.spacing;
        this.mainAxisSizeWithSpacings = size2 >= 0 ? size2 : 0;
        this.crossAxisSize = iMax;
        this.placeableOffsets = new int[this.placeables.size() * 2];
    }

    public final void position(int i2, int i3, int i4) {
        int width;
        this.offset = i2;
        this.mainAxisLayoutSize = isVertical() ? i4 : i3;
        List<AbstractC0974x0> list = this.placeables;
        int size = list.size();
        for (int i5 = 0; i5 < size; i5++) {
            AbstractC0974x0 abstractC0974x0 = list.get(i5);
            int i6 = i5 * 2;
            if (isVertical()) {
                int[] iArr = this.placeableOffsets;
                InterfaceC0822e interfaceC0822e = this.horizontalAlignment;
                if (interfaceC0822e == null) {
                    AbstractC1403e.throwIllegalArgumentExceptionForNullCheck("null horizontalAlignment when isVertical == true");
                    throw new H0.c();
                }
                iArr[i6] = interfaceC0822e.align(abstractC0974x0.getWidth(), i3, this.layoutDirection);
                this.placeableOffsets[i6 + 1] = i2;
                width = abstractC0974x0.getHeight();
            } else {
                int[] iArr2 = this.placeableOffsets;
                iArr2[i6] = i2;
                int i7 = i6 + 1;
                InterfaceC0823f interfaceC0823f = this.verticalAlignment;
                if (interfaceC0823f == null) {
                    AbstractC1403e.throwIllegalArgumentExceptionForNullCheck("null verticalAlignment when isVertical == false");
                    throw new H0.c();
                }
                iArr2[i7] = interfaceC0823f.align(abstractC0974x0.getHeight(), i4);
                width = abstractC0974x0.getWidth();
            }
            i2 = width + i2;
        }
        this.minMainAxisOffset = -this.beforeContentPadding;
        this.maxMainAxisOffset = this.mainAxisLayoutSize + this.afterContentPadding;
    }
}
