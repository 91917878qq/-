package androidx.compose.foundation.lazy;

/* JADX INFO: loaded from: classes.dex */
public final class F implements E {
    public static final int $stable = 0;
    private final int index;
    private final int mainAxisSize;

    public F(int i2, int i3) {
        this.index = i2;
        this.mainAxisSize = i3;
    }

    @Override // androidx.compose.foundation.lazy.E
    public int getIndex() {
        return this.index;
    }

    @Override // androidx.compose.foundation.lazy.E
    public int getMainAxisSize() {
        return this.mainAxisSize;
    }
}
