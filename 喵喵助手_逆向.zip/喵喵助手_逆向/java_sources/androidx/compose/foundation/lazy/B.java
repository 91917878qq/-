package androidx.compose.foundation.lazy;

import androidx.compose.ui.layout.AbstractC0928a;
import androidx.compose.ui.layout.InterfaceC0935d0;
import e0.InterfaceC1307d;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.AbstractC1378g;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class B implements y, InterfaceC0935d0 {
    public static final int $stable = 8;
    private final int afterContentPadding;
    private final boolean canScrollForward;
    private final long childConstraints;
    private final float consumedScroll;
    private final InterfaceC1474x coroutineScope;
    private final InterfaceC1307d density;
    private final C firstVisibleItem;
    private final int firstVisibleItemScrollOffset;
    private final int mainAxisItemSpacing;
    private final InterfaceC0935d0 measureResult;
    private final androidx.compose.foundation.gestures.I orientation;
    private final boolean remeasureNeeded;
    private final boolean reverseLayout;
    private final float scrollBackAmount;
    private final int totalItemsCount;
    private final int viewportEndOffset;
    private final int viewportStartOffset;
    private final List<C> visibleItemsInfo;

    public /* synthetic */ B(C c2, int i2, boolean z2, float f2, InterfaceC0935d0 interfaceC0935d0, float f3, boolean z3, InterfaceC1474x interfaceC1474x, InterfaceC1307d interfaceC1307d, long j2, List list, int i3, int i4, int i5, boolean z4, androidx.compose.foundation.gestures.I i6, int i7, int i8, AbstractC1378g abstractC1378g) {
        this(c2, i2, z2, f2, interfaceC0935d0, f3, z3, interfaceC1474x, interfaceC1307d, j2, list, i3, i4, i5, z4, i6, i7, i8);
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0082  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final B copyWithScrollDeltaWithoutRemeasure(int i2, boolean z2) {
        C c2;
        B b2 = null;
        if (!this.remeasureNeeded && !getVisibleItemsInfo().isEmpty() && (c2 = this.firstVisibleItem) != null) {
            int mainAxisSizeWithSpacings = c2.getMainAxisSizeWithSpacings();
            int i3 = this.firstVisibleItemScrollOffset - i2;
            if (i3 >= 0 && i3 < mainAxisSizeWithSpacings) {
                C c3 = (C) V0.t.u0(getVisibleItemsInfo());
                C c4 = (C) V0.t.z0(getVisibleItemsInfo());
                if (!c3.getNonScrollableItem() && !c4.getNonScrollableItem()) {
                    if (i2 < 0) {
                        if (Math.min((c3.getMainAxisSizeWithSpacings() + c3.getOffset()) - getViewportStartOffset(), (c4.getMainAxisSizeWithSpacings() + c4.getOffset()) - getViewportEndOffset()) > (-i2)) {
                            List<C> visibleItemsInfo = getVisibleItemsInfo();
                            int size = visibleItemsInfo.size();
                            for (int i4 = 0; i4 < size; i4++) {
                                visibleItemsInfo.get(i4).applyScrollDelta(i2, z2);
                            }
                            b2 = new B(this.firstVisibleItem, this.firstVisibleItemScrollOffset - i2, this.canScrollForward || i2 > 0, i2, this.measureResult, this.scrollBackAmount, this.remeasureNeeded, this.coroutineScope, this.density, this.childConstraints, getVisibleItemsInfo(), getViewportStartOffset(), getViewportEndOffset(), getTotalItemsCount(), getReverseLayout(), getOrientation(), getAfterContentPadding(), getMainAxisItemSpacing(), null);
                        }
                    } else if (Math.min(getViewportStartOffset() - c3.getOffset(), getViewportEndOffset() - c4.getOffset()) > i2) {
                    }
                }
            }
        }
        return b2;
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getAfterContentPadding() {
        return this.afterContentPadding;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0935d0
    public Map<AbstractC0928a, Integer> getAlignmentLines() {
        return this.measureResult.getAlignmentLines();
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getBeforeContentPadding() {
        return -getViewportStartOffset();
    }

    public final boolean getCanScrollBackward() {
        C c2 = this.firstVisibleItem;
        return ((c2 != null ? c2.getIndex() : 0) == 0 && this.firstVisibleItemScrollOffset == 0) ? false : true;
    }

    public final boolean getCanScrollForward() {
        return this.canScrollForward;
    }

    /* JADX INFO: renamed from: getChildConstraints-msEJaDk, reason: not valid java name */
    public final long m1045getChildConstraintsmsEJaDk() {
        return this.childConstraints;
    }

    public final float getConsumedScroll() {
        return this.consumedScroll;
    }

    public final InterfaceC1474x getCoroutineScope() {
        return this.coroutineScope;
    }

    public final InterfaceC1307d getDensity() {
        return this.density;
    }

    public final C getFirstVisibleItem() {
        return this.firstVisibleItem;
    }

    public final int getFirstVisibleItemScrollOffset() {
        return this.firstVisibleItemScrollOffset;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0935d0
    public int getHeight() {
        return this.measureResult.getHeight();
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getMainAxisItemSpacing() {
        return this.mainAxisItemSpacing;
    }

    @Override // androidx.compose.foundation.lazy.y
    public androidx.compose.foundation.gestures.I getOrientation() {
        return this.orientation;
    }

    public final boolean getRemeasureNeeded() {
        return this.remeasureNeeded;
    }

    @Override // androidx.compose.foundation.lazy.y
    public boolean getReverseLayout() {
        return this.reverseLayout;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0935d0
    public h1.c getRulers() {
        return this.measureResult.getRulers();
    }

    public final float getScrollBackAmount() {
        return this.scrollBackAmount;
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getTotalItemsCount() {
        return this.totalItemsCount;
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getViewportEndOffset() {
        return this.viewportEndOffset;
    }

    @Override // androidx.compose.foundation.lazy.y
    /* JADX INFO: renamed from: getViewportSize-YbymL2g, reason: not valid java name */
    public long mo1046getViewportSizeYbymL2g() {
        return e0.s.m5234constructorimpl((((long) getHeight()) & 4294967295L) | (((long) getWidth()) << 32));
    }

    @Override // androidx.compose.foundation.lazy.y
    public int getViewportStartOffset() {
        return this.viewportStartOffset;
    }

    @Override // androidx.compose.foundation.lazy.y
    public List<C> getVisibleItemsInfo() {
        return this.visibleItemsInfo;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0935d0
    public int getWidth() {
        return this.measureResult.getWidth();
    }

    @Override // androidx.compose.ui.layout.InterfaceC0935d0
    public void placeChildren() {
        this.measureResult.placeChildren();
    }

    private B(C c2, int i2, boolean z2, float f2, InterfaceC0935d0 interfaceC0935d0, float f3, boolean z3, InterfaceC1474x interfaceC1474x, InterfaceC1307d interfaceC1307d, long j2, List<C> list, int i3, int i4, int i5, boolean z4, androidx.compose.foundation.gestures.I i6, int i7, int i8) {
        this.firstVisibleItem = c2;
        this.firstVisibleItemScrollOffset = i2;
        this.canScrollForward = z2;
        this.consumedScroll = f2;
        this.measureResult = interfaceC0935d0;
        this.scrollBackAmount = f3;
        this.remeasureNeeded = z3;
        this.coroutineScope = interfaceC1474x;
        this.density = interfaceC1307d;
        this.childConstraints = j2;
        this.visibleItemsInfo = list;
        this.viewportStartOffset = i3;
        this.viewportEndOffset = i4;
        this.totalItemsCount = i5;
        this.reverseLayout = z4;
        this.orientation = i6;
        this.afterContentPadding = i7;
        this.mainAxisItemSpacing = i8;
    }
}
