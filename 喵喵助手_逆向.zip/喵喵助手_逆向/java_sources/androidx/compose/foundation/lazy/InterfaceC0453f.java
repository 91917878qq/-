package androidx.compose.foundation.lazy;

import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.U0;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0453f {
    static /* synthetic */ androidx.compose.ui.x animateItem$default(InterfaceC0453f interfaceC0453f, androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, androidx.compose.animation.core.F f3, androidx.compose.animation.core.F f4, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: animateItem");
        }
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        if ((i2 & 2) != 0) {
            f3 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        if ((i2 & 4) != 0) {
            f4 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        return interfaceC0453f.animateItem(xVar, f2, f3, f4);
    }

    static /* synthetic */ androidx.compose.ui.x fillParentMaxHeight$default(InterfaceC0453f interfaceC0453f, androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: fillParentMaxHeight");
        }
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return interfaceC0453f.fillParentMaxHeight(xVar, f2);
    }

    static /* synthetic */ androidx.compose.ui.x fillParentMaxSize$default(InterfaceC0453f interfaceC0453f, androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: fillParentMaxSize");
        }
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return interfaceC0453f.fillParentMaxSize(xVar, f2);
    }

    static /* synthetic */ androidx.compose.ui.x fillParentMaxWidth$default(InterfaceC0453f interfaceC0453f, androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: fillParentMaxWidth");
        }
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return interfaceC0453f.fillParentMaxWidth(xVar, f2);
    }

    default androidx.compose.ui.x animateItem(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, androidx.compose.animation.core.F f3, androidx.compose.animation.core.F f4) {
        return xVar;
    }

    androidx.compose.ui.x fillParentMaxHeight(androidx.compose.ui.x xVar, float f2);

    androidx.compose.ui.x fillParentMaxSize(androidx.compose.ui.x xVar, float f2);

    androidx.compose.ui.x fillParentMaxWidth(androidx.compose.ui.x xVar, float f2);
}
