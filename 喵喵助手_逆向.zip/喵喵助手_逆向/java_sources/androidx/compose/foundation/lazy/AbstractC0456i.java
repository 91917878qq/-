package androidx.compose.foundation.lazy;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0456i {
    public static final androidx.compose.foundation.lazy.layout.r rememberLazyListBeyondBoundsState(O o2, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1877443446, i3, -1, "androidx.compose.foundation.lazy.rememberLazyListBeyondBoundsState (LazyListBeyondBoundsModifier.kt:27)");
        }
        boolean z2 = ((((i3 & 14) ^ 6) > 4 && interfaceC0768p.changed(o2)) || (i3 & 6) == 4) | ((((i3 & 112) ^ 48) > 32 && interfaceC0768p.changed(i2)) || (i3 & 48) == 32);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = new C0457j(o2, i2);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        C0457j c0457j = (C0457j) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return c0457j;
    }
}
