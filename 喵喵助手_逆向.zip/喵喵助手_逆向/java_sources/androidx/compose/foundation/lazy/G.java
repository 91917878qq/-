package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.X;

/* JADX INFO: loaded from: classes.dex */
public interface G {
    static /* synthetic */ X schedulePrefetch$default(G g2, int i2, h1.c cVar, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: schedulePrefetch");
        }
        if ((i3 & 2) != 0) {
            cVar = null;
        }
        return g2.schedulePrefetch(i2, cVar);
    }

    X schedulePrefetch(int i2, h1.c cVar);
}
