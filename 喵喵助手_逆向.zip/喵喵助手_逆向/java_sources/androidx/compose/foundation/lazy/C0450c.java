package androidx.compose.foundation.lazy;

import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.foundation.layout.InterfaceC0420g;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import androidx.compose.foundation.layout.InterfaceC0424i;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0450c implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1830b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ androidx.compose.ui.x f1831c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ O f1832d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0421g0 f1833e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ boolean f1834f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0400y f1835g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ h1.c f1836h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f1837i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1838j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ Object f1839k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Object f1840l;

    public /* synthetic */ C0450c(androidx.compose.ui.x xVar, O o2, InterfaceC0421g0 interfaceC0421g0, boolean z2, Object obj, Object obj2, InterfaceC0400y interfaceC0400y, h1.c cVar, int i2, int i3, int i4) {
        this.f1830b = i4;
        this.f1831c = xVar;
        this.f1832d = o2;
        this.f1833e = interfaceC0421g0;
        this.f1834f = z2;
        this.f1839k = obj;
        this.f1840l = obj2;
        this.f1835g = interfaceC0400y;
        this.f1836h = cVar;
        this.f1837i = i2;
        this.f1838j = i3;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1830b) {
            case 0:
                InterfaceC0768p interfaceC0768p = (InterfaceC0768p) obj;
                int iIntValue = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyColumn$lambda$3(this.f1831c, this.f1832d, this.f1833e, this.f1834f, (InterfaceC0424i) this.f1839k, (InterfaceC0822e) this.f1840l, this.f1835g, this.f1836h, this.f1837i, this.f1838j, interfaceC0768p, iIntValue);
            default:
                InterfaceC0768p interfaceC0768p2 = (InterfaceC0768p) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                return AbstractC0452e.LazyRow$lambda$5(this.f1831c, this.f1832d, this.f1833e, this.f1834f, (InterfaceC0420g) this.f1839k, (InterfaceC0823f) this.f1840l, this.f1835g, this.f1836h, this.f1837i, this.f1838j, interfaceC0768p2, iIntValue2);
        }
    }
}
