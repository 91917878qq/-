package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.AbstractC0468e;
import androidx.compose.foundation.lazy.layout.InterfaceC0484t;
import androidx.compose.foundation.lazy.layout.q0;
import androidx.compose.foundation.lazy.layout.x0;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0459l extends AbstractC0468e implements H {
    public static final int $stable = 8;
    private final C0458k cacheWindowScope;

    public C0459l(InterfaceC0484t interfaceC0484t) {
        super(interfaceC0484t);
        this.cacheWindowScope = new C0458k();
    }

    private final void applyWindowScope(G g2, y yVar, h1.c cVar) {
        this.cacheWindowScope.setLayoutInfo(yVar);
        this.cacheWindowScope.setPrefetchScope(g2);
        cVar.invoke(this.cacheWindowScope);
    }

    @Override // androidx.compose.foundation.lazy.H
    public /* bridge */ /* synthetic */ x0 getPrefetchScheduler() {
        return super.getPrefetchScheduler();
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onNestedPrefetch(q0 q0Var, int i2) {
        int nestedPrefetchItemCount = q0Var.getNestedPrefetchItemCount() == -1 ? 2 : q0Var.getNestedPrefetchItemCount();
        for (int i3 = 0; i3 < nestedPrefetchItemCount; i3++) {
            q0Var.schedulePrecomposition(i2 + i3);
        }
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onScroll(G g2, float f2, y yVar) {
        this.cacheWindowScope.setLayoutInfo(yVar);
        this.cacheWindowScope.setPrefetchScope(g2);
        onScroll(this.cacheWindowScope, f2);
    }

    @Override // androidx.compose.foundation.lazy.H
    public void onVisibleItemsUpdated(G g2, y yVar) {
        this.cacheWindowScope.setLayoutInfo(yVar);
        this.cacheWindowScope.setPrefetchScope(g2);
        onVisibleItemsUpdated(this.cacheWindowScope);
    }
}
