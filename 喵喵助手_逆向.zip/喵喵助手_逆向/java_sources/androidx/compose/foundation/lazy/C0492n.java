package androidx.compose.foundation.lazy;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0492n implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1879b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1880c;

    public /* synthetic */ C0492n(Object obj, int i2) {
        this.f1879b = i2;
        this.f1880c = obj;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1879b) {
            case 0:
                return C0493o.item$lambda$0(this.f1880c, ((Integer) obj).intValue());
            case 1:
                return C0493o.item$lambda$1(this.f1880c, ((Integer) obj).intValue());
            default:
                return Boolean.valueOf(androidx.compose.runtime.r.stackTraceForValue$lambda$43(this.f1880c, obj));
        }
    }
}
