package androidx.compose.foundation.lazy.layout;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {
    private static final C0487w[] EmptyArray = new C0487w[0];

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0478m getSpecs(Object obj) {
        if (obj instanceof C0478m) {
            return (C0478m) obj;
        }
        return null;
    }
}
