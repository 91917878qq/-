package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.InterfaceC0465c0;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class L {

    public static final class a implements InterfaceC0465c0, androidx.compose.foundation.gestures.Q {
        private final /* synthetic */ androidx.compose.foundation.gestures.Q $$delegate_0;
        final /* synthetic */ O $state;

        public a(androidx.compose.foundation.gestures.Q q2, O o2) {
            this.$state = o2;
            this.$$delegate_0 = q2;
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public int calculateDistanceTo(int i2, int i3) {
            InterfaceC0494p interfaceC0494p;
            y layoutInfo = this.$state.getLayoutInfo();
            int firstVisibleItemIndex = 0;
            if (layoutInfo.getVisibleItemsInfo().isEmpty()) {
                return 0;
            }
            int firstVisibleItemIndex2 = getFirstVisibleItemIndex();
            if (i2 > getLastVisibleItemIndex() || firstVisibleItemIndex2 > i2) {
                firstVisibleItemIndex = ((i2 - getFirstVisibleItemIndex()) * z.visibleItemsAverageSize(layoutInfo)) - getFirstVisibleItemScrollOffset();
            } else {
                List<InterfaceC0494p> visibleItemsInfo = layoutInfo.getVisibleItemsInfo();
                int size = visibleItemsInfo.size();
                int i4 = 0;
                while (true) {
                    if (i4 >= size) {
                        interfaceC0494p = null;
                        break;
                    }
                    interfaceC0494p = visibleItemsInfo.get(i4);
                    if (interfaceC0494p.getIndex() == i2) {
                        break;
                    }
                    i4++;
                }
                InterfaceC0494p interfaceC0494p2 = interfaceC0494p;
                if (interfaceC0494p2 != null) {
                    firstVisibleItemIndex = interfaceC0494p2.getOffset();
                }
            }
            return firstVisibleItemIndex + i3;
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public int getFirstVisibleItemIndex() {
            return this.$state.getFirstVisibleItemIndex();
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public int getFirstVisibleItemScrollOffset() {
            return this.$state.getFirstVisibleItemScrollOffset();
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public int getItemCount() {
            return this.$state.getLayoutInfo().getTotalItemsCount();
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public int getLastVisibleItemIndex() {
            InterfaceC0494p interfaceC0494p = (InterfaceC0494p) V0.t.A0(this.$state.getLayoutInfo().getVisibleItemsInfo());
            if (interfaceC0494p != null) {
                return interfaceC0494p.getIndex();
            }
            return 0;
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0, androidx.compose.foundation.gestures.Q
        public float scrollBy(float f2) {
            return this.$$delegate_0.scrollBy(f2);
        }

        @Override // androidx.compose.foundation.lazy.layout.InterfaceC0465c0
        public void snapToItem(int i2, int i3) {
            this.$state.snapToItemIndexInternal$foundation_release(i2, i3, true);
        }
    }

    public static final InterfaceC0465c0 LazyLayoutScrollScope(O o2, androidx.compose.foundation.gestures.Q q2) {
        return new a(q2, o2);
    }
}
