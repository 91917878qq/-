package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.LazyLayoutAnimateItemElement;
import androidx.compose.runtime.F1;
import androidx.compose.runtime.InterfaceC0816z0;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0454g implements InterfaceC0453f {
    public static final int $stable = 0;
    private InterfaceC0816z0 maxWidthState = F1.mutableIntStateOf(Integer.MAX_VALUE);
    private InterfaceC0816z0 maxHeightState = F1.mutableIntStateOf(Integer.MAX_VALUE);

    @Override // androidx.compose.foundation.lazy.InterfaceC0453f
    public androidx.compose.ui.x animateItem(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, androidx.compose.animation.core.F f3, androidx.compose.animation.core.F f4) {
        return (f2 == null && f3 == null && f4 == null) ? xVar : xVar.then(new LazyLayoutAnimateItemElement(f2, f3, f4));
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0453f
    public androidx.compose.ui.x fillParentMaxHeight(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new ParentSizeElement(f2, null, this.maxHeightState, "fillParentMaxHeight", 2, null));
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0453f
    public androidx.compose.ui.x fillParentMaxSize(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new ParentSizeElement(f2, this.maxWidthState, this.maxHeightState, "fillParentMaxSize"));
    }

    @Override // androidx.compose.foundation.lazy.InterfaceC0453f
    public androidx.compose.ui.x fillParentMaxWidth(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new ParentSizeElement(f2, this.maxWidthState, null, "fillParentMaxWidth", 4, null));
    }

    public final void setMaxSize(int i2, int i3) {
        this.maxWidthState.setIntValue(i2);
        this.maxHeightState.setIntValue(i3);
    }
}
