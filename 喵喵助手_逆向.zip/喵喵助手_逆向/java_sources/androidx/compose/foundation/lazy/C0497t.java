package androidx.compose.foundation.lazy;

import androidx.compose.foundation.lazy.layout.I;
import androidx.compose.foundation.text.selection.T;
import androidx.compose.runtime.d2;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0497t implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1886b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ d2 f1887c;

    public /* synthetic */ C0497t(d2 d2Var, int i2) {
        this.f1886b = i2;
        this.f1887c = d2Var;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1886b) {
            case 0:
                return AbstractC0498u.rememberLazyListItemProviderLambda$lambda$2$lambda$0(this.f1887c);
            case 1:
                return I.a.invoke$lambda$1$lambda$0(this.f1887c);
            case 2:
                return Boolean.valueOf(androidx.compose.foundation.text.V.access$CoreTextField$lambda$16(this.f1887c));
            case 3:
                return T.a.invoke$lambda$2$lambda$1(this.f1887c);
            default:
                return T.b.invokeSuspend$lambda$0(this.f1887c);
        }
    }
}
