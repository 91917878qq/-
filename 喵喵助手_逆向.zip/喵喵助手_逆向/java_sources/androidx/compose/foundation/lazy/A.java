package androidx.compose.foundation.lazy;

import O0.C0194a;
import O0.C0218m;
import Q0.W;
import androidx.compose.animation.core.D0;
import androidx.compose.foundation.layout.InterfaceC0420g;
import androidx.compose.foundation.layout.InterfaceC0424i;
import androidx.compose.foundation.lazy.layout.E0;
import androidx.compose.foundation.lazy.layout.LazyLayoutItemAnimator;
import androidx.compose.foundation.lazy.layout.k0;
import androidx.compose.foundation.lazy.layout.r0;
import androidx.compose.runtime.B0;
import androidx.compose.ui.graphics.InterfaceC0881p0;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import e0.AbstractC1306c;
import e0.C1305b;
import e0.InterfaceC1307d;
import java.util.ArrayList;
import java.util.List;
import o.AbstractC1403e;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {
    private static final List<C> calculateItemsOffsets(List<C> list, List<C> list2, List<C> list3, int i2, int i3, int i4, int i5, int i6, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0420g interfaceC0420g, boolean z3, InterfaceC1307d interfaceC1307d) {
        int i7 = z2 ? i3 : i2;
        int i8 = 0;
        boolean z4 = i4 < Math.min(i7, i5);
        if (z4 && i6 != 0) {
            AbstractC1403e.throwIllegalStateException("non-zero itemsScrollOffset");
        }
        ArrayList arrayList = new ArrayList(list3.size() + list2.size() + list.size());
        if (z4) {
            if (!list2.isEmpty() || !list3.isEmpty()) {
                AbstractC1403e.throwIllegalArgumentException("no extra items");
            }
            int size = list.size();
            int[] iArr = new int[size];
            while (i8 < size) {
                iArr[i8] = list.get(calculateItemsOffsets$reverseAware(i8, z3, size)).getSize();
                i8++;
            }
            int[] iArr2 = new int[size];
            if (z2) {
                if (interfaceC0424i == null) {
                    AbstractC1403e.throwIllegalArgumentExceptionForNullCheck("null verticalArrangement when isVertical == true");
                    throw new H0.c();
                }
                interfaceC0424i.arrange(interfaceC1307d, i7, iArr, iArr2);
            } else {
                if (interfaceC0420g == null) {
                    AbstractC1403e.throwIllegalArgumentExceptionForNullCheck("null horizontalArrangement when isVertical == false");
                    throw new H0.c();
                }
                interfaceC0420g.arrange(interfaceC1307d, i7, iArr, e0.u.Ltr, iArr2);
            }
            m1.c cVarA0 = V0.r.a0(iArr2);
            if (z3) {
                cVarA0 = new m1.c(cVarA0.f3190c, cVarA0.f3189b, -cVarA0.f3191d);
            }
            int i9 = cVarA0.f3189b;
            int i10 = cVarA0.f3190c;
            int i11 = cVarA0.f3191d;
            if ((i11 > 0 && i9 <= i10) || (i11 < 0 && i10 <= i9)) {
                while (true) {
                    int size2 = iArr2[i9];
                    C c2 = list.get(calculateItemsOffsets$reverseAware(i9, z3, size));
                    if (z3) {
                        size2 = (i7 - size2) - c2.getSize();
                    }
                    c2.position(size2, i2, i3);
                    arrayList.add(c2);
                    if (i9 == i10) {
                        break;
                    }
                    i9 += i11;
                }
            }
        } else {
            int size3 = list2.size();
            int mainAxisSizeWithSpacings = i6;
            for (int i12 = 0; i12 < size3; i12++) {
                C c3 = list2.get(i12);
                mainAxisSizeWithSpacings -= c3.getMainAxisSizeWithSpacings();
                c3.position(mainAxisSizeWithSpacings, i2, i3);
                arrayList.add(c3);
            }
            int size4 = list.size();
            int mainAxisSizeWithSpacings2 = i6;
            for (int i13 = 0; i13 < size4; i13++) {
                C c4 = list.get(i13);
                c4.position(mainAxisSizeWithSpacings2, i2, i3);
                arrayList.add(c4);
                mainAxisSizeWithSpacings2 += c4.getMainAxisSizeWithSpacings();
            }
            int size5 = list3.size();
            while (i8 < size5) {
                C c5 = list3.get(i8);
                c5.position(mainAxisSizeWithSpacings2, i2, i3);
                arrayList.add(c5);
                mainAxisSizeWithSpacings2 += c5.getMainAxisSizeWithSpacings();
                i8++;
            }
        }
        return arrayList;
    }

    private static final int calculateItemsOffsets$reverseAware(int i2, boolean z2, int i3) {
        return !z2 ? i2 : (i3 - i2) - 1;
    }

    private static final List<C> createItemsAfterList(List<C> list, D d2, int i2, int i3, List<Integer> list2, float f2, boolean z2, y yVar) {
        ArrayList arrayList;
        InterfaceC0494p interfaceC0494p;
        C c2;
        C c3;
        int mainAxisSizeWithSpacings;
        C c4;
        int index;
        int iMin;
        C c5;
        C c6;
        int i4 = i2 - 1;
        int iMin2 = Math.min(((C) V0.t.z0(list)).getIndex() + i3, i4);
        int index2 = ((C) V0.t.z0(list)).getIndex() + 1;
        if (index2 <= iMin2) {
            ArrayList arrayList2 = null;
            while (true) {
                if (arrayList2 == null) {
                    arrayList2 = new ArrayList();
                }
                arrayList = arrayList2;
                arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, index2, 0L, 2, null));
                if (index2 == iMin2) {
                    break;
                }
                index2++;
                arrayList2 = arrayList;
            }
        } else {
            arrayList = null;
        }
        if (z2 && yVar != null && !yVar.getVisibleItemsInfo().isEmpty()) {
            List<InterfaceC0494p> visibleItemsInfo = yVar.getVisibleItemsInfo();
            int size = visibleItemsInfo.size();
            while (true) {
                size--;
                if (-1 >= size) {
                    interfaceC0494p = null;
                    break;
                }
                if (visibleItemsInfo.get(size).getIndex() > iMin2 && (size == 0 || visibleItemsInfo.get(size - 1).getIndex() <= iMin2)) {
                    break;
                }
            }
            interfaceC0494p = visibleItemsInfo.get(size);
            InterfaceC0494p interfaceC0494p2 = (InterfaceC0494p) V0.t.z0(yVar.getVisibleItemsInfo());
            if (interfaceC0494p != null && (index = interfaceC0494p.getIndex()) <= (iMin = Math.min(interfaceC0494p2.getIndex(), i4))) {
                while (true) {
                    if (arrayList != null) {
                        int size2 = arrayList.size();
                        int i5 = 0;
                        while (true) {
                            if (i5 >= size2) {
                                c6 = null;
                                break;
                            }
                            c6 = arrayList.get(i5);
                            if (c6.getIndex() == index) {
                                break;
                            }
                            i5++;
                        }
                        c5 = c6;
                    } else {
                        c5 = null;
                    }
                    if (c5 == null) {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, index, 0L, 2, null));
                    }
                    if (index == iMin) {
                        break;
                    }
                    index++;
                }
            }
            float viewportEndOffset = ((yVar.getViewportEndOffset() - interfaceC0494p2.getOffset()) - interfaceC0494p2.getSize()) - f2;
            if (viewportEndOffset > 0.0f) {
                int index3 = interfaceC0494p2.getIndex() + 1;
                int i6 = 0;
                while (index3 < i2 && i6 < viewportEndOffset) {
                    if (index3 <= iMin2) {
                        int size3 = list.size();
                        int i7 = 0;
                        while (true) {
                            if (i7 >= size3) {
                                c4 = null;
                                break;
                            }
                            c4 = list.get(i7);
                            if (c4.getIndex() == index3) {
                                break;
                            }
                            i7++;
                        }
                        c2 = c4;
                    } else if (arrayList != null) {
                        int size4 = arrayList.size();
                        int i8 = 0;
                        while (true) {
                            if (i8 >= size4) {
                                c3 = null;
                                break;
                            }
                            c3 = arrayList.get(i8);
                            if (c3.getIndex() == index3) {
                                break;
                            }
                            i8++;
                        }
                        c2 = c3;
                    } else {
                        c2 = null;
                    }
                    if (c2 != null) {
                        index3++;
                        mainAxisSizeWithSpacings = c2.getMainAxisSizeWithSpacings();
                    } else {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, index3, 0L, 2, null));
                        index3++;
                        mainAxisSizeWithSpacings = ((C) V0.t.z0(arrayList)).getMainAxisSizeWithSpacings();
                    }
                    i6 += mainAxisSizeWithSpacings;
                }
            }
        }
        if (arrayList != null && ((C) V0.t.z0(arrayList)).getIndex() > iMin2) {
            iMin2 = ((C) V0.t.z0(arrayList)).getIndex();
        }
        int size5 = list2.size();
        for (int i9 = 0; i9 < size5; i9++) {
            int iIntValue = list2.get(i9).intValue();
            if (iIntValue > iMin2) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, iIntValue, 0L, 2, null));
            }
        }
        return arrayList == null ? V0.A.f1524b : arrayList;
    }

    private static final List<C> createItemsBeforeList(int i2, D d2, int i3, List<Integer> list) {
        int iMax = Math.max(0, i2 - i3);
        int i4 = i2 - 1;
        ArrayList arrayList = null;
        if (iMax <= i4) {
            while (true) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, i4, 0L, 2, null));
                if (i4 == iMax) {
                    break;
                }
                i4--;
            }
        }
        int size = list.size() - 1;
        if (size >= 0) {
            while (true) {
                int i5 = size - 1;
                int iIntValue = list.get(size).intValue();
                if (iIntValue < iMax) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(D.m1051getAndMeasure0kLqBqw$default(d2, iIntValue, 0L, 2, null));
                }
                if (i5 < 0) {
                    break;
                }
                size = i5;
            }
        }
        return arrayList == null ? V0.A.f1524b : arrayList;
    }

    /* JADX WARN: Removed duplicated region for block: B:146:0x0403  */
    /* JADX WARN: Removed duplicated region for block: B:164:0x0467  */
    /* JADX INFO: renamed from: measureLazyList-LCrQqZ4, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final B m1044measureLazyListLCrQqZ4(int i2, D d2, int i3, int i4, int i5, int i6, int i7, int i8, float f2, long j2, boolean z2, InterfaceC0424i interfaceC0424i, InterfaceC0420g interfaceC0420g, boolean z3, InterfaceC1307d interfaceC1307d, LazyLayoutItemAnimator lazyLayoutItemAnimator, int i9, List<Integer> list, boolean z4, boolean z5, y yVar, InterfaceC1474x interfaceC1474x, B0 b02, InterfaceC0881p0 interfaceC0881p0, E0 e02, h1.f fVar) {
        int i10;
        int i11;
        int i12;
        boolean z6;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        C c2;
        int i20;
        List<Integer> list2;
        int i21;
        D d3;
        List<C> list3;
        int i22;
        int i23;
        Integer numValueOf;
        boolean z7;
        int i24;
        int i25;
        if (i4 < 0) {
            AbstractC1403e.throwIllegalArgumentException("invalid beforeContentPadding");
        }
        if (i5 < 0) {
            AbstractC1403e.throwIllegalArgumentException("invalid afterContentPadding");
        }
        if (i2 <= 0) {
            int iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(j2);
            int iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(j2);
            lazyLayoutItemAnimator.onMeasured(0, iM5043getMinWidthimpl, iM5042getMinHeightimpl, new ArrayList(), d2.getKeyIndexMap(), d2, z2, z5, 1, z4, 0, 0, interfaceC1474x, interfaceC0881p0);
            if (!z5) {
                long jM1069getMinSizeToFitDisappearingItemsYbymL2g = lazyLayoutItemAnimator.m1069getMinSizeToFitDisappearingItemsYbymL2g();
                if (!e0.s.m5237equalsimpl0(jM1069getMinSizeToFitDisappearingItemsYbymL2g, e0.s.Companion.m5244getZeroYbymL2g())) {
                    iM5043getMinWidthimpl = AbstractC1306c.m5058constrainWidthK40F9xA(j2, (int) (jM1069getMinSizeToFitDisappearingItemsYbymL2g >> 32));
                    iM5042getMinHeightimpl = AbstractC1306c.m5057constrainHeightK40F9xA(j2, (int) (jM1069getMinSizeToFitDisappearingItemsYbymL2g & 4294967295L));
                }
            }
            return new B(null, 0, false, 0.0f, (InterfaceC0935d0) fVar.invoke(Integer.valueOf(iM5043getMinWidthimpl), Integer.valueOf(iM5042getMinHeightimpl), new D0(24)), 0.0f, false, interfaceC1474x, interfaceC1307d, d2.m1055getChildConstraintsmsEJaDk(), V0.A.f1524b, -i4, i3 + i5, 0, z3, z2 ? androidx.compose.foundation.gestures.I.Vertical : androidx.compose.foundation.gestures.I.Horizontal, i5, i6, null);
        }
        int i26 = 0;
        int i27 = i7;
        if (i27 >= i2) {
            i27 = i2 - 1;
            i10 = 0;
        } else {
            i10 = i8;
        }
        int iRound = Math.round(f2);
        int i28 = i10 - iRound;
        if (i27 != 0 || i28 >= 0) {
            i11 = iRound;
        } else {
            i11 = iRound + i28;
            i28 = 0;
        }
        V0.q qVar = new V0.q();
        int i29 = -i4;
        int i30 = i29 + (i6 < 0 ? i6 : 0);
        int mainAxisSizeWithSpacings = i28 + i30;
        int iMax = 0;
        while (mainAxisSizeWithSpacings < 0 && i27 > 0) {
            int i31 = i27 - 1;
            C cM1051getAndMeasure0kLqBqw$default = D.m1051getAndMeasure0kLqBqw$default(d2, i31, 0L, 2, null);
            qVar.add(0, cM1051getAndMeasure0kLqBqw$default);
            iMax = Math.max(iMax, cM1051getAndMeasure0kLqBqw$default.getCrossAxisSize());
            mainAxisSizeWithSpacings = cM1051getAndMeasure0kLqBqw$default.getMainAxisSizeWithSpacings() + mainAxisSizeWithSpacings;
            i27 = i31;
            i29 = i29;
            i30 = i30;
        }
        int i32 = mainAxisSizeWithSpacings;
        int i33 = iMax;
        int i34 = i29;
        int i35 = i30;
        if (i32 < i35) {
            i11 -= i35 - i32;
            i12 = i35;
        } else {
            i12 = i32;
        }
        int i36 = i12 - i35;
        int i37 = i3 + i5;
        int i38 = i37 < 0 ? 0 : i37;
        int i39 = -i36;
        int i40 = i27;
        int i41 = i40;
        boolean z8 = false;
        while (true) {
            z6 = true;
            if (i26 >= qVar.size()) {
                break;
            }
            if (i39 >= i38) {
                qVar.remove(i26);
                z8 = true;
            } else {
                i41++;
                int mainAxisSizeWithSpacings2 = ((C) qVar.get(i26)).getMainAxisSizeWithSpacings() + i39;
                i26++;
                i39 = mainAxisSizeWithSpacings2;
            }
        }
        int i42 = i40;
        int mainAxisSizeWithSpacings3 = i39;
        int i43 = i41;
        int mainAxisSizeWithSpacings4 = i36;
        while (i43 < i2 && (mainAxisSizeWithSpacings3 < i38 || mainAxisSizeWithSpacings3 <= 0 || qVar.isEmpty())) {
            int i44 = i43;
            int i45 = i33;
            int i46 = i38;
            int i47 = i42;
            int i48 = i35;
            C cM1051getAndMeasure0kLqBqw$default2 = D.m1051getAndMeasure0kLqBqw$default(d2, i43, 0L, 2, null);
            mainAxisSizeWithSpacings3 = cM1051getAndMeasure0kLqBqw$default2.getMainAxisSizeWithSpacings() + mainAxisSizeWithSpacings3;
            if (mainAxisSizeWithSpacings3 <= i48) {
                i24 = i44;
                if (i24 != i2 - 1) {
                    i25 = i24 + 1;
                    mainAxisSizeWithSpacings4 -= cM1051getAndMeasure0kLqBqw$default2.getMainAxisSizeWithSpacings();
                    z8 = true;
                    i33 = i45;
                }
                int i49 = i24 + 1;
                i35 = i48;
                i38 = i46;
                i42 = i25;
                i43 = i49;
            } else {
                i24 = i44;
            }
            int iMax2 = Math.max(i45, cM1051getAndMeasure0kLqBqw$default2.getCrossAxisSize());
            qVar.addLast(cM1051getAndMeasure0kLqBqw$default2);
            i33 = iMax2;
            i25 = i47;
            int i492 = i24 + 1;
            i35 = i48;
            i38 = i46;
            i42 = i25;
            i43 = i492;
        }
        int i50 = i43;
        int i51 = i33;
        int i52 = mainAxisSizeWithSpacings3;
        int i53 = i42;
        if (i52 < i3) {
            int i54 = i3 - i52;
            int i55 = i52 + i54;
            int i56 = i53;
            int iMax3 = i51;
            int mainAxisSizeWithSpacings5 = mainAxisSizeWithSpacings4 - i54;
            while (mainAxisSizeWithSpacings5 < i4 && i56 > 0) {
                int i57 = i56 - 1;
                C cM1051getAndMeasure0kLqBqw$default3 = D.m1051getAndMeasure0kLqBqw$default(d2, i57, 0L, 2, null);
                qVar.add(0, cM1051getAndMeasure0kLqBqw$default3);
                iMax3 = Math.max(iMax3, cM1051getAndMeasure0kLqBqw$default3.getCrossAxisSize());
                mainAxisSizeWithSpacings5 = cM1051getAndMeasure0kLqBqw$default3.getMainAxisSizeWithSpacings() + mainAxisSizeWithSpacings5;
                i56 = i57;
                i50 = i50;
            }
            int i58 = mainAxisSizeWithSpacings5;
            int i59 = iMax3;
            i13 = i50;
            int i60 = i54 + i11;
            if (i58 < 0) {
                i14 = i56;
                i16 = i59;
                i18 = 0;
                i17 = i60 + i58;
                i15 = i55 + i58;
            } else {
                i14 = i56;
                i16 = i59;
                i17 = i60;
                i15 = i55;
                i18 = i58;
            }
        } else {
            i13 = i50;
            i14 = i53;
            i15 = i52;
            i16 = i51;
            i17 = i11;
            i18 = mainAxisSizeWithSpacings4;
        }
        float f3 = (Integer.signum(Math.round(f2)) != Integer.signum(i17) || Math.abs(Math.round(f2)) < Math.abs(i17)) ? f2 : i17;
        float f4 = f2 - f3;
        float f5 = 0.0f;
        if (z5 && i17 > i11 && f4 <= 0.0f) {
            f5 = (i17 - i11) + f4;
        }
        if (i18 < 0) {
            AbstractC1403e.throwIllegalArgumentException("negative currentFirstItemScrollOffset");
        }
        int i61 = -i18;
        C c3 = (C) qVar.first();
        if (i4 > 0 || i6 < 0) {
            int size = qVar.size();
            C c4 = c3;
            int i62 = 0;
            while (true) {
                if (i62 >= size) {
                    i19 = i16;
                    break;
                }
                i19 = i16;
                int mainAxisSizeWithSpacings6 = ((C) qVar.get(i62)).getMainAxisSizeWithSpacings();
                if (i18 == 0 || mainAxisSizeWithSpacings6 > i18) {
                    break;
                }
                int i63 = size;
                if (i62 == j1.a.E(qVar)) {
                    break;
                }
                i18 -= mainAxisSizeWithSpacings6;
                i62++;
                size = i63;
                c4 = (C) qVar.get(i62);
                i16 = i19;
            }
            c2 = c4;
            i20 = i9;
            list2 = list;
            i21 = i18;
            d3 = d2;
        } else {
            c2 = c3;
            i19 = i16;
            i21 = i18;
            d3 = d2;
            i20 = i9;
            list2 = list;
        }
        List<C> listCreateItemsBeforeList = createItemsBeforeList(i14, d3, i20, list2);
        int iMax4 = i19;
        int i64 = 0;
        for (int size2 = listCreateItemsBeforeList.size(); i64 < size2; size2 = size2) {
            iMax4 = Math.max(iMax4, listCreateItemsBeforeList.get(i64).getCrossAxisSize());
            i64++;
        }
        C c5 = c2;
        float f6 = f3;
        List<C> listCreateItemsAfterList = createItemsAfterList(qVar, d2, i2, i9, list, f3, z5, yVar);
        int size3 = listCreateItemsAfterList.size();
        for (int i65 = 0; i65 < size3; i65++) {
            iMax4 = Math.max(iMax4, listCreateItemsAfterList.get(i65).getCrossAxisSize());
        }
        boolean z9 = kotlin.jvm.internal.o.a(c5, qVar.first()) && listCreateItemsBeforeList.isEmpty() && listCreateItemsAfterList.isEmpty();
        int iM5058constrainWidthK40F9xA = AbstractC1306c.m5058constrainWidthK40F9xA(j2, z2 ? iMax4 : i15);
        if (z2) {
            iMax4 = i15;
        }
        int iM5057constrainHeightK40F9xA = AbstractC1306c.m5057constrainHeightK40F9xA(j2, iMax4);
        int i66 = i15;
        List<C> listCalculateItemsOffsets = calculateItemsOffsets(qVar, listCreateItemsBeforeList, listCreateItemsAfterList, iM5058constrainWidthK40F9xA, iM5057constrainHeightK40F9xA, i15, i3, i61, z2, interfaceC0424i, interfaceC0420g, z3, interfaceC1307d);
        lazyLayoutItemAnimator.onMeasured((int) f6, iM5058constrainWidthK40F9xA, iM5057constrainHeightK40F9xA, listCalculateItemsOffsets, d2.getKeyIndexMap(), d2, z2, z5, 1, z4, i21, i66, interfaceC1474x, interfaceC0881p0);
        if (!z5) {
            long jM1069getMinSizeToFitDisappearingItemsYbymL2g2 = lazyLayoutItemAnimator.m1069getMinSizeToFitDisappearingItemsYbymL2g();
            if (e0.s.m5237equalsimpl0(jM1069getMinSizeToFitDisappearingItemsYbymL2g2, e0.s.Companion.m5244getZeroYbymL2g())) {
                list3 = listCalculateItemsOffsets;
                i22 = iM5057constrainHeightK40F9xA;
                i23 = iM5058constrainWidthK40F9xA;
            } else {
                int i67 = z2 ? iM5057constrainHeightK40F9xA : iM5058constrainWidthK40F9xA;
                int iM5058constrainWidthK40F9xA2 = AbstractC1306c.m5058constrainWidthK40F9xA(j2, Math.max(iM5058constrainWidthK40F9xA, (int) (jM1069getMinSizeToFitDisappearingItemsYbymL2g2 >> 32)));
                int iM5057constrainHeightK40F9xA2 = AbstractC1306c.m5057constrainHeightK40F9xA(j2, Math.max(iM5057constrainHeightK40F9xA, (int) (jM1069getMinSizeToFitDisappearingItemsYbymL2g2 & 4294967295L)));
                int i68 = z2 ? iM5057constrainHeightK40F9xA2 : iM5058constrainWidthK40F9xA2;
                if (i68 != i67) {
                    int size4 = listCalculateItemsOffsets.size();
                    for (int i69 = 0; i69 < size4; i69++) {
                        listCalculateItemsOffsets.get(i69).updateMainAxisLayoutSize(i68);
                    }
                }
                list3 = listCalculateItemsOffsets;
                i23 = iM5058constrainWidthK40F9xA2;
                i22 = iM5057constrainHeightK40F9xA2;
            }
        }
        Integer numValueOf2 = null;
        C c6 = (C) (qVar.isEmpty() ? null : qVar.f1560c[qVar.f1559b]);
        int index = c6 != null ? c6.getIndex() : 0;
        C c7 = (C) qVar.d();
        List listApplyStickyItems = k0.applyStickyItems(e02, index, c7 != null ? c7.getIndex() : 0, list3, d2.getHeaderIndexes(), i4, i5, i23, i22, new C0218m(d2, 12));
        if (z9) {
            C c8 = (C) V0.t.v0(list3);
            numValueOf = c8 != null ? Integer.valueOf(c8.getIndex()) : null;
        } else {
            C c9 = (C) (qVar.isEmpty() ? null : qVar.f1560c[qVar.f1559b]);
            if (c9 != null) {
                numValueOf = Integer.valueOf(c9.getIndex());
            }
        }
        if (z9) {
            C c10 = (C) V0.t.A0(list3);
            if (c10 != null) {
                numValueOf2 = Integer.valueOf(c10.getIndex());
            }
        } else {
            C c11 = (C) qVar.d();
            if (c11 != null) {
                numValueOf2 = Integer.valueOf(c11.getIndex());
            }
        }
        if (i13 >= i2) {
            z7 = z5;
            if (i66 <= i3) {
                z6 = false;
            }
        } else {
            z7 = z5;
        }
        return new B(c5, i21, z6, f6, (InterfaceC0935d0) fVar.invoke(Integer.valueOf(i23), Integer.valueOf(i22), new C0194a(b02, list3, listApplyStickyItems, z7)), f5, z8, interfaceC1474x, interfaceC1307d, d2.m1055getChildConstraintsmsEJaDk(), androidx.compose.foundation.lazy.layout.O.updatedVisibleItems(numValueOf != null ? numValueOf.intValue() : 0, numValueOf2 != null ? numValueOf2.intValue() : 0, list3, listApplyStickyItems), i34, i37, i2, z3, z2 ? androidx.compose.foundation.gestures.I.Vertical : androidx.compose.foundation.gestures.I.Horizontal, i5, i6, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measureLazyList_LCrQqZ4$lambda$11(B0 b02, List list, List list2, boolean z2, AbstractC0974x0.a aVar) {
        aVar.withMotionFrameOfReferencePlacement(new W(1, list, z2, list2));
        r0.m1088attachToScopeimpl(b02);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measureLazyList_LCrQqZ4$lambda$11$lambda$10(List list, List list2, boolean z2, AbstractC0974x0.a aVar) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((C) list.get(i2)).place(aVar, z2);
        }
        int size2 = list2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((C) list2.get(i3)).place(aVar, z2);
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measureLazyList_LCrQqZ4$lambda$2(AbstractC0974x0.a aVar) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C measureLazyList_LCrQqZ4$lambda$7(D d2, int i2) {
        return D.m1051getAndMeasure0kLqBqw$default(d2, i2, 0L, 2, null);
    }
}
