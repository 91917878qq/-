package androidx.compose.foundation.lazy;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0494p {
    default Object getContentType() {
        return null;
    }

    int getIndex();

    Object getKey();

    int getOffset();

    int getSize();
}
