package androidx.compose.foundation;

import androidx.compose.foundation.gestures.InterfaceC0381e;
import androidx.compose.foundation.gestures.InterfaceC0400y;

/* JADX INFO: loaded from: classes.dex */
public abstract class D0 {
    public static final androidx.compose.ui.x scrollingContainer(androidx.compose.ui.x xVar, androidx.compose.foundation.gestures.c0 c0Var, androidx.compose.foundation.gestures.I i2, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, boolean z4, i0 i0Var, InterfaceC0381e interfaceC0381e) {
        return AbstractC0644x.clipScrollableContainer(xVar, i2).then(new ScrollingContainerElement(c0Var, i2, z2, z3, interfaceC0400y, nVar, interfaceC0381e, z4, i0Var));
    }
}
