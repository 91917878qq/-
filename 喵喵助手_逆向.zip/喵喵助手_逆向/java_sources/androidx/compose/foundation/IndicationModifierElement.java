package androidx.compose.foundation;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class IndicationModifierElement extends AbstractC1000k0 {
    private final Y indication;
    private final androidx.compose.foundation.interaction.l interactionSource;

    public IndicationModifierElement(androidx.compose.foundation.interaction.l lVar, Y y2) {
        this.interactionSource = lVar;
        this.indication = y2;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IndicationModifierElement)) {
            return false;
        }
        IndicationModifierElement indicationModifierElement = (IndicationModifierElement) obj;
        return kotlin.jvm.internal.o.a(this.interactionSource, indicationModifierElement.interactionSource) && kotlin.jvm.internal.o.a(this.indication, indicationModifierElement.indication);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return this.indication.hashCode() + (this.interactionSource.hashCode() * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("indication");
        c1065l1.getProperties().set("interactionSource", this.interactionSource);
        c1065l1.getProperties().set("indication", this.indication);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public X create() {
        return new X(this.indication.create(this.interactionSource));
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(X x2) {
        x2.update(this.indication.create(this.interactionSource));
    }
}
