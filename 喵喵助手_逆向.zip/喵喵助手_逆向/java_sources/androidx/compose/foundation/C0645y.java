package androidx.compose.foundation;

import a.AbstractC0292a;
import android.view.KeyEvent;
import androidx.compose.foundation.C0645y;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.T0;
import androidx.compose.ui.platform.L0;
import androidx.compose.ui.platform.W1;
import androidx.compose.ui.semantics.C1116j;
import j.AbstractC1361t;
import j.C1336G;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0645y extends AbstractC0365b {
    private final C1336G doubleKeyClickStates;
    private boolean hapticFeedbackEnabled;
    private final C1336G longKeyPressJobs;
    private h1.a onDoubleClick;
    private h1.a onLongClick;
    private String onLongClickLabel;

    /* JADX INFO: renamed from: androidx.compose.foundation.y$a */
    public static final class a {
        public static final int $stable = 8;
        private boolean doubleTapMinTimeMillisElapsed;
        private final InterfaceC1451b0 job;

        public a(InterfaceC1451b0 interfaceC1451b0) {
            this.job = interfaceC1451b0;
        }

        public final boolean getDoubleTapMinTimeMillisElapsed() {
            return this.doubleTapMinTimeMillisElapsed;
        }

        public final InterfaceC1451b0 getJob() {
            return this.job;
        }

        public final void setDoubleTapMinTimeMillisElapsed(boolean z2) {
            this.doubleTapMinTimeMillisElapsed = z2;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.y$b */
    public static final class b implements PointerInputEventHandler {

        /* JADX INFO: renamed from: androidx.compose.foundation.y$b$a */
        public static final class a extends a1.j implements h1.f {
            /* synthetic */ long J$0;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0645y this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(C0645y c0645y, Y0.c cVar) {
                super(3, cVar);
                this.this$0 = c0645y;
            }

            @Override // h1.f
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                return m1667invoked4ec7I((androidx.compose.foundation.gestures.J) obj, ((J.f) obj2).m60unboximpl(), (Y0.c) obj3);
            }

            /* JADX INFO: renamed from: invoke-d-4ec7I, reason: not valid java name */
            public final Object m1667invoked4ec7I(androidx.compose.foundation.gestures.J j2, long j3, Y0.c cVar) {
                a aVar = new a(this.this$0, cVar);
                aVar.L$0 = j2;
                aVar.J$0 = j3;
                return aVar.invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    androidx.compose.foundation.gestures.J j2 = (androidx.compose.foundation.gestures.J) this.L$0;
                    long j3 = this.J$0;
                    if (this.this$0.getEnabled()) {
                        C0645y c0645y = this.this$0;
                        this.label = 1;
                        if (c0645y.m708handlePressInteractiond4ec7I(j2, j3, this) == aVar) {
                            return aVar;
                        }
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                }
                return U0.n.f1521a;
            }
        }

        public b() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$0(C0645y c0645y, J.f fVar) {
            h1.a aVar = c0645y.onDoubleClick;
            if (aVar != null) {
                aVar.invoke();
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$1(C0645y c0645y, J.f fVar) {
            h1.a aVar = c0645y.onLongClick;
            if (aVar != null) {
                aVar.invoke();
            }
            if (c0645y.getHapticFeedbackEnabled()) {
                ((M.a) AbstractC1003m.currentValueOf(c0645y, L0.getLocalHapticFeedback())).mo145performHapticFeedbackCdsT49E(M.b.Companion.m158getLongPress5zf0vsI());
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$2(C0645y c0645y, J.f fVar) {
            if (c0645y.getEnabled()) {
                c0645y.getOnClick().invoke();
            }
            return U0.n.f1521a;
        }

        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
        public final Object invoke(androidx.compose.ui.input.pointer.L l2, Y0.c cVar) {
            h1.c cVar2;
            h1.c cVar3;
            if (!C0645y.this.getEnabled() || C0645y.this.onDoubleClick == null) {
                cVar2 = null;
            } else {
                final C0645y c0645y = C0645y.this;
                final int i2 = 0;
                cVar2 = new h1.c() { // from class: androidx.compose.foundation.z
                    @Override // h1.c
                    public final Object invoke(Object obj) {
                        switch (i2) {
                            case 0:
                                return C0645y.b.invoke$lambda$0(c0645y, (J.f) obj);
                            case 1:
                                return C0645y.b.invoke$lambda$1(c0645y, (J.f) obj);
                            default:
                                return C0645y.b.invoke$lambda$2(c0645y, (J.f) obj);
                        }
                    }
                };
            }
            if (!C0645y.this.getEnabled() || C0645y.this.onLongClick == null) {
                cVar3 = null;
            } else {
                final C0645y c0645y2 = C0645y.this;
                final int i3 = 1;
                cVar3 = new h1.c() { // from class: androidx.compose.foundation.z
                    @Override // h1.c
                    public final Object invoke(Object obj) {
                        switch (i3) {
                            case 0:
                                return C0645y.b.invoke$lambda$0(c0645y2, (J.f) obj);
                            case 1:
                                return C0645y.b.invoke$lambda$1(c0645y2, (J.f) obj);
                            default:
                                return C0645y.b.invoke$lambda$2(c0645y2, (J.f) obj);
                        }
                    }
                };
            }
            a aVar = new a(C0645y.this, null);
            final C0645y c0645y3 = C0645y.this;
            final int i4 = 2;
            Object objDetectTapGestures = androidx.compose.foundation.gestures.g0.detectTapGestures(l2, cVar2, cVar3, aVar, new h1.c() { // from class: androidx.compose.foundation.z
                @Override // h1.c
                public final Object invoke(Object obj) {
                    switch (i4) {
                        case 0:
                            return C0645y.b.invoke$lambda$0(c0645y3, (J.f) obj);
                        case 1:
                            return C0645y.b.invoke$lambda$1(c0645y3, (J.f) obj);
                        default:
                            return C0645y.b.invoke$lambda$2(c0645y3, (J.f) obj);
                    }
                }
            }, cVar);
            return objDetectTapGestures == Z0.a.f1616b ? objDetectTapGestures : U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.y$c */
    public static final class c extends a1.j implements h1.e {
        int label;

        public c(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return C0645y.this.new c(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                long longPressTimeoutMillis = ((W1) AbstractC1003m.currentValueOf(C0645y.this, L0.getLocalViewConfiguration())).getLongPressTimeoutMillis();
                this.label = 1;
                if (AbstractC1476z.f(longPressTimeoutMillis, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            h1.a aVar2 = C0645y.this.onLongClick;
            if (aVar2 != null) {
                aVar2.invoke();
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.y$d */
    public static final class d extends a1.j implements h1.e {
        final /* synthetic */ long $keyCode;
        long J$0;
        long J$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$keyCode = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return C0645y.this.new d(this.$keyCode, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            long doubleTapMinTimeMillis;
            long doubleTapTimeoutMillis;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                W1 w12 = (W1) AbstractC1003m.currentValueOf(C0645y.this, L0.getLocalViewConfiguration());
                doubleTapMinTimeMillis = w12.getDoubleTapMinTimeMillis();
                doubleTapTimeoutMillis = w12.getDoubleTapTimeoutMillis();
                this.J$0 = doubleTapMinTimeMillis;
                this.J$1 = doubleTapTimeoutMillis;
                this.label = 1;
                if (AbstractC1476z.f(doubleTapMinTimeMillis, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    C0645y.this.getOnClick().invoke();
                    return U0.n.f1521a;
                }
                doubleTapTimeoutMillis = this.J$1;
                doubleTapMinTimeMillis = this.J$0;
                AbstractC0292a.H(obj);
            }
            a aVar2 = (a) C0645y.this.doubleKeyClickStates.b(this.$keyCode);
            if (aVar2 != null) {
                aVar2.setDoubleTapMinTimeMillisElapsed(true);
            }
            this.label = 2;
            if (AbstractC1476z.f(doubleTapTimeoutMillis - doubleTapMinTimeMillis, this) == aVar) {
                return aVar;
            }
            C0645y.this.getOnClick().invoke();
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((d) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public /* synthetic */ C0645y(h1.a aVar, String str, h1.a aVar2, h1.a aVar3, boolean z2, androidx.compose.foundation.interaction.n nVar, Y y2, boolean z3, boolean z4, String str2, C1116j c1116j, AbstractC1378g abstractC1378g) {
        this(aVar, str, aVar2, aVar3, z2, nVar, y2, z3, z4, str2, c1116j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean applyAdditionalSemantics$lambda$0(C0645y c0645y) {
        h1.a aVar = c0645y.onLongClick;
        if (aVar == null) {
            return true;
        }
        aVar.invoke();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0046  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void resetKeyPressState() {
        /*
            r22 = this;
            r0 = r22
            j.G r1 = r0.longKeyPressJobs
            java.lang.Object[] r2 = r1.f3080c
            long[] r3 = r1.f3078a
            int r4 = r3.length
            int r4 = r4 + (-2)
            r10 = 7
            r11 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            r13 = 8
            if (r4 < 0) goto L4b
            r15 = 0
        L16:
            r5 = r3[r15]
            long r8 = ~r5
            long r7 = r8 << r10
            long r7 = r7 & r5
            long r7 = r7 & r11
            int r7 = (r7 > r11 ? 1 : (r7 == r11 ? 0 : -1))
            if (r7 == 0) goto L46
            int r7 = r15 - r4
            int r7 = ~r7
            int r7 = r7 >>> 31
            int r7 = 8 - r7
            r8 = 0
        L29:
            if (r8 >= r7) goto L44
            r18 = 255(0xff, double:1.26E-321)
            long r20 = r5 & r18
            r16 = 128(0x80, double:6.32E-322)
            int r9 = (r20 > r16 ? 1 : (r20 == r16 ? 0 : -1))
            if (r9 >= 0) goto L40
            int r9 = r15 << 3
            int r9 = r9 + r8
            r9 = r2[r9]
            r1.b0 r9 = (r1.InterfaceC1451b0) r9
            r14 = 0
            r9.cancel(r14)
        L40:
            long r5 = r5 >> r13
            int r8 = r8 + 1
            goto L29
        L44:
            if (r7 != r13) goto L4b
        L46:
            if (r15 == r4) goto L4b
            int r15 = r15 + 1
            goto L16
        L4b:
            r1.c()
            j.G r1 = r0.doubleKeyClickStates
            java.lang.Object[] r2 = r1.f3080c
            long[] r3 = r1.f3078a
            int r4 = r3.length
            int r4 = r4 + (-2)
            if (r4 < 0) goto Lac
            r5 = 0
        L5a:
            r6 = r3[r5]
            long r8 = ~r6
            long r8 = r8 << r10
            long r8 = r8 & r6
            long r8 = r8 & r11
            int r8 = (r8 > r11 ? 1 : (r8 == r11 ? 0 : -1))
            if (r8 == 0) goto L9c
            int r8 = r5 - r4
            int r8 = ~r8
            int r8 = r8 >>> 31
            int r8 = 8 - r8
            r9 = 0
        L6c:
            if (r9 >= r8) goto L94
            r14 = 255(0xff, double:1.26E-321)
            long r18 = r6 & r14
            r16 = 128(0x80, double:6.32E-322)
            int r18 = (r18 > r16 ? 1 : (r18 == r16 ? 0 : -1))
            if (r18 >= 0) goto L89
            int r18 = r5 << 3
            int r18 = r18 + r9
            r18 = r2[r18]
            androidx.compose.foundation.y$a r18 = (androidx.compose.foundation.C0645y.a) r18
            r1.b0 r10 = r18.getJob()
            r11 = 0
            r10.cancel(r11)
            goto L8a
        L89:
            r11 = 0
        L8a:
            long r6 = r6 >> r13
            int r9 = r9 + 1
            r10 = 7
            r11 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            goto L6c
        L94:
            r11 = 0
            r14 = 255(0xff, double:1.26E-321)
            r16 = 128(0x80, double:6.32E-322)
            if (r8 != r13) goto Lac
            goto La1
        L9c:
            r11 = 0
            r14 = 255(0xff, double:1.26E-321)
            r16 = 128(0x80, double:6.32E-322)
        La1:
            if (r5 == r4) goto Lac
            int r5 = r5 + 1
            r10 = 7
            r11 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            goto L5a
        Lac:
            r1.c()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.C0645y.resetKeyPressState():void");
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    public void applyAdditionalSemantics(androidx.compose.ui.semantics.E e2) {
        if (this.onLongClick != null) {
            androidx.compose.ui.semantics.C.onLongClick(e2, this.onLongClickLabel, new E0.f(this, 7));
        }
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    public androidx.compose.ui.input.pointer.Z createPointerInputNodeIfNeeded() {
        return androidx.compose.ui.input.pointer.X.SuspendingPointerInputModifierNode(new b());
    }

    public final boolean getHapticFeedbackEnabled() {
        return this.hapticFeedbackEnabled;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    public void onCancelKeyInput() {
        resetKeyPressState();
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    /* JADX INFO: renamed from: onClickKeyDownEvent-ZmokQxo */
    public boolean mo711onClickKeyDownEventZmokQxo(KeyEvent keyEvent) {
        boolean z2;
        long jM515getKeyZmokQxo = P.d.m515getKeyZmokQxo(keyEvent);
        if (this.onLongClick == null || this.longKeyPressJobs.b(jM515getKeyZmokQxo) != null) {
            z2 = false;
        } else {
            this.longKeyPressJobs.h(jM515getKeyZmokQxo, AbstractC1476z.s(getCoroutineScope(), null, null, new c(null), 3));
            z2 = true;
        }
        a aVar = (a) this.doubleKeyClickStates.b(jM515getKeyZmokQxo);
        if (aVar != null) {
            if (aVar.getJob().isActive()) {
                aVar.getJob().cancel(null);
                if (!aVar.getDoubleTapMinTimeMillisElapsed()) {
                    getOnClick().invoke();
                    this.doubleKeyClickStates.g(jM515getKeyZmokQxo);
                }
            } else {
                this.doubleKeyClickStates.g(jM515getKeyZmokQxo);
            }
        }
        return z2;
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    /* JADX INFO: renamed from: onClickKeyUpEvent-ZmokQxo */
    public boolean mo712onClickKeyUpEventZmokQxo(KeyEvent keyEvent) {
        h1.a aVar;
        long jM515getKeyZmokQxo = P.d.m515getKeyZmokQxo(keyEvent);
        boolean z2 = false;
        if (this.longKeyPressJobs.b(jM515getKeyZmokQxo) != null) {
            InterfaceC1451b0 interfaceC1451b0 = (InterfaceC1451b0) this.longKeyPressJobs.b(jM515getKeyZmokQxo);
            if (interfaceC1451b0 != null) {
                if (interfaceC1451b0.isActive()) {
                    interfaceC1451b0.cancel(null);
                } else {
                    z2 = true;
                }
            }
            this.longKeyPressJobs.g(jM515getKeyZmokQxo);
        }
        if (this.onDoubleClick != null) {
            if (this.doubleKeyClickStates.b(jM515getKeyZmokQxo) != null) {
                if (!z2 && (aVar = this.onDoubleClick) != null) {
                    aVar.invoke();
                }
                this.doubleKeyClickStates.g(jM515getKeyZmokQxo);
            } else if (!z2) {
                this.doubleKeyClickStates.h(jM515getKeyZmokQxo, new a(AbstractC1476z.s(getCoroutineScope(), null, null, new d(jM515getKeyZmokQxo, null), 3)));
            }
        } else if (!z2) {
            getOnClick().invoke();
        }
        return true;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.w
    public void onReset() {
        super.onReset();
        resetKeyPressState();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    public final void setHapticFeedbackEnabled(boolean z2) {
        this.hapticFeedbackEnabled = z2;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    /* JADX INFO: renamed from: update-2tQrsxU, reason: not valid java name */
    public final void m1666update2tQrsxU(h1.a aVar, String str, h1.a aVar2, h1.a aVar3, androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str2, C1116j c1116j) {
        boolean z4;
        if (!kotlin.jvm.internal.o.a(this.onLongClickLabel, str)) {
            this.onLongClickLabel = str;
            T0.invalidateSemantics(this);
        }
        if ((this.onLongClick == null) != (aVar2 == null)) {
            disposeInteractions();
            T0.invalidateSemantics(this);
            z4 = true;
        } else {
            z4 = false;
        }
        this.onLongClick = aVar2;
        if ((this.onDoubleClick == null) != (aVar3 == null)) {
            z4 = true;
        }
        this.onDoubleClick = aVar3;
        boolean z5 = getEnabled() != z3 ? true : z4;
        m713updateCommonO2vRcR0(nVar, y2, z2, z3, str2, c1116j, aVar);
        if (z5) {
            resetPointerInputHandler();
        }
    }

    private C0645y(h1.a aVar, String str, h1.a aVar2, h1.a aVar3, boolean z2, androidx.compose.foundation.interaction.n nVar, Y y2, boolean z3, boolean z4, String str2, C1116j c1116j) {
        super(nVar, y2, z3, z4, str2, c1116j, aVar, null);
        this.onLongClickLabel = str;
        this.onLongClick = aVar2;
        this.onDoubleClick = aVar3;
        this.hapticFeedbackEnabled = z2;
        C1336G c1336g = AbstractC1361t.f3083a;
        this.longKeyPressJobs = new C1336G();
        this.doubleKeyClickStates = new C1336G();
    }
}
