package androidx.compose.foundation;

import androidx.compose.ui.graphics.l1;

/* JADX INFO: renamed from: androidx.compose.foundation.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0503p {
    /* JADX INFO: renamed from: BorderStroke-cXLIe8U, reason: not valid java name */
    public static final C0502o m1122BorderStrokecXLIe8U(float f2, long j2) {
        return new C0502o(f2, new l1(j2, null), null);
    }
}
