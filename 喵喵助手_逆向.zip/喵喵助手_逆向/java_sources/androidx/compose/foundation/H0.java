package androidx.compose.foundation;

import androidx.compose.ui.node.InterfaceC1007o;

/* JADX INFO: loaded from: classes.dex */
public final class H0 implements i0 {
    private final boolean attachNode;
    private final boolean eventHandlingEnabled;
    private final i0 innerOverscrollEffect;
    private final InterfaceC1007o node;

    public static final class a extends androidx.compose.ui.w {
        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }
    }

    public H0(boolean z2, boolean z3, i0 i0Var) {
        this.attachNode = z2;
        this.eventHandlingEnabled = z3;
        this.innerOverscrollEffect = i0Var;
        this.node = z2 ? i0Var.getNode() : new a();
    }

    @Override // androidx.compose.foundation.i0
    /* JADX INFO: renamed from: applyToFling-BMRW4eQ, reason: not valid java name */
    public Object mo694applyToFlingBMRW4eQ(long j2, h1.e eVar, Y0.c cVar) {
        boolean z2 = this.eventHandlingEnabled;
        U0.n nVar = U0.n.f1521a;
        if (z2) {
            Object objMo694applyToFlingBMRW4eQ = this.innerOverscrollEffect.mo694applyToFlingBMRW4eQ(j2, eVar, cVar);
            return objMo694applyToFlingBMRW4eQ == Z0.a.f1616b ? objMo694applyToFlingBMRW4eQ : nVar;
        }
        Object objInvoke = eVar.invoke(e0.z.m5297boximpl(j2), cVar);
        return objInvoke == Z0.a.f1616b ? objInvoke : nVar;
    }

    @Override // androidx.compose.foundation.i0
    /* JADX INFO: renamed from: applyToScroll-Rhakbz0, reason: not valid java name */
    public long mo695applyToScrollRhakbz0(long j2, int i2, h1.c cVar) {
        return this.eventHandlingEnabled ? this.innerOverscrollEffect.mo695applyToScrollRhakbz0(j2, i2, cVar) : ((J.f) cVar.invoke(J.f.m39boximpl(j2))).m60unboximpl();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof H0)) {
            return false;
        }
        H0 h02 = (H0) obj;
        return this.attachNode == h02.attachNode && this.eventHandlingEnabled == h02.eventHandlingEnabled && kotlin.jvm.internal.o.a(this.innerOverscrollEffect, h02.innerOverscrollEffect);
    }

    @Override // androidx.compose.foundation.i0
    public /* bridge */ /* synthetic */ androidx.compose.ui.x getEffectModifier() {
        return super.getEffectModifier();
    }

    @Override // androidx.compose.foundation.i0
    public InterfaceC1007o getNode() {
        return this.node;
    }

    public int hashCode() {
        return this.innerOverscrollEffect.hashCode() + D0.d.c(Boolean.hashCode(this.attachNode) * 31, 31, this.eventHandlingEnabled);
    }

    @Override // androidx.compose.foundation.i0
    public boolean isInProgress() {
        return this.innerOverscrollEffect.isInProgress();
    }
}
