package androidx.compose.foundation;

/* JADX INFO: renamed from: androidx.compose.foundation.f0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0374f0 implements U {
    public static final C0374f0 INSTANCE = new C0374f0();

    private C0374f0() {
    }

    @Override // androidx.compose.foundation.U
    public void drawIndication(androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
    }
}
