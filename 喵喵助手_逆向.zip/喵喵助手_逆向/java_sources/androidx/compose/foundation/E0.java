package androidx.compose.foundation;

import androidx.compose.foundation.gestures.InterfaceC0381e;
import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.node.InterfaceC1001l;
import androidx.compose.ui.node.InterfaceC1007o;
import androidx.compose.ui.node.InterfaceC1029z0;

/* JADX INFO: loaded from: classes.dex */
public final class E0 extends androidx.compose.ui.node.r implements InterfaceC1001l, InterfaceC1029z0 {
    private InterfaceC0381e bringIntoViewSpec;
    private boolean enabled;
    private InterfaceC0400y flingBehavior;
    private androidx.compose.foundation.interaction.n interactionSource;
    private j0 localOverscrollFactory;
    private i0 localOverscrollFactoryCreatedOverscrollEffect;
    private androidx.compose.foundation.gestures.I orientation;
    private InterfaceC1007o overscrollNode;
    private boolean reverseScrolling;
    private androidx.compose.foundation.gestures.b0 scrollableNode;
    private final boolean shouldAutoInvalidate;
    private boolean shouldReverseDirection;
    private androidx.compose.foundation.gestures.c0 state;
    private boolean useLocalOverscrollFactory;
    private i0 userProvidedOverscrollEffect;

    public E0(androidx.compose.foundation.gestures.c0 c0Var, androidx.compose.foundation.gestures.I i2, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e, boolean z4, i0 i0Var) {
        this.state = c0Var;
        this.orientation = i2;
        this.enabled = z2;
        this.reverseScrolling = z3;
        this.flingBehavior = interfaceC0400y;
        this.interactionSource = nVar;
        this.bringIntoViewSpec = interfaceC0381e;
        this.useLocalOverscrollFactory = z4;
        this.userProvidedOverscrollEffect = i0Var;
    }

    private final void attachOverscrollNodeIfNeeded() {
        InterfaceC1007o interfaceC1007o = this.overscrollNode;
        if (interfaceC1007o != null) {
            if (interfaceC1007o.getNode().isAttached()) {
                return;
            }
            delegate(interfaceC1007o);
            return;
        }
        if (this.useLocalOverscrollFactory) {
            androidx.compose.ui.node.A0.observeReads(this, new E0.f(this, 8));
        }
        i0 overscrollEffect = getOverscrollEffect();
        if (overscrollEffect != null) {
            InterfaceC1007o node = overscrollEffect.getNode();
            if (node.getNode().isAttached()) {
                return;
            }
            this.overscrollNode = delegate(node);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n attachOverscrollNodeIfNeeded$lambda$2(E0 e02) {
        j0 j0Var = (j0) AbstractC1003m.currentValueOf(e02, k0.getLocalOverscrollFactory());
        e02.localOverscrollFactory = j0Var;
        e02.localOverscrollFactoryCreatedOverscrollEffect = j0Var != null ? j0Var.createOverscrollEffect() : null;
        return U0.n.f1521a;
    }

    public final i0 getOverscrollEffect() {
        return this.useLocalOverscrollFactory ? this.localOverscrollFactoryCreatedOverscrollEffect : this.userProvidedOverscrollEffect;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        this.shouldReverseDirection = shouldReverseDirection();
        attachOverscrollNodeIfNeeded();
        if (this.scrollableNode == null) {
            this.scrollableNode = (androidx.compose.foundation.gestures.b0) delegate(new androidx.compose.foundation.gestures.b0(this.state, getOverscrollEffect(), this.flingBehavior, this.orientation, this.enabled, this.shouldReverseDirection, this.interactionSource, this.bringIntoViewSpec));
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w
    public void onDetach() {
        InterfaceC1007o interfaceC1007o = this.overscrollNode;
        if (interfaceC1007o != null) {
            undelegate(interfaceC1007o);
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public void onLayoutDirectionChange() {
        boolean zShouldReverseDirection = shouldReverseDirection();
        if (this.shouldReverseDirection != zShouldReverseDirection) {
            this.shouldReverseDirection = zShouldReverseDirection;
            update(this.state, this.orientation, this.useLocalOverscrollFactory, getOverscrollEffect(), this.enabled, this.reverseScrolling, this.flingBehavior, this.interactionSource, this.bringIntoViewSpec);
        }
    }

    @Override // androidx.compose.ui.node.InterfaceC1029z0
    public void onObservedReadsChanged() {
        j0 j0Var = (j0) AbstractC1003m.currentValueOf(this, k0.getLocalOverscrollFactory());
        if (kotlin.jvm.internal.o.a(j0Var, this.localOverscrollFactory)) {
            return;
        }
        this.localOverscrollFactory = j0Var;
        this.localOverscrollFactoryCreatedOverscrollEffect = null;
        InterfaceC1007o interfaceC1007o = this.overscrollNode;
        if (interfaceC1007o != null) {
            undelegate(interfaceC1007o);
        }
        this.overscrollNode = null;
        attachOverscrollNodeIfNeeded();
        androidx.compose.foundation.gestures.b0 b0Var = this.scrollableNode;
        if (b0Var != null) {
            b0Var.update(this.state, this.orientation, getOverscrollEffect(), this.enabled, this.shouldReverseDirection, this.flingBehavior, this.interactionSource, this.bringIntoViewSpec);
        }
    }

    public final boolean shouldReverseDirection() {
        e0.u uVarRequireLayoutDirection = e0.u.Ltr;
        if (isAttached()) {
            uVarRequireLayoutDirection = AbstractC1009p.requireLayoutDirection(this);
        }
        return androidx.compose.foundation.gestures.V.INSTANCE.reverseDirection(uVarRequireLayoutDirection, this.orientation, this.reverseScrolling);
    }

    public final void update(androidx.compose.foundation.gestures.c0 c0Var, androidx.compose.foundation.gestures.I i2, boolean z2, i0 i0Var, boolean z3, boolean z4, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e) {
        boolean z5;
        this.state = c0Var;
        this.orientation = i2;
        boolean z6 = true;
        if (this.useLocalOverscrollFactory != z2) {
            this.useLocalOverscrollFactory = z2;
            z5 = true;
        } else {
            z5 = false;
        }
        if (kotlin.jvm.internal.o.a(this.userProvidedOverscrollEffect, i0Var)) {
            z6 = false;
        } else {
            this.userProvidedOverscrollEffect = i0Var;
        }
        if (z5 || (z6 && !z2)) {
            InterfaceC1007o interfaceC1007o = this.overscrollNode;
            if (interfaceC1007o != null) {
                undelegate(interfaceC1007o);
            }
            this.overscrollNode = null;
            attachOverscrollNodeIfNeeded();
        }
        this.enabled = z3;
        this.reverseScrolling = z4;
        this.flingBehavior = interfaceC0400y;
        this.interactionSource = nVar;
        this.bringIntoViewSpec = interfaceC0381e;
        this.shouldReverseDirection = shouldReverseDirection();
        androidx.compose.foundation.gestures.b0 b0Var = this.scrollableNode;
        if (b0Var != null) {
            b0Var.update(c0Var, i2, getOverscrollEffect(), z3, this.shouldReverseDirection, interfaceC0400y, nVar, interfaceC0381e);
        }
    }
}
