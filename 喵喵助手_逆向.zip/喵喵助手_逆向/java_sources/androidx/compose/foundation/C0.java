package androidx.compose.foundation;

import O0.C0218m;
import androidx.compose.animation.core.C0316j0;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.runtime.F1;
import androidx.compose.runtime.InterfaceC0816z0;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;
import androidx.compose.runtime.snapshots.AbstractC0788j;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class C0 implements androidx.compose.foundation.gestures.c0 {
    public static final int $stable = 0;
    public static final a Companion = new a(null);
    private static final androidx.compose.runtime.saveable.l Saver = androidx.compose.runtime.saveable.m.Saver(new O0.M(18), new androidx.compose.animation.core.D0(10));
    private float accumulator;
    private final d2 canScrollBackward$delegate;
    private final d2 canScrollForward$delegate;
    private final InterfaceC0816z0 value$delegate;
    private final InterfaceC0816z0 viewportSize$delegate = F1.mutableIntStateOf(0);
    private final androidx.compose.foundation.interaction.n internalInteractionSource = androidx.compose.foundation.interaction.m.MutableInteractionSource();
    private InterfaceC0816z0 _maxValueState = F1.mutableIntStateOf(Integer.MAX_VALUE);
    private final androidx.compose.foundation.gestures.c0 scrollableState = androidx.compose.foundation.gestures.d0.ScrollableState(new C0218m(this, 6));

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final androidx.compose.runtime.saveable.l getSaver() {
            return C0.Saver;
        }

        private a() {
        }
    }

    public C0(int i2) {
        this.value$delegate = F1.mutableIntStateOf(i2);
        final int i3 = 0;
        this.canScrollForward$delegate = Q1.derivedStateOf(new h1.a(this) { // from class: androidx.compose.foundation.B0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ C0 f1672c;

            {
                this.f1672c = this;
            }

            @Override // h1.a
            public final Object invoke() {
                switch (i3) {
                    case 0:
                        return Boolean.valueOf(C0.canScrollForward_delegate$lambda$2(this.f1672c));
                    default:
                        return Boolean.valueOf(C0.canScrollBackward_delegate$lambda$3(this.f1672c));
                }
            }
        });
        final int i4 = 1;
        this.canScrollBackward$delegate = Q1.derivedStateOf(new h1.a(this) { // from class: androidx.compose.foundation.B0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ C0 f1672c;

            {
                this.f1672c = this;
            }

            @Override // h1.a
            public final Object invoke() {
                switch (i4) {
                    case 0:
                        return Boolean.valueOf(C0.canScrollForward_delegate$lambda$2(this.f1672c));
                    default:
                        return Boolean.valueOf(C0.canScrollBackward_delegate$lambda$3(this.f1672c));
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Integer Saver$lambda$4(androidx.compose.runtime.saveable.n nVar, C0 c02) {
        return Integer.valueOf(c02.getValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0 Saver$lambda$5(int i2) {
        return new C0(i2);
    }

    public static /* synthetic */ Object animateScrollTo$default(C0 c02, int i2, InterfaceC0313i interfaceC0313i, Y0.c cVar, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = new C0316j0(0.0f, 0.0f, null, 7, null);
        }
        return c02.animateScrollTo(i2, interfaceC0313i, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean canScrollBackward_delegate$lambda$3(C0 c02) {
        return c02.getValue() > 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean canScrollForward_delegate$lambda$2(C0 c02) {
        return c02.getValue() < c02.getMaxValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float scrollableState$lambda$1(C0 c02, float f2) {
        float value = c02.getValue() + f2 + c02.accumulator;
        float fN = j1.a.n(value, 0.0f, c02.getMaxValue());
        boolean z2 = value == fN;
        float value2 = fN - c02.getValue();
        int iRound = Math.round(value2);
        c02.setValue(c02.getValue() + iRound);
        c02.accumulator = value2 - iRound;
        return !z2 ? value2 : f2;
    }

    private final void setValue(int i2) {
        this.value$delegate.setIntValue(i2);
    }

    public final Object animateScrollTo(int i2, InterfaceC0313i interfaceC0313i, Y0.c cVar) {
        Object objAnimateScrollBy = androidx.compose.foundation.gestures.N.animateScrollBy(this, i2 - getValue(), interfaceC0313i, cVar);
        return objAnimateScrollBy == Z0.a.f1616b ? objAnimateScrollBy : U0.n.f1521a;
    }

    @Override // androidx.compose.foundation.gestures.c0
    public float dispatchRawDelta(float f2) {
        return this.scrollableState.dispatchRawDelta(f2);
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getCanScrollBackward() {
        return ((Boolean) this.canScrollBackward$delegate.getValue()).booleanValue();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getCanScrollForward() {
        return ((Boolean) this.canScrollForward$delegate.getValue()).booleanValue();
    }

    public final androidx.compose.foundation.interaction.l getInteractionSource() {
        return this.internalInteractionSource;
    }

    public final androidx.compose.foundation.interaction.n getInternalInteractionSource$foundation_release() {
        return this.internalInteractionSource;
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getLastScrolledBackward() {
        return this.scrollableState.getLastScrolledBackward();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getLastScrolledForward() {
        return this.scrollableState.getLastScrolledForward();
    }

    public final int getMaxValue() {
        return this._maxValueState.getIntValue();
    }

    public final int getValue() {
        return this.value$delegate.getIntValue();
    }

    public final int getViewportSize() {
        return this.viewportSize$delegate.getIntValue();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean isScrollInProgress() {
        return this.scrollableState.isScrollInProgress();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public Object scroll(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
        Object objScroll = this.scrollableState.scroll(enumC0368c0, eVar, cVar);
        return objScroll == Z0.a.f1616b ? objScroll : U0.n.f1521a;
    }

    public final Object scrollTo(int i2, Y0.c cVar) {
        return androidx.compose.foundation.gestures.N.scrollBy(this, i2 - getValue(), cVar);
    }

    public final void setMaxValue$foundation_release(int i2) {
        this._maxValueState.setIntValue(i2);
        AbstractC0788j.a aVar = AbstractC0788j.Companion;
        AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
        h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
        AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
        try {
            if (getValue() > i2) {
                setValue(i2);
            }
        } finally {
            aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
        }
    }

    public final void setViewportSize$foundation_release(int i2) {
        this.viewportSize$delegate.setIntValue(i2);
    }
}
