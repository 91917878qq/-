package androidx.compose.foundation;

import android.content.Context;
import android.widget.EdgeEffect;
import e0.AbstractC1304a;
import e0.C1311h;

/* JADX INFO: loaded from: classes.dex */
public final class L extends EdgeEffect {
    private float oppositeReleaseDelta;
    private final float oppositeReleaseDeltaThreshold;

    public L(Context context) {
        super(context);
        this.oppositeReleaseDeltaThreshold = AbstractC1304a.Density(context).mo788toPx0680j_4(C1311h.m5076constructorimpl(1));
    }

    @Override // android.widget.EdgeEffect
    public void onAbsorb(int i2) {
        this.oppositeReleaseDelta = 0.0f;
        super.onAbsorb(i2);
    }

    @Override // android.widget.EdgeEffect
    public void onPull(float f2, float f3) {
        this.oppositeReleaseDelta = 0.0f;
        super.onPull(f2, f3);
    }

    @Override // android.widget.EdgeEffect
    public void onRelease() {
        this.oppositeReleaseDelta = 0.0f;
        super.onRelease();
    }

    public final void releaseWithOppositeDelta(float f2) {
        float f3 = this.oppositeReleaseDelta + f2;
        this.oppositeReleaseDelta = f3;
        if (Math.abs(f3) > this.oppositeReleaseDeltaThreshold) {
            onRelease();
        }
    }

    @Override // android.widget.EdgeEffect
    public void onPull(float f2) {
        this.oppositeReleaseDelta = 0.0f;
        super.onPull(f2);
    }
}
