package androidx.compose.foundation;

/* JADX INFO: renamed from: androidx.compose.foundation.d0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0370d0 extends o.g {
    public static final int $stable = 8;

    public C0370d0() {
        super("Mutation interrupted");
    }
}
