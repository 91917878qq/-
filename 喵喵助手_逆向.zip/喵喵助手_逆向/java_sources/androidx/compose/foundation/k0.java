package androidx.compose.foundation;

import androidx.compose.runtime.AbstractC0721c1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;

/* JADX INFO: loaded from: classes.dex */
public abstract class k0 {
    private static final AbstractC0721c1 LocalOverscrollFactory = androidx.compose.runtime.D.compositionLocalWithComputedDefaultOf(new androidx.compose.animation.core.D0(8));

    public static final AbstractC0721c1 getLocalOverscrollFactory() {
        return LocalOverscrollFactory;
    }

    public static final androidx.compose.ui.x overscroll(androidx.compose.ui.x xVar, i0 i0Var) {
        androidx.compose.ui.x overscrollModifierElement;
        if (i0Var == null || (overscrollModifierElement = i0Var.getEffectModifier()) == null) {
            overscrollModifierElement = androidx.compose.ui.x.Companion;
        }
        if (overscrollModifierElement == androidx.compose.ui.x.Companion) {
            overscrollModifierElement = new OverscrollModifierElement(i0Var);
        }
        return xVar.then(overscrollModifierElement);
    }

    public static final i0 rememberOverscrollEffect(InterfaceC0768p interfaceC0768p, int i2) {
        interfaceC0768p.startReplaceGroup(282942128);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(282942128, i2, -1, "androidx.compose.foundation.rememberOverscrollEffect (Overscroll.kt:343)");
        }
        j0 j0Var = (j0) interfaceC0768p.consume(LocalOverscrollFactory);
        if (j0Var == null) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return null;
        }
        boolean zChanged = interfaceC0768p.changed(j0Var);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = j0Var.createOverscrollEffect();
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        i0 i0Var = (i0) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        interfaceC0768p.endReplaceGroup();
        return i0Var;
    }

    public static final i0 withoutEventHandling(i0 i0Var) {
        return new H0(true, false, i0Var);
    }

    public static final i0 withoutVisualEffect(i0 i0Var) {
        return new H0(false, true, i0Var);
    }
}
