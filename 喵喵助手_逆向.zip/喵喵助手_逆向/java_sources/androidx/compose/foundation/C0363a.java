package androidx.compose.foundation;

/* JADX INFO: renamed from: androidx.compose.foundation.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0363a implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1684b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AbstractC0365b f1685c;

    public /* synthetic */ C0363a(AbstractC0365b abstractC0365b, int i2) {
        this.f1684b = i2;
        this.f1685c = abstractC0365b;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1684b) {
            case 0:
                return AbstractC0365b.onObservedReadsChanged$lambda$1(this.f1685c);
            default:
                return Boolean.valueOf(AbstractC0365b.applySemantics$lambda$12(this.f1685c));
        }
    }
}
