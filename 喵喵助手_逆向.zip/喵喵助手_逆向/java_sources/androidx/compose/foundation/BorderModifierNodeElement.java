package androidx.compose.foundation;

import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.graphics.l1;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class BorderModifierNodeElement extends AbstractC1000k0 {
    public static final int $stable = 0;
    private final androidx.compose.ui.graphics.P brush;
    private final j1 shape;
    private final float width;

    public /* synthetic */ BorderModifierNodeElement(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var, AbstractC1378g abstractC1378g) {
        this(f2, p2, j1Var);
    }

    /* JADX INFO: renamed from: copy-8Feqmps$default, reason: not valid java name */
    public static /* synthetic */ BorderModifierNodeElement m688copy8Feqmps$default(BorderModifierNodeElement borderModifierNodeElement, float f2, androidx.compose.ui.graphics.P p2, j1 j1Var, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = borderModifierNodeElement.width;
        }
        if ((i2 & 2) != 0) {
            p2 = borderModifierNodeElement.brush;
        }
        if ((i2 & 4) != 0) {
            j1Var = borderModifierNodeElement.shape;
        }
        return borderModifierNodeElement.m690copy8Feqmps(f2, p2, j1Var);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    /* JADX INFO: renamed from: component1-D9Ej5fM, reason: not valid java name */
    public final float m689component1D9Ej5fM() {
        return this.width;
    }

    public final androidx.compose.ui.graphics.P component2() {
        return this.brush;
    }

    public final j1 component3() {
        return this.shape;
    }

    /* JADX INFO: renamed from: copy-8Feqmps, reason: not valid java name */
    public final BorderModifierNodeElement m690copy8Feqmps(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var) {
        return new BorderModifierNodeElement(f2, p2, j1Var, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof BorderModifierNodeElement)) {
            return false;
        }
        BorderModifierNodeElement borderModifierNodeElement = (BorderModifierNodeElement) obj;
        return C1311h.m5081equalsimpl0(this.width, borderModifierNodeElement.width) && kotlin.jvm.internal.o.a(this.brush, borderModifierNodeElement.brush) && kotlin.jvm.internal.o.a(this.shape, borderModifierNodeElement.shape);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final androidx.compose.ui.graphics.P getBrush() {
        return this.brush;
    }

    public final j1 getShape() {
        return this.shape;
    }

    /* JADX INFO: renamed from: getWidth-D9Ej5fM, reason: not valid java name */
    public final float m691getWidthD9Ej5fM() {
        return this.width;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return this.shape.hashCode() + ((this.brush.hashCode() + (C1311h.m5082hashCodeimpl(this.width) * 31)) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("border");
        c1065l1.getProperties().set("width", C1311h.m5074boximpl(this.width));
        if (this.brush instanceof l1) {
            c1065l1.getProperties().set("color", androidx.compose.ui.graphics.Y.m3010boximpl(((l1) this.brush).m3309getValue0d7_KjU()));
            c1065l1.setValue(androidx.compose.ui.graphics.Y.m3010boximpl(((l1) this.brush).m3309getValue0d7_KjU()));
        } else {
            c1065l1.getProperties().set("brush", this.brush);
        }
        c1065l1.getProperties().set("shape", this.shape);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("BorderModifierNodeElement(width=");
        D0.d.u(this.width, sb, ", brush=");
        sb.append(this.brush);
        sb.append(", shape=");
        sb.append(this.shape);
        sb.append(')');
        return sb.toString();
    }

    private BorderModifierNodeElement(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var) {
        this.width = f2;
        this.brush = p2;
        this.shape = j1Var;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0501n create() {
        return new C0501n(this.width, this.brush, this.shape, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0501n c0501n) {
        c0501n.m1117setWidth0680j_4(this.width);
        c0501n.setBrush(this.brush);
        c0501n.setShape(this.shape);
    }
}
