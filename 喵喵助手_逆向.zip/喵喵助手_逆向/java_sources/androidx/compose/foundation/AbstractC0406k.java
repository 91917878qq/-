package androidx.compose.foundation;

import androidx.compose.ui.graphics.K0;
import androidx.compose.ui.graphics.R0;
import androidx.compose.ui.graphics.a1;
import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.graphics.l1;

/* JADX INFO: renamed from: androidx.compose.foundation.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0406k {
    public static final androidx.compose.ui.x border(androidx.compose.ui.x xVar, C0502o c0502o, j1 j1Var) {
        return m892borderziNgDLE(xVar, c0502o.m1120getWidthD9Ej5fM(), c0502o.getBrush(), j1Var);
    }

    public static /* synthetic */ androidx.compose.ui.x border$default(androidx.compose.ui.x xVar, C0502o c0502o, j1 j1Var, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            j1Var = a1.getRectangleShape();
        }
        return border(xVar, c0502o, j1Var);
    }

    /* JADX INFO: renamed from: border-xT4_qwU, reason: not valid java name */
    public static final androidx.compose.ui.x m890borderxT4_qwU(androidx.compose.ui.x xVar, float f2, long j2, j1 j1Var) {
        return m892borderziNgDLE(xVar, f2, new l1(j2, null), j1Var);
    }

    /* JADX INFO: renamed from: border-xT4_qwU$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m891borderxT4_qwU$default(androidx.compose.ui.x xVar, float f2, long j2, j1 j1Var, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            j1Var = a1.getRectangleShape();
        }
        return m890borderxT4_qwU(xVar, f2, j2, j1Var);
    }

    /* JADX INFO: renamed from: border-ziNgDLE, reason: not valid java name */
    public static final androidx.compose.ui.x m892borderziNgDLE(androidx.compose.ui.x xVar, float f2, androidx.compose.ui.graphics.P p2, j1 j1Var) {
        return xVar.then(new BorderModifierNodeElement(f2, p2, j1Var, null));
    }

    private static final J.j createInsetRoundedRect(float f2, J.j jVar) {
        return new J.j(f2, f2, jVar.getWidth() - f2, jVar.getHeight() - f2, m894shrinkKibmq7A(jVar.m100getTopLeftCornerRadiuskKHJgLs(), f2), m894shrinkKibmq7A(jVar.m101getTopRightCornerRadiuskKHJgLs(), f2), m894shrinkKibmq7A(jVar.m99getBottomRightCornerRadiuskKHJgLs(), f2), m894shrinkKibmq7A(jVar.m98getBottomLeftCornerRadiuskKHJgLs(), f2), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final K0 createRoundRectPath(K0 k0, J.j jVar, float f2, boolean z2) {
        k0.reset();
        K0.addRoundRect$default(k0, jVar, null, 2, null);
        if (!z2) {
            K0 k0Path = androidx.compose.ui.graphics.A.Path();
            K0.addRoundRect$default(k0Path, createInsetRoundedRect(f2, jVar), null, 2, null);
            k0.mo2921opN5in7k0(k0, k0Path, R0.Companion.m2969getDifferenceb3I0S0c());
        }
        return k0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.ui.draw.l drawContentWithoutBorder(androidx.compose.ui.draw.g gVar) {
        return gVar.onDrawWithContent(new androidx.compose.animation.core.D0(5));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawContentWithoutBorder$lambda$0(androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: drawRectBorder-NsqcLGU, reason: not valid java name */
    public static final androidx.compose.ui.draw.l m893drawRectBorderNsqcLGU(androidx.compose.ui.draw.g gVar, final androidx.compose.ui.graphics.P p2, long j2, long j3, boolean z2, float f2) {
        final long jM66getZeroF1C5BW0 = z2 ? J.f.Companion.m66getZeroF1C5BW0() : j2;
        final long jM2677getSizeNHjbRc = z2 ? gVar.m2677getSizeNHjbRc() : j3;
        final androidx.compose.ui.graphics.drawscope.h lVar = z2 ? androidx.compose.ui.graphics.drawscope.k.INSTANCE : new androidx.compose.ui.graphics.drawscope.l(f2, 0.0f, 0, 0, null, 30, null);
        return gVar.onDrawWithContent(new h1.c() { // from class: androidx.compose.foundation.j
            @Override // h1.c
            public final Object invoke(Object obj) {
                long j4 = jM66getZeroF1C5BW0;
                long j5 = jM2677getSizeNHjbRc;
                return AbstractC0406k.drawRectBorder_NsqcLGU$lambda$1(p2, j4, j5, lVar, (androidx.compose.ui.graphics.drawscope.c) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n drawRectBorder_NsqcLGU$lambda$1(androidx.compose.ui.graphics.P p2, long j2, long j3, androidx.compose.ui.graphics.drawscope.h hVar, androidx.compose.ui.graphics.drawscope.c cVar) {
        cVar.drawContent();
        androidx.compose.ui.graphics.drawscope.g.m3237drawRectAsUm42w$default(cVar, p2, j2, j3, 0.0f, hVar, null, 0, 104, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: shrink-Kibmq7A, reason: not valid java name */
    public static final long m894shrinkKibmq7A(long j2, float f2) {
        float fMax = Math.max(0.0f, Float.intBitsToFloat((int) (j2 >> 32)) - f2);
        float fMax2 = Math.max(0.0f, Float.intBitsToFloat((int) (j2 & 4294967295L)) - f2);
        return J.a.m4constructorimpl((((long) Float.floatToRawIntBits(fMax)) << 32) | (((long) Float.floatToRawIntBits(fMax2)) & 4294967295L));
    }
}
