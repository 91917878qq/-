package androidx.compose.foundation;

import O0.C0218m;
import a.AbstractC0292a;
import android.view.KeyEvent;
import androidx.compose.ui.input.pointer.AbstractC0919q;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.platform.L0;
import androidx.compose.ui.platform.W1;
import androidx.compose.ui.semantics.C1116j;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0642v extends AbstractC0365b {
    public static final int $stable = 8;
    private androidx.compose.ui.input.pointer.C downEvent;
    private final boolean isSuspendingPointerInputEnabled;

    /* JADX INFO: renamed from: androidx.compose.foundation.v$a */
    public static final class a implements PointerInputEventHandler {

        /* JADX INFO: renamed from: androidx.compose.foundation.v$a$a, reason: collision with other inner class name */
        public static final class C0093a extends a1.j implements h1.f {
            /* synthetic */ long J$0;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0642v this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0093a(C0642v c0642v, Y0.c cVar) {
                super(3, cVar);
                this.this$0 = c0642v;
            }

            @Override // h1.f
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                return m1665invoked4ec7I((androidx.compose.foundation.gestures.J) obj, ((J.f) obj2).m60unboximpl(), (Y0.c) obj3);
            }

            /* JADX INFO: renamed from: invoke-d-4ec7I, reason: not valid java name */
            public final Object m1665invoked4ec7I(androidx.compose.foundation.gestures.J j2, long j3, Y0.c cVar) {
                C0093a c0093a = new C0093a(this.this$0, cVar);
                c0093a.L$0 = j2;
                c0093a.J$0 = j3;
                return c0093a.invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    androidx.compose.foundation.gestures.J j2 = (androidx.compose.foundation.gestures.J) this.L$0;
                    long j3 = this.J$0;
                    if (this.this$0.getEnabled()) {
                        C0642v c0642v = this.this$0;
                        this.label = 1;
                        if (c0642v.m708handlePressInteractiond4ec7I(j2, j3, this) == aVar) {
                            return aVar;
                        }
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                }
                return U0.n.f1521a;
            }
        }

        public a() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$0(C0642v c0642v, J.f fVar) {
            if (c0642v.getEnabled()) {
                c0642v.getOnClick().invoke();
            }
            return U0.n.f1521a;
        }

        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
        public final Object invoke(androidx.compose.ui.input.pointer.L l2, Y0.c cVar) {
            Object objDetectTapAndPress = androidx.compose.foundation.gestures.g0.detectTapAndPress(l2, new C0093a(C0642v.this, null), new C0218m(C0642v.this, 5), cVar);
            return objDetectTapAndPress == Z0.a.f1616b ? objDetectTapAndPress : U0.n.f1521a;
        }
    }

    public /* synthetic */ C0642v(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar, AbstractC1378g abstractC1378g) {
        this(nVar, y2, z2, z3, str, c1116j, aVar);
    }

    /* JADX INFO: renamed from: getExtendedTouchPadding-hWWAJMo, reason: not valid java name */
    private final long m1663getExtendedTouchPaddinghWWAJMo(long j2) {
        long jMo789toSizeXkaWNTQ = AbstractC1009p.requireDensity(this).mo789toSizeXkaWNTQ(((W1) AbstractC1003m.currentValueOf(this, L0.getLocalViewConfiguration())).mo3975getMinimumTouchTargetSizeMYxV2XQ());
        float fMax = Math.max(0.0f, Float.intBitsToFloat((int) (jMo789toSizeXkaWNTQ >> 32)) - ((int) (j2 >> 32))) / 2.0f;
        return J.l.m110constructorimpl((((long) Float.floatToRawIntBits(Math.max(0.0f, Float.intBitsToFloat((int) (jMo789toSizeXkaWNTQ & 4294967295L)) - ((int) (j2 & 4294967295L))) / 2.0f)) & 4294967295L) | (Float.floatToRawIntBits(fMax) << 32));
    }

    private static /* synthetic */ void isSuspendingPointerInputEnabled$annotations() {
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    public androidx.compose.ui.input.pointer.Z createPointerInputNodeIfNeeded() {
        if (this.isSuspendingPointerInputEnabled) {
            return androidx.compose.ui.input.pointer.X.SuspendingPointerInputModifierNode(new a());
        }
        return null;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public void onCancelPointerInput() {
        super.onCancelPointerInput();
        if (this.downEvent != null) {
            this.downEvent = null;
            handlePressInteractionCancel();
        }
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    /* JADX INFO: renamed from: onClickKeyDownEvent-ZmokQxo */
    public final boolean mo711onClickKeyDownEventZmokQxo(KeyEvent keyEvent) {
        return false;
    }

    @Override // androidx.compose.foundation.AbstractC0365b
    /* JADX INFO: renamed from: onClickKeyUpEvent-ZmokQxo */
    public final boolean mo712onClickKeyUpEventZmokQxo(KeyEvent keyEvent) {
        getOnClick().invoke();
        return true;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: onPointerEvent-H0pRuoY */
    public void mo698onPointerEventH0pRuoY(C0918p c0918p, androidx.compose.ui.input.pointer.r rVar, long j2) {
        super.mo698onPointerEventH0pRuoY(c0918p, rVar, j2);
        if (this.isSuspendingPointerInputEnabled) {
            return;
        }
        int i2 = 0;
        if (rVar != androidx.compose.ui.input.pointer.r.Main) {
            if (rVar != androidx.compose.ui.input.pointer.r.Final || this.downEvent == null) {
                return;
            }
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            while (i2 < size) {
                androidx.compose.ui.input.pointer.C c2 = changes.get(i2);
                if (c2.isConsumed() && !c2.equals(this.downEvent)) {
                    this.downEvent = null;
                    handlePressInteractionCancel();
                    return;
                }
                i2++;
            }
            return;
        }
        androidx.compose.ui.input.pointer.C c3 = this.downEvent;
        if (c3 == null) {
            if (androidx.compose.foundation.gestures.g0.isChangedToDown$default(c0918p, true, false, 2, null)) {
                androidx.compose.ui.input.pointer.C c4 = c0918p.getChanges().get(0);
                c4.consume();
                this.downEvent = c4;
                if (getEnabled()) {
                    m710handlePressInteractionStartk4lQ0M(c4.m3659getPositionF1C5BW0());
                    return;
                }
                return;
            }
            return;
        }
        List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
        int size2 = changes2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            if (!AbstractC0919q.changedToUp(changes2.get(i3))) {
                long jM1663getExtendedTouchPaddinghWWAJMo = m1663getExtendedTouchPaddinghWWAJMo(j2);
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p.getChanges();
                int size3 = changes3.size();
                while (i2 < size3) {
                    androidx.compose.ui.input.pointer.C c5 = changes3.get(i2);
                    if (c5.isConsumed() || AbstractC0919q.m3770isOutOfBoundsjwHxaWs(c5, j2, jM1663getExtendedTouchPaddinghWWAJMo)) {
                        this.downEvent = null;
                        handlePressInteractionCancel();
                        return;
                    }
                    i2++;
                }
                return;
            }
        }
        c0918p.getChanges().get(0).consume();
        if (getEnabled()) {
            m709handlePressInteractionReleasek4lQ0M(c3.m3659getPositionF1C5BW0());
            getOnClick().invoke();
        }
        this.downEvent = null;
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    @Override // androidx.compose.foundation.AbstractC0365b, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    /* JADX INFO: renamed from: update-O2vRcR0, reason: not valid java name */
    public final void m1664updateO2vRcR0(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar) {
        m713updateCommonO2vRcR0(nVar, y2, z2, z3, str, c1116j, aVar);
    }

    private C0642v(androidx.compose.foundation.interaction.n nVar, Y y2, boolean z2, boolean z3, String str, C1116j c1116j, h1.a aVar) {
        super(nVar, y2, z2, z3, str, c1116j, aVar, null);
        this.isSuspendingPointerInputEnabled = (A.isDetectTapGesturesImmediateCoroutineDispatchEnabled && A.isNonSuspendingPointerInputInClickableEnabled) ? false : true;
    }
}
