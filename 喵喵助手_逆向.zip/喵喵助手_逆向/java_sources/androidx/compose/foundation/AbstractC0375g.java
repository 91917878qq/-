package androidx.compose.foundation;

import androidx.compose.ui.graphics.a1;
import androidx.compose.ui.graphics.j1;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: renamed from: androidx.compose.foundation.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0375g {

    /* JADX INFO: renamed from: androidx.compose.foundation.g$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $alpha$inlined;
        final /* synthetic */ androidx.compose.ui.graphics.P $brush$inlined;
        final /* synthetic */ j1 $shape$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(float f2, androidx.compose.ui.graphics.P p2, j1 j1Var) {
            super(1);
            this.$alpha$inlined = f2;
            this.$brush$inlined = p2;
            this.$shape$inlined = j1Var;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("background");
            c1065l1.getProperties().set("alpha", Float.valueOf(this.$alpha$inlined));
            c1065l1.getProperties().set("brush", this.$brush$inlined);
            c1065l1.getProperties().set("shape", this.$shape$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.g$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ long $color$inlined;
        final /* synthetic */ j1 $shape$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(long j2, j1 j1Var) {
            super(1);
            this.$color$inlined = j2;
            this.$shape$inlined = j1Var;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("background");
            c1065l1.setValue(androidx.compose.ui.graphics.Y.m3010boximpl(this.$color$inlined));
            c1065l1.getProperties().set("color", androidx.compose.ui.graphics.Y.m3010boximpl(this.$color$inlined));
            c1065l1.getProperties().set("shape", this.$shape$inlined);
        }
    }

    public static final androidx.compose.ui.x background(androidx.compose.ui.x xVar, androidx.compose.ui.graphics.P p2, j1 j1Var, float f2) {
        return xVar.then(new BackgroundElement(0L, p2, f2, j1Var, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(f2, p2, j1Var) : AbstractC1056i1.getNoInspectorInfo(), 1, null));
    }

    public static /* synthetic */ androidx.compose.ui.x background$default(androidx.compose.ui.x xVar, androidx.compose.ui.graphics.P p2, j1 j1Var, float f2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            j1Var = a1.getRectangleShape();
        }
        if ((i2 & 4) != 0) {
            f2 = 1.0f;
        }
        return background(xVar, p2, j1Var, f2);
    }

    /* JADX INFO: renamed from: background-bw27NRU, reason: not valid java name */
    public static final androidx.compose.ui.x m754backgroundbw27NRU(androidx.compose.ui.x xVar, long j2, j1 j1Var) {
        return xVar.then(new BackgroundElement(j2, null, 1.0f, j1Var, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new b(j2, j1Var) : AbstractC1056i1.getNoInspectorInfo(), 2, null));
    }

    /* JADX INFO: renamed from: background-bw27NRU$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m755backgroundbw27NRU$default(androidx.compose.ui.x xVar, long j2, j1 j1Var, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            j1Var = a1.getRectangleShape();
        }
        return m754backgroundbw27NRU(xVar, j2, j1Var);
    }
}
