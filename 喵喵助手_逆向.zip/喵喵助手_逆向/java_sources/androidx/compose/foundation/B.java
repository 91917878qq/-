package androidx.compose.foundation;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;

/* JADX INFO: loaded from: classes.dex */
public abstract class B {
    public static final boolean isSystemInDarkTheme(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1100791446, i2, -1, "androidx.compose.foundation.isSystemInDarkTheme (DarkTheme.kt:36)");
        }
        boolean z_isSystemInDarkTheme = C._isSystemInDarkTheme(interfaceC0768p, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return z_isSystemInDarkTheme;
    }
}
