package androidx.compose.foundation;

import android.view.ViewConfiguration;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public abstract class F {
    private static final double DecelMinusOne;
    private static final double DecelerationRate;
    private static final float GravityEarth = 9.80665f;
    private static final float InchesPerMeter = 39.37f;
    private static final float Inflection = 0.35f;
    private static final float PlatformFlingScrollFriction = ViewConfiguration.getScrollFriction();

    static {
        double dLog = Math.log(0.78d) / Math.log(0.9d);
        DecelerationRate = dLog;
        DecelMinusOne = dLog - 1.0d;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float flingDistance(InterfaceC1307d interfaceC1307d, float f2) {
        double density = interfaceC1307d.getDensity() * 386.0878f * 160.0f * 0.84f;
        double dAbs = Math.abs(f2) * Inflection;
        float f3 = PlatformFlingScrollFriction;
        return (float) (Math.exp((DecelerationRate / DecelMinusOne) * Math.log(dAbs / (((double) f3) * density))) * ((double) f3) * density);
    }
}
