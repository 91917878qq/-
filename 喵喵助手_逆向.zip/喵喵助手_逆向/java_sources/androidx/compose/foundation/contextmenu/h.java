package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.text.input.internal.selection.r;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1702b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ long f1703c;

    public /* synthetic */ h(long j2, int i2) {
        this.f1702b = i2;
        this.f1703c = j2;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1702b) {
            case 0:
                return e0.o.m5187boximpl(this.f1703c);
            case 1:
                return r.b.onDrag_3MmeM6k$lambda$1(this.f1703c);
            case 2:
                return r.c.onDrag_k_4lQ0M$lambda$2(this.f1703c);
            default:
                return r.c.onStart_k_4lQ0M$lambda$1(this.f1703c);
        }
    }
}
