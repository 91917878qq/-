package androidx.compose.foundation.contextmenu;

import G.v;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.snapshots.w;
import androidx.compose.ui.x;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public final class k {
    public static final int $stable = 0;
    private final w composables = Q1.mutableStateListOf();

    public static final class a implements h1.f {
        final /* synthetic */ boolean $enabled;
        final /* synthetic */ h1.e $label;
        final /* synthetic */ h1.f $leadingIcon;
        final /* synthetic */ x $modifier;
        final /* synthetic */ h1.a $onClick;

        public a(h1.e eVar, boolean z2, x xVar, h1.f fVar, h1.a aVar) {
            this.$label = eVar;
            this.$enabled = z2;
            this.$modifier = xVar;
            this.$leadingIcon = fVar;
            this.$onClick = aVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            invoke((e) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(e eVar, InterfaceC0768p interfaceC0768p, int i2) {
            if ((i2 & 6) == 0) {
                i2 |= interfaceC0768p.changed(eVar) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i2 & 19) != 18, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(424163756, i2, -1, "androidx.compose.foundation.contextmenu.ContextMenuScope.item.<anonymous> (ContextMenuUi.android.kt:290)");
            }
            String str = (String) this.$label.invoke(interfaceC0768p, 0);
            if (p1.i.a0(str)) {
                AbstractC1403e.throwIllegalStateException("Label must not be blank");
            }
            t.ContextMenuItem(str, this.$enabled, eVar, this.$modifier, this.$leadingIcon, this.$onClick, interfaceC0768p, (i2 << 6) & 896, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n Content$lambda$1(k kVar, e eVar, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        kVar.Content$foundation_release(eVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1));
        return U0.n.f1521a;
    }

    public static /* synthetic */ void item$default(k kVar, h1.e eVar, x xVar, boolean z2, h1.f fVar, h1.a aVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            xVar = x.Companion;
        }
        x xVar2 = xVar;
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        boolean z3 = z2;
        if ((i2 & 8) != 0) {
            fVar = null;
        }
        kVar.item(eVar, xVar2, z3, fVar, aVar);
    }

    public final void Content$foundation_release(e eVar, InterfaceC0768p interfaceC0768p, int i2) {
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1320309496);
        int i3 = (i2 & 6) == 0 ? (interfaceC0768pStartRestartGroup.changed(eVar) ? 4 : 2) | i2 : i2;
        if ((i2 & 48) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(this) ? 32 : 16;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1320309496, i3, -1, "androidx.compose.foundation.contextmenu.ContextMenuScope.Content (ContextMenuUi.android.kt:248)");
            }
            w wVar = this.composables;
            int size = wVar.size();
            for (int i4 = 0; i4 < size; i4++) {
                ((h1.f) wVar.get(i4)).invoke(eVar, interfaceC0768pStartRestartGroup, Integer.valueOf(i3 & 14));
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new G.s(this, eVar, i2, 10));
        }
    }

    public final void clear$foundation_release() {
        this.composables.clear();
    }

    public final void item(h1.e eVar, x xVar, boolean z2, h1.f fVar, h1.a aVar) {
        this.composables.add(v.composableLambdaInstance(424163756, true, new a(eVar, z2, xVar, fVar, aVar)));
    }

    public final void separator() {
        this.composables.add(androidx.compose.foundation.contextmenu.a.INSTANCE.m725getLambda$355168742$foundation_release());
    }
}
