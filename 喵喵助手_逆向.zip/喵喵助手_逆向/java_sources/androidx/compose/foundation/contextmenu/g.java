package androidx.compose.foundation.contextmenu;

/* JADX INFO: loaded from: classes.dex */
public final class g {
    public static final g INSTANCE = new g();

    private g() {
    }
}
