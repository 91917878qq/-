package androidx.compose.foundation.contextmenu;

import androidx.compose.ui.window.u;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class i implements u {
    public static final int $stable = 0;
    private final h1.a anchorPositionBlock;
    private final h1.e onPositionCalculated;

    public /* synthetic */ i(long j2, h1.e eVar, AbstractC1378g abstractC1378g) {
        this(j2, eVar);
    }

    @Override // androidx.compose.ui.window.u
    /* JADX INFO: renamed from: calculatePosition-llwVHH4, reason: not valid java name */
    public long mo731calculatePositionllwVHH4(e0.q qVar, long j2, e0.u uVar, long j3) {
        long jM5205unboximpl = ((e0.o) this.anchorPositionBlock.invoke()).m5205unboximpl();
        long jM5190constructorimpl = e0.o.m5190constructorimpl((((long) j.alignPopupAxis(e0.o.m5196getXimpl(jM5205unboximpl) + qVar.getLeft(), (int) (j3 >> 32), (int) (j2 >> 32), uVar == e0.u.Ltr)) << 32) | (4294967295L & ((long) j.alignPopupAxis$default(e0.o.m5197getYimpl(jM5205unboximpl) + qVar.getTop(), (int) (j3 & 4294967295L), (int) (j2 & 4294967295L), false, 8, null))));
        h1.e eVar = this.onPositionCalculated;
        if (eVar != null) {
            eVar.invoke(e0.o.m5187boximpl(jM5205unboximpl), e0.r.m5229IntRectVbeCjmY(jM5190constructorimpl, j3));
        }
        return jM5190constructorimpl;
    }

    public i(h1.a aVar, h1.e eVar) {
        this.anchorPositionBlock = aVar;
        this.onPositionCalculated = eVar;
    }

    public /* synthetic */ i(h1.a aVar, h1.e eVar, int i2, AbstractC1378g abstractC1378g) {
        this(aVar, (i2 & 2) != 0 ? null : eVar);
    }

    public /* synthetic */ i(long j2, h1.e eVar, int i2, AbstractC1378g abstractC1378g) {
        this(j2, (i2 & 2) != 0 ? null : eVar, null);
    }

    private i(long j2, h1.e eVar) {
        this(new h(j2, 0), eVar);
    }
}
