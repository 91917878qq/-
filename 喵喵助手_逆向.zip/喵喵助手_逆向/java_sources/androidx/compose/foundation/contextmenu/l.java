package androidx.compose.foundation.contextmenu;

import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.graphics.h1;
import androidx.compose.ui.text.L;
import androidx.compose.ui.text.font.AbstractC1144u;
import androidx.compose.ui.text.font.I;
import androidx.compose.ui.text.font.J;
import androidx.compose.ui.text.font.N;
import androidx.compose.ui.text.l0;
import androidx.compose.ui.text.style.v;
import e0.C1311h;
import e0.x;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class l {
    public static final int $stable = 0;
    private static final float DividerVerticalPadding;
    private static final float VerticalPadding;
    public static final l INSTANCE = new l();
    private static final float ContainerWidthMin = C1311h.m5076constructorimpl(112);
    private static final float ContainerWidthMax = C1311h.m5076constructorimpl(280);
    private static final float ListItemHeight = C1311h.m5076constructorimpl(48);
    private static final float MenuContainerElevation = C1311h.m5076constructorimpl(3);
    private static final float CornerRadius = C1311h.m5076constructorimpl(4);
    private static final InterfaceC0823f LabelVerticalTextAlignment = InterfaceC0849g.Companion.getCenterVertically();
    private static final int LabelHorizontalTextAlignment = androidx.compose.ui.text.style.j.Companion.m4872getStarte0LSkKk();
    private static final float HorizontalPadding = C1311h.m5076constructorimpl(12);
    private static final float IconSize = C1311h.m5076constructorimpl(24);
    private static final float DividerHeight = C1311h.m5076constructorimpl(1);
    private static final long FontSize = x.getSp(14);
    private static final N FontWeight = N.Companion.getMedium();
    private static final long LineHeight = x.getSp(20);
    private static final long LetterSpacing = x.getSp(0.1f);

    static {
        float f2 = 8;
        VerticalPadding = C1311h.m5076constructorimpl(f2);
        DividerVerticalPadding = C1311h.m5076constructorimpl(f2);
    }

    private l() {
    }

    /* JADX INFO: renamed from: getContainerWidthMax-D9Ej5fM, reason: not valid java name */
    public final float m732getContainerWidthMaxD9Ej5fM() {
        return ContainerWidthMax;
    }

    /* JADX INFO: renamed from: getContainerWidthMin-D9Ej5fM, reason: not valid java name */
    public final float m733getContainerWidthMinD9Ej5fM() {
        return ContainerWidthMin;
    }

    /* JADX INFO: renamed from: getCornerRadius-D9Ej5fM, reason: not valid java name */
    public final float m734getCornerRadiusD9Ej5fM() {
        return CornerRadius;
    }

    /* JADX INFO: renamed from: getDividerHeight-D9Ej5fM, reason: not valid java name */
    public final float m735getDividerHeightD9Ej5fM() {
        return DividerHeight;
    }

    /* JADX INFO: renamed from: getDividerVerticalPadding-D9Ej5fM, reason: not valid java name */
    public final float m736getDividerVerticalPaddingD9Ej5fM() {
        return DividerVerticalPadding;
    }

    /* JADX INFO: renamed from: getFontSize-XSAIIZE, reason: not valid java name */
    public final long m737getFontSizeXSAIIZE() {
        return FontSize;
    }

    public final N getFontWeight() {
        return FontWeight;
    }

    /* JADX INFO: renamed from: getHorizontalPadding-D9Ej5fM, reason: not valid java name */
    public final float m738getHorizontalPaddingD9Ej5fM() {
        return HorizontalPadding;
    }

    /* JADX INFO: renamed from: getIconSize-D9Ej5fM, reason: not valid java name */
    public final float m739getIconSizeD9Ej5fM() {
        return IconSize;
    }

    /* JADX INFO: renamed from: getLabelHorizontalTextAlignment-e0LSkKk, reason: not valid java name */
    public final int m740getLabelHorizontalTextAlignmente0LSkKk() {
        return LabelHorizontalTextAlignment;
    }

    public final InterfaceC0823f getLabelVerticalTextAlignment() {
        return LabelVerticalTextAlignment;
    }

    /* JADX INFO: renamed from: getLetterSpacing-XSAIIZE, reason: not valid java name */
    public final long m741getLetterSpacingXSAIIZE() {
        return LetterSpacing;
    }

    /* JADX INFO: renamed from: getLineHeight-XSAIIZE, reason: not valid java name */
    public final long m742getLineHeightXSAIIZE() {
        return LineHeight;
    }

    /* JADX INFO: renamed from: getListItemHeight-D9Ej5fM, reason: not valid java name */
    public final float m743getListItemHeightD9Ej5fM() {
        return ListItemHeight;
    }

    /* JADX INFO: renamed from: getMenuContainerElevation-D9Ej5fM, reason: not valid java name */
    public final float m744getMenuContainerElevationD9Ej5fM() {
        return MenuContainerElevation;
    }

    /* JADX INFO: renamed from: getVerticalPadding-D9Ej5fM, reason: not valid java name */
    public final float m745getVerticalPaddingD9Ej5fM() {
        return VerticalPadding;
    }

    /* JADX INFO: renamed from: textStyle-8_81llA, reason: not valid java name */
    public final l0 m746textStyle8_81llA(long j2) {
        int i2 = LabelHorizontalTextAlignment;
        return new l0(j2, FontSize, FontWeight, (I) null, (J) null, (AbstractC1144u) null, (String) null, LetterSpacing, (androidx.compose.ui.text.style.a) null, (androidx.compose.ui.text.style.r) null, (b0.e) null, 0L, (androidx.compose.ui.text.style.k) null, (h1) null, (androidx.compose.ui.graphics.drawscope.h) null, i2, 0, LineHeight, (androidx.compose.ui.text.style.t) null, (L) null, (androidx.compose.ui.text.style.h) null, 0, 0, (v) null, 16613240, (AbstractC1378g) null);
    }
}
