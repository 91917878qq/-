package androidx.compose.foundation.contextmenu;

/* JADX INFO: loaded from: classes.dex */
public abstract class j {
    private static final int alignEndEdges(int i2, int i3, boolean z2) {
        return alignStartEdges(i2, i3, !z2);
    }

    public static final int alignPopupAxis(int i2, int i3, int i4, boolean z2) {
        return i3 >= i4 ? alignStartEdges(i3, i4, z2) : popupFitsBetweenPositionAndEndEdge(i2, i3, i4, z2) ? alignPopupStartEdgeToPosition(i2, i3, z2) : popupFitsBetweenPositionAndStartEdge(i2, i3, i4, z2) ? alignPopupEndEdgeToPosition(i2, i3, z2) : alignEndEdges(i3, i4, z2);
    }

    public static /* synthetic */ int alignPopupAxis$default(int i2, int i3, int i4, boolean z2, int i5, Object obj) {
        if ((i5 & 8) != 0) {
            z2 = true;
        }
        return alignPopupAxis(i2, i3, i4, z2);
    }

    private static final int alignPopupEndEdgeToPosition(int i2, int i3, boolean z2) {
        return alignPopupStartEdgeToPosition(i2, i3, !z2);
    }

    private static final int alignPopupStartEdgeToPosition(int i2, int i3, boolean z2) {
        return z2 ? i2 : i2 - i3;
    }

    private static final int alignStartEdges(int i2, int i3, boolean z2) {
        if (z2) {
            return 0;
        }
        return i3 - i2;
    }

    private static final boolean popupFitsBetweenPositionAndEndEdge(int i2, int i3, int i4, boolean z2) {
        return popupFitsBetweenPositionAndStartEdge(i2, i3, i4, !z2);
    }

    private static final boolean popupFitsBetweenPositionAndStartEdge(int i2, int i3, int i4, boolean z2) {
        if (z2) {
            if (i3 > i2) {
                return false;
            }
        } else if (i4 - i3 <= i2) {
            return false;
        }
        return true;
    }
}
