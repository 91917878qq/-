package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.text.AbstractC0600s;
import androidx.compose.foundation.text.V;
import androidx.compose.foundation.text.input.internal.AbstractC0548d0;
import u1.x;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class r implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1724b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f1725c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1726d;

    public /* synthetic */ r(int i2, boolean z2, Object obj) {
        this.f1724b = i2;
        this.f1725c = z2;
        this.f1726d = obj;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1724b) {
            case 0:
                return t.ContextMenuItem$lambda$5$lambda$4(this.f1725c, (h1.a) this.f1726d);
            case 1:
                return AbstractC0600s.BasicTextField$lambda$15$lambda$14(this.f1725c, (x) this.f1726d);
            default:
                return V.CoreTextField$lambda$38$lambda$37(this.f1725c, (AbstractC0548d0) this.f1726d);
        }
    }
}
