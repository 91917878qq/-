package androidx.compose.foundation.contextmenu;

import androidx.compose.runtime.B0;
import androidx.compose.runtime.V1;
import kotlin.jvm.internal.AbstractC1378g;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    public static final int $stable = 0;
    private final B0 status$delegate;

    public static abstract class a {
        public static final int $stable = 0;

        /* JADX INFO: renamed from: androidx.compose.foundation.contextmenu.m$a$a, reason: collision with other inner class name */
        public static final class C0025a extends a {
            public static final int $stable = 0;
            public static final C0025a INSTANCE = new C0025a();

            private C0025a() {
                super(null);
            }

            public String toString() {
                return "Closed";
            }
        }

        public static final class b extends a {
            public static final int $stable = 0;
            private final long offset;

            public /* synthetic */ b(long j2, AbstractC1378g abstractC1378g) {
                this(j2);
            }

            public boolean equals(Object obj) {
                if (obj == this) {
                    return true;
                }
                if (obj instanceof b) {
                    return J.f.m47equalsimpl0(this.offset, ((b) obj).offset);
                }
                return false;
            }

            /* JADX INFO: renamed from: getOffset-F1C5BW0, reason: not valid java name */
            public final long m747getOffsetF1C5BW0() {
                return this.offset;
            }

            public int hashCode() {
                return J.f.m52hashCodeimpl(this.offset);
            }

            public String toString() {
                return "Open(offset=" + ((Object) J.f.m58toStringimpl(this.offset)) + ')';
            }

            private b(long j2) {
                super(null);
                this.offset = j2;
                if ((j2 & 9223372034707292159L) != 9205357640488583168L) {
                    return;
                }
                AbstractC1403e.throwIllegalStateException("ContextMenuState.Status should never be open with an unspecified offset. Use ContextMenuState.Status.Closed instead.");
            }
        }

        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        private a() {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public m() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof m) {
            return kotlin.jvm.internal.o.a(((m) obj).getStatus(), getStatus());
        }
        return false;
    }

    public final a getStatus() {
        return (a) this.status$delegate.getValue();
    }

    public int hashCode() {
        return getStatus().hashCode();
    }

    public final void setStatus(a aVar) {
        this.status$delegate.setValue(aVar);
    }

    public String toString() {
        return "ContextMenuState(status=" + getStatus() + ')';
    }

    public m(a aVar) {
        this.status$delegate = V1.mutableStateOf$default(aVar, null, 2, null);
    }

    public /* synthetic */ m(a aVar, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? a.C0025a.INSTANCE : aVar);
    }
}
