package androidx.compose.foundation.contextmenu;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import androidx.compose.foundation.AbstractC0375g;
import androidx.compose.foundation.AbstractC0641u;
import androidx.compose.foundation.layout.AbstractC0413c0;
import androidx.compose.foundation.layout.AbstractC0430l;
import androidx.compose.foundation.layout.AbstractC0443v;
import androidx.compose.foundation.layout.C0418f;
import androidx.compose.foundation.layout.C0439q;
import androidx.compose.foundation.layout.C0446y;
import androidx.compose.foundation.layout.InterfaceC0422h;
import androidx.compose.foundation.layout.InterfaceC0445x;
import androidx.compose.foundation.layout.Q;
import androidx.compose.foundation.layout.T;
import androidx.compose.foundation.layout.r0;
import androidx.compose.foundation.layout.v0;
import androidx.compose.foundation.layout.x0;
import androidx.compose.foundation.text.E0;
import androidx.compose.foundation.text.G;
import androidx.compose.foundation.w0;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.F;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.h2;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.draw.u;
import androidx.compose.ui.graphics.AbstractC0851a0;
import androidx.compose.ui.graphics.InterfaceC0859e0;
import androidx.compose.ui.graphics.Y;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.window.v;
import androidx.compose.ui.x;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class t {
    private static final e DefaultContextMenuColors;
    private static final v DefaultPopupProperties = new v(true, false, false, false, 14, (AbstractC1378g) null);
    private static final float DisabledAlpha = 0.38f;

    public static final class a implements h1.f {
        final /* synthetic */ e $colors;
        final /* synthetic */ h1.c $contextMenuBuilderBlock;

        public a(h1.c cVar, e eVar) {
            this.$contextMenuBuilderBlock = cVar;
            this.$colors = eVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            invoke((InterfaceC0445x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0445x interfaceC0445x, InterfaceC0768p interfaceC0768p, int i2) {
            if (!interfaceC0768p.shouldExecute((i2 & 17) != 16, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(860259975, i2, -1, "androidx.compose.foundation.contextmenu.ContextMenuColumnBuilder.<anonymous> (ContextMenuUi.android.kt:143)");
            }
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new k();
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            k kVar = (k) objRememberedValue;
            h1.c cVar = this.$contextMenuBuilderBlock;
            e eVar = this.$colors;
            kVar.clear$foundation_release();
            cVar.invoke(kVar);
            kVar.Content$foundation_release(eVar, interfaceC0768p, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    public static final class b implements h1.e {
        final /* synthetic */ e $colors;
        final /* synthetic */ h1.c $contextMenuBuilderBlock;
        final /* synthetic */ x $modifier;

        public b(x xVar, e eVar, h1.c cVar) {
            this.$modifier = xVar;
            this.$colors = eVar;
            this.$contextMenuBuilderBlock = cVar;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            if (!interfaceC0768p.shouldExecute((i2 & 3) != 2, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(795909757, i2, -1, "androidx.compose.foundation.contextmenu.ContextMenuPopup.<anonymous> (ContextMenuUi.android.kt:132)");
            }
            t.ContextMenuColumnBuilder(this.$modifier, this.$colors, this.$contextMenuBuilderBlock, interfaceC0768p, 0, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    static {
        Y.a aVar = Y.Companion;
        DefaultContextMenuColors = new e(aVar.m3057getWhite0d7_KjU(), aVar.m3046getBlack0d7_KjU(), aVar.m3046getBlack0d7_KjU(), Y.m3019copywmQWz5c$default(aVar.m3046getBlack0d7_KjU(), 0.38f, 0.0f, 0.0f, 0.0f, 14, null), Y.m3019copywmQWz5c$default(aVar.m3046getBlack0d7_KjU(), 0.38f, 0.0f, 0.0f, 0.0f, 14, null), null);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0151  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x015b  */
    /* JADX WARN: Removed duplicated region for block: B:66:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ContextMenuColumn(e eVar, x xVar, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        x xVar2;
        x xVar3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(621449936);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(eVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i5 = i3 & 2;
        if (i5 == 0) {
            if ((i2 & 48) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 32 : 16;
            }
            if ((i3 & 4) == 0) {
                i4 |= 384;
            } else if ((i2 & 384) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 256 : 128;
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 147) == 146, i4 & 1)) {
                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                xVar3 = xVar2;
            } else {
                xVar3 = i5 != 0 ? x.Companion : xVar2;
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventStart(621449936, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuColumn (ContextMenuUi.android.kt:158)");
                }
                l lVar = l.INSTANCE;
                x xVarVerticalScroll$default = w0.verticalScroll$default(AbstractC0413c0.m961paddingVpY3zN4$default(Q.width(AbstractC0375g.m755backgroundbw27NRU$default(u.m2708shadows4CzXII$default(xVar3, lVar.m744getMenuContainerElevationD9Ej5fM(), q.i.m5365RoundedCornerShape0680j_4(lVar.m734getCornerRadiusD9Ej5fM()), false, 0L, 0L, 28, null), eVar.m726getBackgroundColor0d7_KjU(), null, 2, null), T.Max), 0.0f, lVar.m745getVerticalPaddingD9Ej5fM(), 1, null), w0.rememberScrollState(0, interfaceC0768pStartRestartGroup, 0, 1), false, null, false, 14, null);
                int i6 = (i4 << 3) & 7168;
                InterfaceC0933c0 interfaceC0933c0ColumnMeasurePolicy = AbstractC0443v.columnMeasurePolicy(C0418f.INSTANCE.getTop(), InterfaceC0849g.Companion.getStart(), interfaceC0768pStartRestartGroup, 0);
                int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
                F currentCompositionLocalMap = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
                x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVarVerticalScroll$default);
                C0997j c0997j = InterfaceC0999k.Companion;
                h1.a constructor = c0997j.getConstructor();
                if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                    AbstractC0750j.invalidApplier();
                }
                interfaceC0768pStartRestartGroup.startReusableNode();
                if (interfaceC0768pStartRestartGroup.getInserting()) {
                    interfaceC0768pStartRestartGroup.createNode(constructor);
                } else {
                    interfaceC0768pStartRestartGroup.useNode();
                }
                InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
                h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0ColumnMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
                if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                    D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
                }
                h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
                fVar.invoke(C0446y.INSTANCE, interfaceC0768pStartRestartGroup, Integer.valueOf(((i6 >> 6) & 112) | 6));
                interfaceC0768pStartRestartGroup.endNode();
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventEnd();
                }
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup == null) {
                interfaceC0811x1EndRestartGroup.updateScope(new o(eVar, xVar3, fVar, i2, i3));
                return;
            }
            return;
        }
        i4 |= 48;
        xVar2 = xVar;
        if ((i3 & 4) == 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 147) == 146, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuColumn$lambda$3(e eVar, x xVar, h1.f fVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuColumn(eVar, xVar, fVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    public static final void ContextMenuColumnBuilder(x xVar, e eVar, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1430784946);
        int i5 = i3 & 1;
        if (i5 != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i6 = i3 & 2;
        if (i6 != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(eVar) ? 32 : 16;
        }
        if ((i3 & 4) != 0) {
            i4 |= 384;
        } else if ((i2 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 256 : 128;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 147) != 146, i4 & 1)) {
            if (i5 != 0) {
                xVar = x.Companion;
            }
            if (i6 != 0) {
                eVar = DefaultContextMenuColors;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1430784946, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuColumnBuilder (ContextMenuUi.android.kt:141)");
            }
            ContextMenuColumn(eVar, xVar, G.v.rememberComposableLambda(860259975, true, new a(cVar, eVar), interfaceC0768pStartRestartGroup, 54), interfaceC0768pStartRestartGroup, ((i4 >> 3) & 14) | 384 | ((i4 << 3) & 112), 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        x xVar2 = xVar;
        e eVar2 = eVar;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new o(xVar2, eVar2, cVar, i2, i3));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuColumnBuilder$lambda$2(x xVar, e eVar, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuColumnBuilder(xVar, eVar, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX WARN: Removed duplicated region for block: B:134:0x02b3  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x02bf  */
    /* JADX WARN: Removed duplicated region for block: B:139:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x009e  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x00c7  */
    @SuppressLint({"ComposableLambdaParameterPosition"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ContextMenuItem(final String str, final boolean z2, final e eVar, x xVar, h1.f fVar, final h1.a aVar, InterfaceC0768p interfaceC0768p, final int i2, final int i3) {
        int i4;
        x xVar2;
        int i5;
        h1.f fVar2;
        InterfaceC0768p interfaceC0768p2;
        final x xVar3;
        final h1.f fVar3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1027365588);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(str) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(z2) ? 32 : 16;
        }
        if ((i3 & 4) != 0) {
            i4 |= 384;
        } else if ((i2 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(eVar) ? 256 : 128;
        }
        int i6 = i3 & 8;
        if (i6 != 0) {
            i4 |= 3072;
        } else {
            if ((i2 & 3072) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 2048 : 1024;
            }
            i5 = i3 & 16;
            if (i5 != 0) {
                if ((i2 & 24576) == 0) {
                    fVar2 = fVar;
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar2) ? 16384 : 8192;
                }
                if ((i3 & 32) != 0) {
                    i4 |= 196608;
                } else if ((i2 & 196608) == 0) {
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar) ? 131072 : 65536;
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) != 74898, i4 & 1)) {
                    x xVar4 = i6 != 0 ? x.Companion : xVar2;
                    if (i5 != 0) {
                        fVar2 = null;
                    }
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventStart(-1027365588, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuItem (ContextMenuUi.android.kt:196)");
                    }
                    l lVar = l.INSTANCE;
                    InterfaceC0823f labelVerticalTextAlignment = lVar.getLabelVerticalTextAlignment();
                    InterfaceC0422h interfaceC0422hM976spacedBy0680j_4 = C0418f.INSTANCE.m976spacedBy0680j_4(lVar.m738getHorizontalPaddingD9Ej5fM());
                    boolean z3 = ((i4 & 112) == 32) | ((458752 & i4) == 131072);
                    Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                    if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue = new r(0, z2, aVar);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    int i7 = i4;
                    h1.f fVar4 = fVar2;
                    x xVarM961paddingVpY3zN4$default = AbstractC0413c0.m961paddingVpY3zN4$default(x0.m1030sizeInqDBjuR0(x0.fillMaxWidth$default(AbstractC0641u.m1649clickableoSLSa3U$default(xVar4, z2, str, null, null, (h1.a) objRememberedValue, 12, null), 0.0f, 1, null), lVar.m733getContainerWidthMinD9Ej5fM(), lVar.m743getListItemHeightD9Ej5fM(), lVar.m732getContainerWidthMaxD9Ej5fM(), lVar.m743getListItemHeightD9Ej5fM()), lVar.m738getHorizontalPaddingD9Ej5fM(), 0.0f, 2, null);
                    InterfaceC0933c0 interfaceC0933c0RowMeasurePolicy = r0.rowMeasurePolicy(interfaceC0422hM976spacedBy0680j_4, labelVerticalTextAlignment, interfaceC0768pStartRestartGroup, 54);
                    int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
                    F currentCompositionLocalMap = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
                    x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVarM961paddingVpY3zN4$default);
                    C0997j c0997j = InterfaceC0999k.Companion;
                    h1.a constructor = c0997j.getConstructor();
                    if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                        AbstractC0750j.invalidApplier();
                    }
                    interfaceC0768pStartRestartGroup.startReusableNode();
                    if (interfaceC0768pStartRestartGroup.getInserting()) {
                        interfaceC0768pStartRestartGroup.createNode(constructor);
                    } else {
                        interfaceC0768pStartRestartGroup.useNode();
                    }
                    InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
                    h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0RowMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
                    if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                        D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
                    }
                    h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
                    v0 v0Var = v0.INSTANCE;
                    if (fVar4 == null) {
                        interfaceC0768pStartRestartGroup.startReplaceGroup(-1483499797);
                    } else {
                        interfaceC0768pStartRestartGroup.startReplaceGroup(-1483499796);
                        x xVarM1023requiredSizeInqDBjuR0$default = x0.m1023requiredSizeInqDBjuR0$default(x.Companion, lVar.m739getIconSizeD9Ej5fM(), 0.0f, lVar.m739getIconSizeD9Ej5fM(), lVar.m739getIconSizeD9Ej5fM(), 2, null);
                        InterfaceC0933c0 interfaceC0933c0MaybeCachedBoxMeasurePolicy = AbstractC0430l.maybeCachedBoxMeasurePolicy(InterfaceC0849g.Companion.getTopStart(), false);
                        int iHashCode2 = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
                        F currentCompositionLocalMap2 = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
                        x xVarMaterializeModifier2 = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVarM1023requiredSizeInqDBjuR0$default);
                        h1.a constructor2 = c0997j.getConstructor();
                        if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                            AbstractC0750j.invalidApplier();
                        }
                        interfaceC0768pStartRestartGroup.startReusableNode();
                        if (interfaceC0768pStartRestartGroup.getInserting()) {
                            interfaceC0768pStartRestartGroup.createNode(constructor2);
                        } else {
                            interfaceC0768pStartRestartGroup.useNode();
                        }
                        InterfaceC0768p interfaceC0768pM2592constructorimpl2 = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
                        h1.e eVarM2 = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl2, interfaceC0933c0MaybeCachedBoxMeasurePolicy, interfaceC0768pM2592constructorimpl2, currentCompositionLocalMap2);
                        if (interfaceC0768pM2592constructorimpl2.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            D0.d.z(eVarM2, iHashCode2, interfaceC0768pM2592constructorimpl2, iHashCode2);
                        }
                        h2.m2599setimpl(interfaceC0768pM2592constructorimpl2, xVarMaterializeModifier2, c0997j.getSetModifier());
                        C0439q c0439q = C0439q.INSTANCE;
                        fVar4.invoke(Y.m3010boximpl(z2 ? eVar.m729getIconColor0d7_KjU() : eVar.m727getDisabledIconColor0d7_KjU()), interfaceC0768pStartRestartGroup, 0);
                        interfaceC0768pStartRestartGroup.endNode();
                    }
                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                    interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                    G.m1174BasicTextRWo7tUw(str, v0Var.weight(x.Companion, 1.0f, true), lVar.m746textStyle8_81llA(z2 ? eVar.m730getTextColor0d7_KjU() : eVar.m728getDisabledTextColor0d7_KjU()), (h1.c) null, 0, false, 1, 0, (InterfaceC0859e0) null, (E0) null, interfaceC0768p2, (i7 & 14) | 1572864, 952);
                    interfaceC0768p2.endNode();
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventEnd();
                    }
                    fVar3 = fVar4;
                    xVar3 = xVar4;
                } else {
                    interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                    interfaceC0768p2.skipToGroupEnd();
                    xVar3 = xVar2;
                    fVar3 = fVar2;
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768p2.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                    interfaceC0811x1EndRestartGroup.updateScope(new h1.e() { // from class: androidx.compose.foundation.contextmenu.s
                        @Override // h1.e
                        public final Object invoke(Object obj, Object obj2) {
                            int iIntValue = ((Integer) obj2).intValue();
                            int i8 = i2;
                            int i9 = i3;
                            return t.ContextMenuItem$lambda$9(str, z2, eVar, xVar3, fVar3, aVar, i8, i9, (InterfaceC0768p) obj, iIntValue);
                        }
                    });
                    return;
                }
                return;
            }
            i4 |= 24576;
            fVar2 = fVar;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) != 74898, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768p2.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 16;
        if (i5 != 0) {
        }
        fVar2 = fVar;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) != 74898, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768p2.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuItem$lambda$5$lambda$4(boolean z2, h1.a aVar) {
        if (z2) {
            aVar.invoke();
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuItem$lambda$9(String str, boolean z2, e eVar, x xVar, h1.f fVar, h1.a aVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuItem(str, z2, eVar, xVar, fVar, aVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    public static final void ContextMenuPopup(androidx.compose.ui.window.u uVar, h1.a aVar, x xVar, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(712057293);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(uVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar) ? 32 : 16;
        }
        int i5 = i3 & 4;
        if (i5 != 0) {
            i4 |= 384;
        } else if ((i2 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(xVar) ? 256 : 128;
        }
        if ((i3 & 8) != 0) {
            i4 |= 3072;
        } else if ((i2 & 3072) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 2048 : 1024;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
            if (i5 != 0) {
                xVar = x.Companion;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(712057293, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuPopup (ContextMenuUi.android.kt:108)");
            }
            ContextMenuPopup(uVar, aVar, xVar, computeContextMenuColors(0, 0, interfaceC0768pStartRestartGroup, 0, 3), cVar, interfaceC0768pStartRestartGroup, (i4 & 1022) | ((i4 << 3) & 57344), 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        x xVar2 = xVar;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new p(uVar, aVar, xVar2, cVar, i2, i3));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuPopup$lambda$0(androidx.compose.ui.window.u uVar, h1.a aVar, x xVar, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuPopup(uVar, aVar, xVar, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuPopup$lambda$1(androidx.compose.ui.window.u uVar, h1.a aVar, x xVar, e eVar, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuPopup(uVar, aVar, xVar, eVar, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    public static final e computeContextMenuColors(int i2, int i3, InterfaceC0768p interfaceC0768p, int i4, int i5) {
        int i6 = (i5 & 1) != 0 ? R.style.Widget.PopupMenu : i2;
        int i7 = (i5 & 2) != 0 ? R.style.TextAppearance.Widget.PopupMenu.Large : i3;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1689505294, i4, -1, "androidx.compose.foundation.contextmenu.computeContextMenuColors (ContextMenuUi.android.kt:383)");
        }
        Context context = (Context) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalContext());
        boolean zChanged = interfaceC0768p.changed((Configuration) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalConfiguration())) | interfaceC0768p.changed(context);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            e eVar = DefaultContextMenuColors;
            long jM750resolveColorg2O1Hgs = m750resolveColorg2O1Hgs(context, i6, R.attr.colorBackground, eVar.m726getBackgroundColor0d7_KjU());
            ColorStateList colorStateListResolveColorStateList = resolveColorStateList(context, i7, R.attr.textColorPrimary);
            long jM749enabledColor4WTKRHQ = m749enabledColor4WTKRHQ(colorStateListResolveColorStateList, eVar.m730getTextColor0d7_KjU());
            long jM748disabledColor4WTKRHQ = m748disabledColor4WTKRHQ(colorStateListResolveColorStateList, eVar.m728getDisabledTextColor0d7_KjU());
            objRememberedValue = new e(jM750resolveColorg2O1Hgs, jM749enabledColor4WTKRHQ, jM749enabledColor4WTKRHQ, jM748disabledColor4WTKRHQ, jM748disabledColor4WTKRHQ, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        e eVar2 = (e) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return eVar2;
    }

    /* JADX INFO: renamed from: disabledColor-4WTKRHQ, reason: not valid java name */
    private static final long m748disabledColor4WTKRHQ(ColorStateList colorStateList, long j2) {
        int iM3074toArgb8_81llA = AbstractC0851a0.m3074toArgb8_81llA(j2);
        Integer numValueOf = colorStateList != null ? Integer.valueOf(colorStateList.getColorForState(new int[]{-16842910}, iM3074toArgb8_81llA)) : null;
        return (numValueOf == null || numValueOf.intValue() == iM3074toArgb8_81llA) ? j2 : AbstractC0851a0.Color(numValueOf.intValue());
    }

    /* JADX INFO: renamed from: enabledColor-4WTKRHQ, reason: not valid java name */
    private static final long m749enabledColor4WTKRHQ(ColorStateList colorStateList, long j2) {
        int iM3074toArgb8_81llA = AbstractC0851a0.m3074toArgb8_81llA(j2);
        Integer numValueOf = colorStateList != null ? Integer.valueOf(colorStateList.getColorForState(new int[]{R.attr.state_enabled}, iM3074toArgb8_81llA)) : null;
        return (numValueOf == null || numValueOf.intValue() == iM3074toArgb8_81llA) ? j2 : AbstractC0851a0.Color(numValueOf.intValue());
    }

    public static final e getDefaultContextMenuColors() {
        return DefaultContextMenuColors;
    }

    public static /* synthetic */ void getDefaultContextMenuColors$annotations() {
    }

    /* JADX INFO: renamed from: resolveColor-g2O1Hgs, reason: not valid java name */
    private static final long m750resolveColorg2O1Hgs(Context context, int i2, int i3, long j2) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i2, new int[]{i3});
        int iM3074toArgb8_81llA = AbstractC0851a0.m3074toArgb8_81llA(j2);
        int color = typedArrayObtainStyledAttributes.getColor(0, iM3074toArgb8_81llA);
        typedArrayObtainStyledAttributes.recycle();
        return color == iM3074toArgb8_81llA ? j2 : AbstractC0851a0.Color(color);
    }

    private static final ColorStateList resolveColorStateList(Context context, int i2, int i3) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i2, new int[]{i3});
        ColorStateList colorStateList = typedArrayObtainStyledAttributes.getColorStateList(0);
        typedArrayObtainStyledAttributes.recycle();
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:75:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ContextMenuPopup(final androidx.compose.ui.window.u uVar, final h1.a aVar, x xVar, final e eVar, final h1.c cVar, InterfaceC0768p interfaceC0768p, final int i2, final int i3) {
        int i4;
        x xVar2;
        final x xVar3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1447189339);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(uVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar) ? 32 : 16;
        }
        int i5 = i3 & 4;
        if (i5 == 0) {
            if ((i2 & 384) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
            }
            if ((i3 & 8) == 0) {
                i4 |= 3072;
            } else if ((i2 & 3072) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(eVar) ? 2048 : 1024;
            }
            if ((i3 & 16) == 0) {
                i4 |= 24576;
            } else if ((i2 & 24576) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 16384 : 8192;
            }
            if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 9363) == 9362, i4 & 1)) {
                x xVar4 = i5 != 0 ? x.Companion : xVar2;
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventStart(1447189339, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuPopup (ContextMenuUi.android.kt:126)");
                }
                androidx.compose.ui.window.d.Popup(uVar, aVar, DefaultPopupProperties, G.v.rememberComposableLambda(795909757, true, new b(xVar4, eVar, cVar), interfaceC0768pStartRestartGroup, 54), interfaceC0768pStartRestartGroup, (i4 & 14) | 3456 | (i4 & 112), 0);
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventEnd();
                }
                xVar3 = xVar4;
            } else {
                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                xVar3 = xVar2;
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup == null) {
                interfaceC0811x1EndRestartGroup.updateScope(new h1.e() { // from class: androidx.compose.foundation.contextmenu.q
                    @Override // h1.e
                    public final Object invoke(Object obj, Object obj2) {
                        int iIntValue = ((Integer) obj2).intValue();
                        int i6 = i2;
                        int i7 = i3;
                        return t.ContextMenuPopup$lambda$1(uVar, aVar, xVar3, eVar, cVar, i6, i7, (InterfaceC0768p) obj, iIntValue);
                    }
                });
                return;
            }
            return;
        }
        i4 |= 384;
        xVar2 = xVar;
        if ((i3 & 8) == 0) {
        }
        if ((i3 & 16) == 0) {
        }
        if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 9363) == 9362, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup == null) {
        }
    }
}
