package androidx.compose.foundation.contextmenu;

import O0.C0218m;
import androidx.compose.foundation.contextmenu.m;
import androidx.compose.ui.input.pointer.L;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.input.pointer.X;
import androidx.compose.ui.x;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    public static final class a implements PointerInputEventHandler {
        final /* synthetic */ h1.c $onOpenGesture;

        public a(h1.c cVar) {
            this.$onOpenGesture = cVar;
        }

        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
        public final Object invoke(L l2, Y0.c cVar) {
            Object objOnRightClickDown = androidx.compose.foundation.text.contextmenu.gestures.a.onRightClickDown(l2, this.$onOpenGesture, cVar);
            return objOnRightClickDown == Z0.a.f1616b ? objOnRightClickDown : U0.n.f1521a;
        }
    }

    public static final x contextMenuGestures(x xVar, m mVar) {
        return contextMenuGestures(xVar, new C0218m(mVar, 7));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n contextMenuGestures$lambda$0(m mVar, J.f fVar) {
        mVar.setStatus(new m.a.b(fVar.m60unboximpl(), null));
        return U0.n.f1521a;
    }

    public static final x contextMenuGestures(x xVar, h1.c cVar) {
        return X.pointerInput(xVar, g.INSTANCE, new a(cVar));
    }
}
