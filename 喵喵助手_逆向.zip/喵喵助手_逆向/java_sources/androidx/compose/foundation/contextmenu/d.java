package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.contextmenu.m;
import androidx.compose.foundation.layout.AbstractC0430l;
import androidx.compose.foundation.layout.C0439q;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.F;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.h2;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import androidx.compose.ui.x;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {
    /* JADX WARN: Removed duplicated region for block: B:26:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0110  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:81:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ContextMenu(final m mVar, final h1.a aVar, x xVar, final h1.c cVar, InterfaceC0768p interfaceC0768p, final int i2, final int i3) {
        int i4;
        int i5;
        x xVar2;
        final x xVar3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(645832757);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(mVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar) ? 32 : 16;
            }
            i5 = i3 & 4;
            if (i5 != 0) {
                if ((i2 & 384) == 0) {
                    xVar2 = xVar;
                    i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
                }
                if ((i3 & 8) != 0) {
                    i4 |= 3072;
                } else if ((i2 & 3072) == 0) {
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 2048 : 1024;
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
                    x xVar4 = i5 != 0 ? x.Companion : xVar2;
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventStart(645832757, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenu (ContextMenuArea.android.kt:73)");
                    }
                    m.a status = mVar.getStatus();
                    if (!(status instanceof m.a.b)) {
                        if (AbstractC0776s.isTraceInProgress()) {
                            AbstractC0776s.traceEventEnd();
                        }
                        InterfaceC0811x1 interfaceC0811x1EndRestartGroup2 = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup2 != null) {
                            final int i6 = 0;
                            final x xVar5 = xVar4;
                            interfaceC0811x1EndRestartGroup2.updateScope(new h1.e() { // from class: androidx.compose.foundation.contextmenu.b
                                @Override // h1.e
                                public final Object invoke(Object obj, Object obj2) {
                                    switch (i6) {
                                        case 0:
                                            int iIntValue = ((Integer) obj2).intValue();
                                            int i7 = i2;
                                            int i8 = i3;
                                            return d.ContextMenu$lambda$6(mVar, aVar, xVar5, cVar, i7, i8, (InterfaceC0768p) obj, iIntValue);
                                        default:
                                            int iIntValue2 = ((Integer) obj2).intValue();
                                            int i9 = i2;
                                            int i10 = i3;
                                            return d.ContextMenu$lambda$8(mVar, aVar, xVar5, cVar, i9, i10, (InterfaceC0768p) obj, iIntValue2);
                                    }
                                }
                            });
                            return;
                        }
                        return;
                    }
                    m.a.b bVar = (m.a.b) status;
                    boolean zChanged = interfaceC0768pStartRestartGroup.changed(bVar);
                    Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                    if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue = new i(e0.p.m5213roundk4lQ0M(bVar.m747getOffsetF1C5BW0()), (h1.e) null, 2, (AbstractC1378g) null);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    t.ContextMenuPopup((i) objRememberedValue, aVar, xVar4, cVar, interfaceC0768pStartRestartGroup, i4 & 8176, 0);
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventEnd();
                    }
                    xVar3 = xVar4;
                } else {
                    interfaceC0768pStartRestartGroup.skipToGroupEnd();
                    xVar3 = xVar2;
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                    final int i7 = 1;
                    interfaceC0811x1EndRestartGroup.updateScope(new h1.e() { // from class: androidx.compose.foundation.contextmenu.b
                        @Override // h1.e
                        public final Object invoke(Object obj, Object obj2) {
                            switch (i7) {
                                case 0:
                                    int iIntValue = ((Integer) obj2).intValue();
                                    int i72 = i2;
                                    int i8 = i3;
                                    return d.ContextMenu$lambda$6(mVar, aVar, xVar3, cVar, i72, i8, (InterfaceC0768p) obj, iIntValue);
                                default:
                                    int iIntValue2 = ((Integer) obj2).intValue();
                                    int i9 = i2;
                                    int i10 = i3;
                                    return d.ContextMenu$lambda$8(mVar, aVar, xVar3, cVar, i9, i10, (InterfaceC0768p) obj, iIntValue2);
                            }
                        }
                    });
                    return;
                }
                return;
            }
            i4 |= 384;
            xVar2 = xVar;
            if ((i3 & 8) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 4;
        if (i5 != 0) {
        }
        xVar2 = xVar;
        if ((i3 & 8) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenu$lambda$6(m mVar, h1.a aVar, x xVar, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenu(mVar, aVar, xVar, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenu$lambda$8(m mVar, h1.a aVar, x xVar, h1.c cVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenu(mVar, aVar, xVar, cVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }

    /* JADX WARN: Removed duplicated region for block: B:127:0x01f9  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x0204  */
    /* JADX WARN: Removed duplicated region for block: B:132:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x009e  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00e7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ContextMenuArea(final m mVar, final h1.a aVar, final h1.c cVar, x xVar, boolean z2, h1.a aVar2, final h1.e eVar, InterfaceC0768p interfaceC0768p, final int i2, final int i3) {
        int i4;
        x xVar2;
        int i5;
        boolean z3;
        int i6;
        h1.a aVar3;
        final h1.a aVar4;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        h1.a aVar5;
        x xVarContextMenuGestures;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1877873755);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(mVar) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar) ? 32 : 16;
        }
        if ((i3 & 4) != 0) {
            i4 |= 384;
        } else if ((i2 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 256 : 128;
        }
        int i7 = i3 & 8;
        if (i7 != 0) {
            i4 |= 3072;
        } else {
            if ((i2 & 3072) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 2048 : 1024;
            }
            i5 = i3 & 16;
            if (i5 != 0) {
                if ((i2 & 24576) == 0) {
                    z3 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 16384 : 8192;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= 196608;
                    aVar3 = aVar2;
                } else {
                    aVar3 = aVar2;
                    if ((i2 & 196608) == 0) {
                        i4 |= interfaceC0768pStartRestartGroup.changedInstance(aVar3) ? 131072 : 65536;
                    }
                }
                if ((i3 & 64) != 0) {
                    i4 |= 1572864;
                } else if ((i2 & 1572864) == 0) {
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(eVar) ? 1048576 : 524288;
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                    if (i7 != 0) {
                        xVar2 = x.Companion;
                    }
                    if (i5 != 0) {
                        z3 = true;
                    }
                    if (i6 != 0) {
                        Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                        if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                            objRememberedValue = new F0.a(12);
                            interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                        }
                        aVar5 = (h1.a) objRememberedValue;
                    } else {
                        aVar5 = aVar3;
                    }
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventStart(1877873755, i4, -1, "androidx.compose.foundation.contextmenu.ContextMenuArea (ContextMenuArea.android.kt:46)");
                    }
                    if (z3) {
                        interfaceC0768pStartRestartGroup.startReplaceGroup(1788348907);
                        boolean z4 = ((i4 & 14) == 4) | ((458752 & i4) == 131072);
                        Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                            objRememberedValue2 = new M0.m(14, aVar5, mVar);
                            interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                        }
                        xVarContextMenuGestures = f.contextMenuGestures(xVar2, (h1.c) objRememberedValue2);
                        interfaceC0768pStartRestartGroup.endReplaceGroup();
                    } else {
                        interfaceC0768pStartRestartGroup.startReplaceGroup(1788505767);
                        interfaceC0768pStartRestartGroup.endReplaceGroup();
                        xVarContextMenuGestures = xVar2;
                    }
                    InterfaceC0933c0 interfaceC0933c0MaybeCachedBoxMeasurePolicy = AbstractC0430l.maybeCachedBoxMeasurePolicy(InterfaceC0849g.Companion.getTopStart(), true);
                    int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
                    F currentCompositionLocalMap = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
                    x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVarContextMenuGestures);
                    C0997j c0997j = InterfaceC0999k.Companion;
                    h1.a constructor = c0997j.getConstructor();
                    if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                        AbstractC0750j.invalidApplier();
                    }
                    interfaceC0768pStartRestartGroup.startReusableNode();
                    if (interfaceC0768pStartRestartGroup.getInserting()) {
                        interfaceC0768pStartRestartGroup.createNode(constructor);
                    } else {
                        interfaceC0768pStartRestartGroup.useNode();
                    }
                    InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
                    h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0MaybeCachedBoxMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
                    if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                        D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
                    }
                    h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
                    C0439q c0439q = C0439q.INSTANCE;
                    eVar.invoke(interfaceC0768pStartRestartGroup, Integer.valueOf((i4 >> 18) & 14));
                    ContextMenu(mVar, aVar, null, cVar, interfaceC0768pStartRestartGroup, (i4 & 126) | ((i4 << 3) & 7168), 4);
                    interfaceC0768pStartRestartGroup.endNode();
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventEnd();
                    }
                    aVar4 = aVar5;
                } else {
                    interfaceC0768pStartRestartGroup.skipToGroupEnd();
                    aVar4 = aVar3;
                }
                final x xVar3 = xVar2;
                final boolean z5 = z3;
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                    interfaceC0811x1EndRestartGroup.updateScope(new h1.e() { // from class: androidx.compose.foundation.contextmenu.c
                        @Override // h1.e
                        public final Object invoke(Object obj, Object obj2) {
                            int iIntValue = ((Integer) obj2).intValue();
                            int i8 = i2;
                            int i9 = i3;
                            return d.ContextMenuArea$lambda$5(mVar, aVar, cVar, xVar3, z5, aVar4, eVar, i8, i9, (InterfaceC0768p) obj, iIntValue);
                        }
                    });
                    return;
                }
                return;
            }
            i4 |= 24576;
            z3 = z2;
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            if ((i3 & 64) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
            }
            final x xVar32 = xVar2;
            final boolean z52 = z3;
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 16;
        if (i5 != 0) {
        }
        z3 = z2;
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        if ((i3 & 64) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
        }
        final x xVar322 = xVar2;
        final boolean z522 = z3;
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuArea$lambda$3$lambda$2(h1.a aVar, m mVar, J.f fVar) {
        aVar.invoke();
        mVar.setStatus(new m.a.b(fVar.m60unboximpl(), null));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n ContextMenuArea$lambda$5(m mVar, h1.a aVar, h1.c cVar, x xVar, boolean z2, h1.a aVar2, h1.e eVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        ContextMenuArea(mVar, aVar, cVar, xVar, z2, aVar2, eVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }
}
