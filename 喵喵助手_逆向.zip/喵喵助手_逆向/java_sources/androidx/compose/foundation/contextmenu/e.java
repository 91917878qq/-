package androidx.compose.foundation.contextmenu;

import androidx.compose.ui.graphics.Y;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final int $stable = 0;
    private final long backgroundColor;
    private final long disabledIconColor;
    private final long disabledTextColor;
    private final long iconColor;
    private final long textColor;

    public /* synthetic */ e(long j2, long j3, long j4, long j5, long j6, AbstractC1378g abstractC1378g) {
        this(j2, j3, j4, j5, j6);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return Y.m3021equalsimpl0(this.backgroundColor, eVar.backgroundColor) && Y.m3021equalsimpl0(this.textColor, eVar.textColor) && Y.m3021equalsimpl0(this.iconColor, eVar.iconColor) && Y.m3021equalsimpl0(this.disabledTextColor, eVar.disabledTextColor) && Y.m3021equalsimpl0(this.disabledIconColor, eVar.disabledIconColor);
    }

    /* JADX INFO: renamed from: getBackgroundColor-0d7_KjU, reason: not valid java name */
    public final long m726getBackgroundColor0d7_KjU() {
        return this.backgroundColor;
    }

    /* JADX INFO: renamed from: getDisabledIconColor-0d7_KjU, reason: not valid java name */
    public final long m727getDisabledIconColor0d7_KjU() {
        return this.disabledIconColor;
    }

    /* JADX INFO: renamed from: getDisabledTextColor-0d7_KjU, reason: not valid java name */
    public final long m728getDisabledTextColor0d7_KjU() {
        return this.disabledTextColor;
    }

    /* JADX INFO: renamed from: getIconColor-0d7_KjU, reason: not valid java name */
    public final long m729getIconColor0d7_KjU() {
        return this.iconColor;
    }

    /* JADX INFO: renamed from: getTextColor-0d7_KjU, reason: not valid java name */
    public final long m730getTextColor0d7_KjU() {
        return this.textColor;
    }

    public int hashCode() {
        return Y.m3027hashCodeimpl(this.disabledIconColor) + D0.d.d(this.disabledTextColor, D0.d.d(this.iconColor, D0.d.d(this.textColor, Y.m3027hashCodeimpl(this.backgroundColor) * 31, 31), 31), 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ContextMenuColors(backgroundColor=");
        D0.d.w(this.backgroundColor, sb, ", textColor=");
        D0.d.w(this.textColor, sb, ", iconColor=");
        D0.d.w(this.iconColor, sb, ", disabledTextColor=");
        D0.d.w(this.disabledTextColor, sb, ", disabledIconColor=");
        sb.append((Object) Y.m3028toStringimpl(this.disabledIconColor));
        sb.append(')');
        return sb.toString();
    }

    private e(long j2, long j3, long j4, long j5, long j6) {
        this.backgroundColor = j2;
        this.textColor = j3;
        this.iconColor = j4;
        this.disabledTextColor = j5;
        this.disabledIconColor = j6;
    }
}
