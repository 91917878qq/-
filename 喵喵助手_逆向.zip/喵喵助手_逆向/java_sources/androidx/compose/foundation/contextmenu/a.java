package androidx.compose.foundation.contextmenu;

import G.v;
import androidx.compose.foundation.AbstractC0375g;
import androidx.compose.foundation.layout.AbstractC0413c0;
import androidx.compose.foundation.layout.AbstractC0430l;
import androidx.compose.foundation.layout.x0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.u;
import androidx.compose.ui.x;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public static final a INSTANCE = new a();

    /* JADX INFO: renamed from: lambda$-355168742, reason: not valid java name */
    private static h1.f f0lambda$355168742 = v.composableLambdaInstance(-355168742, false, C0024a.INSTANCE);

    /* JADX INFO: renamed from: androidx.compose.foundation.contextmenu.a$a, reason: collision with other inner class name */
    public static final class C0024a implements h1.f {
        public static final C0024a INSTANCE = new C0024a();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            invoke((e) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(e eVar, InterfaceC0768p interfaceC0768p, int i2) {
            if ((i2 & 6) == 0) {
                i2 |= interfaceC0768p.changed(eVar) ? 4 : 2;
            }
            if (!interfaceC0768p.shouldExecute((i2 & 19) != 18, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-355168742, i2, -1, "androidx.compose.foundation.contextmenu.ComposableSingletons$ContextMenuUi_androidKt.lambda$-355168742.<anonymous> (ContextMenuUi.android.kt:305)");
            }
            u uVar = x.Companion;
            l lVar = l.INSTANCE;
            AbstractC0430l.Box(AbstractC0375g.m755backgroundbw27NRU$default(x0.m1013height3ABfNKs(x0.fillMaxWidth$default(AbstractC0413c0.m961paddingVpY3zN4$default(uVar, 0.0f, lVar.m736getDividerVerticalPaddingD9Ej5fM(), 1, null), 0.0f, 1, null), lVar.m735getDividerHeightD9Ej5fM()), eVar.m729getIconColor0d7_KjU(), null, 2, null), interfaceC0768p, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: getLambda$-355168742$foundation_release, reason: not valid java name */
    public final h1.f m725getLambda$355168742$foundation_release() {
        return f0lambda$355168742;
    }
}
