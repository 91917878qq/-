package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.lazy.layout.C;
import androidx.compose.foundation.lazy.layout.D;
import androidx.compose.foundation.lazy.layout.T;
import androidx.compose.foundation.lazy.layout.V;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.x;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1704b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1705c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1706d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1707e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f1708f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f1709g;

    public /* synthetic */ o(e eVar, x xVar, h1.f fVar, int i2, int i3) {
        this.f1705c = eVar;
        this.f1706d = xVar;
        this.f1709g = fVar;
        this.f1707e = i2;
        this.f1708f = i3;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1704b) {
            case 0:
                InterfaceC0768p interfaceC0768p = (InterfaceC0768p) obj;
                int iIntValue = ((Integer) obj2).intValue();
                return t.ContextMenuColumnBuilder$lambda$2((x) this.f1706d, (e) this.f1705c, (h1.c) this.f1709g, this.f1707e, this.f1708f, interfaceC0768p, iIntValue);
            case 1:
                InterfaceC0768p interfaceC0768p2 = (InterfaceC0768p) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                return t.ContextMenuColumn$lambda$3((e) this.f1705c, (x) this.f1706d, (h1.f) this.f1709g, this.f1707e, this.f1708f, interfaceC0768p2, iIntValue2);
            case 2:
                InterfaceC0768p interfaceC0768p3 = (InterfaceC0768p) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                return C.SkippableItem_JVlU9Rs$lambda$0((D) this.f1706d, this.f1705c, this.f1707e, this.f1709g, this.f1708f, interfaceC0768p3, iIntValue3);
            case 3:
                InterfaceC0768p interfaceC0768p4 = (InterfaceC0768p) obj;
                int iIntValue4 = ((Integer) obj2).intValue();
                return T.LazyLayoutPinnableItem$lambda$4(this.f1706d, this.f1707e, (V) this.f1705c, (h1.e) this.f1709g, this.f1708f, interfaceC0768p4, iIntValue4);
            default:
                InterfaceC0768p interfaceC0768p5 = (InterfaceC0768p) obj;
                int iIntValue5 = ((Integer) obj2).intValue();
                return androidx.compose.foundation.text.contextmenu.internal.g.ProvidePlatformTextContextMenuToolbar$lambda$6((x) this.f1706d, (h1.c) this.f1709g, (h1.e) this.f1705c, this.f1707e, this.f1708f, interfaceC0768p5, iIntValue5);
        }
    }

    public /* synthetic */ o(D d2, Object obj, int i2, Object obj2, int i3) {
        this.f1706d = d2;
        this.f1705c = obj;
        this.f1707e = i2;
        this.f1709g = obj2;
        this.f1708f = i3;
    }

    public /* synthetic */ o(x xVar, e eVar, h1.c cVar, int i2, int i3) {
        this.f1706d = xVar;
        this.f1705c = eVar;
        this.f1709g = cVar;
        this.f1707e = i2;
        this.f1708f = i3;
    }

    public /* synthetic */ o(x xVar, h1.c cVar, h1.e eVar, int i2, int i3) {
        this.f1706d = xVar;
        this.f1709g = cVar;
        this.f1705c = eVar;
        this.f1707e = i2;
        this.f1708f = i3;
    }

    public /* synthetic */ o(Object obj, int i2, V v2, h1.e eVar, int i3) {
        this.f1706d = obj;
        this.f1707e = i2;
        this.f1705c = v2;
        this.f1709g = eVar;
        this.f1708f = i3;
    }
}
