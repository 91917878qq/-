package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.contextmenu.m;

/* JADX INFO: loaded from: classes.dex */
public abstract class n {
    private static final String UNSPECIFIED_OFFSET_ERROR_MESSAGE = "ContextMenuState.Status should never be open with an unspecified offset. Use ContextMenuState.Status.Closed instead.";

    public static final void close(m mVar) {
        mVar.setStatus(m.a.C0025a.INSTANCE);
    }
}
