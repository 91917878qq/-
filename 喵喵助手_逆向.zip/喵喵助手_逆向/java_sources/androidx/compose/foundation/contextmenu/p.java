package androidx.compose.foundation.contextmenu;

import androidx.compose.foundation.lazy.layout.I;
import androidx.compose.foundation.lazy.layout.K;
import androidx.compose.foundation.lazy.layout.W;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.window.u;
import androidx.compose.ui.x;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class p implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1710b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h1.a f1711c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ x f1712d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1713e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f1714f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f1715g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f1716h;

    public /* synthetic */ p(u uVar, h1.a aVar, x xVar, h1.c cVar, int i2, int i3) {
        this.f1710b = 0;
        this.f1715g = uVar;
        this.f1711c = aVar;
        this.f1712d = xVar;
        this.f1716h = cVar;
        this.f1713e = i2;
        this.f1714f = i3;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1710b) {
            case 0:
                InterfaceC0768p interfaceC0768p = (InterfaceC0768p) obj;
                int iIntValue = ((Integer) obj2).intValue();
                return t.ContextMenuPopup$lambda$0((u) this.f1715g, this.f1711c, this.f1712d, (h1.c) this.f1716h, this.f1713e, this.f1714f, interfaceC0768p, iIntValue);
            case 1:
                InterfaceC0768p interfaceC0768p2 = (InterfaceC0768p) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                return I.LazyLayout$lambda$0(this.f1711c, this.f1712d, (W) this.f1715g, (h1.e) this.f1716h, this.f1713e, this.f1714f, interfaceC0768p2, iIntValue2);
            default:
                InterfaceC0768p interfaceC0768p3 = (InterfaceC0768p) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                return I.LazyLayout$lambda$1(this.f1711c, this.f1712d, (W) this.f1715g, (K) this.f1716h, this.f1713e, this.f1714f, interfaceC0768p3, iIntValue3);
        }
    }

    public /* synthetic */ p(h1.a aVar, x xVar, W w2, Object obj, int i2, int i3, int i4) {
        this.f1710b = i4;
        this.f1711c = aVar;
        this.f1712d = xVar;
        this.f1715g = w2;
        this.f1716h = obj;
        this.f1713e = i2;
        this.f1714f = i3;
    }
}
