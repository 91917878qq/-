package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;

/* JADX INFO: loaded from: classes.dex */
public abstract class U extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.m3924placeRelative70tqf50$default(aVar, abstractC0974x0, e0.o.Companion.m5207getZeronOccac(), 0.0f, 2, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: calculateContentConstraints-l58MMJ0 */
    public abstract long mo931calculateContentConstraintsl58MMJ0(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2);

    public abstract boolean getEnforceIncoming();

    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public final InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        long jMo931calculateContentConstraintsl58MMJ0 = mo931calculateContentConstraintsl58MMJ0(interfaceC0937e0, interfaceC0931b0, j2);
        if (getEnforceIncoming()) {
            jMo931calculateContentConstraintsl58MMJ0 = AbstractC1306c.m5056constrainN9IONVI(j2, jMo931calculateContentConstraintsl58MMJ0);
        }
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(jMo931calculateContentConstraintsl58MMJ0);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new E(abstractC0974x0Mo3865measureBRTryo0, 1), 4, null);
    }

    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }
}
