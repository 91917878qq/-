package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class SizeElement extends AbstractC1000k0 {
    private final boolean enforceIncoming;
    private final h1.c inspectorInfo;
    private final float maxHeight;
    private final float maxWidth;
    private final float minHeight;
    private final float minWidth;

    public /* synthetic */ SizeElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5, z2, cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SizeElement)) {
            return false;
        }
        SizeElement sizeElement = (SizeElement) obj;
        return C1311h.m5081equalsimpl0(this.minWidth, sizeElement.minWidth) && C1311h.m5081equalsimpl0(this.minHeight, sizeElement.minHeight) && C1311h.m5081equalsimpl0(this.maxWidth, sizeElement.maxWidth) && C1311h.m5081equalsimpl0(this.maxHeight, sizeElement.maxHeight) && this.enforceIncoming == sizeElement.enforceIncoming;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return Boolean.hashCode(this.enforceIncoming) + D0.d.C(this.maxHeight, D0.d.C(this.maxWidth, D0.d.C(this.minHeight, C1311h.m5082hashCodeimpl(this.minWidth) * 31, 31), 31), 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public /* synthetic */ SizeElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f2, (i2 & 2) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, (i2 & 4) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f4, (i2 & 8) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f5, z2, cVar, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public y0 create() {
        return new y0(this.minWidth, this.minHeight, this.maxWidth, this.maxHeight, this.enforceIncoming, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(y0 y0Var) {
        y0Var.m1043setMinWidth0680j_4(this.minWidth);
        y0Var.m1042setMinHeight0680j_4(this.minHeight);
        y0Var.m1041setMaxWidth0680j_4(this.maxWidth);
        y0Var.m1040setMaxHeight0680j_4(this.maxHeight);
        y0Var.setEnforceIncoming(this.enforceIncoming);
    }

    private SizeElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar) {
        this.minWidth = f2;
        this.minHeight = f3;
        this.maxWidth = f4;
        this.maxHeight = f5;
        this.enforceIncoming = z2;
        this.inspectorInfo = cVar;
    }
}
