package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class t0 implements InterfaceC0933c0, InterfaceC0437o0 {
    public static final int $stable = 0;
    private final InterfaceC0420g horizontalArrangement;
    private final InterfaceC0823f verticalAlignment;

    public t0(InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f) {
        this.horizontalArrangement = interfaceC0420g;
        this.verticalAlignment = interfaceC0823f;
    }

    private final InterfaceC0420g component1() {
        return this.horizontalArrangement;
    }

    private final InterfaceC0823f component2() {
        return this.verticalAlignment;
    }

    public static /* synthetic */ t0 copy$default(t0 t0Var, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0420g = t0Var.horizontalArrangement;
        }
        if ((i2 & 2) != 0) {
            interfaceC0823f = t0Var.verticalAlignment;
        }
        return t0Var.copy(interfaceC0420g, interfaceC0823f);
    }

    private final int getCrossAxisPosition(AbstractC0974x0 abstractC0974x0, q0 q0Var, int i2, int i3) {
        B crossAxisAlignment = q0Var != null ? q0Var.getCrossAxisAlignment() : null;
        return crossAxisAlignment != null ? crossAxisAlignment.align$foundation_layout(i2 - abstractC0974x0.getHeight(), e0.u.Ltr, abstractC0974x0, i3) : this.verticalAlignment.align(0, i2 - abstractC0974x0.getHeight());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n placeHelper$lambda$3$lambda$2(AbstractC0974x0[] abstractC0974x0Arr, t0 t0Var, int i2, int i3, int[] iArr, AbstractC0974x0.a aVar) {
        int length = abstractC0974x0Arr.length;
        int i4 = 0;
        int i5 = 0;
        while (i4 < length) {
            AbstractC0974x0 abstractC0974x0 = abstractC0974x0Arr[i4];
            kotlin.jvm.internal.o.b(abstractC0974x0);
            AbstractC0974x0.a.place$default(aVar, abstractC0974x0, iArr[i5], t0Var.getCrossAxisPosition(abstractC0974x0, AbstractC0435n0.getRowColumnParentData(abstractC0974x0), i2, i3), 0.0f, 4, null);
            i4++;
            i5++;
        }
        return U0.n.f1521a;
    }

    public final t0 copy(InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f) {
        return new t0(interfaceC0420g, interfaceC0823f);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    /* JADX INFO: renamed from: createConstraints-xF2OJ5Q */
    public long mo1002createConstraintsxF2OJ5Q(int i2, int i3, int i4, int i5, boolean z2) {
        return r0.createRowConstraints(z2, i2, i3, i4, i5);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public int crossAxisSize(AbstractC0974x0 abstractC0974x0) {
        return abstractC0974x0.getHeight();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t0)) {
            return false;
        }
        t0 t0Var = (t0) obj;
        return kotlin.jvm.internal.o.a(this.horizontalArrangement, t0Var.horizontalArrangement) && kotlin.jvm.internal.o.a(this.verticalAlignment, t0Var.verticalAlignment);
    }

    public int hashCode() {
        return this.verticalAlignment.hashCode() + (this.horizontalArrangement.hashCode() * 31);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public int mainAxisSize(AbstractC0974x0 abstractC0974x0) {
        return abstractC0974x0.getWidth();
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.HorizontalMaxHeight(list, i2, f2.mo782roundToPx0680j_4(this.horizontalArrangement.mo982getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.HorizontalMaxWidth(list, i2, f2.mo782roundToPx0680j_4(this.horizontalArrangement.mo982getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        return p0.measure(this, C1305b.m5043getMinWidthimpl(j2), C1305b.m5042getMinHeightimpl(j2), C1305b.m5041getMaxWidthimpl(j2), C1305b.m5040getMaxHeightimpl(j2), interfaceC0937e0.mo782roundToPx0680j_4(this.horizontalArrangement.mo982getSpacingD9Ej5fM()), interfaceC0937e0, list, new AbstractC0974x0[list.size()], 0, list.size(), (3072 & 1024) != 0 ? null : null, (3072 & 2048) != 0 ? 0 : 0);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.HorizontalMinHeight(list, i2, f2.mo782roundToPx0680j_4(this.horizontalArrangement.mo982getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.HorizontalMinWidth(list, i2, f2.mo782roundToPx0680j_4(this.horizontalArrangement.mo982getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public InterfaceC0935d0 placeHelper(AbstractC0974x0[] abstractC0974x0Arr, InterfaceC0937e0 interfaceC0937e0, int i2, int[] iArr, int i3, int i4, int[] iArr2, int i5, int i6, int i7) {
        return InterfaceC0937e0.layout$default(interfaceC0937e0, i3, i4, null, new s0(abstractC0974x0Arr, this, i4, i2, iArr), 4, null);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public void populateMainAxisPositions(int i2, int[] iArr, int[] iArr2, InterfaceC0937e0 interfaceC0937e0) {
        this.horizontalArrangement.arrange(interfaceC0937e0, i2, iArr, interfaceC0937e0.getLayoutDirection(), iArr2);
    }

    public String toString() {
        return "RowMeasurePolicy(horizontalArrangement=" + this.horizontalArrangement + ", verticalAlignment=" + this.verticalAlignment + ')';
    }
}
