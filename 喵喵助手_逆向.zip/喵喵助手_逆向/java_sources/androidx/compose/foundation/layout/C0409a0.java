package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0409a0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private h1.c offset;
    private boolean rtlAware;
    private final boolean shouldAutoInvalidate;

    public C0409a0(h1.c cVar, boolean z2) {
        this.offset = cVar;
        this.rtlAware = z2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(C0409a0 c0409a0, AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        long jM5205unboximpl = ((e0.o) c0409a0.offset.invoke(aVar)).m5205unboximpl();
        if (c0409a0.rtlAware) {
            AbstractC0974x0.a.placeRelativeWithLayer$default(aVar, abstractC0974x0, e0.o.m5196getXimpl(jM5205unboximpl), e0.o.m5197getYimpl(jM5205unboximpl), 0.0f, (h1.c) null, 12, (Object) null);
        } else {
            AbstractC0974x0.a.placeWithLayer$default(aVar, abstractC0974x0, e0.o.m5196getXimpl(jM5205unboximpl), e0.o.m5197getYimpl(jM5205unboximpl), 0.0f, (h1.c) null, 12, (Object) null);
        }
        return U0.n.f1521a;
    }

    public final h1.c getOffset() {
        return this.offset;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new M0.m(20, this, abstractC0974x0Mo3865measureBRTryo0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setOffset(h1.c cVar) {
        this.offset = cVar;
    }

    public final void setRtlAware(boolean z2) {
        this.rtlAware = z2;
    }

    public final void update(h1.c cVar, boolean z2) {
        if (this.offset != cVar || this.rtlAware != z2) {
            androidx.compose.ui.node.P.invalidatePlacement(this);
        }
        this.offset = cVar;
        this.rtlAware = z2;
    }
}
