package androidx.compose.foundation.layout;

import android.os.Build;
import android.view.View;
import androidx.core.view.InterfaceC1209m;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class L extends androidx.core.view.B implements Runnable, InterfaceC1209m, View.OnAttachStateChangeListener {
    private final I0 composeInsets;
    private boolean prepared;
    private boolean runningAnimation;
    private androidx.core.view.Z savedInsets;

    public L(I0 i02) {
        super(!i02.getConsumes() ? 1 : 0);
        this.composeInsets = i02;
    }

    public final I0 getComposeInsets() {
        return this.composeInsets;
    }

    public final boolean getPrepared() {
        return this.prepared;
    }

    public final boolean getRunningAnimation() {
        return this.runningAnimation;
    }

    public final androidx.core.view.Z getSavedInsets() {
        return this.savedInsets;
    }

    @Override // androidx.core.view.InterfaceC1209m
    public androidx.core.view.Z onApplyWindowInsets(View view, androidx.core.view.Z z2) {
        this.savedInsets = z2;
        this.composeInsets.updateImeAnimationTarget(z2);
        if (this.prepared) {
            if (Build.VERSION.SDK_INT == 30) {
                view.post(this);
            }
        } else if (!this.runningAnimation) {
            this.composeInsets.updateImeAnimationSource(z2);
            I0.update$default(this.composeInsets, z2, 0, 2, null);
        }
        return this.composeInsets.getConsumes() ? androidx.core.view.Z.f2571b : z2;
    }

    @Override // androidx.core.view.B
    public void onEnd(androidx.core.view.L l2) {
        this.prepared = false;
        this.runningAnimation = false;
        androidx.core.view.Z z2 = this.savedInsets;
        if (l2.f2544a.a() > 0 && z2 != null) {
            this.composeInsets.updateImeAnimationSource(z2);
            this.composeInsets.updateImeAnimationTarget(z2);
            I0.update$default(this.composeInsets, z2, 0, 2, null);
        }
        this.savedInsets = null;
        super.onEnd(l2);
    }

    @Override // androidx.core.view.B
    public void onPrepare(androidx.core.view.L l2) {
        this.prepared = true;
        this.runningAnimation = true;
        super.onPrepare(l2);
    }

    @Override // androidx.core.view.B
    public androidx.core.view.Z onProgress(androidx.core.view.Z z2, List<androidx.core.view.L> list) {
        I0.update$default(this.composeInsets, z2, 0, 2, null);
        return this.composeInsets.getConsumes() ? androidx.core.view.Z.f2571b : z2;
    }

    @Override // androidx.core.view.B
    public androidx.core.view.A onStart(androidx.core.view.L l2, androidx.core.view.A a2) {
        this.prepared = false;
        return a2;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
        view.requestApplyInsets();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.prepared) {
            this.prepared = false;
            this.runningAnimation = false;
            androidx.core.view.Z z2 = this.savedInsets;
            if (z2 != null) {
                this.composeInsets.updateImeAnimationSource(z2);
                I0.update$default(this.composeInsets, z2, 0, 2, null);
                this.savedInsets = null;
            }
        }
    }

    public final void setPrepared(boolean z2) {
        this.prepared = z2;
    }

    public final void setRunningAnimation(boolean z2) {
        this.runningAnimation = z2;
    }

    public final void setSavedInsets(androidx.core.view.Z z2) {
        this.savedInsets = z2;
    }
}
