package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.h2;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;

/* JADX INFO: loaded from: classes.dex */
public abstract class z0 {
    public static final void Spacer(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-72882467, i2, -1, "androidx.compose.foundation.layout.Spacer (Spacer.kt:37)");
        }
        A0 a02 = A0.INSTANCE;
        int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768p, 0));
        androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768p, xVar);
        androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768p.getCurrentCompositionLocalMap();
        C0997j c0997j = InterfaceC0999k.Companion;
        h1.a constructor = c0997j.getConstructor();
        if (interfaceC0768p.getApplier() == null) {
            AbstractC0750j.invalidApplier();
        }
        interfaceC0768p.startReusableNode();
        if (interfaceC0768p.getInserting()) {
            interfaceC0768p.createNode(constructor);
        } else {
            interfaceC0768p.useNode();
        }
        InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768p);
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, a02, c0997j.getSetMeasurePolicy());
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, currentCompositionLocalMap, c0997j.getSetResolvedCompositionLocals());
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
        h1.e setCompositeKeyHash = c0997j.getSetCompositeKeyHash();
        if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
            D0.d.z(setCompositeKeyHash, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
        }
        interfaceC0768p.endNode();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
    }
}
