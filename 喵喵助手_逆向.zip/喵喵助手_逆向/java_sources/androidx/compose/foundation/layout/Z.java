package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private boolean rtlAware;
    private final boolean shouldAutoInvalidate;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f1767x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f1768y;

    public /* synthetic */ Z(float f2, float f3, boolean z2, AbstractC1378g abstractC1378g) {
        this(f2, f3, z2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(Z z2, AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        if (z2.rtlAware) {
            AbstractC0974x0.a.placeRelative$default(aVar, abstractC0974x0, aVar.mo782roundToPx0680j_4(z2.f1767x), aVar.mo782roundToPx0680j_4(z2.f1768y), 0.0f, 4, null);
        } else {
            AbstractC0974x0.a.place$default(aVar, abstractC0974x0, aVar.mo782roundToPx0680j_4(z2.f1767x), aVar.mo782roundToPx0680j_4(z2.f1768y), 0.0f, 4, null);
        }
        return U0.n.f1521a;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    /* JADX INFO: renamed from: getX-D9Ej5fM, reason: not valid java name */
    public final float m947getXD9Ej5fM() {
        return this.f1767x;
    }

    /* JADX INFO: renamed from: getY-D9Ej5fM, reason: not valid java name */
    public final float m948getYD9Ej5fM() {
        return this.f1768y;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new M0.m(19, this, abstractC0974x0Mo3865measureBRTryo0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setRtlAware(boolean z2) {
        this.rtlAware = z2;
    }

    /* JADX INFO: renamed from: setX-0680j_4, reason: not valid java name */
    public final void m949setX0680j_4(float f2) {
        this.f1767x = f2;
    }

    /* JADX INFO: renamed from: setY-0680j_4, reason: not valid java name */
    public final void m950setY0680j_4(float f2) {
        this.f1768y = f2;
    }

    /* JADX INFO: renamed from: update-Md-fbLM, reason: not valid java name */
    public final void m951updateMdfbLM(float f2, float f3, boolean z2) {
        if (!C1311h.m5081equalsimpl0(this.f1767x, f2) || !C1311h.m5081equalsimpl0(this.f1768y, f3) || this.rtlAware != z2) {
            androidx.compose.ui.node.P.invalidatePlacement(this);
        }
        this.f1767x = f2;
        this.f1768y = f3;
        this.rtlAware = z2;
    }

    private Z(float f2, float f3, boolean z2) {
        this.f1767x = f2;
        this.f1768y = f3;
        this.rtlAware = z2;
    }
}
