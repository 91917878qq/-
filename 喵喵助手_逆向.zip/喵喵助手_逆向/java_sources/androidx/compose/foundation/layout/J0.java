package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import e0.C1311h;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public abstract class J0 {
    private static final H EmptyWindowInsets = new H(0, 0, 0, 0);

    public static final H0 WindowInsets() {
        return EmptyWindowInsets;
    }

    public static /* synthetic */ H0 WindowInsets$default(int i2, int i3, int i4, int i5, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i2 = 0;
        }
        if ((i6 & 2) != 0) {
            i3 = 0;
        }
        if ((i6 & 4) != 0) {
            i4 = 0;
        }
        if ((i6 & 8) != 0) {
            i5 = 0;
        }
        return WindowInsets(i2, i3, i4, i5);
    }

    /* JADX INFO: renamed from: WindowInsets-a9UjIt4, reason: not valid java name */
    public static final H0 m899WindowInsetsa9UjIt4(float f2, float f3, float f4, float f5) {
        return new G(f2, f3, f4, f5, null);
    }

    /* JADX INFO: renamed from: WindowInsets-a9UjIt4$default, reason: not valid java name */
    public static /* synthetic */ H0 m900WindowInsetsa9UjIt4$default(float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.m5076constructorimpl(0);
        }
        return m899WindowInsetsa9UjIt4(f2, f3, f4, f5);
    }

    public static final H0 add(H0 h02, H0 h03) {
        return new C0408a(h02, h03);
    }

    public static final H0 asInsets(InterfaceC0421g0 interfaceC0421g0) {
        return new C0427j0(interfaceC0421g0);
    }

    public static final InterfaceC0421g0 asPaddingValues(H0 h02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1485016250, i2, -1, "androidx.compose.foundation.layout.asPaddingValues (WindowInsets.kt:220)");
        }
        N n2 = new N(h02, (InterfaceC1307d) interfaceC0768p.consume(androidx.compose.ui.platform.L0.getLocalDensity()));
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return n2;
    }

    public static final H0 exclude(H0 h02, H0 h03) {
        return new D(h02, h03);
    }

    /* JADX INFO: renamed from: only-bOOhFvg, reason: not valid java name */
    public static final H0 m901onlybOOhFvg(H0 h02, int i2) {
        return new X(h02, i2, null);
    }

    public static final H0 union(H0 h02, H0 h03) {
        return new B0(h02, h03);
    }

    public static final H0 WindowInsets(int i2, int i3, int i4, int i5) {
        return new H(i2, i3, i4, i5);
    }

    public static final InterfaceC0421g0 asPaddingValues(H0 h02, InterfaceC1307d interfaceC1307d) {
        return new N(h02, interfaceC1307d);
    }
}
