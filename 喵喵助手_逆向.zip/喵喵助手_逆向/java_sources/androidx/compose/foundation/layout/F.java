package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public final class F extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private C direction;
    private float fraction;

    public F(C c2, float f2) {
        this.direction = c2;
        this.fraction = f2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.placeRelative$default(aVar, abstractC0974x0, 0, 0, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    public final C getDirection() {
        return this.direction;
    }

    public final float getFraction() {
        return this.fraction;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iM5043getMinWidthimpl;
        int iM5041getMaxWidthimpl;
        int iM5040getMaxHeightimpl;
        int iM5040getMaxHeightimpl2;
        if (!C1305b.m5037getHasBoundedWidthimpl(j2) || this.direction == C.Vertical) {
            iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(j2);
            iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
        } else {
            int iRound = Math.round(C1305b.m5041getMaxWidthimpl(j2) * this.fraction);
            int iM5043getMinWidthimpl2 = C1305b.m5043getMinWidthimpl(j2);
            iM5043getMinWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
            if (iRound < iM5043getMinWidthimpl2) {
                iRound = iM5043getMinWidthimpl2;
            }
            if (iRound <= iM5043getMinWidthimpl) {
                iM5043getMinWidthimpl = iRound;
            }
            iM5041getMaxWidthimpl = iM5043getMinWidthimpl;
        }
        if (!C1305b.m5036getHasBoundedHeightimpl(j2) || this.direction == C.Horizontal) {
            int iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(j2);
            iM5040getMaxHeightimpl = C1305b.m5040getMaxHeightimpl(j2);
            iM5040getMaxHeightimpl2 = iM5042getMinHeightimpl;
        } else {
            int iRound2 = Math.round(C1305b.m5040getMaxHeightimpl(j2) * this.fraction);
            int iM5042getMinHeightimpl2 = C1305b.m5042getMinHeightimpl(j2);
            iM5040getMaxHeightimpl2 = C1305b.m5040getMaxHeightimpl(j2);
            if (iRound2 < iM5042getMinHeightimpl2) {
                iRound2 = iM5042getMinHeightimpl2;
            }
            if (iRound2 <= iM5040getMaxHeightimpl2) {
                iM5040getMaxHeightimpl2 = iRound2;
            }
            iM5040getMaxHeightimpl = iM5040getMaxHeightimpl2;
        }
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.Constraints(iM5043getMinWidthimpl, iM5041getMaxWidthimpl, iM5040getMaxHeightimpl2, iM5040getMaxHeightimpl));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new E(abstractC0974x0Mo3865measureBRTryo0, 0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setDirection(C c2) {
        this.direction = c2;
    }

    public final void setFraction(float f2) {
        this.fraction = f2;
    }
}
