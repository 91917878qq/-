package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0928a;
import androidx.compose.ui.layout.AbstractC0974x0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0410b {
    public static final int $stable = 0;

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.b$a */
    public static final class a extends AbstractC0410b {
        public static final int $stable = 0;
        private final h1.c lineProviderBlock;

        public a(h1.c cVar) {
            super(null);
            this.lineProviderBlock = cVar;
        }

        public static /* synthetic */ a copy$default(a aVar, h1.c cVar, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                cVar = aVar.lineProviderBlock;
            }
            return aVar.copy(cVar);
        }

        @Override // androidx.compose.foundation.layout.AbstractC0410b
        public int calculateAlignmentLinePosition(AbstractC0974x0 abstractC0974x0) {
            return ((Number) this.lineProviderBlock.invoke(abstractC0974x0)).intValue();
        }

        public final h1.c component1() {
            return this.lineProviderBlock;
        }

        public final a copy(h1.c cVar) {
            return new a(cVar);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof a) && kotlin.jvm.internal.o.a(this.lineProviderBlock, ((a) obj).lineProviderBlock);
        }

        public final h1.c getLineProviderBlock() {
            return this.lineProviderBlock;
        }

        public int hashCode() {
            return this.lineProviderBlock.hashCode();
        }

        public String toString() {
            return "Block(lineProviderBlock=" + this.lineProviderBlock + ')';
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.b$b, reason: collision with other inner class name */
    public static final class C0037b extends AbstractC0410b {
        public static final int $stable = 0;
        private final AbstractC0928a alignmentLine;

        public C0037b(AbstractC0928a abstractC0928a) {
            super(null);
            this.alignmentLine = abstractC0928a;
        }

        public static /* synthetic */ C0037b copy$default(C0037b c0037b, AbstractC0928a abstractC0928a, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                abstractC0928a = c0037b.alignmentLine;
            }
            return c0037b.copy(abstractC0928a);
        }

        @Override // androidx.compose.foundation.layout.AbstractC0410b
        public int calculateAlignmentLinePosition(AbstractC0974x0 abstractC0974x0) {
            return abstractC0974x0.get(this.alignmentLine);
        }

        public final AbstractC0928a component1() {
            return this.alignmentLine;
        }

        public final C0037b copy(AbstractC0928a abstractC0928a) {
            return new C0037b(abstractC0928a);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof C0037b) && kotlin.jvm.internal.o.a(this.alignmentLine, ((C0037b) obj).alignmentLine);
        }

        public final AbstractC0928a getAlignmentLine() {
            return this.alignmentLine;
        }

        public int hashCode() {
            return this.alignmentLine.hashCode();
        }

        public String toString() {
            return "Value(alignmentLine=" + this.alignmentLine + ')';
        }
    }

    public /* synthetic */ AbstractC0410b(AbstractC1378g abstractC1378g) {
        this();
    }

    public abstract int calculateAlignmentLinePosition(AbstractC0974x0 abstractC0974x0);

    private AbstractC0410b() {
    }
}
