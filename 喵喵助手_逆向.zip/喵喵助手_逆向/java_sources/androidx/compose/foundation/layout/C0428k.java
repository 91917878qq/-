package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0428k implements InterfaceC0933c0 {
    public static final C0428k INSTANCE = new C0428k();

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0.a aVar) {
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicWidth(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public final InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        return InterfaceC0937e0.layout$default(interfaceC0937e0, C1305b.m5043getMinWidthimpl(j2), C1305b.m5042getMinHeightimpl(j2), null, new androidx.compose.animation.core.D0(21), 4, null);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicWidth(f2, list, i2);
    }
}
