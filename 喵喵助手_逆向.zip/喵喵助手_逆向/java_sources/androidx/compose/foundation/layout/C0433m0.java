package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.m0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0433m0 extends androidx.compose.ui.w implements androidx.compose.ui.modifier.h, androidx.compose.ui.node.M, androidx.compose.ui.node.C {
    private final E0 insets;
    private long oldPosition;
    private final androidx.compose.ui.modifier.g providedValues;

    public C0433m0() {
        E0 e02 = new E0(new O(0, 0, 0, 0), "reset");
        this.insets = e02;
        this.oldPosition = e0.o.Companion.m5207getZeronOccac();
        this.providedValues = androidx.compose.ui.modifier.i.modifierLocalMapOf(new U0.g(K0.getModifierLocalConsumedWindowInsets(), e02));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.place$default(aVar, abstractC0974x0, 0, 0, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$2(C0433m0 c0433m0, InterfaceC0931b0 interfaceC0931b0, int i2, int i3, AbstractC0974x0.a aVar) {
        Object obj;
        androidx.compose.ui.layout.J coordinates = aVar.getCoordinates();
        if (coordinates != null) {
            c0433m0.oldPosition = e0.p.m5213roundk4lQ0M(androidx.compose.ui.layout.K.positionInRoot(coordinates));
        }
        if (coordinates == null) {
            obj = (H0) c0433m0.getCurrent(K0.getModifierLocalConsumedWindowInsets());
        } else {
            long jPositionInRoot = androidx.compose.ui.layout.K.positionInRoot(coordinates);
            long jMo3810getSizeYbymL2g = coordinates.mo3810getSizeYbymL2g();
            long jMo3813localToRootMKHz9U = coordinates.mo3813localToRootMKHz9U(J.f.m42constructorimpl((((long) Float.floatToRawIntBits((int) (jMo3810getSizeYbymL2g & 4294967295L))) & 4294967295L) | (Float.floatToRawIntBits((int) (jMo3810getSizeYbymL2g >> 32)) << 32)));
            long jMo3810getSizeYbymL2g2 = androidx.compose.ui.layout.K.findRootCoordinates(coordinates).mo3810getSizeYbymL2g();
            int iRound = Math.round(Float.intBitsToFloat((int) (jPositionInRoot >> 32)));
            int iRound2 = Math.round(Float.intBitsToFloat((int) (jPositionInRoot & 4294967295L)));
            int iRound3 = ((int) (jMo3810getSizeYbymL2g2 >> 32)) - Math.round(Float.intBitsToFloat((int) (jMo3813localToRootMKHz9U >> 32)));
            int iRound4 = ((int) (jMo3810getSizeYbymL2g2 & 4294967295L)) - Math.round(Float.intBitsToFloat((int) (jMo3813localToRootMKHz9U & 4294967295L)));
            O value$foundation_layout = c0433m0.insets.getValue$foundation_layout();
            if (value$foundation_layout.getLeft() != iRound || value$foundation_layout.getTop() != iRound2 || value$foundation_layout.getRight() != iRound3 || value$foundation_layout.getBottom() != iRound4) {
                c0433m0.insets.setValue$foundation_layout(new O(iRound, iRound2, iRound3, iRound4));
            }
            obj = c0433m0.insets;
        }
        c0433m0.provide(K0.getModifierLocalConsumedWindowInsets(), obj);
        AbstractC0974x0.a.place$default(aVar, interfaceC0931b0.mo3865measureBRTryo0(C1305b.Companion.m5051fixedJhjzzOo(i2, i3)), 0, 0, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.modifier.h, androidx.compose.ui.modifier.k
    public /* bridge */ /* synthetic */ Object getCurrent(androidx.compose.ui.modifier.c cVar) {
        return super.getCurrent(cVar);
    }

    public final E0 getInsets() {
        return this.insets;
    }

    /* JADX INFO: renamed from: getOldPosition-nOcc-ac, reason: not valid java name */
    public final long m999getOldPositionnOccac() {
        return this.oldPosition;
    }

    @Override // androidx.compose.ui.modifier.h
    public androidx.compose.ui.modifier.g getProvidedValues() {
        return this.providedValues;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return false;
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        if (C1305b.m5039getHasFixedWidthimpl(j2) && C1305b.m5038getHasFixedHeightimpl(j2)) {
            int iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
            int iM5040getMaxHeightimpl = C1305b.m5040getMaxHeightimpl(j2);
            return InterfaceC0937e0.layout$default(interfaceC0937e0, iM5041getMaxWidthimpl, iM5040getMaxHeightimpl, null, new C0431l0(this, interfaceC0931b0, iM5041getMaxWidthimpl, iM5040getMaxHeightimpl), 4, null);
        }
        provide(K0.getModifierLocalConsumedWindowInsets(), getCurrent(K0.getModifierLocalConsumedWindowInsets()));
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new E(abstractC0974x0Mo3865measureBRTryo0, 2), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.node.C
    public void onGloballyPositioned(androidx.compose.ui.layout.J j2) {
        long jM5213roundk4lQ0M = e0.p.m5213roundk4lQ0M(androidx.compose.ui.layout.K.positionInRoot(j2));
        boolean zM5195equalsimpl0 = e0.o.m5195equalsimpl0(this.oldPosition, jM5213roundk4lQ0M);
        this.oldPosition = jM5213roundk4lQ0M;
        if (zM5195equalsimpl0) {
            return;
        }
        androidx.compose.ui.node.P.invalidatePlacement(this);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.modifier.h
    public /* bridge */ /* synthetic */ void provide(androidx.compose.ui.modifier.c cVar, Object obj) {
        super.provide(cVar, obj);
    }

    /* JADX INFO: renamed from: setOldPosition--gyyYBs, reason: not valid java name */
    public final void m1000setOldPositiongyyYBs(long j2) {
        this.oldPosition = j2;
    }
}
