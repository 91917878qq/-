package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;
import e0.C1305b;
import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0442u implements InterfaceC0441t, InterfaceC0438p {
    private final /* synthetic */ C0439q $$delegate_0;
    private final long constraints;
    private final InterfaceC1307d density;

    public /* synthetic */ C0442u(InterfaceC1307d interfaceC1307d, long j2, AbstractC1378g abstractC1378g) {
        this(interfaceC1307d, j2);
    }

    private final InterfaceC1307d component1() {
        return this.density;
    }

    /* JADX INFO: renamed from: copy-0kLqBqw$default, reason: not valid java name */
    public static /* synthetic */ C0442u m1008copy0kLqBqw$default(C0442u c0442u, InterfaceC1307d interfaceC1307d, long j2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC1307d = c0442u.density;
        }
        if ((i2 & 2) != 0) {
            j2 = c0442u.constraints;
        }
        return c0442u.m1010copy0kLqBqw(interfaceC1307d, j2);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t, androidx.compose.foundation.layout.InterfaceC0438p
    public androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g) {
        return this.$$delegate_0.align(xVar, interfaceC0849g);
    }

    /* JADX INFO: renamed from: component2-msEJaDk, reason: not valid java name */
    public final long m1009component2msEJaDk() {
        return this.constraints;
    }

    /* JADX INFO: renamed from: copy-0kLqBqw, reason: not valid java name */
    public final C0442u m1010copy0kLqBqw(InterfaceC1307d interfaceC1307d, long j2) {
        return new C0442u(interfaceC1307d, j2, null);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0442u)) {
            return false;
        }
        C0442u c0442u = (C0442u) obj;
        return kotlin.jvm.internal.o.a(this.density, c0442u.density) && C1305b.m5034equalsimpl0(this.constraints, c0442u.constraints);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t
    /* JADX INFO: renamed from: getConstraints-msEJaDk */
    public long mo1003getConstraintsmsEJaDk() {
        return this.constraints;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t
    /* JADX INFO: renamed from: getMaxHeight-D9Ej5fM */
    public float mo1004getMaxHeightD9Ej5fM() {
        return C1305b.m5036getHasBoundedHeightimpl(mo1003getConstraintsmsEJaDk()) ? this.density.mo785toDpu2uoSUM(C1305b.m5040getMaxHeightimpl(mo1003getConstraintsmsEJaDk())) : C1311h.Companion.m5095getInfinityD9Ej5fM();
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t
    /* JADX INFO: renamed from: getMaxWidth-D9Ej5fM */
    public float mo1005getMaxWidthD9Ej5fM() {
        return C1305b.m5037getHasBoundedWidthimpl(mo1003getConstraintsmsEJaDk()) ? this.density.mo785toDpu2uoSUM(C1305b.m5041getMaxWidthimpl(mo1003getConstraintsmsEJaDk())) : C1311h.Companion.m5095getInfinityD9Ej5fM();
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t
    /* JADX INFO: renamed from: getMinHeight-D9Ej5fM */
    public float mo1006getMinHeightD9Ej5fM() {
        return this.density.mo785toDpu2uoSUM(C1305b.m5042getMinHeightimpl(mo1003getConstraintsmsEJaDk()));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t
    /* JADX INFO: renamed from: getMinWidth-D9Ej5fM */
    public float mo1007getMinWidthD9Ej5fM() {
        return this.density.mo785toDpu2uoSUM(C1305b.m5043getMinWidthimpl(mo1003getConstraintsmsEJaDk()));
    }

    public int hashCode() {
        return C1305b.m5044hashCodeimpl(this.constraints) + (this.density.hashCode() * 31);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0441t, androidx.compose.foundation.layout.InterfaceC0438p
    public androidx.compose.ui.x matchParentSize(androidx.compose.ui.x xVar) {
        return this.$$delegate_0.matchParentSize(xVar);
    }

    public String toString() {
        return "BoxWithConstraintsScopeImpl(density=" + this.density + ", constraints=" + ((Object) C1305b.m5046toStringimpl(this.constraints)) + ')';
    }

    private C0442u(InterfaceC1307d interfaceC1307d, long j2) {
        this.$$delegate_0 = C0439q.INSTANCE;
        this.density = interfaceC1307d;
        this.constraints = j2;
    }
}
