package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0426j extends androidx.compose.ui.w implements androidx.compose.ui.node.K0 {
    private InterfaceC0849g alignment;
    private boolean matchParentSize;

    public C0426j(InterfaceC0849g interfaceC0849g, boolean z2) {
        this.alignment = interfaceC0849g;
        this.matchParentSize = z2;
    }

    public final InterfaceC0849g getAlignment() {
        return this.alignment;
    }

    public final boolean getMatchParentSize() {
        return this.matchParentSize;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setAlignment(InterfaceC0849g interfaceC0849g) {
        this.alignment = interfaceC0849g;
    }

    public final void setMatchParentSize(boolean z2) {
        this.matchParentSize = z2;
    }

    @Override // androidx.compose.ui.node.K0
    public C0426j modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
        return this;
    }
}
