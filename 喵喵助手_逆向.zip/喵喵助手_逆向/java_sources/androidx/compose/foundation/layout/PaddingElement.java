package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;
import p.AbstractC1408a;

/* JADX INFO: loaded from: classes.dex */
final class PaddingElement extends AbstractC1000k0 {
    private float bottom;
    private float end;
    private final h1.c inspectorInfo;
    private boolean rtlAware;
    private float start;
    private float top;

    public /* synthetic */ PaddingElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5, z2, cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        PaddingElement paddingElement = obj instanceof PaddingElement ? (PaddingElement) obj : null;
        return paddingElement != null && C1311h.m5081equalsimpl0(this.start, paddingElement.start) && C1311h.m5081equalsimpl0(this.top, paddingElement.top) && C1311h.m5081equalsimpl0(this.end, paddingElement.end) && C1311h.m5081equalsimpl0(this.bottom, paddingElement.bottom) && this.rtlAware == paddingElement.rtlAware;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    /* JADX INFO: renamed from: getBottom-D9Ej5fM, reason: not valid java name */
    public final float m932getBottomD9Ej5fM() {
        return this.bottom;
    }

    /* JADX INFO: renamed from: getEnd-D9Ej5fM, reason: not valid java name */
    public final float m933getEndD9Ej5fM() {
        return this.end;
    }

    public final h1.c getInspectorInfo() {
        return this.inspectorInfo;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    /* JADX INFO: renamed from: getStart-D9Ej5fM, reason: not valid java name */
    public final float m934getStartD9Ej5fM() {
        return this.start;
    }

    /* JADX INFO: renamed from: getTop-D9Ej5fM, reason: not valid java name */
    public final float m935getTopD9Ej5fM() {
        return this.top;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return Boolean.hashCode(this.rtlAware) + D0.d.C(this.bottom, D0.d.C(this.end, D0.d.C(this.top, C1311h.m5082hashCodeimpl(this.start) * 31, 31), 31), 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    /* JADX INFO: renamed from: setBottom-0680j_4, reason: not valid java name */
    public final void m936setBottom0680j_4(float f2) {
        this.bottom = f2;
    }

    /* JADX INFO: renamed from: setEnd-0680j_4, reason: not valid java name */
    public final void m937setEnd0680j_4(float f2) {
        this.end = f2;
    }

    public final void setRtlAware(boolean z2) {
        this.rtlAware = z2;
    }

    /* JADX INFO: renamed from: setStart-0680j_4, reason: not valid java name */
    public final void m938setStart0680j_4(float f2) {
        this.start = f2;
    }

    /* JADX INFO: renamed from: setTop-0680j_4, reason: not valid java name */
    public final void m939setTop0680j_4(float f2) {
        this.top = f2;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    private PaddingElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar) {
        this.start = f2;
        this.top = f3;
        this.end = f4;
        this.bottom = f5;
        this.rtlAware = z2;
        this.inspectorInfo = cVar;
        boolean z3 = true;
        boolean z4 = f2 >= 0.0f || Float.isNaN(f2);
        float f6 = this.top;
        boolean z5 = z4 & (f6 >= 0.0f || Float.isNaN(f6));
        float f7 = this.end;
        boolean z6 = z5 & (f7 >= 0.0f || Float.isNaN(f7));
        float f8 = this.bottom;
        if (f8 < 0.0f && !Float.isNaN(f8)) {
            z3 = false;
        }
        if (!z6 || !z3) {
            AbstractC1408a.throwIllegalArgumentException("Padding must be non-negative");
        }
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0415d0 create() {
        return new C0415d0(this.start, this.top, this.end, this.bottom, this.rtlAware, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0415d0 c0415d0) {
        c0415d0.m970setStart0680j_4(this.start);
        c0415d0.m971setTop0680j_4(this.top);
        c0415d0.m969setEnd0680j_4(this.end);
        c0415d0.m968setBottom0680j_4(this.bottom);
        c0415d0.setRtlAware(this.rtlAware);
    }

    public /* synthetic */ PaddingElement(float f2, float f3, float f4, float f5, boolean z2, h1.c cVar, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.m5076constructorimpl(0) : f2, (i2 & 2) != 0 ? C1311h.m5076constructorimpl(0) : f3, (i2 & 4) != 0 ? C1311h.m5076constructorimpl(0) : f4, (i2 & 8) != 0 ? C1311h.m5076constructorimpl(0) : f5, z2, cVar, null);
    }
}
