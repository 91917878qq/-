package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.w0;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
public final class WithAlignmentLineBlockElement extends AbstractC1000k0 {
    public static final int $stable = 0;
    private final h1.c block;

    public WithAlignmentLineBlockElement(h1.c cVar) {
        this.block = cVar;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        WithAlignmentLineBlockElement withAlignmentLineBlockElement = obj instanceof WithAlignmentLineBlockElement ? (WithAlignmentLineBlockElement) obj : null;
        return withAlignmentLineBlockElement != null && this.block == withAlignmentLineBlockElement.block;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final h1.c getBlock() {
        return this.block;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return this.block.hashCode();
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("alignBy");
        c1065l1.setValue(this.block);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public w0.a create() {
        return new w0.a(this.block);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(w0.a aVar) {
        aVar.setBlock(this.block);
    }
}
