package androidx.compose.foundation.layout;

import androidx.compose.foundation.lazy.layout.C0474i;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import j.C1338I;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.l0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0431l0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1778b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1779c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1780d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1781e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1782f;

    public /* synthetic */ C0431l0(int i2, int i3, C1338I c1338i, androidx.compose.foundation.lazy.layout.p0 p0Var) {
        this.f1779c = i2;
        this.f1780d = i3;
        this.f1781e = c1338i;
        this.f1782f = p0Var;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1778b) {
            case 0:
                InterfaceC0931b0 interfaceC0931b0 = (InterfaceC0931b0) this.f1782f;
                int i2 = this.f1779c;
                return C0433m0.measure_3p2s80s$lambda$2((C0433m0) this.f1781e, interfaceC0931b0, i2, this.f1780d, (AbstractC0974x0.a) obj);
            default:
                C1338I c1338i = (C1338I) this.f1781e;
                return androidx.compose.foundation.lazy.layout.p0.lambda$2$lambda$1(this.f1779c, this.f1780d, c1338i, (androidx.compose.foundation.lazy.layout.p0) this.f1782f, (C0474i) obj);
        }
    }

    public /* synthetic */ C0431l0(C0433m0 c0433m0, InterfaceC0931b0 interfaceC0931b0, int i2, int i3) {
        this.f1781e = c0433m0;
        this.f1782f = interfaceC0931b0;
        this.f1779c = i2;
        this.f1780d = i3;
    }
}
