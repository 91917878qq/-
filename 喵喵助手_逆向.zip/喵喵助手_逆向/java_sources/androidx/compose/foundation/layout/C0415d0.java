package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.d0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0415d0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private float bottom;
    private float end;
    private boolean rtlAware;
    private float start;
    private float top;

    public /* synthetic */ C0415d0(float f2, float f3, float f4, float f5, boolean z2, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5, z2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(C0415d0 c0415d0, AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        if (c0415d0.rtlAware) {
            AbstractC0974x0.a.placeRelative$default(aVar, abstractC0974x0, aVar.mo782roundToPx0680j_4(c0415d0.start), aVar.mo782roundToPx0680j_4(c0415d0.top), 0.0f, 4, null);
        } else {
            AbstractC0974x0.a.place$default(aVar, abstractC0974x0, aVar.mo782roundToPx0680j_4(c0415d0.start), aVar.mo782roundToPx0680j_4(c0415d0.top), 0.0f, 4, null);
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: getBottom-D9Ej5fM, reason: not valid java name */
    public final float m964getBottomD9Ej5fM() {
        return this.bottom;
    }

    /* JADX INFO: renamed from: getEnd-D9Ej5fM, reason: not valid java name */
    public final float m965getEndD9Ej5fM() {
        return this.end;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    /* JADX INFO: renamed from: getStart-D9Ej5fM, reason: not valid java name */
    public final float m966getStartD9Ej5fM() {
        return this.start;
    }

    /* JADX INFO: renamed from: getTop-D9Ej5fM, reason: not valid java name */
    public final float m967getTopD9Ej5fM() {
        return this.top;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iMo782roundToPx0680j_4 = interfaceC0937e0.mo782roundToPx0680j_4(this.end) + interfaceC0937e0.mo782roundToPx0680j_4(this.start);
        int iMo782roundToPx0680j_42 = interfaceC0937e0.mo782roundToPx0680j_4(this.bottom) + interfaceC0937e0.mo782roundToPx0680j_4(this.top);
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.m5060offsetNN6EwU(j2, -iMo782roundToPx0680j_4, -iMo782roundToPx0680j_42));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, AbstractC1306c.m5058constrainWidthK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getWidth() + iMo782roundToPx0680j_4), AbstractC1306c.m5057constrainHeightK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getHeight() + iMo782roundToPx0680j_42), null, new M0.m(21, this, abstractC0974x0Mo3865measureBRTryo0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    /* JADX INFO: renamed from: setBottom-0680j_4, reason: not valid java name */
    public final void m968setBottom0680j_4(float f2) {
        this.bottom = f2;
    }

    /* JADX INFO: renamed from: setEnd-0680j_4, reason: not valid java name */
    public final void m969setEnd0680j_4(float f2) {
        this.end = f2;
    }

    public final void setRtlAware(boolean z2) {
        this.rtlAware = z2;
    }

    /* JADX INFO: renamed from: setStart-0680j_4, reason: not valid java name */
    public final void m970setStart0680j_4(float f2) {
        this.start = f2;
    }

    /* JADX INFO: renamed from: setTop-0680j_4, reason: not valid java name */
    public final void m971setTop0680j_4(float f2) {
        this.top = f2;
    }

    private C0415d0(float f2, float f3, float f4, float f5, boolean z2) {
        this.start = f2;
        this.top = f3;
        this.end = f4;
        this.bottom = f5;
        this.rtlAware = z2;
    }

    public /* synthetic */ C0415d0(float f2, float f3, float f4, float f5, boolean z2, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.m5076constructorimpl(0) : f2, (i2 & 2) != 0 ? C1311h.m5076constructorimpl(0) : f3, (i2 & 4) != 0 ? C1311h.m5076constructorimpl(0) : f4, (i2 & 8) != 0 ? C1311h.m5076constructorimpl(0) : f5, z2, null);
    }
}
