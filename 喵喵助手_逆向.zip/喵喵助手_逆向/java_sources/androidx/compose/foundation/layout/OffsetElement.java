package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class OffsetElement extends AbstractC1000k0 {
    private final h1.c inspectorInfo;
    private final boolean rtlAware;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private final float f1765x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private final float f1766y;

    public /* synthetic */ OffsetElement(float f2, float f3, boolean z2, h1.c cVar, AbstractC1378g abstractC1378g) {
        this(f2, f3, z2, cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        OffsetElement offsetElement = obj instanceof OffsetElement ? (OffsetElement) obj : null;
        if (offsetElement == null) {
            return false;
        }
        return C1311h.m5081equalsimpl0(this.f1765x, offsetElement.f1765x) && C1311h.m5081equalsimpl0(this.f1766y, offsetElement.f1766y) && this.rtlAware == offsetElement.rtlAware;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final h1.c getInspectorInfo() {
        return this.inspectorInfo;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    /* JADX INFO: renamed from: getX-D9Ej5fM, reason: not valid java name */
    public final float m929getXD9Ej5fM() {
        return this.f1765x;
    }

    /* JADX INFO: renamed from: getY-D9Ej5fM, reason: not valid java name */
    public final float m930getYD9Ej5fM() {
        return this.f1766y;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return Boolean.hashCode(this.rtlAware) + D0.d.C(this.f1766y, C1311h.m5082hashCodeimpl(this.f1765x) * 31, 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("OffsetModifierElement(x=");
        D0.d.u(this.f1765x, sb, ", y=");
        D0.d.u(this.f1766y, sb, ", rtlAware=");
        sb.append(this.rtlAware);
        sb.append(')');
        return sb.toString();
    }

    private OffsetElement(float f2, float f3, boolean z2, h1.c cVar) {
        this.f1765x = f2;
        this.f1766y = f3;
        this.rtlAware = z2;
        this.inspectorInfo = cVar;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public Z create() {
        return new Z(this.f1765x, this.f1766y, this.rtlAware, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(Z z2) {
        z2.m951updateMdfbLM(this.f1765x, this.f1766y, this.rtlAware);
    }
}
