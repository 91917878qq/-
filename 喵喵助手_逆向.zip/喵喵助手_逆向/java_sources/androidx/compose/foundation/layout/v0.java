package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.layout.AbstractC0934d;
import androidx.compose.ui.layout.C0975y;
import p.AbstractC1408a;

/* JADX INFO: loaded from: classes.dex */
public final class v0 implements u0 {
    public static final int $stable = 0;
    public static final v0 INSTANCE = new v0();

    private v0() {
    }

    @Override // androidx.compose.foundation.layout.u0
    public androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0823f interfaceC0823f) {
        return xVar.then(new VerticalAlignElement(interfaceC0823f));
    }

    @Override // androidx.compose.foundation.layout.u0
    public androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, C0975y c0975y) {
        return xVar.then(new WithAlignmentLineElement(c0975y));
    }

    @Override // androidx.compose.foundation.layout.u0
    public androidx.compose.ui.x alignByBaseline(androidx.compose.ui.x xVar) {
        return alignBy(xVar, AbstractC0934d.getFirstBaseline());
    }

    @Override // androidx.compose.foundation.layout.u0
    public androidx.compose.ui.x weight(androidx.compose.ui.x xVar, float f2, boolean z2) {
        if (!(((double) f2) > 0.0d)) {
            AbstractC1408a.throwIllegalArgumentException("invalid weight; must be greater than zero");
        }
        return xVar.then(new LayoutWeightElement(j1.a.l(f2, Float.MAX_VALUE), z2));
    }

    @Override // androidx.compose.foundation.layout.u0
    public androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, h1.c cVar) {
        return xVar.then(new WithAlignmentLineBlockElement(cVar));
    }
}
