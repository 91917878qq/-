package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0822e;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class J extends androidx.compose.ui.w implements androidx.compose.ui.node.K0 {
    public static final int $stable = 8;
    private InterfaceC0822e horizontal;

    public J(InterfaceC0822e interfaceC0822e) {
        this.horizontal = interfaceC0822e;
    }

    public final InterfaceC0822e getHorizontal() {
        return this.horizontal;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setHorizontal(InterfaceC0822e interfaceC0822e) {
        this.horizontal = interfaceC0822e;
    }

    @Override // androidx.compose.ui.node.K0
    public q0 modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
        q0 q0Var = obj instanceof q0 ? (q0) obj : null;
        if (q0Var == null) {
            q0Var = new q0(0.0f, false, null, null, 15, null);
        }
        q0Var.setCrossAxisAlignment(B.Companion.horizontal$foundation_layout(this.horizontal));
        return q0Var;
    }
}
