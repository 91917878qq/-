package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class IntrinsicWidthElement extends AbstractC1000k0 {
    private final boolean enforceIncoming;
    private final h1.c inspectorInfo;
    private final T width;

    public IntrinsicWidthElement(T t2, boolean z2, h1.c cVar) {
        this.width = t2;
        this.enforceIncoming = z2;
        this.inspectorInfo = cVar;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        IntrinsicWidthElement intrinsicWidthElement = obj instanceof IntrinsicWidthElement ? (IntrinsicWidthElement) obj : null;
        if (intrinsicWidthElement == null) {
            return false;
        }
        return this.width == intrinsicWidthElement.width && this.enforceIncoming == intrinsicWidthElement.enforceIncoming;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final boolean getEnforceIncoming() {
        return this.enforceIncoming;
    }

    public final h1.c getInspectorInfo() {
        return this.inspectorInfo;
    }

    public final T getWidth() {
        return this.width;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return Boolean.hashCode(this.enforceIncoming) + (this.width.hashCode() * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public V create() {
        return new V(this.width, this.enforceIncoming);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(V v2) {
        v2.setWidth(this.width);
        v2.setEnforceIncoming(this.enforceIncoming);
    }
}
