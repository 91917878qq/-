package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0823f;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class F0 extends androidx.compose.ui.w implements androidx.compose.ui.node.K0 {
    public static final int $stable = 8;
    private InterfaceC0823f vertical;

    public F0(InterfaceC0823f interfaceC0823f) {
        this.vertical = interfaceC0823f;
    }

    public final InterfaceC0823f getVertical() {
        return this.vertical;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setVertical(InterfaceC0823f interfaceC0823f) {
        this.vertical = interfaceC0823f;
    }

    @Override // androidx.compose.ui.node.K0
    public q0 modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
        q0 q0Var = obj instanceof q0 ? (q0) obj : null;
        if (q0Var == null) {
            q0Var = new q0(0.0f, false, null, null, 15, null);
        }
        q0Var.setCrossAxisAlignment(B.Companion.vertical$foundation_layout(this.vertical));
        return q0Var;
    }
}
