package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public final class P extends U {
    private boolean enforceIncoming;
    private T height;

    public P(T t2, boolean z2) {
        this.height = t2;
        this.enforceIncoming = z2;
    }

    @Override // androidx.compose.foundation.layout.U
    /* JADX INFO: renamed from: calculateContentConstraints-l58MMJ0, reason: not valid java name */
    public long mo931calculateContentConstraintsl58MMJ0(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iMinIntrinsicHeight = this.height == T.Min ? interfaceC0931b0.minIntrinsicHeight(C1305b.m5041getMaxWidthimpl(j2)) : interfaceC0931b0.maxIntrinsicHeight(C1305b.m5041getMaxWidthimpl(j2));
        if (iMinIntrinsicHeight < 0) {
            iMinIntrinsicHeight = 0;
        }
        return C1305b.Companion.m5052fixedHeightOenEA2s(iMinIntrinsicHeight);
    }

    @Override // androidx.compose.foundation.layout.U
    public boolean getEnforceIncoming() {
        return this.enforceIncoming;
    }

    public final T getHeight() {
        return this.height;
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return this.height == T.Min ? e2.minIntrinsicHeight(i2) : e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return this.height == T.Min ? e2.minIntrinsicHeight(i2) : e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public void setEnforceIncoming(boolean z2) {
        this.enforceIncoming = z2;
    }

    public final void setHeight(T t2) {
        this.height = t2;
    }
}
