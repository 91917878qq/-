package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0937e0;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0432m implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1783b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1784c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1785d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0937e0 f1786e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1787f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f1788g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f1789h;

    public /* synthetic */ C0432m(AbstractC0974x0 abstractC0974x0, InterfaceC0931b0 interfaceC0931b0, InterfaceC0937e0 interfaceC0937e0, int i2, int i3, C0436o c0436o) {
        this.f1787f = abstractC0974x0;
        this.f1788g = interfaceC0931b0;
        this.f1786e = interfaceC0937e0;
        this.f1784c = i2;
        this.f1785d = i3;
        this.f1789h = c0436o;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1783b) {
            case 0:
                AbstractC0974x0.a aVar = (AbstractC0974x0.a) obj;
                return C0436o.measure_3p2s80s$lambda$1((AbstractC0974x0) this.f1787f, (InterfaceC0931b0) this.f1788g, this.f1786e, this.f1784c, this.f1785d, (C0436o) this.f1789h, aVar);
            default:
                AbstractC0974x0.a aVar2 = (AbstractC0974x0.a) obj;
                return C0444w.placeHelper$lambda$3$lambda$2((AbstractC0974x0[]) this.f1787f, (C0444w) this.f1788g, this.f1784c, this.f1785d, this.f1786e, (int[]) this.f1789h, aVar2);
        }
    }

    public /* synthetic */ C0432m(AbstractC0974x0[] abstractC0974x0Arr, C0444w c0444w, int i2, int i3, InterfaceC0937e0 interfaceC0937e0, int[] iArr) {
        this.f1787f = abstractC0974x0Arr;
        this.f1788g = c0444w;
        this.f1784c = i2;
        this.f1785d = i3;
        this.f1786e = interfaceC0937e0;
        this.f1789h = iArr;
    }
}
