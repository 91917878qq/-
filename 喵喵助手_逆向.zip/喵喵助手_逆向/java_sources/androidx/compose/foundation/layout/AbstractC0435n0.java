package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.n0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0435n0 {
    public static final B getCrossAxisAlignment(q0 q0Var) {
        if (q0Var != null) {
            return q0Var.getCrossAxisAlignment();
        }
        return null;
    }

    public static final boolean getFill(q0 q0Var) {
        if (q0Var != null) {
            return q0Var.getFill();
        }
        return true;
    }

    public static final q0 getRowColumnParentData(androidx.compose.ui.layout.E e2) {
        Object parentData = e2.getParentData();
        if (parentData instanceof q0) {
            return (q0) parentData;
        }
        return null;
    }

    public static final float getWeight(q0 q0Var) {
        if (q0Var != null) {
            return q0Var.getWeight();
        }
        return 0.0f;
    }

    private static final int intrinsicCrossAxisSize(List<? extends androidx.compose.ui.layout.E> list, h1.e eVar, h1.e eVar2, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * i3, i2);
        int size = list.size();
        int iMax = 0;
        float f2 = 0.0f;
        for (int i4 = 0; i4 < size; i4++) {
            androidx.compose.ui.layout.E e2 = list.get(i4);
            float weight = getWeight(getRowColumnParentData(e2));
            if (weight == 0.0f) {
                int iMin2 = Math.min(((Number) eVar.invoke(e2, Integer.MAX_VALUE)).intValue(), i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i2 - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, ((Number) eVar2.invoke(e2, Integer.valueOf(iMin2))).intValue());
            } else if (weight > 0.0f) {
                f2 += weight;
            }
        }
        int iRound = f2 == 0.0f ? 0 : i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i2 - iMin, 0) / f2);
        int size2 = list.size();
        for (int i5 = 0; i5 < size2; i5++) {
            androidx.compose.ui.layout.E e3 = list.get(i5);
            float weight2 = getWeight(getRowColumnParentData(e3));
            if (weight2 > 0.0f) {
                iMax = Math.max(iMax, ((Number) eVar2.invoke(e3, Integer.valueOf(iRound != Integer.MAX_VALUE ? Math.round(iRound * weight2) : Integer.MAX_VALUE))).intValue());
            }
        }
        return iMax;
    }

    private static final int intrinsicMainAxisSize(List<? extends androidx.compose.ui.layout.E> list, h1.e eVar, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i4 = 0;
        float f2 = 0.0f;
        for (int i5 = 0; i5 < size; i5++) {
            androidx.compose.ui.layout.E e2 = list.get(i5);
            float weight = getWeight(getRowColumnParentData(e2));
            int iIntValue = ((Number) eVar.invoke(e2, Integer.valueOf(i2))).intValue();
            if (weight == 0.0f) {
                i4 += iIntValue;
            } else if (weight > 0.0f) {
                f2 += weight;
                iMax = Math.max(iMax, Math.round(iIntValue / weight));
            }
        }
        return ((list.size() - 1) * i3) + Math.round(iMax * f2) + i4;
    }

    public static final boolean isRelative(q0 q0Var) {
        B crossAxisAlignment = getCrossAxisAlignment(q0Var);
        if (crossAxisAlignment != null) {
            return crossAxisAlignment.isRelative$foundation_layout();
        }
        return false;
    }

    public static final q0 getRowColumnParentData(AbstractC0974x0 abstractC0974x0) {
        Object parentData = abstractC0974x0.getParentData();
        if (parentData instanceof q0) {
            return (q0) parentData;
        }
        return null;
    }
}
