package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class W extends androidx.compose.ui.w implements androidx.compose.ui.node.K0 {
    public static final int $stable = 8;
    private boolean fill;
    private float weight;

    public W(float f2, boolean z2) {
        this.weight = f2;
        this.fill = z2;
    }

    public final boolean getFill() {
        return this.fill;
    }

    public final float getWeight() {
        return this.weight;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setFill(boolean z2) {
        this.fill = z2;
    }

    public final void setWeight(float f2) {
        this.weight = f2;
    }

    @Override // androidx.compose.ui.node.K0
    public q0 modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
        q0 q0Var = obj instanceof q0 ? (q0) obj : null;
        if (q0Var == null) {
            q0Var = new q0(0.0f, false, null, null, 15, null);
        }
        q0Var.setWeight(this.weight);
        q0Var.setFill(this.fill);
        return q0Var;
    }
}
