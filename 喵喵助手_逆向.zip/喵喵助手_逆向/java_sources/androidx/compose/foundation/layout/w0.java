package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.AbstractC0410b;
import androidx.compose.ui.layout.AbstractC0928a;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class w0 extends androidx.compose.ui.w implements androidx.compose.ui.node.K0 {
    public static final int $stable = androidx.compose.ui.w.$stable;

    public static final class a extends w0 {
        public static final int $stable = 8;
        private h1.c block;

        public a(h1.c cVar) {
            super(null);
            this.block = cVar;
        }

        public final h1.c getBlock() {
            return this.block;
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.node.K0
        public Object modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
            q0 q0Var = obj instanceof q0 ? (q0) obj : null;
            if (q0Var == null) {
                q0Var = new q0(0.0f, false, null, null, 15, null);
            }
            q0Var.setCrossAxisAlignment(B.Companion.Relative$foundation_layout(new AbstractC0410b.a(this.block)));
            return q0Var;
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }

        public final void setBlock(h1.c cVar) {
            this.block = cVar;
        }
    }

    public static final class b extends w0 {
        public static final int $stable = 8;
        private AbstractC0928a alignmentLine;

        public b(AbstractC0928a abstractC0928a) {
            super(null);
            this.alignmentLine = abstractC0928a;
        }

        public final AbstractC0928a getAlignmentLine() {
            return this.alignmentLine;
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.node.K0
        public Object modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
            q0 q0Var = obj instanceof q0 ? (q0) obj : null;
            if (q0Var == null) {
                q0Var = new q0(0.0f, false, null, null, 15, null);
            }
            q0Var.setCrossAxisAlignment(B.Companion.Relative$foundation_layout(new AbstractC0410b.C0037b(this.alignmentLine)));
            return q0Var;
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.foundation.layout.w0, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }

        public final void setAlignmentLine(AbstractC0928a abstractC0928a) {
            this.alignmentLine = abstractC0928a;
        }
    }

    public /* synthetic */ w0(AbstractC1378g abstractC1378g) {
        this();
    }

    @Override // androidx.compose.ui.node.K0
    public abstract Object modifyParentData(InterfaceC1307d interfaceC1307d, Object obj);

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    private w0() {
    }
}
