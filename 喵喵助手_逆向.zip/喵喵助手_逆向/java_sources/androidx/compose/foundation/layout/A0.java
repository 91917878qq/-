package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class A0 implements InterfaceC0933c0 {
    public static final A0 INSTANCE = new A0();

    private A0() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$1$lambda$0(AbstractC0974x0.a aVar) {
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicWidth(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        return InterfaceC0937e0.layout$default(interfaceC0937e0, C1305b.m5039getHasFixedWidthimpl(j2) ? C1305b.m5041getMaxWidthimpl(j2) : 0, C1305b.m5038getHasFixedHeightimpl(j2) ? C1305b.m5040getMaxHeightimpl(j2) : 0, null, new androidx.compose.animation.core.D0(23), 4, null);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicWidth(f2, list, i2);
    }
}
