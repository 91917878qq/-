package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public final class V extends U {
    private boolean enforceIncoming;
    private T width;

    public V(T t2, boolean z2) {
        this.width = t2;
        this.enforceIncoming = z2;
    }

    @Override // androidx.compose.foundation.layout.U
    /* JADX INFO: renamed from: calculateContentConstraints-l58MMJ0 */
    public long mo931calculateContentConstraintsl58MMJ0(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iMinIntrinsicWidth = this.width == T.Min ? interfaceC0931b0.minIntrinsicWidth(C1305b.m5040getMaxHeightimpl(j2)) : interfaceC0931b0.maxIntrinsicWidth(C1305b.m5040getMaxHeightimpl(j2));
        if (iMinIntrinsicWidth < 0) {
            iMinIntrinsicWidth = 0;
        }
        return C1305b.Companion.m5053fixedWidthOenEA2s(iMinIntrinsicWidth);
    }

    @Override // androidx.compose.foundation.layout.U
    public boolean getEnforceIncoming() {
        return this.enforceIncoming;
    }

    public final T getWidth() {
        return this.width;
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return this.width == T.Min ? e2.minIntrinsicWidth(i2) : e2.maxIntrinsicWidth(i2);
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return this.width == T.Min ? e2.minIntrinsicWidth(i2) : e2.maxIntrinsicWidth(i2);
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.foundation.layout.U, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public void setEnforceIncoming(boolean z2) {
        this.enforceIncoming = z2;
    }

    public final void setWidth(T t2) {
        this.width = t2;
    }
}
