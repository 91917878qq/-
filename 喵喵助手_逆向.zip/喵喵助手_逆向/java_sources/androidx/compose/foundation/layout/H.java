package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class H implements H0 {
    private final int bottomVal;
    private final int leftVal;
    private final int rightVal;
    private final int topVal;

    public H(int i2, int i3, int i4, int i5) {
        this.leftVal = i2;
        this.topVal = i3;
        this.rightVal = i4;
        this.bottomVal = i5;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof H)) {
            return false;
        }
        H h2 = (H) obj;
        return this.leftVal == h2.leftVal && this.topVal == h2.topVal && this.rightVal == h2.rightVal && this.bottomVal == h2.bottomVal;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return this.bottomVal;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return this.leftVal;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return this.rightVal;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return this.topVal;
    }

    public int hashCode() {
        return (((((this.leftVal * 31) + this.topVal) * 31) + this.rightVal) * 31) + this.bottomVal;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Insets(left=");
        sb.append(this.leftVal);
        sb.append(", top=");
        sb.append(this.topVal);
        sb.append(", right=");
        sb.append(this.rightVal);
        sb.append(", bottom=");
        return D0.d.q(sb, this.bottomVal, ')');
    }
}
