package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0441t extends InterfaceC0438p {
    @Override // androidx.compose.foundation.layout.InterfaceC0438p
    /* synthetic */ androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g);

    /* JADX INFO: renamed from: getConstraints-msEJaDk, reason: not valid java name */
    long mo1003getConstraintsmsEJaDk();

    /* JADX INFO: renamed from: getMaxHeight-D9Ej5fM, reason: not valid java name */
    float mo1004getMaxHeightD9Ej5fM();

    /* JADX INFO: renamed from: getMaxWidth-D9Ej5fM, reason: not valid java name */
    float mo1005getMaxWidthD9Ej5fM();

    /* JADX INFO: renamed from: getMinHeight-D9Ej5fM, reason: not valid java name */
    float mo1006getMinHeightD9Ej5fM();

    /* JADX INFO: renamed from: getMinWidth-D9Ej5fM, reason: not valid java name */
    float mo1007getMinWidthD9Ej5fM();

    @Override // androidx.compose.foundation.layout.InterfaceC0438p
    /* synthetic */ androidx.compose.ui.x matchParentSize(androidx.compose.ui.x xVar);
}
