package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1305b;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class D0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private float minHeight;
    private float minWidth;

    public /* synthetic */ D0(float f2, float f3, AbstractC1378g abstractC1378g) {
        this(f2, f3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.placeRelative$default(aVar, abstractC0974x0, 0, 0, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: getMinHeight-D9Ej5fM, reason: not valid java name */
    public final float m895getMinHeightD9Ej5fM() {
        return this.minHeight;
    }

    /* JADX INFO: renamed from: getMinWidth-D9Ej5fM, reason: not valid java name */
    public final float m896getMinWidthD9Ej5fM() {
        return this.minWidth;
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        int iMaxIntrinsicHeight = e2.maxIntrinsicHeight(i2);
        int iMo782roundToPx0680j_4 = !Float.isNaN(this.minHeight) ? f2.mo782roundToPx0680j_4(this.minHeight) : 0;
        return iMaxIntrinsicHeight < iMo782roundToPx0680j_4 ? iMo782roundToPx0680j_4 : iMaxIntrinsicHeight;
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        int iMaxIntrinsicWidth = e2.maxIntrinsicWidth(i2);
        int iMo782roundToPx0680j_4 = !Float.isNaN(this.minWidth) ? f2.mo782roundToPx0680j_4(this.minWidth) : 0;
        return iMaxIntrinsicWidth < iMo782roundToPx0680j_4 ? iMo782roundToPx0680j_4 : iMaxIntrinsicWidth;
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iM5043getMinWidthimpl;
        int iM5042getMinHeightimpl;
        if (Float.isNaN(this.minWidth) || C1305b.m5043getMinWidthimpl(j2) != 0) {
            iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(j2);
        } else {
            int iMo782roundToPx0680j_4 = interfaceC0937e0.mo782roundToPx0680j_4(this.minWidth);
            iM5043getMinWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
            if (iMo782roundToPx0680j_4 < 0) {
                iMo782roundToPx0680j_4 = 0;
            }
            if (iMo782roundToPx0680j_4 <= iM5043getMinWidthimpl) {
                iM5043getMinWidthimpl = iMo782roundToPx0680j_4;
            }
        }
        int iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
        if (Float.isNaN(this.minHeight) || C1305b.m5042getMinHeightimpl(j2) != 0) {
            iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(j2);
        } else {
            int iMo782roundToPx0680j_42 = interfaceC0937e0.mo782roundToPx0680j_4(this.minHeight);
            iM5042getMinHeightimpl = C1305b.m5040getMaxHeightimpl(j2);
            int i2 = iMo782roundToPx0680j_42 >= 0 ? iMo782roundToPx0680j_42 : 0;
            if (i2 <= iM5042getMinHeightimpl) {
                iM5042getMinHeightimpl = i2;
            }
        }
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.Constraints(iM5043getMinWidthimpl, iM5041getMaxWidthimpl, iM5042getMinHeightimpl, C1305b.m5040getMaxHeightimpl(j2)));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new E(abstractC0974x0Mo3865measureBRTryo0, 4), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        int iMinIntrinsicHeight = e2.minIntrinsicHeight(i2);
        int iMo782roundToPx0680j_4 = !Float.isNaN(this.minHeight) ? f2.mo782roundToPx0680j_4(this.minHeight) : 0;
        return iMinIntrinsicHeight < iMo782roundToPx0680j_4 ? iMo782roundToPx0680j_4 : iMinIntrinsicHeight;
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        int iMinIntrinsicWidth = e2.minIntrinsicWidth(i2);
        int iMo782roundToPx0680j_4 = !Float.isNaN(this.minWidth) ? f2.mo782roundToPx0680j_4(this.minWidth) : 0;
        return iMinIntrinsicWidth < iMo782roundToPx0680j_4 ? iMo782roundToPx0680j_4 : iMinIntrinsicWidth;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    /* JADX INFO: renamed from: setMinHeight-0680j_4, reason: not valid java name */
    public final void m897setMinHeight0680j_4(float f2) {
        this.minHeight = f2;
    }

    /* JADX INFO: renamed from: setMinWidth-0680j_4, reason: not valid java name */
    public final void m898setMinWidth0680j_4(float f2) {
        this.minWidth = f2;
    }

    public /* synthetic */ D0(float f2, float f3, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f2, (i2 & 2) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, null);
    }

    private D0(float f2, float f3) {
        this.minWidth = f2;
        this.minHeight = f3;
    }
}
