package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class N implements InterfaceC0421g0 {
    private final InterfaceC1307d density;
    private final H0 insets;

    public N(H0 h02, InterfaceC1307d interfaceC1307d) {
        this.insets = h02;
        this.density = interfaceC1307d;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateBottomPadding-D9Ej5fM, reason: not valid java name */
    public float mo925calculateBottomPaddingD9Ej5fM() {
        InterfaceC1307d interfaceC1307d = this.density;
        return interfaceC1307d.mo785toDpu2uoSUM(this.insets.getBottom(interfaceC1307d));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateLeftPadding-u2uoSUM, reason: not valid java name */
    public float mo926calculateLeftPaddingu2uoSUM(e0.u uVar) {
        InterfaceC1307d interfaceC1307d = this.density;
        return interfaceC1307d.mo785toDpu2uoSUM(this.insets.getLeft(interfaceC1307d, uVar));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateRightPadding-u2uoSUM, reason: not valid java name */
    public float mo927calculateRightPaddingu2uoSUM(e0.u uVar) {
        InterfaceC1307d interfaceC1307d = this.density;
        return interfaceC1307d.mo785toDpu2uoSUM(this.insets.getRight(interfaceC1307d, uVar));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateTopPadding-D9Ej5fM, reason: not valid java name */
    public float mo928calculateTopPaddingD9Ej5fM() {
        InterfaceC1307d interfaceC1307d = this.density;
        return interfaceC1307d.mo785toDpu2uoSUM(this.insets.getTop(interfaceC1307d));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof N)) {
            return false;
        }
        N n2 = (N) obj;
        return kotlin.jvm.internal.o.a(this.insets, n2.insets) && kotlin.jvm.internal.o.a(this.density, n2.density);
    }

    public final H0 getInsets() {
        return this.insets;
    }

    public int hashCode() {
        return this.density.hashCode() + (this.insets.hashCode() * 31);
    }

    public String toString() {
        return "InsetsPaddingValues(insets=" + this.insets + ", density=" + this.density + ')';
    }
}
