package androidx.compose.foundation.layout;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class S {
    public static final int $stable = 0;
    public static final S INSTANCE = new S();

    private S() {
    }

    public final int HorizontalMaxHeight(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * i3, i2);
        int size = list.size();
        int iMax = 0;
        float f2 = 0.0f;
        for (int i4 = 0; i4 < size; i4++) {
            androidx.compose.ui.layout.E e2 = list.get(i4);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            if (weight == 0.0f) {
                int iMin2 = Math.min(e2.maxIntrinsicWidth(Integer.MAX_VALUE), i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i2 - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, e2.maxIntrinsicHeight(iMin2));
            } else if (weight > 0.0f) {
                f2 += weight;
            }
        }
        int iRound = f2 == 0.0f ? 0 : i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i2 - iMin, 0) / f2);
        int size2 = list.size();
        for (int i5 = 0; i5 < size2; i5++) {
            androidx.compose.ui.layout.E e3 = list.get(i5);
            float weight2 = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e3));
            if (weight2 > 0.0f) {
                iMax = Math.max(iMax, e3.maxIntrinsicHeight(iRound != Integer.MAX_VALUE ? Math.round(iRound * weight2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }

    public final int HorizontalMaxWidth(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i4 = 0;
        float f2 = 0.0f;
        for (int i5 = 0; i5 < size; i5++) {
            androidx.compose.ui.layout.E e2 = list.get(i5);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            int iMaxIntrinsicWidth = e2.maxIntrinsicWidth(i2);
            if (weight == 0.0f) {
                i4 += iMaxIntrinsicWidth;
            } else if (weight > 0.0f) {
                f2 += weight;
                iMax = Math.max(iMax, Math.round(iMaxIntrinsicWidth / weight));
            }
        }
        return ((list.size() - 1) * i3) + Math.round(iMax * f2) + i4;
    }

    public final int HorizontalMinHeight(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * i3, i2);
        int size = list.size();
        int iMax = 0;
        float f2 = 0.0f;
        for (int i4 = 0; i4 < size; i4++) {
            androidx.compose.ui.layout.E e2 = list.get(i4);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            if (weight == 0.0f) {
                int iMin2 = Math.min(e2.maxIntrinsicWidth(Integer.MAX_VALUE), i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i2 - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, e2.minIntrinsicHeight(iMin2));
            } else if (weight > 0.0f) {
                f2 += weight;
            }
        }
        int iRound = f2 == 0.0f ? 0 : i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i2 - iMin, 0) / f2);
        int size2 = list.size();
        for (int i5 = 0; i5 < size2; i5++) {
            androidx.compose.ui.layout.E e3 = list.get(i5);
            float weight2 = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e3));
            if (weight2 > 0.0f) {
                iMax = Math.max(iMax, e3.minIntrinsicHeight(iRound != Integer.MAX_VALUE ? Math.round(iRound * weight2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }

    public final int HorizontalMinWidth(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i4 = 0;
        float f2 = 0.0f;
        for (int i5 = 0; i5 < size; i5++) {
            androidx.compose.ui.layout.E e2 = list.get(i5);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            int iMinIntrinsicWidth = e2.minIntrinsicWidth(i2);
            if (weight == 0.0f) {
                i4 += iMinIntrinsicWidth;
            } else if (weight > 0.0f) {
                f2 += weight;
                iMax = Math.max(iMax, Math.round(iMinIntrinsicWidth / weight));
            }
        }
        return ((list.size() - 1) * i3) + Math.round(iMax * f2) + i4;
    }

    public final int VerticalMaxHeight(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i4 = 0;
        float f2 = 0.0f;
        for (int i5 = 0; i5 < size; i5++) {
            androidx.compose.ui.layout.E e2 = list.get(i5);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            int iMaxIntrinsicHeight = e2.maxIntrinsicHeight(i2);
            if (weight == 0.0f) {
                i4 += iMaxIntrinsicHeight;
            } else if (weight > 0.0f) {
                f2 += weight;
                iMax = Math.max(iMax, Math.round(iMaxIntrinsicHeight / weight));
            }
        }
        return ((list.size() - 1) * i3) + Math.round(iMax * f2) + i4;
    }

    public final int VerticalMaxWidth(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * i3, i2);
        int size = list.size();
        int iMax = 0;
        float f2 = 0.0f;
        for (int i4 = 0; i4 < size; i4++) {
            androidx.compose.ui.layout.E e2 = list.get(i4);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            if (weight == 0.0f) {
                int iMin2 = Math.min(e2.maxIntrinsicHeight(Integer.MAX_VALUE), i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i2 - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, e2.maxIntrinsicWidth(iMin2));
            } else if (weight > 0.0f) {
                f2 += weight;
            }
        }
        int iRound = f2 == 0.0f ? 0 : i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i2 - iMin, 0) / f2);
        int size2 = list.size();
        for (int i5 = 0; i5 < size2; i5++) {
            androidx.compose.ui.layout.E e3 = list.get(i5);
            float weight2 = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e3));
            if (weight2 > 0.0f) {
                iMax = Math.max(iMax, e3.maxIntrinsicWidth(iRound != Integer.MAX_VALUE ? Math.round(iRound * weight2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }

    public final int VerticalMinHeight(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i4 = 0;
        float f2 = 0.0f;
        for (int i5 = 0; i5 < size; i5++) {
            androidx.compose.ui.layout.E e2 = list.get(i5);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            int iMinIntrinsicHeight = e2.minIntrinsicHeight(i2);
            if (weight == 0.0f) {
                i4 += iMinIntrinsicHeight;
            } else if (weight > 0.0f) {
                f2 += weight;
                iMax = Math.max(iMax, Math.round(iMinIntrinsicHeight / weight));
            }
        }
        return ((list.size() - 1) * i3) + Math.round(iMax * f2) + i4;
    }

    public final int VerticalMinWidth(List<? extends androidx.compose.ui.layout.E> list, int i2, int i3) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * i3, i2);
        int size = list.size();
        int iMax = 0;
        float f2 = 0.0f;
        for (int i4 = 0; i4 < size; i4++) {
            androidx.compose.ui.layout.E e2 = list.get(i4);
            float weight = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e2));
            if (weight == 0.0f) {
                int iMin2 = Math.min(e2.maxIntrinsicHeight(Integer.MAX_VALUE), i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i2 - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, e2.minIntrinsicWidth(iMin2));
            } else if (weight > 0.0f) {
                f2 += weight;
            }
        }
        int iRound = f2 == 0.0f ? 0 : i2 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i2 - iMin, 0) / f2);
        int size2 = list.size();
        for (int i5 = 0; i5 < size2; i5++) {
            androidx.compose.ui.layout.E e3 = list.get(i5);
            float weight2 = AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(e3));
            if (weight2 > 0.0f) {
                iMax = Math.max(iMax, e3.minIntrinsicWidth(iRound != Integer.MAX_VALUE ? Math.round(iRound * weight2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }
}
