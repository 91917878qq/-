package androidx.compose.foundation.layout;

import O0.C0218m;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0413c0 {
    /* JADX INFO: renamed from: PaddingValues-0680j_4, reason: not valid java name */
    public static final InterfaceC0421g0 m952PaddingValues0680j_4(float f2) {
        return new C0425i0(f2, f2, f2, f2, null);
    }

    /* JADX INFO: renamed from: PaddingValues-YgX7TsA, reason: not valid java name */
    public static final InterfaceC0421g0 m953PaddingValuesYgX7TsA(float f2, float f3) {
        return new C0425i0(f2, f3, f2, f3, null);
    }

    /* JADX INFO: renamed from: PaddingValues-YgX7TsA$default, reason: not valid java name */
    public static /* synthetic */ InterfaceC0421g0 m954PaddingValuesYgX7TsA$default(float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        return m953PaddingValuesYgX7TsA(f2, f3);
    }

    /* JADX INFO: renamed from: PaddingValues-a9UjIt4, reason: not valid java name */
    public static final InterfaceC0421g0 m955PaddingValuesa9UjIt4(float f2, float f3, float f4, float f5) {
        return new C0425i0(f2, f3, f4, f5, null);
    }

    /* JADX INFO: renamed from: PaddingValues-a9UjIt4$default, reason: not valid java name */
    public static /* synthetic */ InterfaceC0421g0 m956PaddingValuesa9UjIt4$default(float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.m5076constructorimpl(0);
        }
        return m955PaddingValuesa9UjIt4(f2, f3, f4, f5);
    }

    /* JADX INFO: renamed from: absolutePadding-qDBjuR0, reason: not valid java name */
    public static final androidx.compose.ui.x m957absolutePaddingqDBjuR0(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5) {
        return xVar.then(new PaddingElement(f2, f3, f4, f5, false, new C0411b0(f2, f3, f4, f5, 1), null));
    }

    /* JADX INFO: renamed from: absolutePadding-qDBjuR0$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m958absolutePaddingqDBjuR0$default(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.m5076constructorimpl(0);
        }
        return m957absolutePaddingqDBjuR0(xVar, f2, f3, f4, f5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n absolutePadding_qDBjuR0$lambda$4(float f2, float f3, float f4, float f5, C1065l1 c1065l1) {
        c1065l1.setName("absolutePadding");
        D0.d.k(f4, D0.d.k(f3, D0.d.k(f2, c1065l1.getProperties(), "left", c1065l1), "top", c1065l1), "right", c1065l1).set("bottom", C1311h.m5074boximpl(f5));
        return U0.n.f1521a;
    }

    public static final float calculateEndPadding(InterfaceC0421g0 interfaceC0421g0, e0.u uVar) {
        return uVar == e0.u.Ltr ? interfaceC0421g0.mo927calculateRightPaddingu2uoSUM(uVar) : interfaceC0421g0.mo926calculateLeftPaddingu2uoSUM(uVar);
    }

    public static final float calculateStartPadding(InterfaceC0421g0 interfaceC0421g0, e0.u uVar) {
        return uVar == e0.u.Ltr ? interfaceC0421g0.mo926calculateLeftPaddingu2uoSUM(uVar) : interfaceC0421g0.mo927calculateRightPaddingu2uoSUM(uVar);
    }

    public static final androidx.compose.ui.x padding(androidx.compose.ui.x xVar, InterfaceC0421g0 interfaceC0421g0) {
        return xVar.then(new PaddingValuesElement(interfaceC0421g0, new C0218m(interfaceC0421g0, 11)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n padding$lambda$3(InterfaceC0421g0 interfaceC0421g0, C1065l1 c1065l1) {
        c1065l1.setName("padding");
        c1065l1.getProperties().set("paddingValues", interfaceC0421g0);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: padding-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m959padding3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new PaddingElement(f2, f2, f2, f2, true, new M0.j(f2, 7), null));
    }

    /* JADX INFO: renamed from: padding-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m960paddingVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new PaddingElement(f2, f3, f2, f3, true, new R0.b(f2, f3, 4), null));
    }

    /* JADX INFO: renamed from: padding-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m961paddingVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        return m960paddingVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: renamed from: padding-qDBjuR0, reason: not valid java name */
    public static final androidx.compose.ui.x m962paddingqDBjuR0(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5) {
        return xVar.then(new PaddingElement(f2, f3, f4, f5, true, new C0411b0(f2, f3, f4, f5, 0), null));
    }

    /* JADX INFO: renamed from: padding-qDBjuR0$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m963paddingqDBjuR0$default(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.m5076constructorimpl(0);
        }
        return m962paddingqDBjuR0(xVar, f2, f3, f4, f5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n padding_3ABfNKs$lambda$2(float f2, C1065l1 c1065l1) {
        c1065l1.setName("padding");
        c1065l1.setValue(C1311h.m5074boximpl(f2));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n padding_VpY3zN4$lambda$1(float f2, float f3, C1065l1 c1065l1) {
        c1065l1.setName("padding");
        D0.d.k(f2, c1065l1.getProperties(), "horizontal", c1065l1).set("vertical", C1311h.m5074boximpl(f3));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n padding_qDBjuR0$lambda$0(float f2, float f3, float f4, float f5, C1065l1 c1065l1) {
        c1065l1.setName("padding");
        D0.d.k(f4, D0.d.k(f3, D0.d.k(f2, c1065l1.getProperties(), "start", c1065l1), "top", c1065l1), "end", c1065l1).set("bottom", C1311h.m5074boximpl(f5));
        return U0.n.f1521a;
    }
}
