package androidx.compose.foundation.layout;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0447z {
    public static final C0447z INSTANCE = new C0447z();
    public static boolean isWindowInsetsDefaultPassThroughEnabled = true;
    public static final int $stable = 8;

    private C0447z() {
    }

    public static /* synthetic */ void isWindowInsetsDefaultPassThroughEnabled$annotations() {
    }
}
