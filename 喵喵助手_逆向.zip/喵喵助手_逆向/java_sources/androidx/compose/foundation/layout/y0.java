package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1305b;
import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class y0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private boolean enforceIncoming;
    private float maxHeight;
    private float maxWidth;
    private float minHeight;
    private float minWidth;

    public /* synthetic */ y0(float f2, float f3, float f4, float f5, boolean z2, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5, z2);
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0041  */
    /* JADX INFO: renamed from: getTargetConstraints-OenEA2s, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final long m1035getTargetConstraintsOenEA2s(InterfaceC1307d interfaceC1307d) {
        int iMo782roundToPx0680j_4;
        int iMo782roundToPx0680j_42;
        int iMo782roundToPx0680j_43;
        int i2 = 0;
        if (Float.isNaN(this.maxWidth)) {
            iMo782roundToPx0680j_4 = Integer.MAX_VALUE;
        } else {
            iMo782roundToPx0680j_4 = interfaceC1307d.mo782roundToPx0680j_4(this.maxWidth);
            if (iMo782roundToPx0680j_4 < 0) {
                iMo782roundToPx0680j_4 = 0;
            }
        }
        if (Float.isNaN(this.maxHeight)) {
            iMo782roundToPx0680j_42 = Integer.MAX_VALUE;
        } else {
            iMo782roundToPx0680j_42 = interfaceC1307d.mo782roundToPx0680j_4(this.maxHeight);
            if (iMo782roundToPx0680j_42 < 0) {
                iMo782roundToPx0680j_42 = 0;
            }
        }
        if (Float.isNaN(this.minWidth)) {
            iMo782roundToPx0680j_43 = 0;
        } else {
            iMo782roundToPx0680j_43 = interfaceC1307d.mo782roundToPx0680j_4(this.minWidth);
            if (iMo782roundToPx0680j_43 < 0) {
                iMo782roundToPx0680j_43 = 0;
            }
            if (iMo782roundToPx0680j_43 > iMo782roundToPx0680j_4) {
                iMo782roundToPx0680j_43 = iMo782roundToPx0680j_4;
            }
            if (iMo782roundToPx0680j_43 == Integer.MAX_VALUE) {
            }
        }
        if (!Float.isNaN(this.minHeight)) {
            int iMo782roundToPx0680j_44 = interfaceC1307d.mo782roundToPx0680j_4(this.minHeight);
            if (iMo782roundToPx0680j_44 < 0) {
                iMo782roundToPx0680j_44 = 0;
            }
            if (iMo782roundToPx0680j_44 > iMo782roundToPx0680j_42) {
                iMo782roundToPx0680j_44 = iMo782roundToPx0680j_42;
            }
            if (iMo782roundToPx0680j_44 != Integer.MAX_VALUE) {
                i2 = iMo782roundToPx0680j_44;
            }
        }
        return AbstractC1306c.Constraints(iMo782roundToPx0680j_43, iMo782roundToPx0680j_4, i2, iMo782roundToPx0680j_42);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$3(AbstractC0974x0 abstractC0974x0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.placeRelative$default(aVar, abstractC0974x0, 0, 0, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    public final boolean getEnforceIncoming() {
        return this.enforceIncoming;
    }

    /* JADX INFO: renamed from: getMaxHeight-D9Ej5fM, reason: not valid java name */
    public final float m1036getMaxHeightD9Ej5fM() {
        return this.maxHeight;
    }

    /* JADX INFO: renamed from: getMaxWidth-D9Ej5fM, reason: not valid java name */
    public final float m1037getMaxWidthD9Ej5fM() {
        return this.maxWidth;
    }

    /* JADX INFO: renamed from: getMinHeight-D9Ej5fM, reason: not valid java name */
    public final float m1038getMinHeightD9Ej5fM() {
        return this.minHeight;
    }

    /* JADX INFO: renamed from: getMinWidth-D9Ej5fM, reason: not valid java name */
    public final float m1039getMinWidthD9Ej5fM() {
        return this.minWidth;
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        long jM1035getTargetConstraintsOenEA2s = m1035getTargetConstraintsOenEA2s(f2);
        if (C1305b.m5038getHasFixedHeightimpl(jM1035getTargetConstraintsOenEA2s)) {
            return C1305b.m5040getMaxHeightimpl(jM1035getTargetConstraintsOenEA2s);
        }
        if (!this.enforceIncoming) {
            i2 = AbstractC1306c.m5058constrainWidthK40F9xA(jM1035getTargetConstraintsOenEA2s, i2);
        }
        return AbstractC1306c.m5057constrainHeightK40F9xA(jM1035getTargetConstraintsOenEA2s, e2.maxIntrinsicHeight(i2));
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        long jM1035getTargetConstraintsOenEA2s = m1035getTargetConstraintsOenEA2s(f2);
        if (C1305b.m5039getHasFixedWidthimpl(jM1035getTargetConstraintsOenEA2s)) {
            return C1305b.m5041getMaxWidthimpl(jM1035getTargetConstraintsOenEA2s);
        }
        if (!this.enforceIncoming) {
            i2 = AbstractC1306c.m5057constrainHeightK40F9xA(jM1035getTargetConstraintsOenEA2s, i2);
        }
        return AbstractC1306c.m5058constrainWidthK40F9xA(jM1035getTargetConstraintsOenEA2s, e2.maxIntrinsicWidth(i2));
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int iM5043getMinWidthimpl;
        int iM5041getMaxWidthimpl;
        int iM5042getMinHeightimpl;
        int iM5040getMaxHeightimpl;
        long jConstraints;
        long jM1035getTargetConstraintsOenEA2s = m1035getTargetConstraintsOenEA2s(interfaceC0937e0);
        if (this.enforceIncoming) {
            jConstraints = AbstractC1306c.m5056constrainN9IONVI(j2, jM1035getTargetConstraintsOenEA2s);
        } else {
            if (Float.isNaN(this.minWidth)) {
                iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(j2);
                int iM5041getMaxWidthimpl2 = C1305b.m5041getMaxWidthimpl(jM1035getTargetConstraintsOenEA2s);
                if (iM5043getMinWidthimpl > iM5041getMaxWidthimpl2) {
                    iM5043getMinWidthimpl = iM5041getMaxWidthimpl2;
                }
            } else {
                iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(jM1035getTargetConstraintsOenEA2s);
            }
            if (Float.isNaN(this.maxWidth)) {
                iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(j2);
                int iM5043getMinWidthimpl2 = C1305b.m5043getMinWidthimpl(jM1035getTargetConstraintsOenEA2s);
                if (iM5041getMaxWidthimpl < iM5043getMinWidthimpl2) {
                    iM5041getMaxWidthimpl = iM5043getMinWidthimpl2;
                }
            } else {
                iM5041getMaxWidthimpl = C1305b.m5041getMaxWidthimpl(jM1035getTargetConstraintsOenEA2s);
            }
            if (Float.isNaN(this.minHeight)) {
                iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(j2);
                int iM5040getMaxHeightimpl2 = C1305b.m5040getMaxHeightimpl(jM1035getTargetConstraintsOenEA2s);
                if (iM5042getMinHeightimpl > iM5040getMaxHeightimpl2) {
                    iM5042getMinHeightimpl = iM5040getMaxHeightimpl2;
                }
            } else {
                iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(jM1035getTargetConstraintsOenEA2s);
            }
            if (Float.isNaN(this.maxHeight)) {
                iM5040getMaxHeightimpl = C1305b.m5040getMaxHeightimpl(j2);
                int iM5042getMinHeightimpl2 = C1305b.m5042getMinHeightimpl(jM1035getTargetConstraintsOenEA2s);
                if (iM5040getMaxHeightimpl < iM5042getMinHeightimpl2) {
                    iM5040getMaxHeightimpl = iM5042getMinHeightimpl2;
                }
            } else {
                iM5040getMaxHeightimpl = C1305b.m5040getMaxHeightimpl(jM1035getTargetConstraintsOenEA2s);
            }
            jConstraints = AbstractC1306c.Constraints(iM5043getMinWidthimpl, iM5041getMaxWidthimpl, iM5042getMinHeightimpl, iM5040getMaxHeightimpl);
        }
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(jConstraints);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new E(abstractC0974x0Mo3865measureBRTryo0, 3), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        long jM1035getTargetConstraintsOenEA2s = m1035getTargetConstraintsOenEA2s(f2);
        if (C1305b.m5038getHasFixedHeightimpl(jM1035getTargetConstraintsOenEA2s)) {
            return C1305b.m5040getMaxHeightimpl(jM1035getTargetConstraintsOenEA2s);
        }
        if (!this.enforceIncoming) {
            i2 = AbstractC1306c.m5058constrainWidthK40F9xA(jM1035getTargetConstraintsOenEA2s, i2);
        }
        return AbstractC1306c.m5057constrainHeightK40F9xA(jM1035getTargetConstraintsOenEA2s, e2.minIntrinsicHeight(i2));
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        long jM1035getTargetConstraintsOenEA2s = m1035getTargetConstraintsOenEA2s(f2);
        if (C1305b.m5039getHasFixedWidthimpl(jM1035getTargetConstraintsOenEA2s)) {
            return C1305b.m5041getMaxWidthimpl(jM1035getTargetConstraintsOenEA2s);
        }
        if (!this.enforceIncoming) {
            i2 = AbstractC1306c.m5057constrainHeightK40F9xA(jM1035getTargetConstraintsOenEA2s, i2);
        }
        return AbstractC1306c.m5058constrainWidthK40F9xA(jM1035getTargetConstraintsOenEA2s, e2.minIntrinsicWidth(i2));
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setEnforceIncoming(boolean z2) {
        this.enforceIncoming = z2;
    }

    /* JADX INFO: renamed from: setMaxHeight-0680j_4, reason: not valid java name */
    public final void m1040setMaxHeight0680j_4(float f2) {
        this.maxHeight = f2;
    }

    /* JADX INFO: renamed from: setMaxWidth-0680j_4, reason: not valid java name */
    public final void m1041setMaxWidth0680j_4(float f2) {
        this.maxWidth = f2;
    }

    /* JADX INFO: renamed from: setMinHeight-0680j_4, reason: not valid java name */
    public final void m1042setMinHeight0680j_4(float f2) {
        this.minHeight = f2;
    }

    /* JADX INFO: renamed from: setMinWidth-0680j_4, reason: not valid java name */
    public final void m1043setMinWidth0680j_4(float f2) {
        this.minWidth = f2;
    }

    public /* synthetic */ y0(float f2, float f3, float f4, float f5, boolean z2, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f2, (i2 & 2) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, (i2 & 4) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f4, (i2 & 8) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f5, z2, null);
    }

    private y0(float f2, float f3, float f4, float f5, boolean z2) {
        this.minWidth = f2;
        this.minHeight = f3;
        this.maxWidth = f4;
        this.maxHeight = f5;
        this.enforceIncoming = z2;
    }
}
