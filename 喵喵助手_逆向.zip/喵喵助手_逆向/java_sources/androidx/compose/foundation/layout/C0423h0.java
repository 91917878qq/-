package androidx.compose.foundation.layout;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.h0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0423h0 extends K {
    private final InterfaceC0421g0 paddingValues;

    public C0423h0(InterfaceC0421g0 interfaceC0421g0) {
        super(null);
        this.paddingValues = interfaceC0421g0;
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.foundation.layout.K
    public H0 calculateInsets(H0 h02) {
        return J0.add(J0.asInsets(this.paddingValues), h02);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0423h0) {
            return kotlin.jvm.internal.o.a(((C0423h0) obj).paddingValues, this.paddingValues);
        }
        return false;
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public int hashCode() {
        return this.paddingValues.hashCode();
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }
}
