package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.WrapContentElement;
import androidx.compose.ui.C0821d;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;

/* JADX INFO: loaded from: classes.dex */
public abstract class x0 {
    private static final FillElement FillWholeMaxHeight;
    private static final FillElement FillWholeMaxSize;
    private static final FillElement FillWholeMaxWidth;
    private static final WrapContentElement WrapContentHeightCenter;
    private static final WrapContentElement WrapContentHeightTop;
    private static final WrapContentElement WrapContentSizeCenter;
    private static final WrapContentElement WrapContentSizeTopStart;
    private static final WrapContentElement WrapContentWidthCenter;
    private static final WrapContentElement WrapContentWidthStart;

    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $height$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(float f2) {
            super(1);
            this.$height$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("height");
            c1065l1.setValue(C1311h.m5074boximpl(this.$height$inlined));
        }
    }

    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $max$inlined;
        final /* synthetic */ float $min$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(float f2, float f3) {
            super(1);
            this.$min$inlined = f2;
            this.$max$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("heightIn");
            D0.d.k(this.$min$inlined, c1065l1.getProperties(), "min", c1065l1).set("max", C1311h.m5074boximpl(this.$max$inlined));
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $height$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(float f2) {
            super(1);
            this.$height$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredHeight");
            c1065l1.setValue(C1311h.m5074boximpl(this.$height$inlined));
        }
    }

    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $max$inlined;
        final /* synthetic */ float $min$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(float f2, float f3) {
            super(1);
            this.$min$inlined = f2;
            this.$max$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredHeightIn");
            D0.d.k(this.$min$inlined, c1065l1.getProperties(), "min", c1065l1).set("max", C1311h.m5074boximpl(this.$max$inlined));
        }
    }

    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $size$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(float f2) {
            super(1);
            this.$size$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredSize");
            c1065l1.setValue(C1311h.m5074boximpl(this.$size$inlined));
        }
    }

    public static final class f extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $height$inlined;
        final /* synthetic */ float $width$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(float f2, float f3) {
            super(1);
            this.$width$inlined = f2;
            this.$height$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredSize");
            D0.d.k(this.$width$inlined, c1065l1.getProperties(), "width", c1065l1).set("height", C1311h.m5074boximpl(this.$height$inlined));
        }
    }

    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $maxHeight$inlined;
        final /* synthetic */ float $maxWidth$inlined;
        final /* synthetic */ float $minHeight$inlined;
        final /* synthetic */ float $minWidth$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(float f2, float f3, float f4, float f5) {
            super(1);
            this.$minWidth$inlined = f2;
            this.$minHeight$inlined = f3;
            this.$maxWidth$inlined = f4;
            this.$maxHeight$inlined = f5;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredSizeIn");
            D0.d.k(this.$maxWidth$inlined, D0.d.k(this.$minHeight$inlined, D0.d.k(this.$minWidth$inlined, c1065l1.getProperties(), "minWidth", c1065l1), "minHeight", c1065l1), "maxWidth", c1065l1).set("maxHeight", C1311h.m5074boximpl(this.$maxHeight$inlined));
        }
    }

    public static final class h extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $width$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(float f2) {
            super(1);
            this.$width$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredWidth");
            c1065l1.setValue(C1311h.m5074boximpl(this.$width$inlined));
        }
    }

    public static final class i extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $max$inlined;
        final /* synthetic */ float $min$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(float f2, float f3) {
            super(1);
            this.$min$inlined = f2;
            this.$max$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredWidthIn");
            D0.d.k(this.$min$inlined, c1065l1.getProperties(), "min", c1065l1).set("max", C1311h.m5074boximpl(this.$max$inlined));
        }
    }

    public static final class j extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $size$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(float f2) {
            super(1);
            this.$size$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("size");
            c1065l1.setValue(C1311h.m5074boximpl(this.$size$inlined));
        }
    }

    public static final class k extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $height$inlined;
        final /* synthetic */ float $width$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public k(float f2, float f3) {
            super(1);
            this.$width$inlined = f2;
            this.$height$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("size");
            D0.d.k(this.$width$inlined, c1065l1.getProperties(), "width", c1065l1).set("height", C1311h.m5074boximpl(this.$height$inlined));
        }
    }

    public static final class l extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $maxHeight$inlined;
        final /* synthetic */ float $maxWidth$inlined;
        final /* synthetic */ float $minHeight$inlined;
        final /* synthetic */ float $minWidth$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public l(float f2, float f3, float f4, float f5) {
            super(1);
            this.$minWidth$inlined = f2;
            this.$minHeight$inlined = f3;
            this.$maxWidth$inlined = f4;
            this.$maxHeight$inlined = f5;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("sizeIn");
            D0.d.k(this.$maxWidth$inlined, D0.d.k(this.$minHeight$inlined, D0.d.k(this.$minWidth$inlined, c1065l1.getProperties(), "minWidth", c1065l1), "minHeight", c1065l1), "maxWidth", c1065l1).set("maxHeight", C1311h.m5074boximpl(this.$maxHeight$inlined));
        }
    }

    public static final class m extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $width$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public m(float f2) {
            super(1);
            this.$width$inlined = f2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("width");
            c1065l1.setValue(C1311h.m5074boximpl(this.$width$inlined));
        }
    }

    public static final class n extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ float $max$inlined;
        final /* synthetic */ float $min$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public n(float f2, float f3) {
            super(1);
            this.$min$inlined = f2;
            this.$max$inlined = f3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("widthIn");
            D0.d.k(this.$min$inlined, c1065l1.getProperties(), "min", c1065l1).set("max", C1311h.m5074boximpl(this.$max$inlined));
        }
    }

    static {
        FillElement.a aVar = FillElement.Companion;
        FillWholeMaxWidth = aVar.width(1.0f);
        FillWholeMaxHeight = aVar.height(1.0f);
        FillWholeMaxSize = aVar.size(1.0f);
        WrapContentElement.a aVar2 = WrapContentElement.Companion;
        C0821d c0821d = InterfaceC0849g.Companion;
        WrapContentWidthCenter = aVar2.width(c0821d.getCenterHorizontally(), false);
        WrapContentWidthStart = aVar2.width(c0821d.getStart(), false);
        WrapContentHeightCenter = aVar2.height(c0821d.getCenterVertically(), false);
        WrapContentHeightTop = aVar2.height(c0821d.getTop(), false);
        WrapContentSizeCenter = aVar2.size(c0821d.getCenter(), false);
        WrapContentSizeTopStart = aVar2.size(c0821d.getTopStart(), false);
    }

    /* JADX INFO: renamed from: defaultMinSize-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1011defaultMinSizeVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new UnspecifiedConstraintsElement(f2, f3, null));
    }

    /* JADX INFO: renamed from: defaultMinSize-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1012defaultMinSizeVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1011defaultMinSizeVpY3zN4(xVar, f2, f3);
    }

    public static final androidx.compose.ui.x fillMaxHeight(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(f2 == 1.0f ? FillWholeMaxHeight : FillElement.Companion.height(f2));
    }

    public static /* synthetic */ androidx.compose.ui.x fillMaxHeight$default(androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return fillMaxHeight(xVar, f2);
    }

    public static final androidx.compose.ui.x fillMaxSize(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(f2 == 1.0f ? FillWholeMaxSize : FillElement.Companion.size(f2));
    }

    public static /* synthetic */ androidx.compose.ui.x fillMaxSize$default(androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return fillMaxSize(xVar, f2);
    }

    public static final androidx.compose.ui.x fillMaxWidth(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(f2 == 1.0f ? FillWholeMaxWidth : FillElement.Companion.width(f2));
    }

    public static /* synthetic */ androidx.compose.ui.x fillMaxWidth$default(androidx.compose.ui.x xVar, float f2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        return fillMaxWidth(xVar, f2);
    }

    /* JADX INFO: renamed from: height-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1013height3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(0.0f, f2, 0.0f, f2, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(f2) : AbstractC1056i1.getNoInspectorInfo(), 5, null));
    }

    /* JADX INFO: renamed from: heightIn-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1014heightInVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(0.0f, f2, 0.0f, f3, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new b(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), 5, null));
    }

    /* JADX INFO: renamed from: heightIn-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1015heightInVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1014heightInVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: renamed from: requiredHeight-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1016requiredHeight3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(0.0f, f2, 0.0f, f2, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new c(f2) : AbstractC1056i1.getNoInspectorInfo(), 5, null));
    }

    /* JADX INFO: renamed from: requiredHeightIn-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1017requiredHeightInVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(0.0f, f2, 0.0f, f3, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new d(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), 5, null));
    }

    /* JADX INFO: renamed from: requiredHeightIn-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1018requiredHeightInVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1017requiredHeightInVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: renamed from: requiredSize-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1019requiredSize3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(f2, f2, f2, f2, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new e(f2) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: requiredSize-6HolHcs, reason: not valid java name */
    public static final androidx.compose.ui.x m1020requiredSize6HolHcs(androidx.compose.ui.x xVar, long j2) {
        return m1021requiredSizeVpY3zN4(xVar, e0.l.m5174getWidthD9Ej5fM(j2), e0.l.m5172getHeightD9Ej5fM(j2));
    }

    /* JADX INFO: renamed from: requiredSize-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1021requiredSizeVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(f2, f3, f2, f3, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new f(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: requiredSizeIn-qDBjuR0, reason: not valid java name */
    public static final androidx.compose.ui.x m1022requiredSizeInqDBjuR0(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5) {
        return xVar.then(new SizeElement(f2, f3, f4, f5, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new g(f2, f3, f4, f5) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: requiredSizeIn-qDBjuR0$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1023requiredSizeInqDBjuR0$default(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1022requiredSizeInqDBjuR0(xVar, f2, f3, f4, f5);
    }

    /* JADX INFO: renamed from: requiredWidth-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1024requiredWidth3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(f2, 0.0f, f2, 0.0f, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new h(f2) : AbstractC1056i1.getNoInspectorInfo(), 10, null));
    }

    /* JADX INFO: renamed from: requiredWidthIn-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1025requiredWidthInVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(f2, 0.0f, f3, 0.0f, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new i(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), 10, null));
    }

    /* JADX INFO: renamed from: requiredWidthIn-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1026requiredWidthInVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1025requiredWidthInVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: renamed from: size-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1027size3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(f2, f2, f2, f2, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new j(f2) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: size-6HolHcs, reason: not valid java name */
    public static final androidx.compose.ui.x m1028size6HolHcs(androidx.compose.ui.x xVar, long j2) {
        return m1029sizeVpY3zN4(xVar, e0.l.m5174getWidthD9Ej5fM(j2), e0.l.m5172getHeightD9Ej5fM(j2));
    }

    /* JADX INFO: renamed from: size-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1029sizeVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(f2, f3, f2, f3, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new k(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: sizeIn-qDBjuR0, reason: not valid java name */
    public static final androidx.compose.ui.x m1030sizeInqDBjuR0(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5) {
        return xVar.then(new SizeElement(f2, f3, f4, f5, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new l(f2, f3, f4, f5) : AbstractC1056i1.getNoInspectorInfo(), null));
    }

    /* JADX INFO: renamed from: sizeIn-qDBjuR0$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1031sizeInqDBjuR0$default(androidx.compose.ui.x xVar, float f2, float f3, float f4, float f5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 4) != 0) {
            f4 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 8) != 0) {
            f5 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1030sizeInqDBjuR0(xVar, f2, f3, f4, f5);
    }

    /* JADX INFO: renamed from: width-3ABfNKs, reason: not valid java name */
    public static final androidx.compose.ui.x m1032width3ABfNKs(androidx.compose.ui.x xVar, float f2) {
        return xVar.then(new SizeElement(f2, 0.0f, f2, 0.0f, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new m(f2) : AbstractC1056i1.getNoInspectorInfo(), 10, null));
    }

    /* JADX INFO: renamed from: widthIn-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m1033widthInVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new SizeElement(f2, 0.0f, f3, 0.0f, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new n(f2, f3) : AbstractC1056i1.getNoInspectorInfo(), 10, null));
    }

    /* JADX INFO: renamed from: widthIn-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m1034widthInVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.Companion.m5096getUnspecifiedD9Ej5fM();
        }
        return m1033widthInVpY3zN4(xVar, f2, f3);
    }

    public static final androidx.compose.ui.x wrapContentHeight(androidx.compose.ui.x xVar, InterfaceC0823f interfaceC0823f, boolean z2) {
        C0821d c0821d = InterfaceC0849g.Companion;
        return xVar.then((!kotlin.jvm.internal.o.a(interfaceC0823f, c0821d.getCenterVertically()) || z2) ? (!kotlin.jvm.internal.o.a(interfaceC0823f, c0821d.getTop()) || z2) ? WrapContentElement.Companion.height(interfaceC0823f, z2) : WrapContentHeightTop : WrapContentHeightCenter);
    }

    public static /* synthetic */ androidx.compose.ui.x wrapContentHeight$default(androidx.compose.ui.x xVar, InterfaceC0823f interfaceC0823f, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0823f = InterfaceC0849g.Companion.getCenterVertically();
        }
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return wrapContentHeight(xVar, interfaceC0823f, z2);
    }

    public static final androidx.compose.ui.x wrapContentSize(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g, boolean z2) {
        C0821d c0821d = InterfaceC0849g.Companion;
        return xVar.then((!kotlin.jvm.internal.o.a(interfaceC0849g, c0821d.getCenter()) || z2) ? (!kotlin.jvm.internal.o.a(interfaceC0849g, c0821d.getTopStart()) || z2) ? WrapContentElement.Companion.size(interfaceC0849g, z2) : WrapContentSizeTopStart : WrapContentSizeCenter);
    }

    public static /* synthetic */ androidx.compose.ui.x wrapContentSize$default(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0849g = InterfaceC0849g.Companion.getCenter();
        }
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return wrapContentSize(xVar, interfaceC0849g, z2);
    }

    public static final androidx.compose.ui.x wrapContentWidth(androidx.compose.ui.x xVar, InterfaceC0822e interfaceC0822e, boolean z2) {
        C0821d c0821d = InterfaceC0849g.Companion;
        return xVar.then((!kotlin.jvm.internal.o.a(interfaceC0822e, c0821d.getCenterHorizontally()) || z2) ? (!kotlin.jvm.internal.o.a(interfaceC0822e, c0821d.getStart()) || z2) ? WrapContentElement.Companion.width(interfaceC0822e, z2) : WrapContentWidthStart : WrapContentWidthCenter);
    }

    public static /* synthetic */ androidx.compose.ui.x wrapContentWidth$default(androidx.compose.ui.x xVar, InterfaceC0822e interfaceC0822e, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0822e = InterfaceC0849g.Companion.getCenterHorizontally();
        }
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return wrapContentWidth(xVar, interfaceC0822e, z2);
    }
}
