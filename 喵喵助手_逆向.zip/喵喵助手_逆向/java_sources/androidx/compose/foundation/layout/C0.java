package androidx.compose.foundation.layout;

/* JADX INFO: loaded from: classes.dex */
public final class C0 extends K {
    private final H0 insets;

    public C0(H0 h02) {
        super(null);
        this.insets = h02;
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.foundation.layout.K
    public H0 calculateInsets(H0 h02) {
        return J0.union(this.insets, h02);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0) {
            return kotlin.jvm.internal.o.a(((C0) obj).insets, this.insets);
        }
        return false;
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public int hashCode() {
        return this.insets.hashCode();
    }

    @Override // androidx.compose.foundation.layout.K, androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }
}
