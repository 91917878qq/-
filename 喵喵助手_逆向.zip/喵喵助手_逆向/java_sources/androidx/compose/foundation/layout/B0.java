package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class B0 implements H0 {
    private final H0 first;
    private final H0 second;

    public B0(H0 h02, H0 h03) {
        this.first = h02;
        this.second = h03;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof B0)) {
            return false;
        }
        B0 b02 = (B0) obj;
        return kotlin.jvm.internal.o.a(b02.first, this.first) && kotlin.jvm.internal.o.a(b02.second, this.second);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return Math.max(this.first.getBottom(interfaceC1307d), this.second.getBottom(interfaceC1307d));
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return Math.max(this.first.getLeft(interfaceC1307d, uVar), this.second.getLeft(interfaceC1307d, uVar));
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return Math.max(this.first.getRight(interfaceC1307d, uVar), this.second.getRight(interfaceC1307d, uVar));
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return Math.max(this.first.getTop(interfaceC1307d), this.second.getTop(interfaceC1307d));
    }

    public int hashCode() {
        return (this.second.hashCode() * 31) + this.first.hashCode();
    }

    public String toString() {
        return "(" + this.first + " ∪ " + this.second + ')';
    }
}
