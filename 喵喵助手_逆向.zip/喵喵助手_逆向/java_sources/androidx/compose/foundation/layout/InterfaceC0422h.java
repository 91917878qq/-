package androidx.compose.foundation.layout;

import e0.C1311h;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0422h extends InterfaceC0420g, InterfaceC0424i {
    @Override // androidx.compose.foundation.layout.InterfaceC0420g
    /* synthetic */ void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2);

    /* synthetic */ void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2);

    @Override // androidx.compose.foundation.layout.InterfaceC0420g
    /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
    default float mo982getSpacingD9Ej5fM() {
        return C1311h.m5076constructorimpl(0);
    }
}
