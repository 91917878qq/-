package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0418f {
    public static final int $stable = 0;
    public static final C0418f INSTANCE = new C0418f();
    private static final InterfaceC0420g Start = new i();
    private static final InterfaceC0420g End = new d();
    private static final InterfaceC0424i Top = new j();
    private static final InterfaceC0424i Bottom = new b();
    private static final InterfaceC0422h Center = new c();
    private static final InterfaceC0422h SpaceEvenly = new g();
    private static final InterfaceC0422h SpaceBetween = new C0040f();
    private static final InterfaceC0422h SpaceAround = new e();

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a */
    public static final class a {
        public static final int $stable = 0;
        public static final a INSTANCE = new a();
        private static final InterfaceC0420g Left = new b();
        private static final InterfaceC0420g Center = new C0038a();
        private static final InterfaceC0420g Right = new c();
        private static final InterfaceC0420g SpaceBetween = new e();
        private static final InterfaceC0420g SpaceEvenly = new C0039f();
        private static final InterfaceC0420g SpaceAround = new d();

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$a, reason: collision with other inner class name */
        public static final class C0038a implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeCenter$foundation_layout(i2, iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM, reason: not valid java name */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#Center";
            }
        }

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$b */
        public static final class b implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeLeftOrTop$foundation_layout(iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#Left";
            }
        }

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$c */
        public static final class c implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeRightOrBottom$foundation_layout(i2, iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#Right";
            }
        }

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$d */
        public static final class d implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeSpaceAround$foundation_layout(i2, iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#SpaceAround";
            }
        }

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$e */
        public static final class e implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeSpaceBetween$foundation_layout(i2, iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#SpaceBetween";
            }
        }

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$a$f, reason: collision with other inner class name */
        public static final class C0039f implements InterfaceC0420g {
            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
                C0418f.INSTANCE.placeSpaceEvenly$foundation_layout(i2, iArr, iArr2, false);
            }

            @Override // androidx.compose.foundation.layout.InterfaceC0420g
            /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
            public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
                return super.mo982getSpacingD9Ej5fM();
            }

            public String toString() {
                return "AbsoluteArrangement#SpaceEvenly";
            }
        }

        private a() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final int aligned$lambda$2(InterfaceC0822e interfaceC0822e, int i2, e0.u uVar) {
            return interfaceC0822e.align(0, i2, uVar);
        }

        public static /* synthetic */ void getCenter$annotations() {
        }

        public static /* synthetic */ void getLeft$annotations() {
        }

        public static /* synthetic */ void getRight$annotations() {
        }

        public static /* synthetic */ void getSpaceAround$annotations() {
        }

        public static /* synthetic */ void getSpaceBetween$annotations() {
        }

        public static /* synthetic */ void getSpaceEvenly$annotations() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final int spacedBy_D5KLDUw$lambda$0(InterfaceC0822e interfaceC0822e, int i2, e0.u uVar) {
            return interfaceC0822e.align(0, i2, uVar);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final int spacedBy_D5KLDUw$lambda$1(InterfaceC0823f interfaceC0823f, int i2, e0.u uVar) {
            return interfaceC0823f.align(0, i2);
        }

        public final InterfaceC0420g aligned(InterfaceC0822e interfaceC0822e) {
            return new h(C1311h.m5076constructorimpl(0), false, new C0414d(interfaceC0822e, 2), null);
        }

        public final InterfaceC0420g getCenter() {
            return Center;
        }

        public final InterfaceC0420g getLeft() {
            return Left;
        }

        public final InterfaceC0420g getRight() {
            return Right;
        }

        public final InterfaceC0420g getSpaceAround() {
            return SpaceAround;
        }

        public final InterfaceC0420g getSpaceBetween() {
            return SpaceBetween;
        }

        public final InterfaceC0420g getSpaceEvenly() {
            return SpaceEvenly;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX INFO: renamed from: spacedBy-0680j_4, reason: not valid java name */
        public final InterfaceC0422h m979spacedBy0680j_4(float f2) {
            return new h(f2, false, null, 0 == true ? 1 : 0);
        }

        /* JADX INFO: renamed from: spacedBy-D5KLDUw, reason: not valid java name */
        public final InterfaceC0420g m980spacedByD5KLDUw(float f2, InterfaceC0822e interfaceC0822e) {
            return new h(f2, false, new C0414d(interfaceC0822e, 3), null);
        }

        /* JADX INFO: renamed from: spacedBy-D5KLDUw, reason: not valid java name */
        public final InterfaceC0424i m981spacedByD5KLDUw(float f2, InterfaceC0823f interfaceC0823f) {
            return new h(f2, false, new C0416e(interfaceC0823f, 2), null);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$b */
    public static final class b implements InterfaceC0424i {
        @Override // androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeRightOrBottom$foundation_layout(i2, iArr, iArr2, false);
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0424i
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM, reason: not valid java name */
        public /* bridge */ /* synthetic */ float mo983getSpacingD9Ej5fM() {
            return super.mo983getSpacingD9Ej5fM();
        }

        public String toString() {
            return "Arrangement#Bottom";
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$d */
    public static final class d implements InterfaceC0420g {
        @Override // androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeRightOrBottom$foundation_layout(i2, iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeLeftOrTop$foundation_layout(iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
            return super.mo982getSpacingD9Ej5fM();
        }

        public String toString() {
            return "Arrangement#End";
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$h */
    public static final class h implements InterfaceC0422h {
        public static final int $stable = 0;
        private final h1.e alignment;
        private final boolean rtlMirror;
        private final float space;
        private final float spacing;

        public /* synthetic */ h(float f2, boolean z2, h1.e eVar, AbstractC1378g abstractC1378g) {
            this(f2, z2, eVar);
        }

        /* JADX INFO: renamed from: copy-8Feqmps$default, reason: not valid java name */
        public static /* synthetic */ h m984copy8Feqmps$default(h hVar, float f2, boolean z2, h1.e eVar, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                f2 = hVar.space;
            }
            if ((i2 & 2) != 0) {
                z2 = hVar.rtlMirror;
            }
            if ((i2 & 4) != 0) {
                eVar = hVar.alignment;
            }
            return hVar.m986copy8Feqmps(f2, z2, eVar);
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            int i3;
            int i4;
            if (iArr.length == 0) {
                return;
            }
            int iMo782roundToPx0680j_4 = interfaceC1307d.mo782roundToPx0680j_4(this.space);
            boolean z2 = this.rtlMirror && uVar == e0.u.Rtl;
            C0418f c0418f = C0418f.INSTANCE;
            if (z2) {
                int length = iArr.length - 1;
                i3 = 0;
                i4 = 0;
                while (-1 < length) {
                    int i5 = iArr[length];
                    int iMin = Math.min(i3, i2 - i5);
                    iArr2[length] = iMin;
                    int iMin2 = Math.min(iMo782roundToPx0680j_4, (i2 - iMin) - i5);
                    int i6 = iArr2[length] + i5 + iMin2;
                    length--;
                    i4 = iMin2;
                    i3 = i6;
                }
            } else {
                int length2 = iArr.length;
                int i7 = 0;
                i3 = 0;
                i4 = 0;
                int i8 = 0;
                while (i7 < length2) {
                    int i9 = iArr[i7];
                    int iMin3 = Math.min(i3, i2 - i9);
                    iArr2[i8] = iMin3;
                    int iMin4 = Math.min(iMo782roundToPx0680j_4, (i2 - iMin3) - i9);
                    int i10 = iArr2[i8] + i9 + iMin4;
                    i7++;
                    i8++;
                    i4 = iMin4;
                    i3 = i10;
                }
            }
            int i11 = i3 - i4;
            h1.e eVar = this.alignment;
            if (eVar == null || i11 >= i2) {
                return;
            }
            int iIntValue = ((Number) eVar.invoke(Integer.valueOf(i2 - i11), uVar)).intValue();
            int length3 = iArr2.length;
            for (int i12 = 0; i12 < length3; i12++) {
                iArr2[i12] = iArr2[i12] + iIntValue;
            }
        }

        /* JADX INFO: renamed from: component1-D9Ej5fM, reason: not valid java name */
        public final float m985component1D9Ej5fM() {
            return this.space;
        }

        public final boolean component2() {
            return this.rtlMirror;
        }

        public final h1.e component3() {
            return this.alignment;
        }

        /* JADX INFO: renamed from: copy-8Feqmps, reason: not valid java name */
        public final h m986copy8Feqmps(float f2, boolean z2, h1.e eVar) {
            return new h(f2, z2, eVar, null);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof h)) {
                return false;
            }
            h hVar = (h) obj;
            return C1311h.m5081equalsimpl0(this.space, hVar.space) && this.rtlMirror == hVar.rtlMirror && kotlin.jvm.internal.o.a(this.alignment, hVar.alignment);
        }

        public final h1.e getAlignment() {
            return this.alignment;
        }

        public final boolean getRtlMirror() {
            return this.rtlMirror;
        }

        /* JADX INFO: renamed from: getSpace-D9Ej5fM, reason: not valid java name */
        public final float m987getSpaceD9Ej5fM() {
            return this.space;
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public float mo982getSpacingD9Ej5fM() {
            return this.spacing;
        }

        public int hashCode() {
            int iC = D0.d.c(C1311h.m5082hashCodeimpl(this.space) * 31, 31, this.rtlMirror);
            h1.e eVar = this.alignment;
            return iC + (eVar == null ? 0 : eVar.hashCode());
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.rtlMirror ? "" : "Absolute");
            sb.append("Arrangement#spacedAligned(");
            D0.d.u(this.space, sb, ", ");
            sb.append(this.alignment);
            sb.append(')');
            return sb.toString();
        }

        private h(float f2, boolean z2, h1.e eVar) {
            this.space = f2;
            this.rtlMirror = z2;
            this.alignment = eVar;
            this.spacing = f2;
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            arrange(interfaceC1307d, i2, iArr, e0.u.Ltr, iArr2);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$i */
    public static final class i implements InterfaceC0420g {
        @Override // androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeLeftOrTop$foundation_layout(iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeRightOrBottom$foundation_layout(i2, iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public /* bridge */ /* synthetic */ float mo982getSpacingD9Ej5fM() {
            return super.mo982getSpacingD9Ej5fM();
        }

        public String toString() {
            return "Arrangement#Start";
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$j */
    public static final class j implements InterfaceC0424i {
        @Override // androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeLeftOrTop$foundation_layout(iArr, iArr2, false);
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0424i
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public /* bridge */ /* synthetic */ float mo983getSpacingD9Ej5fM() {
            return super.mo983getSpacingD9Ej5fM();
        }

        public String toString() {
            return "Arrangement#Top";
        }
    }

    private C0418f() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int aligned$lambda$3(InterfaceC0822e interfaceC0822e, int i2, e0.u uVar) {
        return interfaceC0822e.align(0, i2, uVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int aligned$lambda$4(InterfaceC0823f interfaceC0823f, int i2, e0.u uVar) {
        return interfaceC0823f.align(0, i2);
    }

    private final void forEachIndexed(int[] iArr, boolean z2, h1.e eVar) {
        if (!z2) {
            int length = iArr.length;
            int i2 = 0;
            int i3 = 0;
            while (i2 < length) {
                eVar.invoke(Integer.valueOf(i3), Integer.valueOf(iArr[i2]));
                i2++;
                i3++;
            }
            return;
        }
        int length2 = iArr.length;
        while (true) {
            length2--;
            if (-1 >= length2) {
                return;
            } else {
                eVar.invoke(Integer.valueOf(length2), Integer.valueOf(iArr[length2]));
            }
        }
    }

    public static /* synthetic */ void getBottom$annotations() {
    }

    public static /* synthetic */ void getCenter$annotations() {
    }

    public static /* synthetic */ void getEnd$annotations() {
    }

    public static /* synthetic */ void getSpaceAround$annotations() {
    }

    public static /* synthetic */ void getSpaceBetween$annotations() {
    }

    public static /* synthetic */ void getSpaceEvenly$annotations() {
    }

    public static /* synthetic */ void getStart$annotations() {
    }

    public static /* synthetic */ void getTop$annotations() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int spacedBy_0680j_4$lambda$0(int i2, e0.u uVar) {
        return InterfaceC0849g.Companion.getStart().align(0, i2, uVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int spacedBy_D5KLDUw$lambda$1(InterfaceC0822e interfaceC0822e, int i2, e0.u uVar) {
        return interfaceC0822e.align(0, i2, uVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int spacedBy_D5KLDUw$lambda$2(InterfaceC0823f interfaceC0823f, int i2, e0.u uVar) {
        return interfaceC0823f.align(0, i2);
    }

    public final InterfaceC0420g aligned(InterfaceC0822e interfaceC0822e) {
        return new h(C1311h.m5076constructorimpl(0), 1 == true ? 1 : 0, new C0414d(interfaceC0822e, 1), null);
    }

    public final InterfaceC0424i getBottom() {
        return Bottom;
    }

    public final InterfaceC0422h getCenter() {
        return Center;
    }

    public final InterfaceC0420g getEnd() {
        return End;
    }

    public final InterfaceC0422h getSpaceAround() {
        return SpaceAround;
    }

    public final InterfaceC0422h getSpaceBetween() {
        return SpaceBetween;
    }

    public final InterfaceC0422h getSpaceEvenly() {
        return SpaceEvenly;
    }

    public final InterfaceC0420g getStart() {
        return Start;
    }

    public final InterfaceC0424i getTop() {
        return Top;
    }

    public final void placeCenter$foundation_layout(int i2, int[] iArr, int[] iArr2, boolean z2) {
        int i3 = 0;
        int i4 = 0;
        for (int i5 : iArr) {
            i4 += i5;
        }
        float f2 = (i2 - i4) / 2;
        if (!z2) {
            int length = iArr.length;
            int i6 = 0;
            while (i3 < length) {
                int i7 = iArr[i3];
                iArr2[i6] = Math.round(f2);
                f2 += i7;
                i3++;
                i6++;
            }
            return;
        }
        int length2 = iArr.length;
        while (true) {
            length2--;
            if (-1 >= length2) {
                return;
            }
            int i8 = iArr[length2];
            iArr2[length2] = Math.round(f2);
            f2 += i8;
        }
    }

    public final void placeLeftOrTop$foundation_layout(int[] iArr, int[] iArr2, boolean z2) {
        int i2 = 0;
        if (!z2) {
            int length = iArr.length;
            int i3 = 0;
            int i4 = 0;
            while (i2 < length) {
                int i5 = iArr[i2];
                iArr2[i3] = i4;
                i4 += i5;
                i2++;
                i3++;
            }
            return;
        }
        int length2 = iArr.length;
        while (true) {
            length2--;
            if (-1 >= length2) {
                return;
            }
            int i6 = iArr[length2];
            iArr2[length2] = i2;
            i2 += i6;
        }
    }

    public final void placeRightOrBottom$foundation_layout(int i2, int[] iArr, int[] iArr2, boolean z2) {
        int i3 = 0;
        int i4 = 0;
        for (int i5 : iArr) {
            i4 += i5;
        }
        int i6 = i2 - i4;
        if (!z2) {
            int length = iArr.length;
            int i7 = 0;
            while (i3 < length) {
                int i8 = iArr[i3];
                iArr2[i7] = i6;
                i6 += i8;
                i3++;
                i7++;
            }
            return;
        }
        int length2 = iArr.length;
        while (true) {
            length2--;
            if (-1 >= length2) {
                return;
            }
            int i9 = iArr[length2];
            iArr2[length2] = i6;
            i6 += i9;
        }
    }

    public final void placeSpaceAround$foundation_layout(int i2, int[] iArr, int[] iArr2, boolean z2) {
        int i3 = 0;
        int i4 = 0;
        for (int i5 : iArr) {
            i4 += i5;
        }
        float length = !(iArr.length == 0) ? (i2 - i4) / iArr.length : 0.0f;
        float f2 = length / 2;
        if (z2) {
            for (int length2 = iArr.length - 1; -1 < length2; length2--) {
                int i6 = iArr[length2];
                iArr2[length2] = Math.round(f2);
                f2 += i6 + length;
            }
            return;
        }
        int length3 = iArr.length;
        int i7 = 0;
        while (i3 < length3) {
            int i8 = iArr[i3];
            iArr2[i7] = Math.round(f2);
            f2 += i8 + length;
            i3++;
            i7++;
        }
    }

    public final void placeSpaceBetween$foundation_layout(int i2, int[] iArr, int[] iArr2, boolean z2) {
        if (iArr.length == 0) {
            return;
        }
        int i3 = 0;
        int i4 = 0;
        for (int i5 : iArr) {
            i4 += i5;
        }
        float fMax = (i2 - i4) / Math.max(iArr.length - 1, 1);
        float f2 = (z2 && iArr.length == 1) ? fMax : 0.0f;
        if (z2) {
            for (int length = iArr.length - 1; -1 < length; length--) {
                int i6 = iArr[length];
                iArr2[length] = Math.round(f2);
                f2 += i6 + fMax;
            }
            return;
        }
        int length2 = iArr.length;
        int i7 = 0;
        while (i3 < length2) {
            int i8 = iArr[i3];
            iArr2[i7] = Math.round(f2);
            f2 += i8 + fMax;
            i3++;
            i7++;
        }
    }

    public final void placeSpaceEvenly$foundation_layout(int i2, int[] iArr, int[] iArr2, boolean z2) {
        int i3 = 0;
        int i4 = 0;
        for (int i5 : iArr) {
            i4 += i5;
        }
        float length = (i2 - i4) / (iArr.length + 1);
        if (z2) {
            float f2 = length;
            for (int length2 = iArr.length - 1; -1 < length2; length2--) {
                int i6 = iArr[length2];
                iArr2[length2] = Math.round(f2);
                f2 += i6 + length;
            }
            return;
        }
        int length3 = iArr.length;
        float f3 = length;
        int i7 = 0;
        while (i3 < length3) {
            int i8 = iArr[i3];
            iArr2[i7] = Math.round(f3);
            f3 += i8 + length;
            i3++;
            i7++;
        }
    }

    /* JADX INFO: renamed from: spacedBy-0680j_4, reason: not valid java name */
    public final InterfaceC0422h m976spacedBy0680j_4(float f2) {
        return new h(f2, true, new O0.M(19), null);
    }

    /* JADX INFO: renamed from: spacedBy-D5KLDUw, reason: not valid java name */
    public final InterfaceC0420g m977spacedByD5KLDUw(float f2, InterfaceC0822e interfaceC0822e) {
        return new h(f2, true, new C0414d(interfaceC0822e, 0), null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: spacedBy-D5KLDUw, reason: not valid java name */
    public final InterfaceC0424i m978spacedByD5KLDUw(float f2, InterfaceC0823f interfaceC0823f) {
        return new h(f2, 0 == true ? 1 : 0, new C0416e(interfaceC0823f, 0), null);
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$c */
    public static final class c implements InterfaceC0422h {
        private final float spacing = C1311h.m5076constructorimpl(0);

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeCenter$foundation_layout(i2, iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeCenter$foundation_layout(i2, iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public float mo982getSpacingD9Ej5fM() {
            return this.spacing;
        }

        public String toString() {
            return "Arrangement#Center";
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeCenter$foundation_layout(i2, iArr, iArr2, false);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$e */
    public static final class e implements InterfaceC0422h {
        private final float spacing = C1311h.m5076constructorimpl(0);

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeSpaceAround$foundation_layout(i2, iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeSpaceAround$foundation_layout(i2, iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public float mo982getSpacingD9Ej5fM() {
            return this.spacing;
        }

        public String toString() {
            return "Arrangement#SpaceAround";
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeSpaceAround$foundation_layout(i2, iArr, iArr2, false);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$f, reason: collision with other inner class name */
    public static final class C0040f implements InterfaceC0422h {
        private final float spacing = C1311h.m5076constructorimpl(0);

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeSpaceBetween$foundation_layout(i2, iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeSpaceBetween$foundation_layout(i2, iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public float mo982getSpacingD9Ej5fM() {
            return this.spacing;
        }

        public String toString() {
            return "Arrangement#SpaceBetween";
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeSpaceBetween$foundation_layout(i2, iArr, iArr2, false);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.f$g */
    public static final class g implements InterfaceC0422h {
        private final float spacing = C1311h.m5076constructorimpl(0);

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2) {
            if (uVar == e0.u.Ltr) {
                C0418f.INSTANCE.placeSpaceEvenly$foundation_layout(i2, iArr, iArr2, false);
            } else {
                C0418f.INSTANCE.placeSpaceEvenly$foundation_layout(i2, iArr, iArr2, true);
            }
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0420g
        /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
        public float mo982getSpacingD9Ej5fM() {
            return this.spacing;
        }

        public String toString() {
            return "Arrangement#SpaceEvenly";
        }

        @Override // androidx.compose.foundation.layout.InterfaceC0422h, androidx.compose.foundation.layout.InterfaceC0424i
        public void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, int[] iArr2) {
            C0418f.INSTANCE.placeSpaceEvenly$foundation_layout(i2, iArr, iArr2, false);
        }
    }

    public final InterfaceC0424i aligned(InterfaceC0823f interfaceC0823f) {
        return new h(C1311h.m5076constructorimpl(0), false, new C0416e(interfaceC0823f, 1), null);
    }
}
