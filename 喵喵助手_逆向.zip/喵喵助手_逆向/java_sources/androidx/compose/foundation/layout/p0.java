package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import java.util.List;
import p.AbstractC1408a;

/* JADX INFO: loaded from: classes.dex */
public abstract class p0 {
    public static final InterfaceC0935d0 measure(InterfaceC0437o0 interfaceC0437o0, int i2, int i3, int i4, int i5, int i6, InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, AbstractC0974x0[] abstractC0974x0Arr, int i7, int i8, int[] iArr, int i9) {
        int i10;
        int i11;
        int i12;
        int i13;
        float f2;
        I flowLayoutData;
        int iMax;
        int i14;
        int i15;
        int i16;
        int[] iArr2;
        int i17;
        I flowLayoutData2;
        long j2 = i6;
        int i18 = i8 - i7;
        int[] iArr3 = new int[i18];
        int i19 = i7;
        float f3 = 0.0f;
        int i20 = 0;
        int i21 = 0;
        int i22 = 0;
        boolean z2 = false;
        int i23 = 0;
        while (true) {
            Integer numValueOf = null;
            if (i19 >= i8) {
                break;
            }
            InterfaceC0931b0 interfaceC0931b0 = list.get(i19);
            q0 rowColumnParentData = AbstractC0435n0.getRowColumnParentData(interfaceC0931b0);
            float weight = AbstractC0435n0.getWeight(rowColumnParentData);
            z2 = z2 || AbstractC0435n0.isRelative(rowColumnParentData);
            if (weight > 0.0f) {
                f3 += weight;
                i22++;
                i16 = i19;
                i17 = i18;
            } else {
                if (i5 != Integer.MAX_VALUE && rowColumnParentData != null && (flowLayoutData2 = rowColumnParentData.getFlowLayoutData()) != null) {
                    numValueOf = Integer.valueOf(Math.round(flowLayoutData2.getFillCrossAxisFraction() * i5));
                }
                int i24 = i4 - i23;
                AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = abstractC0974x0Arr[i19];
                if (abstractC0974x0Mo3865measureBRTryo0 == null) {
                    i16 = i19;
                    i15 = i21;
                    iArr2 = iArr3;
                    i17 = i18;
                    abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(InterfaceC0437o0.m1001createConstraintsxF2OJ5Q$default(interfaceC0437o0, 0, numValueOf != null ? numValueOf.intValue() : 0, i4 == Integer.MAX_VALUE ? Integer.MAX_VALUE : i24 < 0 ? 0 : i24, numValueOf != null ? numValueOf.intValue() : i5, false, 16, null));
                } else {
                    i15 = i21;
                    i16 = i19;
                    iArr2 = iArr3;
                    i17 = i18;
                }
                int iMainAxisSize = interfaceC0437o0.mainAxisSize(abstractC0974x0Mo3865measureBRTryo0);
                int iCrossAxisSize = interfaceC0437o0.crossAxisSize(abstractC0974x0Mo3865measureBRTryo0);
                iArr3 = iArr2;
                iArr3[i16 - i7] = iMainAxisSize;
                int i25 = i24 - iMainAxisSize;
                if (i25 < 0) {
                    i25 = 0;
                }
                int iMin = Math.min(i6, i25);
                int iMax2 = Math.max(i15, iCrossAxisSize);
                abstractC0974x0Arr[i16] = abstractC0974x0Mo3865measureBRTryo0;
                i23 = iMainAxisSize + iMin + i23;
                i20 = iMin;
                i21 = iMax2;
            }
            i19 = i16 + 1;
            i18 = i17;
        }
        int i26 = i21;
        int i27 = i18;
        if (i22 == 0) {
            i23 -= i20;
            i12 = i26;
            i11 = 0;
            i10 = 0;
        } else {
            long j3 = j2 * ((long) (i22 - 1));
            long jRound = ((long) ((i4 != Integer.MAX_VALUE ? i4 : i2) - i23)) - j3;
            if (jRound < 0) {
                jRound = 0;
            }
            float f4 = jRound / f3;
            for (int i28 = i7; i28 < i8; i28++) {
                jRound -= (long) Math.round(AbstractC0435n0.getWeight(AbstractC0435n0.getRowColumnParentData(list.get(i28))) * f4);
            }
            int i29 = i7;
            int i30 = 0;
            while (i29 < i8) {
                if (abstractC0974x0Arr[i29] == null) {
                    InterfaceC0931b0 interfaceC0931b02 = list.get(i29);
                    q0 rowColumnParentData2 = AbstractC0435n0.getRowColumnParentData(interfaceC0931b02);
                    float weight2 = AbstractC0435n0.getWeight(rowColumnParentData2);
                    Integer numValueOf2 = (i5 == Integer.MAX_VALUE || rowColumnParentData2 == null || (flowLayoutData = rowColumnParentData2.getFlowLayoutData()) == null) ? null : Integer.valueOf(Math.round(flowLayoutData.getFillCrossAxisFraction() * i5));
                    if (!(weight2 > 0.0f)) {
                        AbstractC1408a.throwIllegalStateException("All weights <= 0 should have placeables");
                    }
                    int iSignum = Long.signum(jRound);
                    int i31 = i29;
                    int i32 = i30;
                    long j4 = jRound - ((long) iSignum);
                    int iMax3 = Math.max(0, Math.round(weight2 * f4) + iSignum);
                    int i33 = (!AbstractC0435n0.getFill(rowColumnParentData2) || iMax3 == Integer.MAX_VALUE) ? 0 : iMax3;
                    i13 = i31;
                    f2 = f4;
                    AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo02 = interfaceC0931b02.mo3865measureBRTryo0(interfaceC0437o0.mo1002createConstraintsxF2OJ5Q(i33, numValueOf2 != null ? numValueOf2.intValue() : 0, iMax3, numValueOf2 != null ? numValueOf2.intValue() : i5, true));
                    int iMainAxisSize2 = interfaceC0437o0.mainAxisSize(abstractC0974x0Mo3865measureBRTryo02);
                    int iCrossAxisSize2 = interfaceC0437o0.crossAxisSize(abstractC0974x0Mo3865measureBRTryo02);
                    iArr3[i13 - i7] = iMainAxisSize2;
                    i30 = i32 + iMainAxisSize2;
                    int iMax4 = Math.max(i26, iCrossAxisSize2);
                    abstractC0974x0Arr[i13] = abstractC0974x0Mo3865measureBRTryo02;
                    i26 = iMax4;
                    jRound = j4;
                } else {
                    i13 = i29;
                    f2 = f4;
                }
                i29 = i13 + 1;
                f4 = f2;
            }
            int i34 = i26;
            i10 = 0;
            i11 = (int) (((long) i30) + j3);
            int i35 = i4 - i23;
            if (i11 < 0) {
                i11 = 0;
            }
            if (i11 > i35) {
                i11 = i35;
            }
            i12 = i34;
        }
        if (z2) {
            int iMax5 = i10;
            iMax = iMax5;
            for (int i36 = i7; i36 < i8; i36++) {
                AbstractC0974x0 abstractC0974x0 = abstractC0974x0Arr[i36];
                kotlin.jvm.internal.o.b(abstractC0974x0);
                B crossAxisAlignment = AbstractC0435n0.getCrossAxisAlignment(AbstractC0435n0.getRowColumnParentData(abstractC0974x0));
                Integer numCalculateAlignmentLinePosition$foundation_layout = crossAxisAlignment != null ? crossAxisAlignment.calculateAlignmentLinePosition$foundation_layout(abstractC0974x0) : null;
                if (numCalculateAlignmentLinePosition$foundation_layout != null) {
                    int iIntValue = numCalculateAlignmentLinePosition$foundation_layout.intValue();
                    int iCrossAxisSize3 = interfaceC0437o0.crossAxisSize(abstractC0974x0);
                    iMax5 = Math.max(iMax5, iIntValue != Integer.MIN_VALUE ? numCalculateAlignmentLinePosition$foundation_layout.intValue() : i10);
                    if (iIntValue == Integer.MIN_VALUE) {
                        iIntValue = iCrossAxisSize3;
                    }
                    iMax = Math.max(iMax, iCrossAxisSize3 - iIntValue);
                }
            }
            i14 = iMax5;
        } else {
            iMax = i10;
            i14 = iMax;
        }
        int i37 = i23 + i11;
        if (i37 < 0) {
            i37 = i10;
        }
        int iMax6 = Math.max(i37, i2);
        int iMax7 = Math.max(i12, Math.max(i3, iMax + i14));
        int[] iArr4 = new int[i27];
        interfaceC0437o0.populateMainAxisPositions(iMax6, iArr3, iArr4, interfaceC0937e0);
        return interfaceC0437o0.placeHelper(abstractC0974x0Arr, interfaceC0937e0, i14, iArr4, iMax6, iMax7, iArr, i9, i7, i8);
    }
}
