package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
public abstract class K0 {
    private static final androidx.compose.ui.modifier.m ModifierLocalConsumedWindowInsets = androidx.compose.ui.modifier.e.modifierLocalOf(new F0.a(24));

    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ H0 $insets$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(H0 h02) {
            super(1);
            this.$insets$inlined = h02;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("consumeWindowInsets");
            c1065l1.getProperties().set("insets", this.$insets$inlined);
        }
    }

    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ InterfaceC0421g0 $paddingValues$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(InterfaceC0421g0 interfaceC0421g0) {
            super(1);
            this.$paddingValues$inlined = interfaceC0421g0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("consumeWindowInsets");
            c1065l1.getProperties().set("paddingValues", this.$paddingValues$inlined);
        }
    }

    public static final class c implements h1.f {
        final /* synthetic */ H0 $insets;

        public c(H0 h02) {
            this.$insets = h02;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(788931215);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(788931215, i2, -1, "androidx.compose.foundation.layout.consumeWindowInsets.<anonymous> (WindowInsetsPadding.kt:100)");
            }
            boolean zChanged = interfaceC0768p.changed(this.$insets);
            H0 h02 = this.$insets;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new C0(h02);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            C0 c02 = (C0) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c02;
        }
    }

    public static final class d implements h1.f {
        final /* synthetic */ InterfaceC0421g0 $paddingValues;

        public d(InterfaceC0421g0 interfaceC0421g0) {
            this.$paddingValues = interfaceC0421g0;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(114694318);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(114694318, i2, -1, "androidx.compose.foundation.layout.consumeWindowInsets.<anonymous> (WindowInsetsPadding.kt:124)");
            }
            boolean zChanged = interfaceC0768p.changed(this.$paddingValues);
            InterfaceC0421g0 interfaceC0421g0 = this.$paddingValues;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new C0423h0(interfaceC0421g0);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            C0423h0 c0423h0 = (C0423h0) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0423h0;
        }
    }

    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $block$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(h1.c cVar) {
            super(1);
            this.$block$inlined = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("onConsumedWindowInsetsChanged");
            c1065l1.getProperties().set("block", this.$block$inlined);
        }
    }

    public static final class f implements h1.f {
        final /* synthetic */ h1.c $block;

        public f(h1.c cVar) {
            this.$block = cVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1608161351);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1608161351, i2, -1, "androidx.compose.foundation.layout.onConsumedWindowInsetsChanged.<anonymous> (WindowInsetsPadding.kt:141)");
            }
            boolean zChanged = interfaceC0768p.changed(this.$block);
            h1.c cVar = this.$block;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new A(cVar);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            A a2 = (A) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return a2;
        }
    }

    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ H0 $insets$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(H0 h02) {
            super(1);
            this.$insets$inlined = h02;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("windowInsetsPadding");
            c1065l1.getProperties().set("insets", this.$insets$inlined);
        }
    }

    public static final class h implements h1.f {
        final /* synthetic */ H0 $insets;

        public h(H0 h02) {
            this.$insets = h02;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1415685722);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1415685722, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.kt:79)");
            }
            boolean zChanged = interfaceC0768p.changed(this.$insets);
            H0 h02 = this.$insets;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(h02);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final H0 ModifierLocalConsumedWindowInsets$lambda$4() {
        return J0.WindowInsets(0, 0, 0, 0);
    }

    public static final androidx.compose.ui.x consumeWindowInsets(androidx.compose.ui.x xVar, H0 h02) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(h02) : AbstractC1056i1.getNoInspectorInfo(), new c(h02));
    }

    public static final androidx.compose.ui.modifier.m getModifierLocalConsumedWindowInsets() {
        return ModifierLocalConsumedWindowInsets;
    }

    public static final androidx.compose.ui.x onConsumedWindowInsetsChanged(androidx.compose.ui.x xVar, h1.c cVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new e(cVar) : AbstractC1056i1.getNoInspectorInfo(), new f(cVar));
    }

    public static final androidx.compose.ui.x recalculateWindowInsets(androidx.compose.ui.x xVar) {
        return xVar.then(RecalculateWindowInsetsModifierElement.INSTANCE);
    }

    public static final androidx.compose.ui.x windowInsetsPadding(androidx.compose.ui.x xVar, H0 h02) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new g(h02) : AbstractC1056i1.getNoInspectorInfo(), new h(h02));
    }

    public static final androidx.compose.ui.x consumeWindowInsets(androidx.compose.ui.x xVar, InterfaceC0421g0 interfaceC0421g0) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new b(interfaceC0421g0) : AbstractC1056i1.getNoInspectorInfo(), new d(interfaceC0421g0));
    }
}
