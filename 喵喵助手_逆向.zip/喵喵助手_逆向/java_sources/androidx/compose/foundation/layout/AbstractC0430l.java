package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.h2;
import androidx.compose.ui.C0821d;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0430l {
    private static final j.S Cache1 = cacheFor(true);
    private static final j.S Cache2 = cacheFor(false);
    private static final InterfaceC0933c0 DefaultBoxMeasurePolicy = new C0436o(InterfaceC0849g.Companion.getTopStart(), false);
    private static final InterfaceC0933c0 EmptyBoxMeasurePolicy = C0428k.INSTANCE;

    public static final void Box(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g, boolean z2, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 1) != 0) {
            xVar = androidx.compose.ui.x.Companion;
        }
        if ((i3 & 2) != 0) {
            interfaceC0849g = InterfaceC0849g.Companion.getTopStart();
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        InterfaceC0933c0 interfaceC0933c0MaybeCachedBoxMeasurePolicy = maybeCachedBoxMeasurePolicy(interfaceC0849g, z2);
        int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768p, 0));
        androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768p.getCurrentCompositionLocalMap();
        androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768p, xVar);
        C0997j c0997j = InterfaceC0999k.Companion;
        h1.a constructor = c0997j.getConstructor();
        if (interfaceC0768p.getApplier() == null) {
            AbstractC0750j.invalidApplier();
        }
        interfaceC0768p.startReusableNode();
        if (interfaceC0768p.getInserting()) {
            interfaceC0768p.createNode(constructor);
        } else {
            interfaceC0768p.useNode();
        }
        InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768p);
        h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0MaybeCachedBoxMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
        if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
            D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
        }
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
        fVar.invoke(C0439q.INSTANCE, interfaceC0768p, Integer.valueOf(((i2 >> 6) & 112) | 6));
        interfaceC0768p.endNode();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n Box$lambda$3(androidx.compose.ui.x xVar, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        Box(xVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1));
        return U0.n.f1521a;
    }

    private static final j.S cacheFor(boolean z2) {
        j.S s2 = new j.S(9);
        C0821d c0821d = InterfaceC0849g.Companion;
        s2.l(c0821d.getTopStart(), new C0436o(c0821d.getTopStart(), z2));
        s2.l(c0821d.getTopCenter(), new C0436o(c0821d.getTopCenter(), z2));
        s2.l(c0821d.getTopEnd(), new C0436o(c0821d.getTopEnd(), z2));
        s2.l(c0821d.getCenterStart(), new C0436o(c0821d.getCenterStart(), z2));
        s2.l(c0821d.getCenter(), new C0436o(c0821d.getCenter(), z2));
        s2.l(c0821d.getCenterEnd(), new C0436o(c0821d.getCenterEnd(), z2));
        s2.l(c0821d.getBottomStart(), new C0436o(c0821d.getBottomStart(), z2));
        s2.l(c0821d.getBottomCenter(), new C0436o(c0821d.getBottomCenter(), z2));
        s2.l(c0821d.getBottomEnd(), new C0436o(c0821d.getBottomEnd(), z2));
        return s2;
    }

    private static final C0426j getBoxChildDataNode(InterfaceC0931b0 interfaceC0931b0) {
        Object parentData = interfaceC0931b0.getParentData();
        if (parentData instanceof C0426j) {
            return (C0426j) parentData;
        }
        return null;
    }

    public static final InterfaceC0933c0 getEmptyBoxMeasurePolicy() {
        return EmptyBoxMeasurePolicy;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean getMatchesParentSize(InterfaceC0931b0 interfaceC0931b0) {
        C0426j boxChildDataNode = getBoxChildDataNode(interfaceC0931b0);
        if (boxChildDataNode != null) {
            return boxChildDataNode.getMatchParentSize();
        }
        return false;
    }

    public static final InterfaceC0933c0 maybeCachedBoxMeasurePolicy(InterfaceC0849g interfaceC0849g, boolean z2) {
        InterfaceC0933c0 interfaceC0933c0 = (InterfaceC0933c0) (z2 ? Cache1 : Cache2).d(interfaceC0849g);
        return interfaceC0933c0 == null ? new C0436o(interfaceC0849g, z2) : interfaceC0933c0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void placeInBox(AbstractC0974x0.a aVar, AbstractC0974x0 abstractC0974x0, InterfaceC0931b0 interfaceC0931b0, e0.u uVar, int i2, int i3, InterfaceC0849g interfaceC0849g) {
        InterfaceC0849g alignment;
        C0426j boxChildDataNode = getBoxChildDataNode(interfaceC0931b0);
        AbstractC0974x0.a.m3923place70tqf50$default(aVar, abstractC0974x0, ((boxChildDataNode == null || (alignment = boxChildDataNode.getAlignment()) == null) ? interfaceC0849g : alignment).mo2803alignKFBX0sM(e0.s.m5234constructorimpl((((long) abstractC0974x0.getWidth()) << 32) | (((long) abstractC0974x0.getHeight()) & 4294967295L)), e0.s.m5234constructorimpl((((long) i2) << 32) | (((long) i3) & 4294967295L)), uVar), 0.0f, 2, null);
    }

    public static final InterfaceC0933c0 rememberBoxMeasurePolicy(InterfaceC0849g interfaceC0849g, boolean z2, InterfaceC0768p interfaceC0768p, int i2) {
        InterfaceC0933c0 interfaceC0933c0;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(56522820, i2, -1, "androidx.compose.foundation.layout.rememberBoxMeasurePolicy (Box.kt:109)");
        }
        if (!kotlin.jvm.internal.o.a(interfaceC0849g, InterfaceC0849g.Companion.getTopStart()) || z2) {
            interfaceC0768p.startReplaceGroup(244414741);
            boolean z3 = ((((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(interfaceC0849g)) || (i2 & 6) == 4) | ((((i2 & 112) ^ 48) > 32 && interfaceC0768p.changed(z2)) || (i2 & 48) == 32);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new C0436o(interfaceC0849g, z2);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0933c0 = (C0436o) objRememberedValue;
            interfaceC0768p.endReplaceGroup();
        } else {
            interfaceC0768p.startReplaceGroup(244367063);
            interfaceC0768p.endReplaceGroup();
            interfaceC0933c0 = DefaultBoxMeasurePolicy;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return interfaceC0933c0;
    }

    public static final void Box(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-211209833);
        if ((i2 & 6) == 0) {
            i3 = (interfaceC0768pStartRestartGroup.changed(xVar) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-211209833, i3, -1, "androidx.compose.foundation.layout.Box (Box.kt:232)");
            }
            InterfaceC0933c0 interfaceC0933c0 = EmptyBoxMeasurePolicy;
            int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
            androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVar);
            androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
            C0997j c0997j = InterfaceC0999k.Companion;
            h1.a constructor = c0997j.getConstructor();
            if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                AbstractC0750j.invalidApplier();
            }
            interfaceC0768pStartRestartGroup.startReusableNode();
            if (interfaceC0768pStartRestartGroup.getInserting()) {
                interfaceC0768pStartRestartGroup.createNode(constructor);
            } else {
                interfaceC0768pStartRestartGroup.useNode();
            }
            InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
            h2.m2599setimpl(interfaceC0768pM2592constructorimpl, interfaceC0933c0, c0997j.getSetMeasurePolicy());
            h2.m2599setimpl(interfaceC0768pM2592constructorimpl, currentCompositionLocalMap, c0997j.getSetResolvedCompositionLocals());
            h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
            h1.e setCompositeKeyHash = c0997j.getSetCompositeKeyHash();
            if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                D0.d.z(setCompositeKeyHash, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
            }
            interfaceC0768pStartRestartGroup.endNode();
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new M0.k(xVar, i2, 3));
        }
    }
}
