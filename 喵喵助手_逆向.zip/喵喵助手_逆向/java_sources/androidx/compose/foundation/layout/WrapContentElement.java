package androidx.compose.foundation.layout;

import O0.C0233u;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: loaded from: classes.dex */
public final class WrapContentElement extends AbstractC1000k0 {
    public static final a Companion = new a(null);
    private final Object align;
    private final h1.e alignmentCallback;
    private final C direction;
    private final String inspectorName;
    private final boolean unbounded;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final e0.o height$lambda$1(InterfaceC0823f interfaceC0823f, e0.s sVar, e0.u uVar) {
            return e0.o.m5187boximpl(e0.o.m5190constructorimpl((((long) 0) << 32) | (4294967295L & ((long) interfaceC0823f.align(0, (int) (sVar.m5243unboximpl() & 4294967295L))))));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final e0.o size$lambda$2(InterfaceC0849g interfaceC0849g, e0.s sVar, e0.u uVar) {
            return e0.o.m5187boximpl(interfaceC0849g.mo2803alignKFBX0sM(e0.s.Companion.m5244getZeroYbymL2g(), sVar.m5243unboximpl(), uVar));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final e0.o width$lambda$0(InterfaceC0822e interfaceC0822e, e0.s sVar, e0.u uVar) {
            return e0.o.m5187boximpl(e0.o.m5190constructorimpl((((long) interfaceC0822e.align(0, (int) (sVar.m5243unboximpl() >> 32), uVar)) << 32) | (((long) 0) & 4294967295L)));
        }

        public final WrapContentElement height(InterfaceC0823f interfaceC0823f, boolean z2) {
            return new WrapContentElement(C.Vertical, z2, new C0416e(interfaceC0823f, 3), interfaceC0823f, "wrapContentHeight");
        }

        public final WrapContentElement size(InterfaceC0849g interfaceC0849g, boolean z2) {
            return new WrapContentElement(C.Both, z2, new C0233u(interfaceC0849g, 5), interfaceC0849g, "wrapContentSize");
        }

        public final WrapContentElement width(InterfaceC0822e interfaceC0822e, boolean z2) {
            return new WrapContentElement(C.Horizontal, z2, new C0414d(interfaceC0822e, 4), interfaceC0822e, "wrapContentWidth");
        }

        private a() {
        }
    }

    public WrapContentElement(C c2, boolean z2, h1.e eVar, Object obj, String str) {
        this.direction = c2;
        this.unbounded = z2;
        this.alignmentCallback = eVar;
        this.align = obj;
        this.inspectorName = str;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || WrapContentElement.class != obj.getClass()) {
            return false;
        }
        WrapContentElement wrapContentElement = (WrapContentElement) obj;
        return this.direction == wrapContentElement.direction && this.unbounded == wrapContentElement.unbounded && kotlin.jvm.internal.o.a(this.align, wrapContentElement.align);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return this.align.hashCode() + D0.d.c(this.direction.hashCode() * 31, 31, this.unbounded);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName(this.inspectorName);
        c1065l1.getProperties().set("align", this.align);
        c1065l1.getProperties().set("unbounded", Boolean.valueOf(this.unbounded));
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public O0 create() {
        return new O0(this.direction, this.unbounded, this.alignmentCallback);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(O0 o02) {
        o02.setDirection(this.direction);
        o02.setUnbounded(this.unbounded);
        o02.setAlignmentCallback(this.alignmentCallback);
    }
}
