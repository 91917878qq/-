package androidx.compose.foundation.layout;

import android.view.View;
import android.view.WindowInsets;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.snapshots.AbstractC0788j;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.core.view.AbstractC1215t;
import androidx.core.view.AbstractC1220y;
import androidx.core.view.C1201e;
import java.util.WeakHashMap;
import kotlin.jvm.internal.AbstractC1378g;
import m0.C1390c;

/* JADX INFO: loaded from: classes.dex */
public final class I0 {
    private static boolean testInsets;
    private int accessCount;
    private final C0412c captionBar;
    private final E0 captionBarIgnoringVisibility;
    private final boolean consumes;
    private final C0412c displayCutout;
    private final C0412c ime;
    private final E0 imeAnimationSource;
    private final E0 imeAnimationTarget;
    private final L insetsListener;
    private final C0412c mandatorySystemGestures;
    private final C0412c navigationBars;
    private final E0 navigationBarsIgnoringVisibility;
    private final H0 safeContent;
    private final H0 safeDrawing;
    private final H0 safeGestures;
    private final C0412c statusBars;
    private final E0 statusBarsIgnoringVisibility;
    private final C0412c systemBars;
    private final E0 systemBarsIgnoringVisibility;
    private final C0412c systemGestures;
    private final C0412c tappableElement;
    private final E0 tappableElementIgnoringVisibility;
    private final E0 waterfall;
    public static final a Companion = new a(null);
    public static final int $stable = 8;
    private static final WeakHashMap<View, I0> viewMap = new WeakHashMap<>();

    public static final class a {

        /* JADX INFO: renamed from: androidx.compose.foundation.layout.I0$a$a, reason: collision with other inner class name */
        public static final class C0036a implements androidx.compose.runtime.V {
            final /* synthetic */ I0 $insets$inlined;
            final /* synthetic */ View $view$inlined;

            public C0036a(I0 i02, View view) {
                this.$insets$inlined = i02;
                this.$view$inlined = view;
            }

            @Override // androidx.compose.runtime.V
            public void dispose() {
                this.$insets$inlined.decrementAccessors(this.$view$inlined);
            }
        }

        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final androidx.compose.runtime.V current$lambda$2$lambda$1(I0 i02, View view, androidx.compose.runtime.W w2) {
            i02.incrementAccessors(view);
            return new C0036a(i02, view);
        }

        private final I0 getOrCreateFor(View view) {
            I0 i02;
            synchronized (I0.viewMap) {
                try {
                    WeakHashMap weakHashMap = I0.viewMap;
                    Object obj = weakHashMap.get(view);
                    Object obj2 = obj;
                    if (obj == null) {
                        I0 i03 = new I0(null, view, false ? 1 : 0);
                        weakHashMap.put(view, i03);
                        obj2 = i03;
                    }
                    i02 = (I0) obj2;
                } catch (Throwable th) {
                    throw th;
                }
            }
            return i02;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final C0412c systemInsets(androidx.core.view.Z z2, int i2, String str) {
            C0412c c0412c = new C0412c(i2, str);
            if (z2 != null) {
                c0412c.update$foundation_layout(z2, i2);
            }
            return c0412c;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final E0 valueInsetsIgnoringVisibility(androidx.core.view.Z z2, int i2, String str) {
            C1390c c1390cH;
            if (z2 == null || (c1390cH = z2.f2572a.h(i2)) == null) {
                c1390cH = C1390c.f3167e;
            }
            return N0.ValueInsets(c1390cH, str);
        }

        public final I0 current(InterfaceC0768p interfaceC0768p, int i2) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1366542614, i2, -1, "androidx.compose.foundation.layout.WindowInsetsHolder.Companion.current (WindowInsets.android.kt:549)");
            }
            View view = (View) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalView());
            I0 orCreateFor = getOrCreateFor(view);
            boolean zChangedInstance = interfaceC0768p.changedInstance(orCreateFor) | interfaceC0768p.changedInstance(view);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChangedInstance || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M0.m(22, orCreateFor, view);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.Z.DisposableEffect(orCreateFor, (h1.c) objRememberedValue, interfaceC0768p, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            return orCreateFor;
        }

        public final void setUseTestInsets(boolean z2) {
            I0.testInsets = z2;
        }

        private a() {
        }
    }

    public /* synthetic */ I0(androidx.core.view.Z z2, View view, AbstractC1378g abstractC1378g) {
        this(z2, view);
    }

    public static /* synthetic */ void getConsumes$annotations() {
    }

    public static /* synthetic */ void update$default(I0 i02, androidx.core.view.Z z2, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        i02.update(z2, i2);
    }

    public final void decrementAccessors(View view) {
        int i2 = this.accessCount - 1;
        this.accessCount = i2;
        if (i2 == 0) {
            int i3 = AbstractC1220y.f2603a;
            AbstractC1215t.c(view, null);
            AbstractC1220y.b(view, null);
            view.removeOnAttachStateChangeListener(this.insetsListener);
        }
    }

    public final C0412c getCaptionBar() {
        return this.captionBar;
    }

    public final E0 getCaptionBarIgnoringVisibility() {
        return this.captionBarIgnoringVisibility;
    }

    public final boolean getConsumes() {
        return this.consumes;
    }

    public final C0412c getDisplayCutout() {
        return this.displayCutout;
    }

    public final C0412c getIme() {
        return this.ime;
    }

    public final E0 getImeAnimationSource() {
        return this.imeAnimationSource;
    }

    public final E0 getImeAnimationTarget() {
        return this.imeAnimationTarget;
    }

    public final C0412c getMandatorySystemGestures() {
        return this.mandatorySystemGestures;
    }

    public final C0412c getNavigationBars() {
        return this.navigationBars;
    }

    public final E0 getNavigationBarsIgnoringVisibility() {
        return this.navigationBarsIgnoringVisibility;
    }

    public final H0 getSafeContent() {
        return this.safeContent;
    }

    public final H0 getSafeDrawing() {
        return this.safeDrawing;
    }

    public final H0 getSafeGestures() {
        return this.safeGestures;
    }

    public final C0412c getStatusBars() {
        return this.statusBars;
    }

    public final E0 getStatusBarsIgnoringVisibility() {
        return this.statusBarsIgnoringVisibility;
    }

    public final C0412c getSystemBars() {
        return this.systemBars;
    }

    public final E0 getSystemBarsIgnoringVisibility() {
        return this.systemBarsIgnoringVisibility;
    }

    public final C0412c getSystemGestures() {
        return this.systemGestures;
    }

    public final C0412c getTappableElement() {
        return this.tappableElement;
    }

    public final E0 getTappableElementIgnoringVisibility() {
        return this.tappableElementIgnoringVisibility;
    }

    public final E0 getWaterfall() {
        return this.waterfall;
    }

    public final void incrementAccessors(View view) {
        if (this.accessCount == 0) {
            L l2 = this.insetsListener;
            int i2 = AbstractC1220y.f2603a;
            AbstractC1215t.c(view, l2);
            if (view.isAttachedToWindow()) {
                view.requestApplyInsets();
            }
            view.addOnAttachStateChangeListener(this.insetsListener);
            AbstractC1220y.b(view, this.insetsListener);
        }
        this.accessCount++;
    }

    public final void update(androidx.core.view.Z z2, int i2) {
        if (testInsets) {
            WindowInsets windowInsetsB = z2.b();
            kotlin.jvm.internal.o.b(windowInsetsB);
            z2 = androidx.core.view.Z.c(null, windowInsetsB);
        }
        this.captionBar.update$foundation_layout(z2, i2);
        this.ime.update$foundation_layout(z2, i2);
        this.displayCutout.update$foundation_layout(z2, i2);
        this.navigationBars.update$foundation_layout(z2, i2);
        this.statusBars.update$foundation_layout(z2, i2);
        this.systemBars.update$foundation_layout(z2, i2);
        this.systemGestures.update$foundation_layout(z2, i2);
        this.tappableElement.update$foundation_layout(z2, i2);
        this.mandatorySystemGestures.update$foundation_layout(z2, i2);
        if (i2 == 0) {
            this.captionBarIgnoringVisibility.setValue$foundation_layout(N0.toInsetsValues(z2.f2572a.h(4)));
            E0 e02 = this.navigationBarsIgnoringVisibility;
            androidx.core.view.X x2 = z2.f2572a;
            e02.setValue$foundation_layout(N0.toInsetsValues(x2.h(2)));
            this.statusBarsIgnoringVisibility.setValue$foundation_layout(N0.toInsetsValues(x2.h(1)));
            this.systemBarsIgnoringVisibility.setValue$foundation_layout(N0.toInsetsValues(x2.h(7)));
            this.tappableElementIgnoringVisibility.setValue$foundation_layout(N0.toInsetsValues(x2.h(64)));
            C1201e c1201eF = x2.f();
            if (c1201eF != null) {
                this.waterfall.setValue$foundation_layout(N0.toInsetsValues(c1201eF.a()));
            }
        }
        AbstractC0788j.Companion.sendApplyNotifications();
    }

    public final void updateImeAnimationSource(androidx.core.view.Z z2) {
        this.imeAnimationSource.setValue$foundation_layout(N0.toInsetsValues(z2.f2572a.g(8)));
    }

    public final void updateImeAnimationTarget(androidx.core.view.Z z2) {
        this.imeAnimationTarget.setValue$foundation_layout(N0.toInsetsValues(z2.f2572a.g(8)));
    }

    private I0(androidx.core.view.Z z2, View view) {
        C1201e c1201eF;
        a aVar = Companion;
        this.captionBar = aVar.systemInsets(z2, 4, "captionBar");
        C0412c c0412cSystemInsets = aVar.systemInsets(z2, 128, "displayCutout");
        this.displayCutout = c0412cSystemInsets;
        C0412c c0412cSystemInsets2 = aVar.systemInsets(z2, 8, "ime");
        this.ime = c0412cSystemInsets2;
        C0412c c0412cSystemInsets3 = aVar.systemInsets(z2, 32, "mandatorySystemGestures");
        this.mandatorySystemGestures = c0412cSystemInsets3;
        this.navigationBars = aVar.systemInsets(z2, 2, "navigationBars");
        boolean zBooleanValue = true;
        this.statusBars = aVar.systemInsets(z2, 1, "statusBars");
        C0412c c0412cSystemInsets4 = aVar.systemInsets(z2, 7, "systemBars");
        this.systemBars = c0412cSystemInsets4;
        C0412c c0412cSystemInsets5 = aVar.systemInsets(z2, 16, "systemGestures");
        this.systemGestures = c0412cSystemInsets5;
        C0412c c0412cSystemInsets6 = aVar.systemInsets(z2, 64, "tappableElement");
        this.tappableElement = c0412cSystemInsets6;
        E0 e0ValueInsets = N0.ValueInsets((z2 == null || (c1201eF = z2.f2572a.f()) == null) ? C1390c.f3167e : c1201eF.a(), "waterfall");
        this.waterfall = e0ValueInsets;
        H0 h0Union = J0.union(J0.union(c0412cSystemInsets4, c0412cSystemInsets2), c0412cSystemInsets);
        this.safeDrawing = h0Union;
        H0 h0Union2 = J0.union(J0.union(J0.union(c0412cSystemInsets6, c0412cSystemInsets3), c0412cSystemInsets5), e0ValueInsets);
        this.safeGestures = h0Union2;
        this.safeContent = J0.union(h0Union, h0Union2);
        this.captionBarIgnoringVisibility = aVar.valueInsetsIgnoringVisibility(z2, 4, "captionBarIgnoringVisibility");
        this.navigationBarsIgnoringVisibility = aVar.valueInsetsIgnoringVisibility(z2, 2, "navigationBarsIgnoringVisibility");
        this.statusBarsIgnoringVisibility = aVar.valueInsetsIgnoringVisibility(z2, 1, "statusBarsIgnoringVisibility");
        this.systemBarsIgnoringVisibility = aVar.valueInsetsIgnoringVisibility(z2, 7, "systemBarsIgnoringVisibility");
        this.tappableElementIgnoringVisibility = aVar.valueInsetsIgnoringVisibility(z2, 64, "tappableElementIgnoringVisibility");
        this.imeAnimationTarget = aVar.valueInsetsIgnoringVisibility(z2, 8, "imeAnimationTarget");
        this.imeAnimationSource = aVar.valueInsetsIgnoringVisibility(z2, 8, "imeAnimationSource");
        Object parent = view.getParent();
        View view2 = parent instanceof View ? (View) parent : null;
        Object tag = view2 != null ? view2.getTag(androidx.compose.ui.C.consume_window_insets_tag) : null;
        Boolean bool = tag instanceof Boolean ? (Boolean) tag : null;
        if (bool != null) {
            zBooleanValue = bool.booleanValue();
        } else if (C0447z.isWindowInsetsDefaultPassThroughEnabled) {
            zBooleanValue = false;
        }
        this.consumes = zBooleanValue;
        this.insetsListener = new L(this);
    }
}
