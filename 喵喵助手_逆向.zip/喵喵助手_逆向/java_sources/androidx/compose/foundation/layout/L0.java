package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
public abstract class L0 {

    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        public a() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("captionBarPadding");
        }
    }

    public static final class b implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getCaptionBar());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        public c() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("displayCutoutPadding");
        }
    }

    public static final class d implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getDisplayCutout());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        public e() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("imePadding");
        }
    }

    public static final class f implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getIme());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        public g() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("mandatorySystemGesturesPadding");
        }
    }

    public static final class h implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getMandatorySystemGestures());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class i extends kotlin.jvm.internal.p implements h1.c {
        public i() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("navigationBarsPadding");
        }
    }

    public static final class j implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getNavigationBars());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class k extends kotlin.jvm.internal.p implements h1.c {
        public k() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("safeContentPadding");
        }
    }

    public static final class l implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getSafeContent());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class m extends kotlin.jvm.internal.p implements h1.c {
        public m() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("safeDrawingPadding");
        }
    }

    public static final class n implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getSafeDrawing());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class o extends kotlin.jvm.internal.p implements h1.c {
        public o() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("safeGesturesPadding");
        }
    }

    public static final class p implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getSafeGestures());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class q extends kotlin.jvm.internal.p implements h1.c {
        public q() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("statusBarsPadding");
        }
    }

    public static final class r implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getStatusBars());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class s extends kotlin.jvm.internal.p implements h1.c {
        public s() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("systemBarsPadding");
        }
    }

    public static final class t implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getSystemBars());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class u extends kotlin.jvm.internal.p implements h1.c {
        public u() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("systemGesturesPadding");
        }
    }

    public static final class v implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getSystemGestures());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class w extends kotlin.jvm.internal.p implements h1.c {
        public w() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("waterfallPadding");
        }
    }

    public static final class x implements h1.f {
        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M(i0Current.getWaterfall());
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final class y implements h1.f {
        final /* synthetic */ h1.c $insetsCalculation;

        public y(h1.c cVar) {
            this.$insetsCalculation = cVar;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(359872873);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(359872873, i2, -1, "androidx.compose.foundation.layout.windowInsetsPadding.<anonymous> (WindowInsetsPadding.android.kt:240)");
            }
            I0 i0Current = I0.Companion.current(interfaceC0768p, 6);
            boolean zChanged = interfaceC0768p.changed(i0Current);
            h1.c cVar = this.$insetsCalculation;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new M((H0) cVar.invoke(i0Current));
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            M m2 = (M) objRememberedValue;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return m2;
        }
    }

    public static final androidx.compose.ui.x captionBarPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a() : AbstractC1056i1.getNoInspectorInfo(), new b());
    }

    public static final androidx.compose.ui.x displayCutoutPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new c() : AbstractC1056i1.getNoInspectorInfo(), new d());
    }

    public static final androidx.compose.ui.x imePadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new e() : AbstractC1056i1.getNoInspectorInfo(), new f());
    }

    public static final androidx.compose.ui.x mandatorySystemGesturesPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new g() : AbstractC1056i1.getNoInspectorInfo(), new h());
    }

    public static final androidx.compose.ui.x navigationBarsPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new i() : AbstractC1056i1.getNoInspectorInfo(), new j());
    }

    public static final androidx.compose.ui.x safeContentPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new k() : AbstractC1056i1.getNoInspectorInfo(), new l());
    }

    public static final androidx.compose.ui.x safeDrawingPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new m() : AbstractC1056i1.getNoInspectorInfo(), new n());
    }

    public static final androidx.compose.ui.x safeGesturesPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new o() : AbstractC1056i1.getNoInspectorInfo(), new p());
    }

    public static final androidx.compose.ui.x statusBarsPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new q() : AbstractC1056i1.getNoInspectorInfo(), new r());
    }

    public static final androidx.compose.ui.x systemBarsPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new s() : AbstractC1056i1.getNoInspectorInfo(), new t());
    }

    public static final androidx.compose.ui.x systemGesturesPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new u() : AbstractC1056i1.getNoInspectorInfo(), new v());
    }

    public static final androidx.compose.ui.x waterfallPadding(androidx.compose.ui.x xVar) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new w() : AbstractC1056i1.getNoInspectorInfo(), new x());
    }

    private static final androidx.compose.ui.x windowInsetsPadding(androidx.compose.ui.x xVar, h1.c cVar, h1.c cVar2) {
        return androidx.compose.ui.n.composed(xVar, cVar, new y(cVar2));
    }
}
