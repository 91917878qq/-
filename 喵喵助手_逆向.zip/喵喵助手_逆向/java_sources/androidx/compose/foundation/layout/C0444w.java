package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.C1305b;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0444w implements InterfaceC0933c0, InterfaceC0437o0 {
    public static final int $stable = 0;
    private final InterfaceC0822e horizontalAlignment;
    private final InterfaceC0424i verticalArrangement;

    public C0444w(InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e) {
        this.verticalArrangement = interfaceC0424i;
        this.horizontalAlignment = interfaceC0822e;
    }

    private final InterfaceC0424i component1() {
        return this.verticalArrangement;
    }

    private final InterfaceC0822e component2() {
        return this.horizontalAlignment;
    }

    public static /* synthetic */ C0444w copy$default(C0444w c0444w, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0424i = c0444w.verticalArrangement;
        }
        if ((i2 & 2) != 0) {
            interfaceC0822e = c0444w.horizontalAlignment;
        }
        return c0444w.copy(interfaceC0424i, interfaceC0822e);
    }

    private final int getCrossAxisPosition(AbstractC0974x0 abstractC0974x0, q0 q0Var, int i2, int i3, e0.u uVar) {
        B crossAxisAlignment = q0Var != null ? q0Var.getCrossAxisAlignment() : null;
        return crossAxisAlignment != null ? crossAxisAlignment.align$foundation_layout(i2 - abstractC0974x0.getWidth(), uVar, abstractC0974x0, i3) : this.horizontalAlignment.align(0, i2 - abstractC0974x0.getWidth(), uVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n placeHelper$lambda$3$lambda$2(AbstractC0974x0[] abstractC0974x0Arr, C0444w c0444w, int i2, int i3, InterfaceC0937e0 interfaceC0937e0, int[] iArr, AbstractC0974x0.a aVar) {
        int length = abstractC0974x0Arr.length;
        int i4 = 0;
        int i5 = 0;
        while (i4 < length) {
            AbstractC0974x0 abstractC0974x0 = abstractC0974x0Arr[i4];
            kotlin.jvm.internal.o.b(abstractC0974x0);
            AbstractC0974x0.a.place$default(aVar, abstractC0974x0, c0444w.getCrossAxisPosition(abstractC0974x0, AbstractC0435n0.getRowColumnParentData(abstractC0974x0), i2, i3, interfaceC0937e0.getLayoutDirection()), iArr[i5], 0.0f, 4, null);
            i4++;
            i5++;
        }
        return U0.n.f1521a;
    }

    public final C0444w copy(InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e) {
        return new C0444w(interfaceC0424i, interfaceC0822e);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    /* JADX INFO: renamed from: createConstraints-xF2OJ5Q */
    public long mo1002createConstraintsxF2OJ5Q(int i2, int i3, int i4, int i5, boolean z2) {
        return AbstractC0443v.createColumnConstraints(z2, i2, i3, i4, i5);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public int crossAxisSize(AbstractC0974x0 abstractC0974x0) {
        return abstractC0974x0.getWidth();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0444w)) {
            return false;
        }
        C0444w c0444w = (C0444w) obj;
        return kotlin.jvm.internal.o.a(this.verticalArrangement, c0444w.verticalArrangement) && kotlin.jvm.internal.o.a(this.horizontalAlignment, c0444w.horizontalAlignment);
    }

    public int hashCode() {
        return this.horizontalAlignment.hashCode() + (this.verticalArrangement.hashCode() * 31);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public int mainAxisSize(AbstractC0974x0 abstractC0974x0) {
        return abstractC0974x0.getHeight();
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.VerticalMaxHeight(list, i2, f2.mo782roundToPx0680j_4(this.verticalArrangement.mo983getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.VerticalMaxWidth(list, i2, f2.mo782roundToPx0680j_4(this.verticalArrangement.mo983getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        return p0.measure(this, C1305b.m5042getMinHeightimpl(j2), C1305b.m5043getMinWidthimpl(j2), C1305b.m5040getMaxHeightimpl(j2), C1305b.m5041getMaxWidthimpl(j2), interfaceC0937e0.mo782roundToPx0680j_4(this.verticalArrangement.mo983getSpacingD9Ej5fM()), interfaceC0937e0, list, new AbstractC0974x0[list.size()], 0, list.size(), (3072 & 1024) != 0 ? null : null, (3072 & 2048) != 0 ? 0 : 0);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.VerticalMinHeight(list, i2, f2.mo782roundToPx0680j_4(this.verticalArrangement.mo983getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        return S.INSTANCE.VerticalMinWidth(list, i2, f2.mo782roundToPx0680j_4(this.verticalArrangement.mo983getSpacingD9Ej5fM()));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public InterfaceC0935d0 placeHelper(AbstractC0974x0[] abstractC0974x0Arr, InterfaceC0937e0 interfaceC0937e0, int i2, int[] iArr, int i3, int i4, int[] iArr2, int i5, int i6, int i7) {
        return InterfaceC0937e0.layout$default(interfaceC0937e0, i4, i3, null, new C0432m(abstractC0974x0Arr, this, i4, i2, interfaceC0937e0, iArr), 4, null);
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0437o0
    public void populateMainAxisPositions(int i2, int[] iArr, int[] iArr2, InterfaceC0937e0 interfaceC0937e0) {
        this.verticalArrangement.arrange(interfaceC0937e0, i2, iArr, iArr2);
    }

    public String toString() {
        return "ColumnMeasurePolicy(verticalArrangement=" + this.verticalArrangement + ", horizontalAlignment=" + this.horizontalAlignment + ')';
    }
}
