package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class D implements H0 {
    private final H0 excluded;
    private final H0 included;

    public D(H0 h02, H0 h03) {
        this.included = h02;
        this.excluded = h03;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof D)) {
            return false;
        }
        D d2 = (D) obj;
        return kotlin.jvm.internal.o.a(d2.included, this.included) && kotlin.jvm.internal.o.a(d2.excluded, this.excluded);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        int bottom = this.included.getBottom(interfaceC1307d) - this.excluded.getBottom(interfaceC1307d);
        if (bottom < 0) {
            return 0;
        }
        return bottom;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        int left = this.included.getLeft(interfaceC1307d, uVar) - this.excluded.getLeft(interfaceC1307d, uVar);
        if (left < 0) {
            return 0;
        }
        return left;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        int right = this.included.getRight(interfaceC1307d, uVar) - this.excluded.getRight(interfaceC1307d, uVar);
        if (right < 0) {
            return 0;
        }
        return right;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        int top = this.included.getTop(interfaceC1307d) - this.excluded.getTop(interfaceC1307d);
        if (top < 0) {
            return 0;
        }
        return top;
    }

    public int hashCode() {
        return this.excluded.hashCode() + (this.included.hashCode() * 31);
    }

    public String toString() {
        return "(" + this.included + " - " + this.excluded + ')';
    }
}
