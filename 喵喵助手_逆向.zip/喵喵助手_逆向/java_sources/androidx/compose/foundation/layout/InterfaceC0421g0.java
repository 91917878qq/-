package androidx.compose.foundation.layout;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0421g0 {
    public static final C0419f0 Companion = C0419f0.$$INSTANCE;

    /* JADX INFO: renamed from: calculateBottomPadding-D9Ej5fM */
    float mo925calculateBottomPaddingD9Ej5fM();

    /* JADX INFO: renamed from: calculateLeftPadding-u2uoSUM */
    float mo926calculateLeftPaddingu2uoSUM(e0.u uVar);

    /* JADX INFO: renamed from: calculateRightPadding-u2uoSUM */
    float mo927calculateRightPaddingu2uoSUM(e0.u uVar);

    /* JADX INFO: renamed from: calculateTopPadding-D9Ej5fM */
    float mo928calculateTopPaddingD9Ej5fM();
}
