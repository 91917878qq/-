package androidx.compose.foundation.layout;

import e0.C1311h;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0420g {
    void arrange(InterfaceC1307d interfaceC1307d, int i2, int[] iArr, e0.u uVar, int[] iArr2);

    /* JADX INFO: renamed from: getSpacing-D9Ej5fM */
    default float mo982getSpacingD9Ej5fM() {
        return C1311h.m5076constructorimpl(0);
    }
}
