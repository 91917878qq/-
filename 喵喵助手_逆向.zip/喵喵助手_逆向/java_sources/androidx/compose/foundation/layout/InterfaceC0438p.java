package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0438p {
    androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g);

    androidx.compose.ui.x matchParentSize(androidx.compose.ui.x xVar);
}
