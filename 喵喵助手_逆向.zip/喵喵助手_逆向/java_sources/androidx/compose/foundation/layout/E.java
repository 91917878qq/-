package androidx.compose.foundation.layout;

import androidx.compose.foundation.lazy.layout.C0481p;
import androidx.compose.foundation.text.b1;
import androidx.compose.ui.layout.AbstractC0974x0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class E implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1763b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AbstractC0974x0 f1764c;

    public /* synthetic */ E(AbstractC0974x0 abstractC0974x0, int i2) {
        this.f1763b = i2;
        this.f1764c = abstractC0974x0;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1763b) {
            case 0:
                return F.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 1:
                return U.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 2:
                return C0433m0.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 3:
                return y0.measure_3p2s80s$lambda$3(this.f1764c, (AbstractC0974x0.a) obj);
            case 4:
                return D0.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 5:
                return androidx.compose.foundation.lazy.V.measure_3p2s80s$lambda$2(this.f1764c, (AbstractC0974x0.a) obj);
            case 6:
                return C0481p.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 7:
                return b1.a.invoke$lambda$6$lambda$5$lambda$4(this.f1764c, (AbstractC0974x0.a) obj);
            case 8:
                return androidx.compose.foundation.text.input.internal.J0.measure_3p2s80s$lambda$0(this.f1764c, (AbstractC0974x0.a) obj);
            case 9:
                return androidx.compose.foundation.text.modifiers.o.measure_3p2s80s$lambda$10$lambda$9(this.f1764c, (AbstractC0974x0.a) obj);
            default:
                return androidx.compose.foundation.text.modifiers.t.measure_3p2s80s$lambda$7$lambda$6(this.f1764c, (AbstractC0974x0.a) obj);
        }
    }
}
