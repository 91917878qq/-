package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1305b;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0436o implements InterfaceC0933c0 {
    private final InterfaceC0849g alignment;
    private final boolean propagateMinConstraints;

    public C0436o(InterfaceC0849g interfaceC0849g, boolean z2) {
        this.alignment = interfaceC0849g;
        this.propagateMinConstraints = z2;
    }

    private final InterfaceC0849g component1() {
        return this.alignment;
    }

    private final boolean component2() {
        return this.propagateMinConstraints;
    }

    public static /* synthetic */ C0436o copy$default(C0436o c0436o, InterfaceC0849g interfaceC0849g, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0849g = c0436o.alignment;
        }
        if ((i2 & 2) != 0) {
            z2 = c0436o.propagateMinConstraints;
        }
        return c0436o.copy(interfaceC0849g, z2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0.a aVar) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$1(AbstractC0974x0 abstractC0974x0, InterfaceC0931b0 interfaceC0931b0, InterfaceC0937e0 interfaceC0937e0, int i2, int i3, C0436o c0436o, AbstractC0974x0.a aVar) {
        AbstractC0430l.placeInBox(aVar, abstractC0974x0, interfaceC0931b0, interfaceC0937e0.getLayoutDirection(), i2, i3, c0436o.alignment);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$5(AbstractC0974x0[] abstractC0974x0Arr, List list, InterfaceC0937e0 interfaceC0937e0, kotlin.jvm.internal.C c2, kotlin.jvm.internal.C c3, C0436o c0436o, AbstractC0974x0.a aVar) {
        int length = abstractC0974x0Arr.length;
        int i2 = 0;
        int i3 = 0;
        while (i2 < length) {
            AbstractC0974x0 abstractC0974x0 = abstractC0974x0Arr[i2];
            kotlin.jvm.internal.o.c(abstractC0974x0, "null cannot be cast to non-null type androidx.compose.ui.layout.Placeable");
            AbstractC0430l.placeInBox(aVar, abstractC0974x0, (InterfaceC0931b0) list.get(i3), interfaceC0937e0.getLayoutDirection(), c2.f3116b, c3.f3116b, c0436o.alignment);
            i2++;
            i3++;
        }
        return U0.n.f1521a;
    }

    public final C0436o copy(InterfaceC0849g interfaceC0849g, boolean z2) {
        return new C0436o(interfaceC0849g, z2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0436o)) {
            return false;
        }
        C0436o c0436o = (C0436o) obj;
        return kotlin.jvm.internal.o.a(this.alignment, c0436o.alignment) && this.propagateMinConstraints == c0436o.propagateMinConstraints;
    }

    public int hashCode() {
        return Boolean.hashCode(this.propagateMinConstraints) + (this.alignment.hashCode() * 31);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.maxIntrinsicWidth(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo579measure3p2s80s(final InterfaceC0937e0 interfaceC0937e0, final List<? extends InterfaceC0931b0> list, long j2) {
        int iM5043getMinWidthimpl;
        int iM5042getMinHeightimpl;
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0;
        if (list.isEmpty()) {
            return InterfaceC0937e0.layout$default(interfaceC0937e0, C1305b.m5043getMinWidthimpl(j2), C1305b.m5042getMinHeightimpl(j2), null, new androidx.compose.animation.core.D0(22), 4, null);
        }
        long jM5029constructorimpl = this.propagateMinConstraints ? j2 : C1305b.m5029constructorimpl(j2 & AbstractC1306c.MaxDimensionsAndFocusMask);
        if (list.size() == 1) {
            InterfaceC0931b0 interfaceC0931b0 = list.get(0);
            if (AbstractC0430l.getMatchesParentSize(interfaceC0931b0)) {
                iM5043getMinWidthimpl = C1305b.m5043getMinWidthimpl(j2);
                iM5042getMinHeightimpl = C1305b.m5042getMinHeightimpl(j2);
                abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(C1305b.Companion.m5051fixedJhjzzOo(C1305b.m5043getMinWidthimpl(j2), C1305b.m5042getMinHeightimpl(j2)));
            } else {
                abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(jM5029constructorimpl);
                iM5043getMinWidthimpl = Math.max(C1305b.m5043getMinWidthimpl(j2), abstractC0974x0Mo3865measureBRTryo0.getWidth());
                iM5042getMinHeightimpl = Math.max(C1305b.m5042getMinHeightimpl(j2), abstractC0974x0Mo3865measureBRTryo0.getHeight());
            }
            int i2 = iM5043getMinWidthimpl;
            int i3 = iM5042getMinHeightimpl;
            return InterfaceC0937e0.layout$default(interfaceC0937e0, i2, i3, null, new C0432m(abstractC0974x0Mo3865measureBRTryo0, interfaceC0931b0, interfaceC0937e0, i2, i3, this), 4, null);
        }
        final AbstractC0974x0[] abstractC0974x0Arr = new AbstractC0974x0[list.size()];
        final kotlin.jvm.internal.C c2 = new kotlin.jvm.internal.C();
        c2.f3116b = C1305b.m5043getMinWidthimpl(j2);
        final kotlin.jvm.internal.C c3 = new kotlin.jvm.internal.C();
        c3.f3116b = C1305b.m5042getMinHeightimpl(j2);
        int size = list.size();
        boolean z2 = false;
        for (int i4 = 0; i4 < size; i4++) {
            InterfaceC0931b0 interfaceC0931b02 = list.get(i4);
            if (AbstractC0430l.getMatchesParentSize(interfaceC0931b02)) {
                z2 = true;
            } else {
                AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo02 = interfaceC0931b02.mo3865measureBRTryo0(jM5029constructorimpl);
                abstractC0974x0Arr[i4] = abstractC0974x0Mo3865measureBRTryo02;
                c2.f3116b = Math.max(c2.f3116b, abstractC0974x0Mo3865measureBRTryo02.getWidth());
                c3.f3116b = Math.max(c3.f3116b, abstractC0974x0Mo3865measureBRTryo02.getHeight());
            }
        }
        if (z2) {
            int i5 = c2.f3116b;
            int i6 = i5 != Integer.MAX_VALUE ? i5 : 0;
            int i7 = c3.f3116b;
            long jConstraints = AbstractC1306c.Constraints(i6, i5, i7 != Integer.MAX_VALUE ? i7 : 0, i7);
            int size2 = list.size();
            for (int i8 = 0; i8 < size2; i8++) {
                InterfaceC0931b0 interfaceC0931b03 = list.get(i8);
                if (AbstractC0430l.getMatchesParentSize(interfaceC0931b03)) {
                    abstractC0974x0Arr[i8] = interfaceC0931b03.mo3865measureBRTryo0(jConstraints);
                }
            }
        }
        return InterfaceC0937e0.layout$default(interfaceC0937e0, c2.f3116b, c3.f3116b, null, new h1.c() { // from class: androidx.compose.foundation.layout.n
            @Override // h1.c
            public final Object invoke(Object obj) {
                AbstractC0974x0[] abstractC0974x0Arr2 = abstractC0974x0Arr;
                kotlin.jvm.internal.C c4 = c2;
                kotlin.jvm.internal.C c5 = c3;
                return C0436o.measure_3p2s80s$lambda$5(abstractC0974x0Arr2, list, interfaceC0937e0, c4, c5, this, (AbstractC0974x0.a) obj);
            }
        }, 4, null);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicHeight(f2, list, i2);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List list, int i2) {
        return super.minIntrinsicWidth(f2, list, i2);
    }

    public String toString() {
        return "BoxMeasurePolicy(alignment=" + this.alignment + ", propagateMinConstraints=" + this.propagateMinConstraints + ')';
    }
}
