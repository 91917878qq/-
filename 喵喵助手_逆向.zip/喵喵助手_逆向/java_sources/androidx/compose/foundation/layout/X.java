package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class X implements H0 {
    private final H0 insets;
    private final int sides;

    public /* synthetic */ X(H0 h02, int i2, AbstractC1378g abstractC1378g) {
        this(h02, i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof X)) {
            return false;
        }
        X x2 = (X) obj;
        return kotlin.jvm.internal.o.a(this.insets, x2.insets) && M0.m906equalsimpl0(this.sides, x2.sides);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        if (M0.m907hasAnybkgdKaI$foundation_layout(this.sides, M0.Companion.m917getBottomJoeWqyM())) {
            return this.insets.getBottom(interfaceC1307d);
        }
        return 0;
    }

    public final H0 getInsets() {
        return this.insets;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        if (M0.m907hasAnybkgdKaI$foundation_layout(this.sides, uVar == e0.u.Ltr ? M0.Companion.m913getAllowLeftInLtrJoeWqyM$foundation_layout() : M0.Companion.m914getAllowLeftInRtlJoeWqyM$foundation_layout())) {
            return this.insets.getLeft(interfaceC1307d, uVar);
        }
        return 0;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        if (M0.m907hasAnybkgdKaI$foundation_layout(this.sides, uVar == e0.u.Ltr ? M0.Companion.m915getAllowRightInLtrJoeWqyM$foundation_layout() : M0.Companion.m916getAllowRightInRtlJoeWqyM$foundation_layout())) {
            return this.insets.getRight(interfaceC1307d, uVar);
        }
        return 0;
    }

    /* JADX INFO: renamed from: getSides-JoeWqyM, reason: not valid java name */
    public final int m942getSidesJoeWqyM() {
        return this.sides;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        if (M0.m907hasAnybkgdKaI$foundation_layout(this.sides, M0.Companion.m923getTopJoeWqyM())) {
            return this.insets.getTop(interfaceC1307d);
        }
        return 0;
    }

    public int hashCode() {
        return M0.m908hashCodeimpl(this.sides) + (this.insets.hashCode() * 31);
    }

    public String toString() {
        return "(" + this.insets + " only " + ((Object) M0.m910toStringimpl(this.sides)) + ')';
    }

    private X(H0 h02, int i2) {
        this.insets = h02;
        this.sides = i2;
    }
}
