package androidx.compose.foundation.layout;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class C {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ C[] $VALUES;
    public static final C Vertical = new C("Vertical", 0);
    public static final C Horizontal = new C("Horizontal", 1);
    public static final C Both = new C("Both", 2);

    private static final /* synthetic */ C[] $values() {
        return new C[]{Vertical, Horizontal, Both};
    }

    static {
        C[] cArr$values = $values();
        $VALUES = cArr$values;
        $ENTRIES = AbstractC0292a.q(cArr$values);
    }

    private C(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static C valueOf(String str) {
        return (C) Enum.valueOf(C.class, str);
    }

    public static C[] values() {
        return (C[]) $VALUES.clone();
    }
}
