package androidx.compose.foundation.layout;

import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;
import p.AbstractC1408a;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.e0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0417e0 implements InterfaceC0421g0 {
    public static final int $stable = 0;
    private final float bottom;
    private final float left;
    private final float right;
    private final float top;

    public /* synthetic */ C0417e0(float f2, float f3, float f4, float f5, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5);
    }

    /* JADX INFO: renamed from: getBottom-D9Ej5fM$annotations, reason: not valid java name */
    private static /* synthetic */ void m972getBottomD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getLeft-D9Ej5fM$annotations, reason: not valid java name */
    private static /* synthetic */ void m973getLeftD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getRight-D9Ej5fM$annotations, reason: not valid java name */
    private static /* synthetic */ void m974getRightD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getTop-D9Ej5fM$annotations, reason: not valid java name */
    private static /* synthetic */ void m975getTopD9Ej5fM$annotations() {
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateBottomPadding-D9Ej5fM */
    public float mo925calculateBottomPaddingD9Ej5fM() {
        return this.bottom;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateLeftPadding-u2uoSUM */
    public float mo926calculateLeftPaddingu2uoSUM(e0.u uVar) {
        return this.left;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateRightPadding-u2uoSUM */
    public float mo927calculateRightPaddingu2uoSUM(e0.u uVar) {
        return this.right;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateTopPadding-D9Ej5fM */
    public float mo928calculateTopPaddingD9Ej5fM() {
        return this.top;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0417e0)) {
            return false;
        }
        C0417e0 c0417e0 = (C0417e0) obj;
        return C1311h.m5081equalsimpl0(this.left, c0417e0.left) && C1311h.m5081equalsimpl0(this.top, c0417e0.top) && C1311h.m5081equalsimpl0(this.right, c0417e0.right) && C1311h.m5081equalsimpl0(this.bottom, c0417e0.bottom);
    }

    public int hashCode() {
        return C1311h.m5082hashCodeimpl(this.bottom) + D0.d.C(this.right, D0.d.C(this.top, C1311h.m5082hashCodeimpl(this.left) * 31, 31), 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("PaddingValues.Absolute(left=");
        D0.d.u(this.left, sb, ", top=");
        D0.d.u(this.top, sb, ", right=");
        D0.d.u(this.right, sb, ", bottom=");
        sb.append((Object) C1311h.m5087toStringimpl(this.bottom));
        sb.append(')');
        return sb.toString();
    }

    private C0417e0(float f2, float f3, float f4, float f5) {
        this.left = f2;
        this.top = f3;
        this.right = f4;
        this.bottom = f5;
        if (!((f2 >= 0.0f) & (f3 >= 0.0f) & (f4 >= 0.0f)) || !(f5 >= 0.0f)) {
            AbstractC1408a.throwIllegalArgumentException("Padding must be non-negative");
        }
    }

    public /* synthetic */ C0417e0(float f2, float f3, float f4, float f5, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.m5076constructorimpl(0) : f2, (i2 & 2) != 0 ? C1311h.m5076constructorimpl(0) : f3, (i2 & 4) != 0 ? C1311h.m5076constructorimpl(0) : f4, (i2 & 8) != 0 ? C1311h.m5076constructorimpl(0) : f5, null);
    }
}
