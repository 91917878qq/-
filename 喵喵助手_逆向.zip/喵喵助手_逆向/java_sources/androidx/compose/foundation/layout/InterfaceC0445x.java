package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.layout.Z0;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0445x {
    static /* synthetic */ androidx.compose.ui.x weight$default(InterfaceC0445x interfaceC0445x, androidx.compose.ui.x xVar, float f2, boolean z2, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: weight");
        }
        if ((i2 & 2) != 0) {
            z2 = true;
        }
        return interfaceC0445x.weight(xVar, f2, z2);
    }

    androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0822e interfaceC0822e);

    androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, Z0 z02);

    androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, h1.c cVar);

    androidx.compose.ui.x weight(androidx.compose.ui.x xVar, float f2, boolean z2);
}
