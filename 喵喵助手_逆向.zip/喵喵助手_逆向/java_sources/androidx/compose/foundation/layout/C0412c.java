package androidx.compose.foundation.layout;

import androidx.compose.runtime.V1;
import e0.InterfaceC1307d;
import m0.C1390c;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0412c implements H0 {
    public static final int $stable = 0;
    private final androidx.compose.runtime.B0 insets$delegate = V1.mutableStateOf$default(C1390c.f3167e, null, 2, null);
    private final androidx.compose.runtime.B0 isVisible$delegate = V1.mutableStateOf$default(Boolean.TRUE, null, 2, null);
    private final String name;
    private final int type;

    public C0412c(int i2, String str) {
        this.type = i2;
        this.name = str;
    }

    private final void setVisible(boolean z2) {
        this.isVisible$delegate.setValue(Boolean.valueOf(z2));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0412c) && this.type == ((C0412c) obj).type;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return getInsets$foundation_layout().f3171d;
    }

    public final C1390c getInsets$foundation_layout() {
        return (C1390c) this.insets$delegate.getValue();
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return getInsets$foundation_layout().f3168a;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return getInsets$foundation_layout().f3170c;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return getInsets$foundation_layout().f3169b;
    }

    public final int getType$foundation_layout() {
        return this.type;
    }

    public int hashCode() {
        return this.type;
    }

    public final boolean isVisible() {
        return ((Boolean) this.isVisible$delegate.getValue()).booleanValue();
    }

    public final void setInsets$foundation_layout(C1390c c1390c) {
        this.insets$delegate.setValue(c1390c);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.name);
        sb.append('(');
        sb.append(getInsets$foundation_layout().f3168a);
        sb.append(", ");
        sb.append(getInsets$foundation_layout().f3169b);
        sb.append(", ");
        sb.append(getInsets$foundation_layout().f3170c);
        sb.append(", ");
        return D0.d.q(sb, getInsets$foundation_layout().f3171d, ')');
    }

    public final void update$foundation_layout(androidx.core.view.Z z2, int i2) {
        if (i2 == 0 || (i2 & this.type) != 0) {
            setInsets$foundation_layout(z2.f2572a.g(this.type));
            setVisible(z2.f2572a.q(this.type));
        }
    }
}
