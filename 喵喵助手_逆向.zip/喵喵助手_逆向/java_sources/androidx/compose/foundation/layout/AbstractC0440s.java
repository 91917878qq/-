package androidx.compose.foundation.layout;

import O0.C0198c;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.Q0;
import androidx.compose.ui.layout.U0;
import e0.C1305b;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0440s {

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.s$a */
    public static final class a implements h1.e {
        final /* synthetic */ h1.f $content;
        final /* synthetic */ C0442u $scope;

        public a(h1.f fVar, C0442u c0442u) {
            this.$content = fVar;
            this.$scope = c0442u;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            if (!interfaceC0768p.shouldExecute((i2 & 3) != 2, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-431986394, i2, -1, "androidx.compose.foundation.layout.BoxWithConstraints.<anonymous>.<anonymous>.<anonymous> (BoxWithConstraints.kt:65)");
            }
            this.$content.invoke(this.$scope, interfaceC0768p, 0);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00e3  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x00ee  */
    /* JADX WARN: Removed duplicated region for block: B:79:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void BoxWithConstraints(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g, boolean z2, final h1.f fVar, InterfaceC0768p interfaceC0768p, final int i2, final int i3) {
        androidx.compose.ui.x xVar2;
        int i4;
        InterfaceC0849g interfaceC0849g2;
        int i5;
        boolean z3;
        androidx.compose.ui.x xVar3;
        InterfaceC0849g topStart;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(380139498);
        int i6 = i3 & 1;
        if (i6 != 0) {
            i4 = i2 | 6;
            xVar2 = xVar;
        } else if ((i2 & 6) == 0) {
            xVar2 = xVar;
            i4 = (interfaceC0768pStartRestartGroup.changed(xVar2) ? 4 : 2) | i2;
        } else {
            xVar2 = xVar;
            i4 = i2;
        }
        int i7 = i3 & 2;
        if (i7 != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                interfaceC0849g2 = interfaceC0849g;
                i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0849g2) ? 32 : 16;
            }
            i5 = i3 & 4;
            if (i5 != 0) {
                if ((i2 & 384) == 0) {
                    z3 = z2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(z3) ? 256 : 128;
                }
                if ((i3 & 8) != 0) {
                    i4 |= 3072;
                } else if ((i2 & 3072) == 0) {
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 2048 : 1024;
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
                    xVar3 = i6 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                    topStart = i7 != 0 ? InterfaceC0849g.Companion.getTopStart() : interfaceC0849g2;
                    if (i5 != 0) {
                        z3 = false;
                    }
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventStart(380139498, i4, -1, "androidx.compose.foundation.layout.BoxWithConstraints (BoxWithConstraints.kt:61)");
                    }
                    InterfaceC0933c0 interfaceC0933c0MaybeCachedBoxMeasurePolicy = AbstractC0430l.maybeCachedBoxMeasurePolicy(topStart, z3);
                    boolean zChanged = interfaceC0768pStartRestartGroup.changed(interfaceC0933c0MaybeCachedBoxMeasurePolicy) | ((i4 & 7168) == 2048);
                    Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                    if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue = new C0198c(8, interfaceC0933c0MaybeCachedBoxMeasurePolicy, fVar);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    Q0.SubcomposeLayout(xVar3, (h1.e) objRememberedValue, interfaceC0768pStartRestartGroup, i4 & 14, 0);
                    if (AbstractC0776s.isTraceInProgress()) {
                        AbstractC0776s.traceEventEnd();
                    }
                } else {
                    interfaceC0768pStartRestartGroup.skipToGroupEnd();
                    xVar3 = xVar2;
                    topStart = interfaceC0849g2;
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                    final androidx.compose.ui.x xVar4 = xVar3;
                    final InterfaceC0849g interfaceC0849g3 = topStart;
                    final boolean z4 = z3;
                    interfaceC0811x1EndRestartGroup.updateScope(new h1.e() { // from class: androidx.compose.foundation.layout.r
                        @Override // h1.e
                        public final Object invoke(Object obj, Object obj2) {
                            int iIntValue = ((Integer) obj2).intValue();
                            int i8 = i2;
                            int i9 = i3;
                            return AbstractC0440s.BoxWithConstraints$lambda$3(xVar4, interfaceC0849g3, z4, fVar, i8, i9, (InterfaceC0768p) obj, iIntValue);
                        }
                    });
                    return;
                }
                return;
            }
            i4 |= 384;
            z3 = z2;
            if ((i3 & 8) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        interfaceC0849g2 = interfaceC0849g;
        i5 = i3 & 4;
        if (i5 != 0) {
        }
        z3 = z2;
        if ((i3 & 8) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 1171) != 1170, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final InterfaceC0935d0 BoxWithConstraints$lambda$2$lambda$1(InterfaceC0933c0 interfaceC0933c0, h1.f fVar, U0 u02, C1305b c1305b) {
        return interfaceC0933c0.mo579measure3p2s80s(u02, u02.subcompose(U0.n.f1521a, G.v.composableLambdaInstance(-431986394, true, new a(fVar, new C0442u(u02, c1305b.m5047unboximpl(), null)))), c1305b.m5047unboximpl());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n BoxWithConstraints$lambda$3(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g, boolean z2, h1.f fVar, int i2, int i3, InterfaceC0768p interfaceC0768p, int i4) {
        BoxWithConstraints(xVar, interfaceC0849g, z2, fVar, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1), i3);
        return U0.n.f1521a;
    }
}
