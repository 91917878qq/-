package androidx.compose.foundation.layout;

import e0.C1311h;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.j0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0427j0 implements H0 {
    private final InterfaceC0421g0 paddingValues;

    public C0427j0(InterfaceC0421g0 interfaceC0421g0) {
        this.paddingValues = interfaceC0421g0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0427j0) {
            return kotlin.jvm.internal.o.a(((C0427j0) obj).paddingValues, this.paddingValues);
        }
        return false;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.paddingValues.mo925calculateBottomPaddingD9Ej5fM());
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.paddingValues.mo926calculateLeftPaddingu2uoSUM(uVar));
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.paddingValues.mo927calculateRightPaddingu2uoSUM(uVar));
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.paddingValues.mo928calculateTopPaddingD9Ej5fM());
    }

    public int hashCode() {
        return this.paddingValues.hashCode();
    }

    public String toString() {
        e0.u uVar = e0.u.Ltr;
        return "PaddingValues(" + ((Object) C1311h.m5087toStringimpl(this.paddingValues.mo926calculateLeftPaddingu2uoSUM(uVar))) + ", " + ((Object) C1311h.m5087toStringimpl(this.paddingValues.mo928calculateTopPaddingD9Ej5fM())) + ", " + ((Object) C1311h.m5087toStringimpl(this.paddingValues.mo927calculateRightPaddingu2uoSUM(uVar))) + ", " + ((Object) C1311h.m5087toStringimpl(this.paddingValues.mo925calculateBottomPaddingD9Ej5fM())) + ')';
    }
}
