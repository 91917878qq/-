package androidx.compose.foundation.layout;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class M0 {
    private static final int AllowLeftInLtr;
    private static final int AllowLeftInRtl;
    private static final int AllowRightInLtr;
    private static final int AllowRightInRtl;
    private static final int Bottom;
    public static final a Companion = new a(null);
    private static final int End;
    private static final int Horizontal;
    private static final int Left;
    private static final int Right;
    private static final int Start;
    private static final int Top;
    private static final int Vertical;
    private final int value;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: renamed from: getAllowLeftInLtr-JoeWqyM$foundation_layout, reason: not valid java name */
        public final int m913getAllowLeftInLtrJoeWqyM$foundation_layout() {
            return M0.AllowLeftInLtr;
        }

        /* JADX INFO: renamed from: getAllowLeftInRtl-JoeWqyM$foundation_layout, reason: not valid java name */
        public final int m914getAllowLeftInRtlJoeWqyM$foundation_layout() {
            return M0.AllowLeftInRtl;
        }

        /* JADX INFO: renamed from: getAllowRightInLtr-JoeWqyM$foundation_layout, reason: not valid java name */
        public final int m915getAllowRightInLtrJoeWqyM$foundation_layout() {
            return M0.AllowRightInLtr;
        }

        /* JADX INFO: renamed from: getAllowRightInRtl-JoeWqyM$foundation_layout, reason: not valid java name */
        public final int m916getAllowRightInRtlJoeWqyM$foundation_layout() {
            return M0.AllowRightInRtl;
        }

        /* JADX INFO: renamed from: getBottom-JoeWqyM, reason: not valid java name */
        public final int m917getBottomJoeWqyM() {
            return M0.Bottom;
        }

        /* JADX INFO: renamed from: getEnd-JoeWqyM, reason: not valid java name */
        public final int m918getEndJoeWqyM() {
            return M0.End;
        }

        /* JADX INFO: renamed from: getHorizontal-JoeWqyM, reason: not valid java name */
        public final int m919getHorizontalJoeWqyM() {
            return M0.Horizontal;
        }

        /* JADX INFO: renamed from: getLeft-JoeWqyM, reason: not valid java name */
        public final int m920getLeftJoeWqyM() {
            return M0.Left;
        }

        /* JADX INFO: renamed from: getRight-JoeWqyM, reason: not valid java name */
        public final int m921getRightJoeWqyM() {
            return M0.Right;
        }

        /* JADX INFO: renamed from: getStart-JoeWqyM, reason: not valid java name */
        public final int m922getStartJoeWqyM() {
            return M0.Start;
        }

        /* JADX INFO: renamed from: getTop-JoeWqyM, reason: not valid java name */
        public final int m923getTopJoeWqyM() {
            return M0.Top;
        }

        /* JADX INFO: renamed from: getVertical-JoeWqyM, reason: not valid java name */
        public final int m924getVerticalJoeWqyM() {
            return M0.Vertical;
        }

        private a() {
        }
    }

    static {
        int iM904constructorimpl = m904constructorimpl(8);
        AllowLeftInLtr = iM904constructorimpl;
        int iM904constructorimpl2 = m904constructorimpl(4);
        AllowRightInLtr = iM904constructorimpl2;
        int iM904constructorimpl3 = m904constructorimpl(2);
        AllowLeftInRtl = iM904constructorimpl3;
        int iM904constructorimpl4 = m904constructorimpl(1);
        AllowRightInRtl = iM904constructorimpl4;
        Start = m909plusgK_yJZ4(iM904constructorimpl, iM904constructorimpl4);
        End = m909plusgK_yJZ4(iM904constructorimpl2, iM904constructorimpl3);
        int iM904constructorimpl5 = m904constructorimpl(16);
        Top = iM904constructorimpl5;
        int iM904constructorimpl6 = m904constructorimpl(32);
        Bottom = iM904constructorimpl6;
        int iM909plusgK_yJZ4 = m909plusgK_yJZ4(iM904constructorimpl, iM904constructorimpl3);
        Left = iM909plusgK_yJZ4;
        int iM909plusgK_yJZ42 = m909plusgK_yJZ4(iM904constructorimpl2, iM904constructorimpl4);
        Right = iM909plusgK_yJZ42;
        Horizontal = m909plusgK_yJZ4(iM909plusgK_yJZ4, iM909plusgK_yJZ42);
        Vertical = m909plusgK_yJZ4(iM904constructorimpl5, iM904constructorimpl6);
    }

    private /* synthetic */ M0(int i2) {
        this.value = i2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ M0 m903boximpl(int i2) {
        return new M0(i2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    private static int m904constructorimpl(int i2) {
        return i2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m905equalsimpl(int i2, Object obj) {
        return (obj instanceof M0) && i2 == ((M0) obj).m912unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m906equalsimpl0(int i2, int i3) {
        return i2 == i3;
    }

    /* JADX INFO: renamed from: hasAny-bkgdKaI$foundation_layout, reason: not valid java name */
    public static final boolean m907hasAnybkgdKaI$foundation_layout(int i2, int i3) {
        return (i2 & i3) != 0;
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m908hashCodeimpl(int i2) {
        return Integer.hashCode(i2);
    }

    /* JADX INFO: renamed from: plus-gK_yJZ4, reason: not valid java name */
    public static final int m909plusgK_yJZ4(int i2, int i3) {
        return m904constructorimpl(i2 | i3);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m910toStringimpl(int i2) {
        return D0.d.r(new StringBuilder("WindowInsetsSides("), m911valueToStringimpl(i2), ')');
    }

    /* JADX INFO: renamed from: valueToString-impl, reason: not valid java name */
    private static final String m911valueToStringimpl(int i2) {
        StringBuilder sb = new StringBuilder();
        int i3 = Start;
        if ((i2 & i3) == i3) {
            valueToString_impl$lambda$0$appendPlus(sb, "Start");
        }
        int i4 = Left;
        if ((i2 & i4) == i4) {
            valueToString_impl$lambda$0$appendPlus(sb, "Left");
        }
        int i5 = Top;
        if ((i2 & i5) == i5) {
            valueToString_impl$lambda$0$appendPlus(sb, "Top");
        }
        int i6 = End;
        if ((i2 & i6) == i6) {
            valueToString_impl$lambda$0$appendPlus(sb, "End");
        }
        int i7 = Right;
        if ((i2 & i7) == i7) {
            valueToString_impl$lambda$0$appendPlus(sb, "Right");
        }
        int i8 = Bottom;
        if ((i2 & i8) == i8) {
            valueToString_impl$lambda$0$appendPlus(sb, "Bottom");
        }
        String string = sb.toString();
        kotlin.jvm.internal.o.d(string, "toString(...)");
        return string;
    }

    private static final void valueToString_impl$lambda$0$appendPlus(StringBuilder sb, String str) {
        if (sb.length() > 0) {
            sb.append('+');
        }
        sb.append(str);
    }

    public boolean equals(Object obj) {
        return m905equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m908hashCodeimpl(this.value);
    }

    public String toString() {
        return m910toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ int m912unboximpl() {
        return this.value;
    }
}
