package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.layout.Z0;
import p.AbstractC1408a;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0446y implements InterfaceC0445x {
    public static final int $stable = 0;
    public static final C0446y INSTANCE = new C0446y();

    private C0446y() {
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0445x
    public androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0822e interfaceC0822e) {
        return xVar.then(new HorizontalAlignElement(interfaceC0822e));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0445x
    public androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, Z0 z02) {
        return xVar.then(new WithAlignmentLineElement(z02));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0445x
    public androidx.compose.ui.x weight(androidx.compose.ui.x xVar, float f2, boolean z2) {
        if (!(((double) f2) > 0.0d)) {
            AbstractC1408a.throwIllegalArgumentException("invalid weight; must be greater than zero");
        }
        return xVar.then(new LayoutWeightElement(j1.a.l(f2, Float.MAX_VALUE), z2));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0445x
    public androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, h1.c cVar) {
        return xVar.then(new WithAlignmentLineBlockElement(cVar));
    }
}
