package androidx.compose.foundation.layout;

import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.b0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0411b0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1769b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ float f1770c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ float f1771d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f1772e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ float f1773f;

    public /* synthetic */ C0411b0(float f2, float f3, float f4, float f5, int i2) {
        this.f1769b = i2;
        this.f1770c = f2;
        this.f1771d = f3;
        this.f1772e = f4;
        this.f1773f = f5;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        C1065l1 c1065l1 = (C1065l1) obj;
        switch (this.f1769b) {
            case 0:
                return AbstractC0413c0.padding_qDBjuR0$lambda$0(this.f1770c, this.f1771d, this.f1772e, this.f1773f, c1065l1);
            default:
                return AbstractC0413c0.absolutePadding_qDBjuR0$lambda$4(this.f1770c, this.f1771d, this.f1772e, this.f1773f, c1065l1);
        }
    }
}
