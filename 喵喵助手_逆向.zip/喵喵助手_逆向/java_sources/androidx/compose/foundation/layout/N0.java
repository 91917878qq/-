package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.AbstractC1030a;
import androidx.compose.ui.platform.C1070n0;
import m0.C1390c;

/* JADX INFO: loaded from: classes.dex */
public abstract class N0 {
    public static final E0 ValueInsets(C1390c c1390c, String str) {
        return new E0(toInsetsValues(c1390c), str);
    }

    public static final boolean getAreNavigationBarsVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(710310464, i2, -1, "androidx.compose.foundation.layout.<get-areNavigationBarsVisible> (WindowInsets.android.kt:307)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getNavigationBars().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void getAreNavigationBarsVisible$annotations(G0 g02) {
    }

    public static final boolean getAreStatusBarsVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1613283456, i2, -1, "androidx.compose.foundation.layout.<get-areStatusBarsVisible> (WindowInsets.android.kt:297)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getStatusBars().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void getAreStatusBarsVisible$annotations(G0 g02) {
    }

    public static final boolean getAreSystemBarsVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1985490720, i2, -1, "androidx.compose.foundation.layout.<get-areSystemBarsVisible> (WindowInsets.android.kt:315)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getSystemBars().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void getAreSystemBarsVisible$annotations(G0 g02) {
    }

    public static final H0 getCaptionBar(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1832025528, i2, -1, "androidx.compose.foundation.layout.<get-captionBar> (WindowInsets.android.kt:143)");
        }
        C0412c captionBar = I0.Companion.current(interfaceC0768p, 6).getCaptionBar();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return captionBar;
    }

    public static final H0 getCaptionBarIgnoringVisibility(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1731251574, i2, -1, "androidx.compose.foundation.layout.<get-captionBarIgnoringVisibility> (WindowInsets.android.kt:230)");
        }
        E0 captionBarIgnoringVisibility = I0.Companion.current(interfaceC0768p, 6).getCaptionBarIgnoringVisibility();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return captionBarIgnoringVisibility;
    }

    public static /* synthetic */ void getCaptionBarIgnoringVisibility$annotations(G0 g02) {
    }

    public static final boolean getConsumeWindowInsets(AbstractC1030a abstractC1030a) {
        Object tag = abstractC1030a.getTag(androidx.compose.ui.C.consume_window_insets_tag);
        Boolean bool = tag instanceof Boolean ? (Boolean) tag : null;
        return bool != null ? bool.booleanValue() : !C0447z.isWindowInsetsDefaultPassThroughEnabled;
    }

    public static /* synthetic */ void getConsumeWindowInsets$annotations(AbstractC1030a abstractC1030a) {
    }

    public static final H0 getDisplayCutout(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1324817724, i2, -1, "androidx.compose.foundation.layout.<get-displayCutout> (WindowInsets.android.kt:150)");
        }
        C0412c displayCutout = I0.Companion.current(interfaceC0768p, 6).getDisplayCutout();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return displayCutout;
    }

    public static final H0 getIme(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1466917860, i2, -1, "androidx.compose.foundation.layout.<get-ime> (WindowInsets.android.kt:162)");
        }
        C0412c ime = I0.Companion.current(interfaceC0768p, 6).getIme();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return ime;
    }

    public static final H0 getImeAnimationSource(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1126064918, i2, -1, "androidx.compose.foundation.layout.<get-imeAnimationSource> (WindowInsets.android.kt:334)");
        }
        E0 imeAnimationSource = I0.Companion.current(interfaceC0768p, 6).getImeAnimationSource();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return imeAnimationSource;
    }

    public static /* synthetic */ void getImeAnimationSource$annotations(G0 g02) {
    }

    public static final H0 getImeAnimationTarget(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-466319786, i2, -1, "androidx.compose.foundation.layout.<get-imeAnimationTarget> (WindowInsets.android.kt:344)");
        }
        E0 imeAnimationTarget = I0.Companion.current(interfaceC0768p, 6).getImeAnimationTarget();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return imeAnimationTarget;
    }

    public static /* synthetic */ void getImeAnimationTarget$annotations(G0 g02) {
    }

    public static final H0 getMandatorySystemGestures(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1369492988, i2, -1, "androidx.compose.foundation.layout.<get-mandatorySystemGestures> (WindowInsets.android.kt:171)");
        }
        C0412c mandatorySystemGestures = I0.Companion.current(interfaceC0768p, 6).getMandatorySystemGestures();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return mandatorySystemGestures;
    }

    public static final H0 getNavigationBars(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1596175702, i2, -1, "androidx.compose.foundation.layout.<get-navigationBars> (WindowInsets.android.kt:178)");
        }
        C0412c navigationBars = I0.Companion.current(interfaceC0768p, 6).getNavigationBars();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return navigationBars;
    }

    public static final H0 getNavigationBarsIgnoringVisibility(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1990981160, i2, -1, "androidx.compose.foundation.layout.<get-navigationBarsIgnoringVisibility> (WindowInsets.android.kt:241)");
        }
        E0 navigationBarsIgnoringVisibility = I0.Companion.current(interfaceC0768p, 6).getNavigationBarsIgnoringVisibility();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return navigationBarsIgnoringVisibility;
    }

    public static /* synthetic */ void getNavigationBarsIgnoringVisibility$annotations(G0 g02) {
    }

    public static final H0 getSafeContent(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-2026663876, i2, -1, "androidx.compose.foundation.layout.<get-safeContent> (WindowInsets.android.kt:220)");
        }
        H0 safeContent = I0.Companion.current(interfaceC0768p, 6).getSafeContent();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return safeContent;
    }

    public static final H0 getSafeDrawing(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-49441252, i2, -1, "androidx.compose.foundation.layout.<get-safeDrawing> (WindowInsets.android.kt:205)");
        }
        H0 safeDrawing = I0.Companion.current(interfaceC0768p, 6).getSafeDrawing();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return safeDrawing;
    }

    public static final H0 getSafeGestures(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1594247780, i2, -1, "androidx.compose.foundation.layout.<get-safeGestures> (WindowInsets.android.kt:213)");
        }
        H0 safeGestures = I0.Companion.current(interfaceC0768p, 6).getSafeGestures();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return safeGestures;
    }

    public static final H0 getStatusBars(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-675090670, i2, -1, "androidx.compose.foundation.layout.<get-statusBars> (WindowInsets.android.kt:182)");
        }
        C0412c statusBars = I0.Companion.current(interfaceC0768p, 6).getStatusBars();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return statusBars;
    }

    public static final H0 getStatusBarsIgnoringVisibility(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(594020756, i2, -1, "androidx.compose.foundation.layout.<get-statusBarsIgnoringVisibility> (WindowInsets.android.kt:251)");
        }
        E0 statusBarsIgnoringVisibility = I0.Companion.current(interfaceC0768p, 6).getStatusBarsIgnoringVisibility();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return statusBarsIgnoringVisibility;
    }

    public static /* synthetic */ void getStatusBarsIgnoringVisibility$annotations(G0 g02) {
    }

    public static final H0 getSystemBars(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-282936756, i2, -1, "androidx.compose.foundation.layout.<get-systemBars> (WindowInsets.android.kt:186)");
        }
        C0412c systemBars = I0.Companion.current(interfaceC0768p, 6).getSystemBars();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return systemBars;
    }

    public static final H0 getSystemBarsIgnoringVisibility(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1564566798, i2, -1, "androidx.compose.foundation.layout.<get-systemBarsIgnoringVisibility> (WindowInsets.android.kt:262)");
        }
        E0 systemBarsIgnoringVisibility = I0.Companion.current(interfaceC0768p, 6).getSystemBarsIgnoringVisibility();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return systemBarsIgnoringVisibility;
    }

    public static /* synthetic */ void getSystemBarsIgnoringVisibility$annotations(G0 g02) {
    }

    public static final H0 getSystemGestures(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(989216224, i2, -1, "androidx.compose.foundation.layout.<get-systemGestures> (WindowInsets.android.kt:190)");
        }
        C0412c systemGestures = I0.Companion.current(interfaceC0768p, 6).getSystemGestures();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return systemGestures;
    }

    public static final H0 getTappableElement(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1994205284, i2, -1, "androidx.compose.foundation.layout.<get-tappableElement> (WindowInsets.android.kt:194)");
        }
        C0412c tappableElement = I0.Companion.current(interfaceC0768p, 6).getTappableElement();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return tappableElement;
    }

    public static final H0 getTappableElementIgnoringVisibility(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1488788292, i2, -1, "androidx.compose.foundation.layout.<get-tappableElementIgnoringVisibility> (WindowInsets.android.kt:273)");
        }
        E0 tappableElementIgnoringVisibility = I0.Companion.current(interfaceC0768p, 6).getTappableElementIgnoringVisibility();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return tappableElementIgnoringVisibility;
    }

    public static /* synthetic */ void getTappableElementIgnoringVisibility$annotations(G0 g02) {
    }

    public static final H0 getWaterfall(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1943241020, i2, -1, "androidx.compose.foundation.layout.<get-waterfall> (WindowInsets.android.kt:198)");
        }
        E0 waterfall = I0.Companion.current(interfaceC0768p, 6).getWaterfall();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return waterfall;
    }

    public static final boolean isCaptionBarVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-501076620, i2, -1, "androidx.compose.foundation.layout.<get-isCaptionBarVisible> (WindowInsets.android.kt:281)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getCaptionBar().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void isCaptionBarVisible$annotations(G0 g02) {
    }

    public static final boolean isImeVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1873571424, i2, -1, "androidx.compose.foundation.layout.<get-isImeVisible> (WindowInsets.android.kt:289)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getIme().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void isImeVisible$annotations(G0 g02) {
    }

    public static final boolean isTappableElementVisible(G0 g02, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1737201120, i2, -1, "androidx.compose.foundation.layout.<get-isTappableElementVisible> (WindowInsets.android.kt:324)");
        }
        boolean zIsVisible = I0.Companion.current(interfaceC0768p, 6).getTappableElement().isVisible();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return zIsVisible;
    }

    public static /* synthetic */ void isTappableElementVisible$annotations(G0 g02) {
    }

    public static final void setConsumeWindowInsets(AbstractC1030a abstractC1030a, boolean z2) {
        abstractC1030a.setTag(androidx.compose.ui.C.consume_window_insets_tag, Boolean.valueOf(z2));
    }

    public static final O toInsetsValues(C1390c c1390c) {
        return new O(c1390c.f3168a, c1390c.f3169b, c1390c.f3170c, c1390c.f3171d);
    }

    @U0.a
    public static /* synthetic */ void getConsumeWindowInsets$annotations(C1070n0 c1070n0) {
    }

    public static final /* synthetic */ boolean getConsumeWindowInsets(C1070n0 c1070n0) {
        Object tag = c1070n0.getTag(androidx.compose.ui.C.consume_window_insets_tag);
        Boolean bool = tag instanceof Boolean ? (Boolean) tag : null;
        return bool != null ? bool.booleanValue() : !C0447z.isWindowInsetsDefaultPassThroughEnabled;
    }
}
