package androidx.compose.foundation.layout;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class T {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ T[] $VALUES;
    public static final T Min = new T("Min", 0);
    public static final T Max = new T("Max", 1);

    private static final /* synthetic */ T[] $values() {
        return new T[]{Min, Max};
    }

    static {
        T[] tArr$values = $values();
        $VALUES = tArr$values;
        $ENTRIES = AbstractC0292a.q(tArr$values);
    }

    private T(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static T valueOf(String str) {
        return (T) Enum.valueOf(T.class, str);
    }

    public static T[] values() {
        return (T[]) $VALUES.clone();
    }
}
