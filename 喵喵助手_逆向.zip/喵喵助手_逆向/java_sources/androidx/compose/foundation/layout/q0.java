package androidx.compose.foundation.layout;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class q0 {
    public static final int $stable = 8;
    private B crossAxisAlignment;
    private boolean fill;
    private I flowLayoutData;
    private float weight;

    public q0() {
        this(0.0f, false, null, null, 15, null);
    }

    public static /* synthetic */ q0 copy$default(q0 q0Var, float f2, boolean z2, B b2, I i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            f2 = q0Var.weight;
        }
        if ((i3 & 2) != 0) {
            z2 = q0Var.fill;
        }
        if ((i3 & 4) != 0) {
            b2 = q0Var.crossAxisAlignment;
        }
        if ((i3 & 8) != 0) {
            i2 = q0Var.flowLayoutData;
        }
        return q0Var.copy(f2, z2, b2, i2);
    }

    public final float component1() {
        return this.weight;
    }

    public final boolean component2() {
        return this.fill;
    }

    public final B component3() {
        return this.crossAxisAlignment;
    }

    public final I component4() {
        return this.flowLayoutData;
    }

    public final q0 copy(float f2, boolean z2, B b2, I i2) {
        return new q0(f2, z2, b2, i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q0)) {
            return false;
        }
        q0 q0Var = (q0) obj;
        return Float.compare(this.weight, q0Var.weight) == 0 && this.fill == q0Var.fill && kotlin.jvm.internal.o.a(this.crossAxisAlignment, q0Var.crossAxisAlignment) && kotlin.jvm.internal.o.a(this.flowLayoutData, q0Var.flowLayoutData);
    }

    public final B getCrossAxisAlignment() {
        return this.crossAxisAlignment;
    }

    public final boolean getFill() {
        return this.fill;
    }

    public final I getFlowLayoutData() {
        return this.flowLayoutData;
    }

    public final float getWeight() {
        return this.weight;
    }

    public int hashCode() {
        int iC = D0.d.c(Float.hashCode(this.weight) * 31, 31, this.fill);
        B b2 = this.crossAxisAlignment;
        int iHashCode = (iC + (b2 == null ? 0 : b2.hashCode())) * 31;
        I i2 = this.flowLayoutData;
        return iHashCode + (i2 != null ? i2.hashCode() : 0);
    }

    public final void setCrossAxisAlignment(B b2) {
        this.crossAxisAlignment = b2;
    }

    public final void setFill(boolean z2) {
        this.fill = z2;
    }

    public final void setFlowLayoutData(I i2) {
        this.flowLayoutData = i2;
    }

    public final void setWeight(float f2) {
        this.weight = f2;
    }

    public String toString() {
        return "RowColumnParentData(weight=" + this.weight + ", fill=" + this.fill + ", crossAxisAlignment=" + this.crossAxisAlignment + ", flowLayoutData=" + this.flowLayoutData + ')';
    }

    public q0(float f2, boolean z2, B b2, I i2) {
        this.weight = f2;
        this.fill = z2;
        this.crossAxisAlignment = b2;
        this.flowLayoutData = i2;
    }

    public /* synthetic */ q0(float f2, boolean z2, B b2, I i2, int i3, AbstractC1378g abstractC1378g) {
        this((i3 & 1) != 0 ? 0.0f : f2, (i3 & 2) != 0 ? true : z2, (i3 & 4) != 0 ? null : b2, (i3 & 8) != 0 ? null : i2);
    }
}
