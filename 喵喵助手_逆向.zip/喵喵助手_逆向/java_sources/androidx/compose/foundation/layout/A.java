package androidx.compose.foundation.layout;

/* JADX INFO: loaded from: classes.dex */
public final class A implements androidx.compose.ui.modifier.d {
    private final h1.c block;
    private H0 oldWindowInsets;

    public A(h1.c cVar) {
        this.block = cVar;
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof A) && ((A) obj).block == this.block;
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public int hashCode() {
        return this.block.hashCode();
    }

    @Override // androidx.compose.ui.modifier.d
    public void onModifierLocalsUpdated(androidx.compose.ui.modifier.k kVar) {
        H0 h02 = (H0) kVar.getCurrent(K0.getModifierLocalConsumedWindowInsets());
        if (kotlin.jvm.internal.o.a(h02, this.oldWindowInsets)) {
            return;
        }
        this.oldWindowInsets = h02;
        this.block.invoke(h02);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }
}
