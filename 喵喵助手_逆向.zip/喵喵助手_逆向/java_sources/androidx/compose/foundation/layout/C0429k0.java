package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1311h;
import p.AbstractC1408a;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.k0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0429k0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private InterfaceC0421g0 paddingValues;

    public C0429k0(InterfaceC0421g0 interfaceC0421g0) {
        this.paddingValues = interfaceC0421g0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$1(AbstractC0974x0 abstractC0974x0, int i2, int i3, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.place$default(aVar, abstractC0974x0, i2, i3, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    public final InterfaceC0421g0 getPaddingValues() {
        return this.paddingValues;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        float fMo926calculateLeftPaddingu2uoSUM = this.paddingValues.mo926calculateLeftPaddingu2uoSUM(interfaceC0937e0.getLayoutDirection());
        float fMo928calculateTopPaddingD9Ej5fM = this.paddingValues.mo928calculateTopPaddingD9Ej5fM();
        float fMo927calculateRightPaddingu2uoSUM = this.paddingValues.mo927calculateRightPaddingu2uoSUM(interfaceC0937e0.getLayoutDirection());
        float fMo925calculateBottomPaddingD9Ej5fM = this.paddingValues.mo925calculateBottomPaddingD9Ej5fM();
        float f2 = 0;
        if (!((C1311h.m5075compareTo0680j_4(fMo925calculateBottomPaddingD9Ej5fM, C1311h.m5076constructorimpl(f2)) >= 0) & (C1311h.m5075compareTo0680j_4(fMo926calculateLeftPaddingu2uoSUM, C1311h.m5076constructorimpl(f2)) >= 0) & (C1311h.m5075compareTo0680j_4(fMo928calculateTopPaddingD9Ej5fM, C1311h.m5076constructorimpl(f2)) >= 0) & (C1311h.m5075compareTo0680j_4(fMo927calculateRightPaddingu2uoSUM, C1311h.m5076constructorimpl(f2)) >= 0))) {
            AbstractC1408a.throwIllegalArgumentException("Padding must be non-negative");
        }
        int iMo782roundToPx0680j_4 = interfaceC0937e0.mo782roundToPx0680j_4(fMo926calculateLeftPaddingu2uoSUM);
        int iMo782roundToPx0680j_42 = interfaceC0937e0.mo782roundToPx0680j_4(fMo927calculateRightPaddingu2uoSUM) + iMo782roundToPx0680j_4;
        int iMo782roundToPx0680j_43 = interfaceC0937e0.mo782roundToPx0680j_4(fMo928calculateTopPaddingD9Ej5fM);
        int iMo782roundToPx0680j_44 = interfaceC0937e0.mo782roundToPx0680j_4(fMo925calculateBottomPaddingD9Ej5fM) + iMo782roundToPx0680j_43;
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.m5060offsetNN6EwU(j2, -iMo782roundToPx0680j_42, -iMo782roundToPx0680j_44));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, AbstractC1306c.m5058constrainWidthK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getWidth() + iMo782roundToPx0680j_42), AbstractC1306c.m5057constrainHeightK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getHeight() + iMo782roundToPx0680j_44), null, new androidx.compose.foundation.y0(abstractC0974x0Mo3865measureBRTryo0, iMo782roundToPx0680j_4, iMo782roundToPx0680j_43, 2), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setPaddingValues(InterfaceC0421g0 interfaceC0421g0) {
        this.paddingValues = interfaceC0421g0;
    }
}
