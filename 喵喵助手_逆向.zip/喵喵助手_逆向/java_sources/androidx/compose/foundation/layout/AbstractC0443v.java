package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.h2;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import e0.AbstractC1306c;
import e0.C1305b;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0443v {
    private static final InterfaceC0933c0 DefaultColumnMeasurePolicy = new C0444w(C0418f.INSTANCE.getTop(), InterfaceC0849g.Companion.getStart());

    public static final void Column(androidx.compose.ui.x xVar, InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 1) != 0) {
            xVar = androidx.compose.ui.x.Companion;
        }
        if ((i3 & 2) != 0) {
            interfaceC0424i = C0418f.INSTANCE.getTop();
        }
        if ((i3 & 4) != 0) {
            interfaceC0822e = InterfaceC0849g.Companion.getStart();
        }
        InterfaceC0933c0 interfaceC0933c0ColumnMeasurePolicy = columnMeasurePolicy(interfaceC0424i, interfaceC0822e, interfaceC0768p, (i2 >> 3) & 126);
        int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768p, 0));
        androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768p.getCurrentCompositionLocalMap();
        androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768p, xVar);
        C0997j c0997j = InterfaceC0999k.Companion;
        h1.a constructor = c0997j.getConstructor();
        if (interfaceC0768p.getApplier() == null) {
            AbstractC0750j.invalidApplier();
        }
        interfaceC0768p.startReusableNode();
        if (interfaceC0768p.getInserting()) {
            interfaceC0768p.createNode(constructor);
        } else {
            interfaceC0768p.useNode();
        }
        InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768p);
        h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0ColumnMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
        if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
            D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
        }
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
        fVar.invoke(C0446y.INSTANCE, interfaceC0768p, Integer.valueOf(((i2 >> 6) & 112) | 6));
        interfaceC0768p.endNode();
    }

    public static final InterfaceC0933c0 columnMeasurePolicy(InterfaceC0424i interfaceC0424i, InterfaceC0822e interfaceC0822e, InterfaceC0768p interfaceC0768p, int i2) {
        InterfaceC0933c0 interfaceC0933c0;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1089876336, i2, -1, "androidx.compose.foundation.layout.columnMeasurePolicy (Column.kt:108)");
        }
        if (kotlin.jvm.internal.o.a(interfaceC0424i, C0418f.INSTANCE.getTop()) && kotlin.jvm.internal.o.a(interfaceC0822e, InterfaceC0849g.Companion.getStart())) {
            interfaceC0768p.startReplaceGroup(-1446569784);
            interfaceC0768p.endReplaceGroup();
            interfaceC0933c0 = DefaultColumnMeasurePolicy;
        } else {
            interfaceC0768p.startReplaceGroup(-1446515937);
            boolean z2 = ((((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(interfaceC0424i)) || (i2 & 6) == 4) | ((((i2 & 112) ^ 48) > 32 && interfaceC0768p.changed(interfaceC0822e)) || (i2 & 48) == 32);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new C0444w(interfaceC0424i, interfaceC0822e);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0933c0 = (C0444w) objRememberedValue;
            interfaceC0768p.endReplaceGroup();
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return interfaceC0933c0;
    }

    public static final long createColumnConstraints(boolean z2, int i2, int i3, int i4, int i5) {
        return !z2 ? AbstractC1306c.Constraints(i3, i5, i2, i4) : C1305b.Companion.m5049fitPrioritizingHeightZbe2FdA(i3, i5, i2, i4);
    }

    public static final InterfaceC0933c0 getDefaultColumnMeasurePolicy() {
        return DefaultColumnMeasurePolicy;
    }

    public static /* synthetic */ void getDefaultColumnMeasurePolicy$annotations() {
    }
}
