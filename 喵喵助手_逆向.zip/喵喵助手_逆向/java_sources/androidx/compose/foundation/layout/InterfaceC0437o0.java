package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.o0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0437o0 {
    /* JADX INFO: renamed from: createConstraints-xF2OJ5Q$default, reason: not valid java name */
    static /* synthetic */ long m1001createConstraintsxF2OJ5Q$default(InterfaceC0437o0 interfaceC0437o0, int i2, int i3, int i4, int i5, boolean z2, int i6, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: createConstraints-xF2OJ5Q");
        }
        if ((i6 & 16) != 0) {
            z2 = false;
        }
        return interfaceC0437o0.mo1002createConstraintsxF2OJ5Q(i2, i3, i4, i5, z2);
    }

    /* JADX INFO: renamed from: createConstraints-xF2OJ5Q, reason: not valid java name */
    long mo1002createConstraintsxF2OJ5Q(int i2, int i3, int i4, int i5, boolean z2);

    int crossAxisSize(AbstractC0974x0 abstractC0974x0);

    int mainAxisSize(AbstractC0974x0 abstractC0974x0);

    InterfaceC0935d0 placeHelper(AbstractC0974x0[] abstractC0974x0Arr, InterfaceC0937e0 interfaceC0937e0, int i2, int[] iArr, int i3, int i4, int[] iArr2, int i5, int i6, int i7);

    void populateMainAxisPositions(int i2, int[] iArr, int[] iArr2, InterfaceC0937e0 interfaceC0937e0);
}
