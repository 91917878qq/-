package androidx.compose.foundation.layout;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.f0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0419f0 {
    static final /* synthetic */ C0419f0 $$INSTANCE = new C0419f0();
    private static final InterfaceC0421g0 Zero = new C0417e0(0.0f, 0.0f, 0.0f, 0.0f, 15, null);

    private C0419f0() {
    }

    public static /* synthetic */ void getZero$annotations() {
    }

    public final InterfaceC0421g0 getZero() {
        return Zero;
    }
}
