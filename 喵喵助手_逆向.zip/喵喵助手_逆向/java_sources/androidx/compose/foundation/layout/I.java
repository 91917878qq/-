package androidx.compose.foundation.layout;

/* JADX INFO: loaded from: classes.dex */
public final class I {
    public static final int $stable = 8;
    private float fillCrossAxisFraction;

    public I(float f2) {
        this.fillCrossAxisFraction = f2;
    }

    public static /* synthetic */ I copy$default(I i2, float f2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            f2 = i2.fillCrossAxisFraction;
        }
        return i2.copy(f2);
    }

    public final float component1() {
        return this.fillCrossAxisFraction;
    }

    public final I copy(float f2) {
        return new I(f2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof I) && Float.compare(this.fillCrossAxisFraction, ((I) obj).fillCrossAxisFraction) == 0;
    }

    public final float getFillCrossAxisFraction() {
        return this.fillCrossAxisFraction;
    }

    public int hashCode() {
        return Float.hashCode(this.fillCrossAxisFraction);
    }

    public final void setFillCrossAxisFraction(float f2) {
        this.fillCrossAxisFraction = f2;
    }

    public String toString() {
        return D0.d.p(new StringBuilder("FlowLayoutData(fillCrossAxisFraction="), this.fillCrossAxisFraction, ')');
    }
}
