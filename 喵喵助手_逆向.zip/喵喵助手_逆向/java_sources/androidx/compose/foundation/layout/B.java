package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.AbstractC0410b;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.layout.AbstractC0928a;
import androidx.compose.ui.layout.AbstractC0974x0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class B {
    public static final int $stable = 0;
    public static final c Companion = new c(null);
    private static final B Center = b.INSTANCE;
    private static final B Start = f.INSTANCE;
    private static final B End = d.INSTANCE;

    public static final class a extends B {
        private final AbstractC0410b alignmentLineProvider;

        public a(AbstractC0410b abstractC0410b) {
            super(null);
            this.alignmentLineProvider = abstractC0410b;
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            int iCalculateAlignmentLinePosition = this.alignmentLineProvider.calculateAlignmentLinePosition(abstractC0974x0);
            if (iCalculateAlignmentLinePosition == Integer.MIN_VALUE) {
                return 0;
            }
            int i4 = i3 - iCalculateAlignmentLinePosition;
            return uVar == e0.u.Rtl ? i2 - i4 : i4;
        }

        @Override // androidx.compose.foundation.layout.B
        public Integer calculateAlignmentLinePosition$foundation_layout(AbstractC0974x0 abstractC0974x0) {
            return Integer.valueOf(this.alignmentLineProvider.calculateAlignmentLinePosition(abstractC0974x0));
        }

        public final AbstractC0410b getAlignmentLineProvider() {
            return this.alignmentLineProvider;
        }

        @Override // androidx.compose.foundation.layout.B
        public boolean isRelative$foundation_layout() {
            return true;
        }
    }

    public static final class b extends B {
        public static final b INSTANCE = new b();

        private b() {
            super(null);
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            return i2 / 2;
        }
    }

    public static final class c {
        public /* synthetic */ c(AbstractC1378g abstractC1378g) {
            this();
        }

        public static /* synthetic */ void getCenter$annotations() {
        }

        public static /* synthetic */ void getEnd$annotations() {
        }

        public static /* synthetic */ void getStart$annotations() {
        }

        public final B AlignmentLine(AbstractC0928a abstractC0928a) {
            return new a(new AbstractC0410b.C0037b(abstractC0928a));
        }

        public final B Relative$foundation_layout(AbstractC0410b abstractC0410b) {
            return new a(abstractC0410b);
        }

        public final B getCenter() {
            return B.Center;
        }

        public final B getEnd() {
            return B.End;
        }

        public final B getStart() {
            return B.Start;
        }

        public final B horizontal$foundation_layout(InterfaceC0822e interfaceC0822e) {
            return new e(interfaceC0822e);
        }

        public final B vertical$foundation_layout(InterfaceC0823f interfaceC0823f) {
            return new g(interfaceC0823f);
        }

        private c() {
        }
    }

    public static final class d extends B {
        public static final d INSTANCE = new d();

        private d() {
            super(null);
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            if (uVar == e0.u.Ltr) {
                return i2;
            }
            return 0;
        }
    }

    public static final class e extends B {
        private final InterfaceC0822e horizontal;

        public e(InterfaceC0822e interfaceC0822e) {
            super(null);
            this.horizontal = interfaceC0822e;
        }

        public static /* synthetic */ e copy$default(e eVar, InterfaceC0822e interfaceC0822e, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                interfaceC0822e = eVar.horizontal;
            }
            return eVar.copy(interfaceC0822e);
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            return this.horizontal.align(0, i2, uVar);
        }

        public final InterfaceC0822e component1() {
            return this.horizontal;
        }

        public final e copy(InterfaceC0822e interfaceC0822e) {
            return new e(interfaceC0822e);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof e) && kotlin.jvm.internal.o.a(this.horizontal, ((e) obj).horizontal);
        }

        public final InterfaceC0822e getHorizontal() {
            return this.horizontal;
        }

        public int hashCode() {
            return this.horizontal.hashCode();
        }

        public String toString() {
            return "HorizontalCrossAxisAlignment(horizontal=" + this.horizontal + ')';
        }
    }

    public static final class f extends B {
        public static final f INSTANCE = new f();

        private f() {
            super(null);
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            if (uVar == e0.u.Ltr) {
                return 0;
            }
            return i2;
        }
    }

    public static final class g extends B {
        private final InterfaceC0823f vertical;

        public g(InterfaceC0823f interfaceC0823f) {
            super(null);
            this.vertical = interfaceC0823f;
        }

        public static /* synthetic */ g copy$default(g gVar, InterfaceC0823f interfaceC0823f, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                interfaceC0823f = gVar.vertical;
            }
            return gVar.copy(interfaceC0823f);
        }

        @Override // androidx.compose.foundation.layout.B
        public int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3) {
            return this.vertical.align(0, i2);
        }

        public final InterfaceC0823f component1() {
            return this.vertical;
        }

        public final g copy(InterfaceC0823f interfaceC0823f) {
            return new g(interfaceC0823f);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof g) && kotlin.jvm.internal.o.a(this.vertical, ((g) obj).vertical);
        }

        public final InterfaceC0823f getVertical() {
            return this.vertical;
        }

        public int hashCode() {
            return this.vertical.hashCode();
        }

        public String toString() {
            return "VerticalCrossAxisAlignment(vertical=" + this.vertical + ')';
        }
    }

    public /* synthetic */ B(AbstractC1378g abstractC1378g) {
        this();
    }

    public abstract int align$foundation_layout(int i2, e0.u uVar, AbstractC0974x0 abstractC0974x0, int i3);

    public Integer calculateAlignmentLinePosition$foundation_layout(AbstractC0974x0 abstractC0974x0) {
        return null;
    }

    public boolean isRelative$foundation_layout() {
        return false;
    }

    private B() {
    }
}
