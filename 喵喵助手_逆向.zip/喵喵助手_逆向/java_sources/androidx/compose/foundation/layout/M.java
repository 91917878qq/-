package androidx.compose.foundation.layout;

import androidx.compose.runtime.V1;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;

/* JADX INFO: loaded from: classes.dex */
public final class M implements androidx.compose.ui.layout.P, androidx.compose.ui.modifier.d, androidx.compose.ui.modifier.j {
    public static final int $stable = 0;
    private final androidx.compose.runtime.B0 consumedInsets$delegate;
    private final H0 insets;
    private final androidx.compose.runtime.B0 unconsumedInsets$delegate;

    public M(H0 h02) {
        this.insets = h02;
        this.unconsumedInsets$delegate = V1.mutableStateOf$default(h02, null, 2, null);
        this.consumedInsets$delegate = V1.mutableStateOf$default(h02, null, 2, null);
    }

    private final H0 getConsumedInsets() {
        return (H0) this.consumedInsets$delegate.getValue();
    }

    private final H0 getUnconsumedInsets() {
        return (H0) this.unconsumedInsets$delegate.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(AbstractC0974x0 abstractC0974x0, int i2, int i3, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.place$default(aVar, abstractC0974x0, i2, i3, 0.0f, 4, null);
        return U0.n.f1521a;
    }

    private final void setConsumedInsets(H0 h02) {
        this.consumedInsets$delegate.setValue(h02);
    }

    private final void setUnconsumedInsets(H0 h02) {
        this.unconsumedInsets$delegate.setValue(h02);
    }

    @Override // androidx.compose.ui.layout.P, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.layout.P, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof M) {
            return kotlin.jvm.internal.o.a(((M) obj).insets, this.insets);
        }
        return false;
    }

    @Override // androidx.compose.ui.layout.P, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.layout.P, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.modifier.j
    public androidx.compose.ui.modifier.m getKey() {
        return K0.getModifierLocalConsumedWindowInsets();
    }

    public int hashCode() {
        return this.insets.hashCode();
    }

    @Override // androidx.compose.ui.layout.P
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.layout.P
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.layout.P
    /* JADX INFO: renamed from: measure-3p2s80s, reason: not valid java name */
    public InterfaceC0935d0 mo902measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        int left = getUnconsumedInsets().getLeft(interfaceC0937e0, interfaceC0937e0.getLayoutDirection());
        int top = getUnconsumedInsets().getTop(interfaceC0937e0);
        int right = getUnconsumedInsets().getRight(interfaceC0937e0, interfaceC0937e0.getLayoutDirection()) + left;
        int bottom = getUnconsumedInsets().getBottom(interfaceC0937e0) + top;
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.m5060offsetNN6EwU(j2, -right, -bottom));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, AbstractC1306c.m5058constrainWidthK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getWidth() + right), AbstractC1306c.m5057constrainHeightK40F9xA(j2, abstractC0974x0Mo3865measureBRTryo0.getHeight() + bottom), null, new androidx.compose.foundation.y0(abstractC0974x0Mo3865measureBRTryo0, left, top, 1), 4, null);
    }

    @Override // androidx.compose.ui.layout.P
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.layout.P
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.modifier.d
    public void onModifierLocalsUpdated(androidx.compose.ui.modifier.k kVar) {
        H0 h02 = (H0) kVar.getCurrent(K0.getModifierLocalConsumedWindowInsets());
        setUnconsumedInsets(J0.exclude(this.insets, h02));
        setConsumedInsets(J0.union(h02, this.insets));
    }

    @Override // androidx.compose.ui.layout.P, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.modifier.j
    public H0 getValue() {
        return getConsumedInsets();
    }
}
