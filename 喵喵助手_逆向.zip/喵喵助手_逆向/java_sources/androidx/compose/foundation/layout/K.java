package androidx.compose.foundation.layout;

import androidx.compose.runtime.V1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class K implements androidx.compose.ui.modifier.d, androidx.compose.ui.modifier.j {
    private final androidx.compose.runtime.B0 consumedInsets$delegate;

    public /* synthetic */ K(AbstractC1378g abstractC1378g) {
        this();
    }

    private final H0 getConsumedInsets() {
        return (H0) this.consumedInsets$delegate.getValue();
    }

    private final void setConsumedInsets(H0 h02) {
        this.consumedInsets$delegate.setValue(h02);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    public abstract H0 calculateInsets(H0 h02);

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.modifier.j
    public androidx.compose.ui.modifier.m getKey() {
        return K0.getModifierLocalConsumedWindowInsets();
    }

    @Override // androidx.compose.ui.modifier.d
    public void onModifierLocalsUpdated(androidx.compose.ui.modifier.k kVar) {
        setConsumedInsets(calculateInsets((H0) kVar.getCurrent(K0.getModifierLocalConsumedWindowInsets())));
    }

    @Override // androidx.compose.ui.modifier.d, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    private K() {
        this.consumedInsets$delegate = V1.mutableStateOf$default(J0.WindowInsets(0, 0, 0, 0), null, 2, null);
    }

    @Override // androidx.compose.ui.modifier.j
    public H0 getValue() {
        return getConsumedInsets();
    }
}
