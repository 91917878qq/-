package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.layout.C0975y;

/* JADX INFO: loaded from: classes.dex */
public interface u0 {
    static /* synthetic */ androidx.compose.ui.x weight$default(u0 u0Var, androidx.compose.ui.x xVar, float f2, boolean z2, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: weight");
        }
        if ((i2 & 2) != 0) {
            z2 = true;
        }
        return u0Var.weight(xVar, f2, z2);
    }

    androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0823f interfaceC0823f);

    androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, C0975y c0975y);

    androidx.compose.ui.x alignBy(androidx.compose.ui.x xVar, h1.c cVar);

    androidx.compose.ui.x alignByBaseline(androidx.compose.ui.x xVar);

    androidx.compose.ui.x weight(androidx.compose.ui.x xVar, float f2, boolean z2);
}
