package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0408a implements H0 {
    private final H0 first;
    private final H0 second;

    public C0408a(H0 h02, H0 h03) {
        this.first = h02;
        this.second = h03;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0408a)) {
            return false;
        }
        C0408a c0408a = (C0408a) obj;
        return kotlin.jvm.internal.o.a(c0408a.first, this.first) && kotlin.jvm.internal.o.a(c0408a.second, this.second);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return this.second.getBottom(interfaceC1307d) + this.first.getBottom(interfaceC1307d);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return this.second.getLeft(interfaceC1307d, uVar) + this.first.getLeft(interfaceC1307d, uVar);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return this.second.getRight(interfaceC1307d, uVar) + this.first.getRight(interfaceC1307d, uVar);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return this.second.getTop(interfaceC1307d) + this.first.getTop(interfaceC1307d);
    }

    public int hashCode() {
        return (this.second.hashCode() * 31) + this.first.hashCode();
    }

    public String toString() {
        return "(" + this.first + " + " + this.second + ')';
    }
}
