package androidx.compose.foundation.layout;

import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;

/* JADX INFO: loaded from: classes.dex */
public abstract class Y {
    public static final androidx.compose.ui.x absoluteOffset(androidx.compose.ui.x xVar, h1.c cVar) {
        return xVar.then(new OffsetPxElement(cVar, false, new O0.S(3, cVar)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n absoluteOffset$lambda$3(h1.c cVar, C1065l1 c1065l1) {
        c1065l1.setName("absoluteOffset");
        c1065l1.getProperties().set("offset", cVar);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: absoluteOffset-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m943absoluteOffsetVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new OffsetElement(f2, f3, false, new R0.b(f2, f3, 2), null));
    }

    /* JADX INFO: renamed from: absoluteOffset-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m944absoluteOffsetVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        return m943absoluteOffsetVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n absoluteOffset_VpY3zN4$lambda$1(float f2, float f3, C1065l1 c1065l1) {
        c1065l1.setName("absoluteOffset");
        D0.d.k(f2, c1065l1.getProperties(), "x", c1065l1).set("y", C1311h.m5074boximpl(f3));
        return U0.n.f1521a;
    }

    public static final androidx.compose.ui.x offset(androidx.compose.ui.x xVar, h1.c cVar) {
        return xVar.then(new OffsetPxElement(cVar, true, new O0.S(2, cVar)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n offset$lambda$2(h1.c cVar, C1065l1 c1065l1) {
        c1065l1.setName("offset");
        c1065l1.getProperties().set("offset", cVar);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: offset-VpY3zN4, reason: not valid java name */
    public static final androidx.compose.ui.x m945offsetVpY3zN4(androidx.compose.ui.x xVar, float f2, float f3) {
        return xVar.then(new OffsetElement(f2, f3, true, new R0.b(f2, f3, 3), null));
    }

    /* JADX INFO: renamed from: offset-VpY3zN4$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m946offsetVpY3zN4$default(androidx.compose.ui.x xVar, float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = C1311h.m5076constructorimpl(0);
        }
        if ((i2 & 2) != 0) {
            f3 = C1311h.m5076constructorimpl(0);
        }
        return m945offsetVpY3zN4(xVar, f2, f3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n offset_VpY3zN4$lambda$0(float f2, float f3, C1065l1 c1065l1) {
        c1065l1.setName("offset");
        D0.d.k(f2, c1065l1.getProperties(), "x", c1065l1).set("y", C1311h.m5074boximpl(f3));
        return U0.n.f1521a;
    }
}
