package androidx.compose.foundation.layout;

import e0.C1311h;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class G implements H0 {
    private final float bottomDp;
    private final float leftDp;
    private final float rightDp;
    private final float topDp;

    public /* synthetic */ G(float f2, float f3, float f4, float f5, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof G)) {
            return false;
        }
        G g2 = (G) obj;
        return C1311h.m5081equalsimpl0(this.leftDp, g2.leftDp) && C1311h.m5081equalsimpl0(this.topDp, g2.topDp) && C1311h.m5081equalsimpl0(this.rightDp, g2.rightDp) && C1311h.m5081equalsimpl0(this.bottomDp, g2.bottomDp);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.bottomDp);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.leftDp);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.rightDp);
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return interfaceC1307d.mo782roundToPx0680j_4(this.topDp);
    }

    public int hashCode() {
        return C1311h.m5082hashCodeimpl(this.bottomDp) + D0.d.C(this.rightDp, D0.d.C(this.topDp, C1311h.m5082hashCodeimpl(this.leftDp) * 31, 31), 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Insets(left=");
        D0.d.u(this.leftDp, sb, ", top=");
        D0.d.u(this.topDp, sb, ", right=");
        D0.d.u(this.rightDp, sb, ", bottom=");
        sb.append((Object) C1311h.m5087toStringimpl(this.bottomDp));
        sb.append(')');
        return sb.toString();
    }

    private G(float f2, float f3, float f4, float f5) {
        this.leftDp = f2;
        this.topDp = f3;
        this.rightDp = f4;
        this.bottomDp = f5;
    }
}
