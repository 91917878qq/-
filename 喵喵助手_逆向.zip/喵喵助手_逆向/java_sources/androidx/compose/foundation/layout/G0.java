package androidx.compose.foundation.layout;

/* JADX INFO: loaded from: classes.dex */
public final class G0 {
    static final /* synthetic */ G0 $$INSTANCE = new G0();

    private G0() {
    }
}
