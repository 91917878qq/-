package androidx.compose.foundation.layout;

import androidx.compose.runtime.V1;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class E0 implements H0 {
    public static final int $stable = 0;
    private final String name;
    private final androidx.compose.runtime.B0 value$delegate;

    public E0(O o2, String str) {
        this.name = str;
        this.value$delegate = V1.mutableStateOf$default(o2, null, 2, null);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof E0) {
            return kotlin.jvm.internal.o.a(getValue$foundation_layout(), ((E0) obj).getValue$foundation_layout());
        }
        return false;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getBottom(InterfaceC1307d interfaceC1307d) {
        return getValue$foundation_layout().getBottom();
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return getValue$foundation_layout().getLeft();
    }

    public final String getName() {
        return this.name;
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar) {
        return getValue$foundation_layout().getRight();
    }

    @Override // androidx.compose.foundation.layout.H0
    public int getTop(InterfaceC1307d interfaceC1307d) {
        return getValue$foundation_layout().getTop();
    }

    public final O getValue$foundation_layout() {
        return (O) this.value$delegate.getValue();
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    public final void setValue$foundation_layout(O o2) {
        this.value$delegate.setValue(o2);
    }

    public String toString() {
        return this.name + "(left=" + getValue$foundation_layout().getLeft() + ", top=" + getValue$foundation_layout().getTop() + ", right=" + getValue$foundation_layout().getRight() + ", bottom=" + getValue$foundation_layout().getBottom() + ')';
    }
}
