package androidx.compose.foundation.layout;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public interface H0 {
    public static final G0 Companion = G0.$$INSTANCE;

    int getBottom(InterfaceC1307d interfaceC1307d);

    int getLeft(InterfaceC1307d interfaceC1307d, e0.u uVar);

    int getRight(InterfaceC1307d interfaceC1307d, e0.u uVar);

    int getTop(InterfaceC1307d interfaceC1307d);
}
