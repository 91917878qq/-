package androidx.compose.foundation.layout;

import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
public abstract class Q {

    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ T $intrinsicSize$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(T t2) {
            super(1);
            this.$intrinsicSize$inlined = t2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("height");
            c1065l1.getProperties().set("intrinsicSize", this.$intrinsicSize$inlined);
        }
    }

    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ T $intrinsicSize$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(T t2) {
            super(1);
            this.$intrinsicSize$inlined = t2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredHeight");
            c1065l1.getProperties().set("intrinsicSize", this.$intrinsicSize$inlined);
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ T $intrinsicSize$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(T t2) {
            super(1);
            this.$intrinsicSize$inlined = t2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("requiredWidth");
            c1065l1.getProperties().set("intrinsicSize", this.$intrinsicSize$inlined);
        }
    }

    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ T $intrinsicSize$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(T t2) {
            super(1);
            this.$intrinsicSize$inlined = t2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("width");
            c1065l1.getProperties().set("intrinsicSize", this.$intrinsicSize$inlined);
        }
    }

    public static final androidx.compose.ui.x height(androidx.compose.ui.x xVar, T t2) {
        return xVar.then(new IntrinsicHeightElement(t2, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(t2) : AbstractC1056i1.getNoInspectorInfo()));
    }

    public static final androidx.compose.ui.x requiredHeight(androidx.compose.ui.x xVar, T t2) {
        return xVar.then(new IntrinsicHeightElement(t2, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new b(t2) : AbstractC1056i1.getNoInspectorInfo()));
    }

    public static final androidx.compose.ui.x requiredWidth(androidx.compose.ui.x xVar, T t2) {
        return xVar.then(new IntrinsicWidthElement(t2, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new c(t2) : AbstractC1056i1.getNoInspectorInfo()));
    }

    public static final androidx.compose.ui.x width(androidx.compose.ui.x xVar, T t2) {
        return xVar.then(new IntrinsicWidthElement(t2, true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new d(t2) : AbstractC1056i1.getNoInspectorInfo()));
    }
}
