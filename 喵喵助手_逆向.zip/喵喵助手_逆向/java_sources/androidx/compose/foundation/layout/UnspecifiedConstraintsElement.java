package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
final class UnspecifiedConstraintsElement extends AbstractC1000k0 {
    private final float minHeight;
    private final float minWidth;

    public /* synthetic */ UnspecifiedConstraintsElement(float f2, float f3, AbstractC1378g abstractC1378g) {
        this(f2, f3);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (!(obj instanceof UnspecifiedConstraintsElement)) {
            return false;
        }
        UnspecifiedConstraintsElement unspecifiedConstraintsElement = (UnspecifiedConstraintsElement) obj;
        return C1311h.m5081equalsimpl0(this.minWidth, unspecifiedConstraintsElement.minWidth) && C1311h.m5081equalsimpl0(this.minHeight, unspecifiedConstraintsElement.minHeight);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    /* JADX INFO: renamed from: getMinHeight-D9Ej5fM, reason: not valid java name */
    public final float m940getMinHeightD9Ej5fM() {
        return this.minHeight;
    }

    /* JADX INFO: renamed from: getMinWidth-D9Ej5fM, reason: not valid java name */
    public final float m941getMinWidthD9Ej5fM() {
        return this.minWidth;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return C1311h.m5082hashCodeimpl(this.minHeight) + (C1311h.m5082hashCodeimpl(this.minWidth) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("defaultMinSize");
        D0.d.k(this.minWidth, c1065l1.getProperties(), "minWidth", c1065l1).set("minHeight", C1311h.m5074boximpl(this.minHeight));
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public /* synthetic */ UnspecifiedConstraintsElement(float f2, float f3, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f2, (i2 & 2) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public D0 create() {
        return new D0(this.minWidth, this.minHeight, null);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(D0 d02) {
        d02.m898setMinWidth0680j_4(this.minWidth);
        d02.m897setMinHeight0680j_4(this.minHeight);
    }

    private UnspecifiedConstraintsElement(float f2, float f3) {
        this.minWidth = f2;
        this.minHeight = f3;
    }
}
