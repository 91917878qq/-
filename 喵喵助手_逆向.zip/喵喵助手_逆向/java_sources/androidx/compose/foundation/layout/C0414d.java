package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.C0418f;
import androidx.compose.foundation.layout.WrapContentElement;
import androidx.compose.ui.InterfaceC0822e;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0414d implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1774b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0822e f1775c;

    public /* synthetic */ C0414d(InterfaceC0822e interfaceC0822e, int i2) {
        this.f1774b = i2;
        this.f1775c = interfaceC0822e;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1774b) {
            case 0:
                return Integer.valueOf(C0418f.spacedBy_D5KLDUw$lambda$1(this.f1775c, ((Integer) obj).intValue(), (e0.u) obj2));
            case 1:
                return Integer.valueOf(C0418f.aligned$lambda$3(this.f1775c, ((Integer) obj).intValue(), (e0.u) obj2));
            case 2:
                return Integer.valueOf(C0418f.a.aligned$lambda$2(this.f1775c, ((Integer) obj).intValue(), (e0.u) obj2));
            case 3:
                return Integer.valueOf(C0418f.a.spacedBy_D5KLDUw$lambda$0(this.f1775c, ((Integer) obj).intValue(), (e0.u) obj2));
            default:
                return WrapContentElement.a.width$lambda$0(this.f1775c, (e0.s) obj, (e0.u) obj2);
        }
    }
}
