package androidx.compose.foundation.layout;

import androidx.compose.foundation.layout.C0418f;
import androidx.compose.foundation.layout.WrapContentElement;
import androidx.compose.ui.InterfaceC0823f;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0416e implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1776b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0823f f1777c;

    public /* synthetic */ C0416e(InterfaceC0823f interfaceC0823f, int i2) {
        this.f1776b = i2;
        this.f1777c = interfaceC0823f;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1776b) {
            case 0:
                return Integer.valueOf(C0418f.spacedBy_D5KLDUw$lambda$2(this.f1777c, ((Integer) obj).intValue(), (e0.u) obj2));
            case 1:
                return Integer.valueOf(C0418f.aligned$lambda$4(this.f1777c, ((Integer) obj).intValue(), (e0.u) obj2));
            case 2:
                return Integer.valueOf(C0418f.a.spacedBy_D5KLDUw$lambda$1(this.f1777c, ((Integer) obj).intValue(), (e0.u) obj2));
            default:
                return WrapContentElement.a.height$lambda$1(this.f1777c, (e0.s) obj, (e0.u) obj2);
        }
    }
}
