package androidx.compose.foundation.layout;

import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.h2;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import e0.AbstractC1306c;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public abstract class r0 {
    private static final InterfaceC0933c0 DefaultRowMeasurePolicy = new t0(C0418f.INSTANCE.getStart(), InterfaceC0849g.Companion.getTop());

    public static final void Row(androidx.compose.ui.x xVar, InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 1) != 0) {
            xVar = androidx.compose.ui.x.Companion;
        }
        if ((i3 & 2) != 0) {
            interfaceC0420g = C0418f.INSTANCE.getStart();
        }
        if ((i3 & 4) != 0) {
            interfaceC0823f = InterfaceC0849g.Companion.getTop();
        }
        InterfaceC0933c0 interfaceC0933c0RowMeasurePolicy = rowMeasurePolicy(interfaceC0420g, interfaceC0823f, interfaceC0768p, (i2 >> 3) & 126);
        int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768p, 0));
        androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768p.getCurrentCompositionLocalMap();
        androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768p, xVar);
        C0997j c0997j = InterfaceC0999k.Companion;
        h1.a constructor = c0997j.getConstructor();
        if (interfaceC0768p.getApplier() == null) {
            AbstractC0750j.invalidApplier();
        }
        interfaceC0768p.startReusableNode();
        if (interfaceC0768p.getInserting()) {
            interfaceC0768p.createNode(constructor);
        } else {
            interfaceC0768p.useNode();
        }
        InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768p);
        h1.e eVarM = D0.d.m(c0997j, interfaceC0768pM2592constructorimpl, interfaceC0933c0RowMeasurePolicy, interfaceC0768pM2592constructorimpl, currentCompositionLocalMap);
        if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
            D0.d.z(eVarM, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
        }
        h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
        fVar.invoke(v0.INSTANCE, interfaceC0768p, Integer.valueOf(((i2 >> 6) & 112) | 6));
        interfaceC0768p.endNode();
    }

    public static final long createRowConstraints(boolean z2, int i2, int i3, int i4, int i5) {
        return !z2 ? AbstractC1306c.Constraints(i2, i4, i3, i5) : C1305b.Companion.m5050fitPrioritizingWidthZbe2FdA(i2, i4, i3, i5);
    }

    public static final InterfaceC0933c0 getDefaultRowMeasurePolicy() {
        return DefaultRowMeasurePolicy;
    }

    public static /* synthetic */ void getDefaultRowMeasurePolicy$annotations() {
    }

    public static final InterfaceC0933c0 rowMeasurePolicy(InterfaceC0420g interfaceC0420g, InterfaceC0823f interfaceC0823f, InterfaceC0768p interfaceC0768p, int i2) {
        InterfaceC0933c0 interfaceC0933c0;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-837807694, i2, -1, "androidx.compose.foundation.layout.rowMeasurePolicy (Row.kt:118)");
        }
        if (kotlin.jvm.internal.o.a(interfaceC0420g, C0418f.INSTANCE.getStart()) && kotlin.jvm.internal.o.a(interfaceC0823f, InterfaceC0849g.Companion.getTop())) {
            interfaceC0768p.startReplaceGroup(-1073795767);
            interfaceC0768p.endReplaceGroup();
            interfaceC0933c0 = DefaultRowMeasurePolicy;
        } else {
            interfaceC0768p.startReplaceGroup(-1073744896);
            boolean z2 = ((((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(interfaceC0420g)) || (i2 & 6) == 4) | ((((i2 & 112) ^ 48) > 32 && interfaceC0768p.changed(interfaceC0823f)) || (i2 & 48) == 32);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new t0(interfaceC0420g, interfaceC0823f);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0933c0 = (t0) objRememberedValue;
            interfaceC0768p.endReplaceGroup();
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return interfaceC0933c0;
    }
}
