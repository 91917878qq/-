package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0937e0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class s0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1802b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1803c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1804d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1805e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1806f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f1807g;

    public /* synthetic */ s0(O0 o02, int i2, AbstractC0974x0 abstractC0974x0, int i3, InterfaceC0937e0 interfaceC0937e0) {
        this.f1805e = o02;
        this.f1803c = i2;
        this.f1806f = abstractC0974x0;
        this.f1804d = i3;
        this.f1807g = interfaceC0937e0;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1802b) {
            case 0:
                AbstractC0974x0.a aVar = (AbstractC0974x0.a) obj;
                return t0.placeHelper$lambda$3$lambda$2((AbstractC0974x0[]) this.f1805e, (t0) this.f1806f, this.f1803c, this.f1804d, (int[]) this.f1807g, aVar);
            default:
                AbstractC0974x0.a aVar2 = (AbstractC0974x0.a) obj;
                return O0.measure_3p2s80s$lambda$0((O0) this.f1805e, this.f1803c, (AbstractC0974x0) this.f1806f, this.f1804d, (InterfaceC0937e0) this.f1807g, aVar2);
        }
    }

    public /* synthetic */ s0(AbstractC0974x0[] abstractC0974x0Arr, t0 t0Var, int i2, int i3, int[] iArr) {
        this.f1805e = abstractC0974x0Arr;
        this.f1806f = t0Var;
        this.f1803c = i2;
        this.f1804d = i3;
        this.f1807g = iArr;
    }
}
