package androidx.compose.foundation.layout;

import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;
import p.AbstractC1408a;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.i0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0425i0 implements InterfaceC0421g0 {
    public static final int $stable = 0;
    private final float bottom;
    private final float end;
    private final float start;
    private final float top;

    public /* synthetic */ C0425i0(float f2, float f3, float f4, float f5, AbstractC1378g abstractC1378g) {
        this(f2, f3, f4, f5);
    }

    /* JADX INFO: renamed from: getBottom-D9Ej5fM$annotations, reason: not valid java name */
    public static /* synthetic */ void m991getBottomD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getEnd-D9Ej5fM$annotations, reason: not valid java name */
    public static /* synthetic */ void m992getEndD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getStart-D9Ej5fM$annotations, reason: not valid java name */
    public static /* synthetic */ void m993getStartD9Ej5fM$annotations() {
    }

    /* JADX INFO: renamed from: getTop-D9Ej5fM$annotations, reason: not valid java name */
    public static /* synthetic */ void m994getTopD9Ej5fM$annotations() {
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateBottomPadding-D9Ej5fM */
    public float mo925calculateBottomPaddingD9Ej5fM() {
        return this.bottom;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateLeftPadding-u2uoSUM */
    public float mo926calculateLeftPaddingu2uoSUM(e0.u uVar) {
        return uVar == e0.u.Ltr ? this.start : this.end;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateRightPadding-u2uoSUM */
    public float mo927calculateRightPaddingu2uoSUM(e0.u uVar) {
        return uVar == e0.u.Ltr ? this.end : this.start;
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0421g0
    /* JADX INFO: renamed from: calculateTopPadding-D9Ej5fM */
    public float mo928calculateTopPaddingD9Ej5fM() {
        return this.top;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0425i0)) {
            return false;
        }
        C0425i0 c0425i0 = (C0425i0) obj;
        return C1311h.m5081equalsimpl0(this.start, c0425i0.start) && C1311h.m5081equalsimpl0(this.top, c0425i0.top) && C1311h.m5081equalsimpl0(this.end, c0425i0.end) && C1311h.m5081equalsimpl0(this.bottom, c0425i0.bottom);
    }

    /* JADX INFO: renamed from: getBottom-D9Ej5fM, reason: not valid java name */
    public final float m995getBottomD9Ej5fM() {
        return this.bottom;
    }

    /* JADX INFO: renamed from: getEnd-D9Ej5fM, reason: not valid java name */
    public final float m996getEndD9Ej5fM() {
        return this.end;
    }

    /* JADX INFO: renamed from: getStart-D9Ej5fM, reason: not valid java name */
    public final float m997getStartD9Ej5fM() {
        return this.start;
    }

    /* JADX INFO: renamed from: getTop-D9Ej5fM, reason: not valid java name */
    public final float m998getTopD9Ej5fM() {
        return this.top;
    }

    public int hashCode() {
        return C1311h.m5082hashCodeimpl(this.bottom) + D0.d.C(this.end, D0.d.C(this.top, C1311h.m5082hashCodeimpl(this.start) * 31, 31), 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("PaddingValues(start=");
        D0.d.u(this.start, sb, ", top=");
        D0.d.u(this.top, sb, ", end=");
        D0.d.u(this.end, sb, ", bottom=");
        sb.append((Object) C1311h.m5087toStringimpl(this.bottom));
        sb.append(')');
        return sb.toString();
    }

    private C0425i0(float f2, float f3, float f4, float f5) {
        this.start = f2;
        this.top = f3;
        this.end = f4;
        this.bottom = f5;
        if (!((f2 >= 0.0f) & (f3 >= 0.0f) & (f4 >= 0.0f)) || !(f5 >= 0.0f)) {
            AbstractC1408a.throwIllegalArgumentException("Padding must be non-negative");
        }
    }

    public /* synthetic */ C0425i0(float f2, float f3, float f4, float f5, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? C1311h.m5076constructorimpl(0) : f2, (i2 & 2) != 0 ? C1311h.m5076constructorimpl(0) : f3, (i2 & 4) != 0 ? C1311h.m5076constructorimpl(0) : f4, (i2 & 8) != 0 ? C1311h.m5076constructorimpl(0) : f5, null);
    }
}
