package androidx.compose.foundation.layout;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class OffsetPxElement extends AbstractC1000k0 {
    private final h1.c inspectorInfo;
    private final h1.c offset;
    private final boolean rtlAware;

    public OffsetPxElement(h1.c cVar, boolean z2, h1.c cVar2) {
        this.offset = cVar;
        this.rtlAware = z2;
        this.inspectorInfo = cVar2;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        OffsetPxElement offsetPxElement = obj instanceof OffsetPxElement ? (OffsetPxElement) obj : null;
        if (offsetPxElement == null) {
            return false;
        }
        return this.offset == offsetPxElement.offset && this.rtlAware == offsetPxElement.rtlAware;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final h1.c getInspectorInfo() {
        return this.inspectorInfo;
    }

    public final h1.c getOffset() {
        return this.offset;
    }

    public final boolean getRtlAware() {
        return this.rtlAware;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        return Boolean.hashCode(this.rtlAware) + (this.offset.hashCode() * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        this.inspectorInfo.invoke(c1065l1);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public String toString() {
        return "OffsetPxModifier(offset=" + this.offset + ", rtlAware=" + this.rtlAware + ')';
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0409a0 create() {
        return new C0409a0(this.offset, this.rtlAware);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0409a0 c0409a0) {
        c0409a0.update(this.offset, this.rtlAware);
    }
}
