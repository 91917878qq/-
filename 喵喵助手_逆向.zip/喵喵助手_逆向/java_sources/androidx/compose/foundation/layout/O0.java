package androidx.compose.foundation.layout;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import e0.C1305b;

/* JADX INFO: loaded from: classes.dex */
public final class O0 extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    private h1.e alignmentCallback;
    private C direction;
    private boolean unbounded;

    public O0(C c2, boolean z2, h1.e eVar) {
        this.direction = c2;
        this.unbounded = z2;
        this.alignmentCallback = eVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n measure_3p2s80s$lambda$0(O0 o02, int i2, AbstractC0974x0 abstractC0974x0, int i3, InterfaceC0937e0 interfaceC0937e0, AbstractC0974x0.a aVar) {
        AbstractC0974x0.a.m3923place70tqf50$default(aVar, abstractC0974x0, ((e0.o) o02.alignmentCallback.invoke(e0.s.m5231boximpl(e0.s.m5234constructorimpl((((long) (i2 - abstractC0974x0.getWidth())) << 32) | (((long) (i3 - abstractC0974x0.getHeight())) & 4294967295L))), interfaceC0937e0.getLayoutDirection())).m5205unboximpl(), 0.0f, 2, null);
        return U0.n.f1521a;
    }

    public final h1.e getAlignmentCallback() {
        return this.alignmentCallback;
    }

    public final C getDirection() {
        return this.direction;
    }

    public final boolean getUnbounded() {
        return this.unbounded;
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.maxIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        C c2 = this.direction;
        C c3 = C.Vertical;
        int iM5043getMinWidthimpl = c2 != c3 ? 0 : C1305b.m5043getMinWidthimpl(j2);
        C c4 = this.direction;
        C c5 = C.Horizontal;
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(AbstractC1306c.Constraints(iM5043getMinWidthimpl, (this.direction == c3 || !this.unbounded) ? C1305b.m5041getMaxWidthimpl(j2) : Integer.MAX_VALUE, c4 == c5 ? C1305b.m5042getMinHeightimpl(j2) : 0, (this.direction == c5 || !this.unbounded) ? C1305b.m5040getMaxHeightimpl(j2) : Integer.MAX_VALUE));
        int iO = j1.a.o(abstractC0974x0Mo3865measureBRTryo0.getWidth(), C1305b.m5043getMinWidthimpl(j2), C1305b.m5041getMaxWidthimpl(j2));
        int iO2 = j1.a.o(abstractC0974x0Mo3865measureBRTryo0.getHeight(), C1305b.m5042getMinHeightimpl(j2), C1305b.m5040getMaxHeightimpl(j2));
        return InterfaceC0937e0.layout$default(interfaceC0937e0, iO, iO2, null, new s0(this, iO, abstractC0974x0Mo3865measureBRTryo0, iO2, interfaceC0937e0), 4, null);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicHeight(f2, e2, i2);
    }

    @Override // androidx.compose.ui.node.M
    public /* bridge */ /* synthetic */ int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return super.minIntrinsicWidth(f2, e2, i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setAlignmentCallback(h1.e eVar) {
        this.alignmentCallback = eVar;
    }

    public final void setDirection(C c2) {
        this.direction = c2;
    }

    public final void setUnbounded(boolean z2) {
        this.unbounded = z2;
    }
}
