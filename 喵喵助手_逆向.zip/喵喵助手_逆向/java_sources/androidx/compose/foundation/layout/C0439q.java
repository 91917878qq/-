package androidx.compose.foundation.layout;

import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: renamed from: androidx.compose.foundation.layout.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0439q implements InterfaceC0438p {
    public static final int $stable = 0;
    public static final C0439q INSTANCE = new C0439q();

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.q$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ InterfaceC0849g $alignment$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(InterfaceC0849g interfaceC0849g) {
            super(1);
            this.$alignment$inlined = interfaceC0849g;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("align");
            c1065l1.setValue(this.$alignment$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.layout.q$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        public b() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("matchParentSize");
        }
    }

    private C0439q() {
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0438p
    public androidx.compose.ui.x align(androidx.compose.ui.x xVar, InterfaceC0849g interfaceC0849g) {
        return xVar.then(new BoxChildDataElement(interfaceC0849g, false, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(interfaceC0849g) : AbstractC1056i1.getNoInspectorInfo()));
    }

    @Override // androidx.compose.foundation.layout.InterfaceC0438p
    public androidx.compose.ui.x matchParentSize(androidx.compose.ui.x xVar) {
        return xVar.then(new BoxChildDataElement(InterfaceC0849g.Companion.getCenter(), true, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new b() : AbstractC1056i1.getNoInspectorInfo()));
    }
}
