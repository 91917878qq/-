package androidx.compose.foundation;

import androidx.compose.ui.graphics.AbstractC0897x0;
import androidx.compose.ui.graphics.C0895w0;
import androidx.compose.ui.graphics.InterfaceC0892v0;
import androidx.compose.ui.graphics.K0;
import androidx.compose.ui.graphics.drawscope.a;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0404i {
    private K0 borderPath;
    private androidx.compose.ui.graphics.S canvas;
    private androidx.compose.ui.graphics.drawscope.a canvasDrawScope;
    private InterfaceC0892v0 imageBitmap;

    public C0404i() {
        this(null, null, null, null, 15, null);
    }

    private final InterfaceC0892v0 component1() {
        return this.imageBitmap;
    }

    private final androidx.compose.ui.graphics.S component2() {
        return this.canvas;
    }

    private final androidx.compose.ui.graphics.drawscope.a component3() {
        return this.canvasDrawScope;
    }

    private final K0 component4() {
        return this.borderPath;
    }

    public static /* synthetic */ C0404i copy$default(C0404i c0404i, InterfaceC0892v0 interfaceC0892v0, androidx.compose.ui.graphics.S s2, androidx.compose.ui.graphics.drawscope.a aVar, K0 k0, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0892v0 = c0404i.imageBitmap;
        }
        if ((i2 & 2) != 0) {
            s2 = c0404i.canvas;
        }
        if ((i2 & 4) != 0) {
            aVar = c0404i.canvasDrawScope;
        }
        if ((i2 & 8) != 0) {
            k0 = c0404i.borderPath;
        }
        return c0404i.copy(interfaceC0892v0, s2, aVar, k0);
    }

    public final C0404i copy(InterfaceC0892v0 interfaceC0892v0, androidx.compose.ui.graphics.S s2, androidx.compose.ui.graphics.drawscope.a aVar, K0 k0) {
        return new C0404i(interfaceC0892v0, s2, aVar, k0);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0097  */
    /* JADX INFO: renamed from: drawBorderCache-EMwLDEs, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final InterfaceC0892v0 m886drawBorderCacheEMwLDEs(androidx.compose.ui.draw.g gVar, long j2, int i2, h1.c cVar) {
        androidx.compose.ui.graphics.drawscope.a aVar;
        InterfaceC0892v0 interfaceC0892v0M3607ImageBitmapx__hDU$default = this.imageBitmap;
        androidx.compose.ui.graphics.S sCanvas = this.canvas;
        C0895w0 c0895w0M3593boximpl = interfaceC0892v0M3607ImageBitmapx__hDU$default != null ? C0895w0.m3593boximpl(interfaceC0892v0M3607ImageBitmapx__hDU$default.mo3286getConfig_sVssgQ()) : null;
        boolean z2 = false;
        if (!(c0895w0M3593boximpl == null ? false : C0895w0.m3596equalsimpl0(c0895w0M3593boximpl.m3599unboximpl(), C0895w0.Companion.m3601getArgb8888_sVssgQ()))) {
            if (C0895w0.m3595equalsimpl(i2, interfaceC0892v0M3607ImageBitmapx__hDU$default != null ? C0895w0.m3593boximpl(interfaceC0892v0M3607ImageBitmapx__hDU$default.mo3286getConfig_sVssgQ()) : null)) {
            }
            if (interfaceC0892v0M3607ImageBitmapx__hDU$default != null || sCanvas == null || Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() >> 32)) > interfaceC0892v0M3607ImageBitmapx__hDU$default.getWidth() || Float.intBitsToFloat((int) (gVar.m2677getSizeNHjbRc() & 4294967295L)) > interfaceC0892v0M3607ImageBitmapx__hDU$default.getHeight() || !z2) {
                interfaceC0892v0M3607ImageBitmapx__hDU$default = AbstractC0897x0.m3607ImageBitmapx__hDU$default((int) (j2 >> 32), (int) (j2 & 4294967295L), i2, false, null, 24, null);
                this.imageBitmap = interfaceC0892v0M3607ImageBitmapx__hDU$default;
                sCanvas = androidx.compose.ui.graphics.U.Canvas(interfaceC0892v0M3607ImageBitmapx__hDU$default);
                this.canvas = sCanvas;
            }
            aVar = this.canvasDrawScope;
            if (aVar == null) {
                aVar = new androidx.compose.ui.graphics.drawscope.a();
                this.canvasDrawScope = aVar;
            }
            long jM5251toSizeozmzZPI = e0.t.m5251toSizeozmzZPI(j2);
            e0.u layoutDirection = gVar.getLayoutDirection();
            a.C0130a drawParams = aVar.getDrawParams();
            InterfaceC1307d interfaceC1307dComponent1 = drawParams.component1();
            e0.u uVarComponent2 = drawParams.component2();
            androidx.compose.ui.graphics.S sComponent3 = drawParams.component3();
            long jM3175component4NHjbRc = drawParams.m3175component4NHjbRc();
            a.C0130a drawParams2 = aVar.getDrawParams();
            drawParams2.setDensity(gVar);
            drawParams2.setLayoutDirection(layoutDirection);
            drawParams2.setCanvas(sCanvas);
            drawParams2.m3178setSizeuvyYCjk(jM5251toSizeozmzZPI);
            sCanvas.save();
            androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(aVar, androidx.compose.ui.graphics.Y.Companion.m3046getBlack0d7_KjU(), 0L, jM5251toSizeozmzZPI, 0.0f, null, null, androidx.compose.ui.graphics.K.Companion.m2888getClear0nO6VwU(), 58, null);
            cVar.invoke(aVar);
            sCanvas.restore();
            a.C0130a drawParams3 = aVar.getDrawParams();
            drawParams3.setDensity(interfaceC1307dComponent1);
            drawParams3.setLayoutDirection(uVarComponent2);
            drawParams3.setCanvas(sComponent3);
            drawParams3.m3178setSizeuvyYCjk(jM3175component4NHjbRc);
            interfaceC0892v0M3607ImageBitmapx__hDU$default.prepareToDraw();
            return interfaceC0892v0M3607ImageBitmapx__hDU$default;
        }
        z2 = true;
        if (interfaceC0892v0M3607ImageBitmapx__hDU$default != null) {
            interfaceC0892v0M3607ImageBitmapx__hDU$default = AbstractC0897x0.m3607ImageBitmapx__hDU$default((int) (j2 >> 32), (int) (j2 & 4294967295L), i2, false, null, 24, null);
            this.imageBitmap = interfaceC0892v0M3607ImageBitmapx__hDU$default;
            sCanvas = androidx.compose.ui.graphics.U.Canvas(interfaceC0892v0M3607ImageBitmapx__hDU$default);
            this.canvas = sCanvas;
        }
        aVar = this.canvasDrawScope;
        if (aVar == null) {
        }
        long jM5251toSizeozmzZPI2 = e0.t.m5251toSizeozmzZPI(j2);
        e0.u layoutDirection2 = gVar.getLayoutDirection();
        a.C0130a drawParams4 = aVar.getDrawParams();
        InterfaceC1307d interfaceC1307dComponent12 = drawParams4.component1();
        e0.u uVarComponent22 = drawParams4.component2();
        androidx.compose.ui.graphics.S sComponent32 = drawParams4.component3();
        long jM3175component4NHjbRc2 = drawParams4.m3175component4NHjbRc();
        a.C0130a drawParams22 = aVar.getDrawParams();
        drawParams22.setDensity(gVar);
        drawParams22.setLayoutDirection(layoutDirection2);
        drawParams22.setCanvas(sCanvas);
        drawParams22.m3178setSizeuvyYCjk(jM5251toSizeozmzZPI2);
        sCanvas.save();
        androidx.compose.ui.graphics.drawscope.g.m3238drawRectnJ9OG0$default(aVar, androidx.compose.ui.graphics.Y.Companion.m3046getBlack0d7_KjU(), 0L, jM5251toSizeozmzZPI2, 0.0f, null, null, androidx.compose.ui.graphics.K.Companion.m2888getClear0nO6VwU(), 58, null);
        cVar.invoke(aVar);
        sCanvas.restore();
        a.C0130a drawParams32 = aVar.getDrawParams();
        drawParams32.setDensity(interfaceC1307dComponent12);
        drawParams32.setLayoutDirection(uVarComponent22);
        drawParams32.setCanvas(sComponent32);
        drawParams32.m3178setSizeuvyYCjk(jM3175component4NHjbRc2);
        interfaceC0892v0M3607ImageBitmapx__hDU$default.prepareToDraw();
        return interfaceC0892v0M3607ImageBitmapx__hDU$default;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0404i)) {
            return false;
        }
        C0404i c0404i = (C0404i) obj;
        return kotlin.jvm.internal.o.a(this.imageBitmap, c0404i.imageBitmap) && kotlin.jvm.internal.o.a(this.canvas, c0404i.canvas) && kotlin.jvm.internal.o.a(this.canvasDrawScope, c0404i.canvasDrawScope) && kotlin.jvm.internal.o.a(this.borderPath, c0404i.borderPath);
    }

    public int hashCode() {
        InterfaceC0892v0 interfaceC0892v0 = this.imageBitmap;
        int iHashCode = (interfaceC0892v0 == null ? 0 : interfaceC0892v0.hashCode()) * 31;
        androidx.compose.ui.graphics.S s2 = this.canvas;
        int iHashCode2 = (iHashCode + (s2 == null ? 0 : s2.hashCode())) * 31;
        androidx.compose.ui.graphics.drawscope.a aVar = this.canvasDrawScope;
        int iHashCode3 = (iHashCode2 + (aVar == null ? 0 : aVar.hashCode())) * 31;
        K0 k0 = this.borderPath;
        return iHashCode3 + (k0 != null ? k0.hashCode() : 0);
    }

    public final K0 obtainPath() {
        K0 k0 = this.borderPath;
        if (k0 != null) {
            return k0;
        }
        K0 k0Path = androidx.compose.ui.graphics.A.Path();
        this.borderPath = k0Path;
        return k0Path;
    }

    public String toString() {
        return "BorderCache(imageBitmap=" + this.imageBitmap + ", canvas=" + this.canvas + ", canvasDrawScope=" + this.canvasDrawScope + ", borderPath=" + this.borderPath + ')';
    }

    public C0404i(InterfaceC0892v0 interfaceC0892v0, androidx.compose.ui.graphics.S s2, androidx.compose.ui.graphics.drawscope.a aVar, K0 k0) {
        this.imageBitmap = interfaceC0892v0;
        this.canvas = s2;
        this.canvasDrawScope = aVar;
        this.borderPath = k0;
    }

    public /* synthetic */ C0404i(InterfaceC0892v0 interfaceC0892v0, androidx.compose.ui.graphics.S s2, androidx.compose.ui.graphics.drawscope.a aVar, K0 k0, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? null : interfaceC0892v0, (i2 & 2) != 0 ? null : s2, (i2 & 4) != 0 ? null : aVar, (i2 & 8) != 0 ? null : k0);
    }
}
