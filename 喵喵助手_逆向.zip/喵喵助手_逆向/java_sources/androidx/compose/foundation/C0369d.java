package androidx.compose.foundation;

import android.content.Context;
import androidx.compose.foundation.layout.InterfaceC0421g0;
import e0.InterfaceC1307d;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0369d implements j0 {
    private final Context context;
    private final InterfaceC1307d density;
    private final long glowColor;
    private final InterfaceC0421g0 glowDrawPadding;

    public /* synthetic */ C0369d(Context context, InterfaceC1307d interfaceC1307d, long j2, InterfaceC0421g0 interfaceC0421g0, AbstractC1378g abstractC1378g) {
        this(context, interfaceC1307d, j2, interfaceC0421g0);
    }

    @Override // androidx.compose.foundation.j0
    public i0 createOverscrollEffect() {
        return new C0367c(this.context, this.density, this.glowColor, this.glowDrawPadding, null);
    }

    @Override // androidx.compose.foundation.j0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!C0369d.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        kotlin.jvm.internal.o.c(obj, "null cannot be cast to non-null type androidx.compose.foundation.AndroidEdgeEffectOverscrollFactory");
        C0369d c0369d = (C0369d) obj;
        return kotlin.jvm.internal.o.a(this.context, c0369d.context) && kotlin.jvm.internal.o.a(this.density, c0369d.density) && androidx.compose.ui.graphics.Y.m3021equalsimpl0(this.glowColor, c0369d.glowColor) && kotlin.jvm.internal.o.a(this.glowDrawPadding, c0369d.glowDrawPadding);
    }

    @Override // androidx.compose.foundation.j0
    public int hashCode() {
        return this.glowDrawPadding.hashCode() + D0.d.d(this.glowColor, (this.density.hashCode() + (this.context.hashCode() * 31)) * 31, 31);
    }

    private C0369d(Context context, InterfaceC1307d interfaceC1307d, long j2, InterfaceC0421g0 interfaceC0421g0) {
        this.context = context;
        this.density = interfaceC1307d;
        this.glowColor = j2;
        this.glowDrawPadding = interfaceC0421g0;
    }

    public /* synthetic */ C0369d(Context context, InterfaceC1307d interfaceC1307d, long j2, InterfaceC0421g0 interfaceC0421g0, int i2, AbstractC1378g abstractC1378g) {
        this(context, interfaceC1307d, (i2 & 4) != 0 ? AbstractC0371e.DefaultGlowColor : j2, (i2 & 8) != 0 ? AbstractC0371e.DefaultGlowPaddingValues : interfaceC0421g0, null);
    }
}
