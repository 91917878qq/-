package androidx.compose.foundation;

/* JADX INFO: loaded from: classes.dex */
public interface j0 {
    i0 createOverscrollEffect();

    boolean equals(Object obj);

    int hashCode();
}
