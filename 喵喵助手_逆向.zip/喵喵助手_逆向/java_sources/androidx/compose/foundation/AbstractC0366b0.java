package androidx.compose.foundation;

import android.os.Build;
import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.b0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0366b0 {
    private static final androidx.compose.ui.semantics.D MagnifierPositionInRoot = new androidx.compose.ui.semantics.D("MagnifierPositionInRoot", (h1.e) null, 2, (AbstractC1378g) (0 == true ? 1 : 0));

    public static final boolean equalsIncludingNaN(float f2, float f3) {
        return (Float.isNaN(f2) && Float.isNaN(f3)) || f2 == f3;
    }

    public static final androidx.compose.ui.semantics.D getMagnifierPositionInRoot() {
        return MagnifierPositionInRoot;
    }

    public static final boolean isPlatformMagnifierSupported(int i2) {
        return i2 >= 28;
    }

    public static /* synthetic */ boolean isPlatformMagnifierSupported$default(int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i2 = Build.VERSION.SDK_INT;
        }
        return isPlatformMagnifierSupported(i2);
    }

    /* JADX INFO: renamed from: magnifier-UpNRX3w, reason: not valid java name */
    public static final androidx.compose.ui.x m714magnifierUpNRX3w(androidx.compose.ui.x xVar, h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, long j2, float f3, float f4, boolean z2) {
        return m717magnifierjPUL71Q$default(xVar, cVar, cVar2, cVar3, f2, false, j2, f3, f4, z2, null, 512, null);
    }

    /* JADX INFO: renamed from: magnifier-jPUL71Q, reason: not valid java name */
    public static final androidx.compose.ui.x m716magnifierjPUL71Q(androidx.compose.ui.x xVar, h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, boolean z2, long j2, float f3, float f4, boolean z3, o0 o0Var) {
        if (isPlatformMagnifierSupported$default(0, 1, null)) {
            return xVar.then(new MagnifierElement(cVar, cVar2, cVar3, f2, z2, j2, f3, f4, z3, o0Var == null ? o0.Companion.getForCurrentPlatform() : o0Var, null));
        }
        return xVar;
    }

    /* JADX INFO: renamed from: magnifier-jPUL71Q$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.ui.x m717magnifierjPUL71Q$default(androidx.compose.ui.x xVar, h1.c cVar, h1.c cVar2, h1.c cVar3, float f2, boolean z2, long j2, float f3, float f4, boolean z3, o0 o0Var, int i2, Object obj) {
        return m716magnifierjPUL71Q(xVar, cVar, (i2 & 2) != 0 ? null : cVar2, (i2 & 4) != 0 ? null : cVar3, (i2 & 8) != 0 ? Float.NaN : f2, (i2 & 16) != 0 ? false : z2, (i2 & 32) != 0 ? e0.l.Companion.m5183getUnspecifiedMYxV2XQ() : j2, (i2 & 64) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f3, (i2 & 128) != 0 ? C1311h.Companion.m5096getUnspecifiedD9Ej5fM() : f4, (i2 & 256) != 0 ? true : z3, (i2 & 512) == 0 ? o0Var : null);
    }
}
