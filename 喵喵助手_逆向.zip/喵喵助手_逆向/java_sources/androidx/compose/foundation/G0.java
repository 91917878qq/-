package androidx.compose.foundation;

import androidx.compose.ui.graphics.E0;
import androidx.compose.ui.graphics.j1;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class G0 implements j1 {
    public static final G0 INSTANCE = new G0();

    private G0() {
    }

    @Override // androidx.compose.ui.graphics.j1
    /* JADX INFO: renamed from: createOutline-Pq9zytI, reason: not valid java name */
    public androidx.compose.ui.graphics.E0 mo693createOutlinePq9zytI(long j2, e0.u uVar, InterfaceC1307d interfaceC1307d) {
        float fMo782roundToPx0680j_4 = interfaceC1307d.mo782roundToPx0680j_4(AbstractC0644x.getMaxSupportedElevation());
        return new E0.b(new J.h(-fMo782roundToPx0680j_4, 0.0f, Float.intBitsToFloat((int) (j2 >> 32)) + fMo782roundToPx0680j_4, Float.intBitsToFloat((int) (j2 & 4294967295L))));
    }
}
