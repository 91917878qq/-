package androidx.compose.foundation;

import androidx.compose.ui.text.C1189s;
import androidx.compose.ui.text.C1196z;
import java.io.Serializable;

/* JADX INFO: renamed from: androidx.compose.foundation.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0500m implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1910b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ long f1911c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1912d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Serializable f1913e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1914f;

    public /* synthetic */ C0500m(long j2, float[] fArr, kotlin.jvm.internal.C c2, kotlin.jvm.internal.B b2) {
        this.f1911c = j2;
        this.f1912d = fArr;
        this.f1913e = c2;
        this.f1914f = b2;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1910b) {
            case 0:
                return C0501n.drawGenericBorder$lambda$8((J.h) this.f1912d, (kotlin.jvm.internal.E) this.f1913e, this.f1911c, (androidx.compose.ui.graphics.Z) this.f1914f, (androidx.compose.ui.graphics.drawscope.c) obj);
            default:
                kotlin.jvm.internal.B b2 = (kotlin.jvm.internal.B) this.f1914f;
                C1196z c1196z = (C1196z) obj;
                return C1189s.fillBoundingBoxes_8ffj60Q$lambda$19(this.f1911c, (float[]) this.f1912d, (kotlin.jvm.internal.C) this.f1913e, b2, c1196z);
        }
    }

    public /* synthetic */ C0500m(J.h hVar, kotlin.jvm.internal.E e2, long j2, androidx.compose.ui.graphics.Z z2) {
        this.f1912d = hVar;
        this.f1913e = e2;
        this.f1911c = j2;
        this.f1914f = z2;
    }
}
