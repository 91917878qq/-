package androidx.compose.foundation;

import androidx.compose.foundation.text.selection.C0625y;
import androidx.compose.ui.node.a1;

/* JADX INFO: renamed from: androidx.compose.foundation.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0522t implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1997b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ kotlin.jvm.internal.A f1998c;

    public /* synthetic */ C0522t(kotlin.jvm.internal.A a2, int i2) {
        this.f1997b = i2;
        this.f1998c = a2;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1997b) {
            case 0:
                return Boolean.valueOf(AbstractC0641u.hasScrollableContainer$lambda$8(this.f1998c, (a1) obj));
            default:
                return androidx.compose.foundation.text.selection.S.isCollapsed$lambda$0(this.f1998c, (C0625y) obj);
        }
    }
}
