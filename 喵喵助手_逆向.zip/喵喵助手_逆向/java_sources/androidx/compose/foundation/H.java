package androidx.compose.foundation;

/* JADX INFO: loaded from: classes.dex */
public final class H extends androidx.compose.ui.node.r {
    public H() {
        delegate(androidx.compose.ui.focus.M.m2740FocusTargetModifierNodePYyLHbc$default(androidx.compose.ui.focus.V.Companion.m2763getNeverLCbbffg(), null, 2, null));
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }
}
