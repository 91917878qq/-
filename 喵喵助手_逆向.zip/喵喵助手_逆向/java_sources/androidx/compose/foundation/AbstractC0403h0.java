package androidx.compose.foundation;

import androidx.compose.runtime.AbstractC0721c1;

/* JADX INFO: renamed from: androidx.compose.foundation.h0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0403h0 {
    private static final AbstractC0721c1 LocalOverscrollConfiguration = androidx.compose.runtime.D.compositionLocalOf$default(null, new F0.a(11), 1, null);

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0376g0 LocalOverscrollConfiguration$lambda$0() {
        return new C0376g0(0L, null, 3, null);
    }

    public static final AbstractC0721c1 getLocalOverscrollConfiguration() {
        return LocalOverscrollConfiguration;
    }

    @U0.a
    public static /* synthetic */ void getLocalOverscrollConfiguration$annotations() {
    }
}
