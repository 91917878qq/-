package androidx.compose.foundation.gestures;

import androidx.compose.ui.input.pointer.C0918p;

/* JADX INFO: loaded from: classes.dex */
public abstract class h0 {
    public static final boolean firstDownRefersToPrimaryMouseButtonOnly() {
        return false;
    }

    public static final boolean isDeepPress(C0918p c0918p) {
        return c0918p.getClassification() == 2;
    }
}
