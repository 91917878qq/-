package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public interface Q {
    float scrollBy(float f2);
}
