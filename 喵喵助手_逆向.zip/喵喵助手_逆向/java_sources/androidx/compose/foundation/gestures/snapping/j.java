package androidx.compose.foundation.gestures.snapping;

import androidx.compose.animation.T;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.C0311h;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.animation.core.InterfaceC0341y;
import androidx.compose.foundation.gestures.Q;
import androidx.compose.foundation.gestures.i0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.L0;
import e0.C1311h;
import e0.InterfaceC1307d;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.B;

/* JADX INFO: loaded from: classes.dex */
public abstract class j {
    private static final boolean DEBUG = false;
    private static final float MinFlingVelocityDp = C1311h.m5076constructorimpl(400);
    public static final float NoDistance = 0.0f;
    public static final float NoVelocity = 0.0f;

    public static final class a extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return j.animateDecay(null, 0.0f, null, null, null, this);
        }
    }

    public static final class b extends a1.c {
        float F$0;
        float F$1;
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return j.animateWithTarget(null, 0.0f, 0.0f, null, null, null, this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object animateDecay(androidx.compose.foundation.gestures.Q r13, float r14, androidx.compose.animation.core.C0317k r15, androidx.compose.animation.core.InterfaceC0341y r16, h1.c r17, Y0.c r18) {
        /*
            r0 = r15
            r1 = r18
            boolean r2 = r1 instanceof androidx.compose.foundation.gestures.snapping.j.a
            if (r2 == 0) goto L16
            r2 = r1
            androidx.compose.foundation.gestures.snapping.j$a r2 = (androidx.compose.foundation.gestures.snapping.j.a) r2
            int r3 = r2.label
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L16
            int r3 = r3 - r4
            r2.label = r3
            goto L1b
        L16:
            androidx.compose.foundation.gestures.snapping.j$a r2 = new androidx.compose.foundation.gestures.snapping.j$a
            r2.<init>(r1)
        L1b:
            java.lang.Object r1 = r2.result
            Z0.a r3 = Z0.a.f1616b
            int r4 = r2.label
            r5 = 1
            if (r4 == 0) goto L3c
            if (r4 != r5) goto L34
            float r0 = r2.F$0
            java.lang.Object r3 = r2.L$1
            kotlin.jvm.internal.B r3 = (kotlin.jvm.internal.B) r3
            java.lang.Object r2 = r2.L$0
            androidx.compose.animation.core.k r2 = (androidx.compose.animation.core.C0317k) r2
            a.AbstractC0292a.H(r1)
            goto L78
        L34:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L3c:
            a.AbstractC0292a.H(r1)
            kotlin.jvm.internal.B r1 = new kotlin.jvm.internal.B
            r1.<init>()
            java.lang.Object r4 = r15.getVelocity()
            java.lang.Number r4 = (java.lang.Number) r4
            float r4 = r4.floatValue()
            r6 = 0
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 != 0) goto L55
            r4 = r5
            goto L56
        L55:
            r4 = 0
        L56:
            r4 = r4 ^ r5
            androidx.compose.foundation.gestures.snapping.i r12 = new androidx.compose.foundation.gestures.snapping.i
            r11 = 0
            r6 = r12
            r7 = r14
            r8 = r1
            r9 = r13
            r10 = r17
            r6.<init>(r7, r8, r9, r10, r11)
            r2.L$0 = r0
            r2.L$1 = r1
            r6 = r14
            r2.F$0 = r6
            r2.label = r5
            r5 = r16
            java.lang.Object r2 = androidx.compose.animation.core.AbstractC0333s0.animateDecay(r15, r5, r4, r12, r2)
            if (r2 != r3) goto L75
            return r3
        L75:
            r2 = r0
            r3 = r1
            r0 = r6
        L78:
            androidx.compose.foundation.gestures.snapping.a r1 = new androidx.compose.foundation.gestures.snapping.a
            float r3 = r3.f3115b
            float r0 = r0 - r3
            java.lang.Float r3 = new java.lang.Float
            r3.<init>(r0)
            r1.<init>(r3, r2)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.j.animateDecay(androidx.compose.foundation.gestures.Q, float, androidx.compose.animation.core.k, androidx.compose.animation.core.y, h1.c, Y0.c):java.lang.Object");
    }

    private static final void animateDecay$consumeDelta(C0311h c0311h, Q q2, h1.c cVar, float f2) {
        float fScrollBy;
        try {
            fScrollBy = q2.scrollBy(f2);
        } catch (CancellationException unused) {
            c0311h.cancelAnimation();
            fScrollBy = 0.0f;
        }
        cVar.invoke(Float.valueOf(fScrollBy));
        if (Math.abs(f2 - fScrollBy) > 0.5f) {
            c0311h.cancelAnimation();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateDecay$lambda$1(float f2, B b2, Q q2, h1.c cVar, C0311h c0311h) {
        if (Math.abs(((Number) c0311h.getValue()).floatValue()) >= Math.abs(f2)) {
            float fCoerceToTarget = coerceToTarget(((Number) c0311h.getValue()).floatValue(), f2);
            animateDecay$consumeDelta(c0311h, q2, cVar, fCoerceToTarget - b2.f3115b);
            c0311h.cancelAnimation();
            b2.f3115b = fCoerceToTarget;
        } else {
            animateDecay$consumeDelta(c0311h, q2, cVar, ((Number) c0311h.getValue()).floatValue() - b2.f3115b);
            b2.f3115b = ((Number) c0311h.getValue()).floatValue();
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object animateWithTarget(androidx.compose.foundation.gestures.Q r16, float r17, float r18, androidx.compose.animation.core.C0317k r19, androidx.compose.animation.core.InterfaceC0313i r20, h1.c r21, Y0.c r22) {
        /*
            r0 = r17
            r1 = r22
            boolean r2 = r1 instanceof androidx.compose.foundation.gestures.snapping.j.b
            if (r2 == 0) goto L18
            r2 = r1
            androidx.compose.foundation.gestures.snapping.j$b r2 = (androidx.compose.foundation.gestures.snapping.j.b) r2
            int r3 = r2.label
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L18
            int r3 = r3 - r4
            r2.label = r3
        L16:
            r8 = r2
            goto L1e
        L18:
            androidx.compose.foundation.gestures.snapping.j$b r2 = new androidx.compose.foundation.gestures.snapping.j$b
            r2.<init>(r1)
            goto L16
        L1e:
            java.lang.Object r1 = r8.result
            Z0.a r2 = Z0.a.f1616b
            int r3 = r8.label
            r4 = 1
            if (r3 == 0) goto L44
            if (r3 != r4) goto L3c
            float r0 = r8.F$1
            float r2 = r8.F$0
            java.lang.Object r3 = r8.L$1
            kotlin.jvm.internal.B r3 = (kotlin.jvm.internal.B) r3
            java.lang.Object r4 = r8.L$0
            androidx.compose.animation.core.k r4 = (androidx.compose.animation.core.C0317k) r4
            a.AbstractC0292a.H(r1)
            r15 = r0
            r0 = r2
            r1 = r4
            goto L97
        L3c:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L44:
            a.AbstractC0292a.H(r1)
            kotlin.jvm.internal.B r1 = new kotlin.jvm.internal.B
            r1.<init>()
            java.lang.Object r3 = r19.getVelocity()
            java.lang.Number r3 = (java.lang.Number) r3
            float r15 = r3.floatValue()
            java.lang.Float r5 = new java.lang.Float
            r5.<init>(r0)
            java.lang.Object r3 = r19.getVelocity()
            java.lang.Number r3 = (java.lang.Number) r3
            float r3 = r3.floatValue()
            r6 = 0
            int r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
            if (r3 != 0) goto L6c
            r3 = r4
            goto L6d
        L6c:
            r3 = 0
        L6d:
            r6 = r3 ^ 1
            androidx.compose.foundation.gestures.snapping.i r7 = new androidx.compose.foundation.gestures.snapping.i
            r14 = 1
            r9 = r7
            r10 = r18
            r11 = r1
            r12 = r16
            r13 = r21
            r9.<init>(r10, r11, r12, r13, r14)
            r9 = r19
            r8.L$0 = r9
            r8.L$1 = r1
            r8.F$0 = r0
            r8.F$1 = r15
            r8.label = r4
            r3 = r19
            r4 = r5
            r5 = r20
            java.lang.Object r3 = androidx.compose.animation.core.AbstractC0333s0.animateTo(r3, r4, r5, r6, r7, r8)
            if (r3 != r2) goto L95
            return r2
        L95:
            r3 = r1
            r1 = r9
        L97:
            java.lang.Object r2 = r1.getVelocity()
            java.lang.Number r2 = (java.lang.Number) r2
            float r2 = r2.floatValue()
            float r4 = coerceToTarget(r2, r15)
            androidx.compose.foundation.gestures.snapping.a r11 = new androidx.compose.foundation.gestures.snapping.a
            float r2 = r3.f3115b
            float r0 = r0 - r2
            java.lang.Float r12 = new java.lang.Float
            r12.<init>(r0)
            r6 = 0
            r8 = 0
            r2 = 0
            r9 = 0
            r0 = 29
            r13 = 0
            r3 = r4
            r4 = r9
            r9 = r0
            r10 = r13
            androidx.compose.animation.core.k r0 = androidx.compose.animation.core.AbstractC0319l.copy$default(r1, r2, r3, r4, r6, r8, r9, r10)
            r11.<init>(r12, r0)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.j.animateWithTarget(androidx.compose.foundation.gestures.Q, float, float, androidx.compose.animation.core.k, androidx.compose.animation.core.i, h1.c, Y0.c):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateWithTarget$lambda$3(float f2, B b2, Q q2, h1.c cVar, C0311h c0311h) {
        float fScrollBy;
        float fCoerceToTarget = coerceToTarget(((Number) c0311h.getValue()).floatValue(), f2);
        float f3 = fCoerceToTarget - b2.f3115b;
        try {
            fScrollBy = q2.scrollBy(f3);
        } catch (CancellationException unused) {
            c0311h.cancelAnimation();
            fScrollBy = 0.0f;
        }
        cVar.invoke(Float.valueOf(fScrollBy));
        if (Math.abs(f3 - fScrollBy) > 0.5f || fCoerceToTarget != ((Number) c0311h.getValue()).floatValue()) {
            c0311h.cancelAnimation();
        }
        b2.f3115b += fScrollBy;
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object approach(Q q2, float f2, float f3, androidx.compose.foundation.gestures.snapping.b bVar, h1.c cVar, Y0.c cVar2) {
        return bVar.approachAnimation(q2, new Float(f2), new Float(f3), cVar, cVar2);
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0024  */
    /* JADX INFO: renamed from: calculateFinalOffset-Fhqu1e0, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final float m872calculateFinalOffsetFhqu1e0(int r3, float r4, float r5) {
        /*
            androidx.compose.foundation.gestures.snapping.d$a r0 = androidx.compose.foundation.gestures.snapping.d.Companion
            int r1 = r0.m869getClosestItembbeMdSM()
            boolean r1 = androidx.compose.foundation.gestures.snapping.d.m865equalsimpl0(r3, r1)
            r2 = 0
            if (r1 == 0) goto L1a
            float r3 = java.lang.Math.abs(r5)
            float r0 = java.lang.Math.abs(r4)
            int r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
            if (r3 > 0) goto L32
            goto L24
        L1a:
            int r1 = r0.m870getNextItembbeMdSM()
            boolean r1 = androidx.compose.foundation.gestures.snapping.d.m865equalsimpl0(r3, r1)
            if (r1 == 0) goto L26
        L24:
            r4 = r5
            goto L32
        L26:
            int r5 = r0.m871getPreviousItembbeMdSM()
            boolean r3 = androidx.compose.foundation.gestures.snapping.d.m865equalsimpl0(r3, r5)
            if (r3 == 0) goto L31
            goto L32
        L31:
            r4 = r2
        L32:
            boolean r3 = calculateFinalOffset_Fhqu1e0$isValidDistance(r4)
            if (r3 == 0) goto L39
            r2 = r4
        L39:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.j.m872calculateFinalOffsetFhqu1e0(int, float, float):float");
    }

    private static final boolean calculateFinalOffset_Fhqu1e0$isValidDistance(float f2) {
        return (f2 == Float.POSITIVE_INFINITY || f2 == Float.NEGATIVE_INFINITY) ? false : true;
    }

    private static final float coerceToTarget(float f2, float f3) {
        if (f3 == 0.0f) {
            return 0.0f;
        }
        return f3 > 0.0f ? j1.a.l(f2, f3) : j1.a.k(f2, f3);
    }

    private static final <T extends Comparable<? super T>> T component1(m1.b bVar) {
        return Float.valueOf(((m1.a) bVar).f3187a);
    }

    private static final <T extends Comparable<? super T>> T component2(m1.b bVar) {
        return Float.valueOf(((m1.a) bVar).f3188b);
    }

    private static final void debugLog(h1.a aVar) {
    }

    public static final float getMinFlingVelocityDp() {
        return MinFlingVelocityDp;
    }

    public static final i0 rememberSnapFlingBehavior(k kVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1921733134, i2, -1, "androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior (SnapFlingBehavior.kt:230)");
        }
        Object obj = (InterfaceC1307d) interfaceC0768p.consume(L0.getLocalDensity());
        InterfaceC0341y interfaceC0341yRememberSplineBasedDecay = T.rememberSplineBasedDecay(interfaceC0768p, 0);
        boolean zChanged = interfaceC0768p.changed(interfaceC0341yRememberSplineBasedDecay) | ((((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(kVar)) || (i2 & 6) == 4) | interfaceC0768p.changed(obj);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = snapFlingBehavior(kVar, interfaceC0341yRememberSplineBasedDecay, AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        i0 i0Var = (i0) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return i0Var;
    }

    public static final i0 snapFlingBehavior(k kVar, InterfaceC0341y interfaceC0341y, InterfaceC0313i interfaceC0313i) {
        return new g(kVar, interfaceC0341y, interfaceC0313i);
    }
}
