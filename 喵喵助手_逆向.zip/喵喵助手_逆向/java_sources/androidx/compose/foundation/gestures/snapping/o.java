package androidx.compose.foundation.gestures.snapping;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {
    public static final float calculateDistanceToDesiredSnapPosition(int i2, int i3, int i4, int i5, int i6, int i7, n nVar, int i8) {
        return i6 - nVar.position(i2, i5, i3, i4, i7, i8);
    }
}
