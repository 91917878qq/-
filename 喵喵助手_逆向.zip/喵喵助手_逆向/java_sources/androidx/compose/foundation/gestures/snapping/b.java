package androidx.compose.foundation.gestures.snapping;

import androidx.compose.foundation.gestures.Q;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    Object approachAnimation(Q q2, Object obj, Object obj2, h1.c cVar, Y0.c cVar2);
}
