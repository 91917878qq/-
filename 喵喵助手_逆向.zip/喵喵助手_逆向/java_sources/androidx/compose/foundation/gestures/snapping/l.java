package androidx.compose.foundation.gestures.snapping;

/* JADX INFO: loaded from: classes.dex */
public final class l implements n {
    public static final int $stable = 0;
    public static final l INSTANCE = new l();

    private l() {
    }

    @Override // androidx.compose.foundation.gestures.snapping.n
    public int position(int i2, int i3, int i4, int i5, int i6, int i7) {
        return (((i2 - i4) - i5) / 2) - (i3 / 2);
    }

    public String toString() {
        return "Center";
    }
}
