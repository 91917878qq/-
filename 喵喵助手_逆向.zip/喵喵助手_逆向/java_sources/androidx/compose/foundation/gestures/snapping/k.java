package androidx.compose.foundation.gestures.snapping;

/* JADX INFO: loaded from: classes.dex */
public interface k {
    default float calculateApproachOffset(float f2, float f3) {
        return f3;
    }

    float calculateSnapOffset(float f2);
}
