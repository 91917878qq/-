package androidx.compose.foundation.gestures.snapping;

import androidx.compose.foundation.gestures.I;
import androidx.compose.foundation.gestures.InterfaceC0400y;
import androidx.compose.foundation.gestures.i0;
import androidx.compose.foundation.lazy.InterfaceC0494p;
import androidx.compose.foundation.lazy.O;
import androidx.compose.foundation.lazy.layout.N;
import androidx.compose.foundation.lazy.y;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import e0.InterfaceC1307d;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    public static final class a implements k {
        final /* synthetic */ O $lazyListState;
        final /* synthetic */ n $snapPosition;

        public a(O o2, n nVar) {
            this.$lazyListState = o2;
            this.$snapPosition = nVar;
        }

        private final int getAverageItemSize() {
            y layoutInfo = getLayoutInfo();
            int size = 0;
            if (layoutInfo.getVisibleItemsInfo().isEmpty()) {
                return 0;
            }
            int size2 = layoutInfo.getVisibleItemsInfo().size();
            Iterator<T> it = layoutInfo.getVisibleItemsInfo().iterator();
            while (it.hasNext()) {
                size += ((InterfaceC0494p) it.next()).getSize();
            }
            return size / size2;
        }

        private final y getLayoutInfo() {
            return this.$lazyListState.getLayoutInfo();
        }

        @Override // androidx.compose.foundation.gestures.snapping.k
        public float calculateApproachOffset(float f2, float f3) {
            return Math.signum(f3) * j1.a.k(Math.abs(f3) - getAverageItemSize(), 0.0f);
        }

        @Override // androidx.compose.foundation.gestures.snapping.k
        public float calculateSnapOffset(float f2) {
            List<InterfaceC0494p> visibleItemsInfo = getLayoutInfo().getVisibleItemsInfo();
            n nVar = this.$snapPosition;
            int size = visibleItemsInfo.size();
            float f3 = Float.NEGATIVE_INFINITY;
            float f4 = Float.POSITIVE_INFINITY;
            for (int i2 = 0; i2 < size; i2++) {
                InterfaceC0494p interfaceC0494p = visibleItemsInfo.get(i2);
                N n2 = interfaceC0494p instanceof N ? (N) interfaceC0494p : null;
                if (n2 == null || !n2.getNonScrollableItem()) {
                    float fCalculateDistanceToDesiredSnapPosition = o.calculateDistanceToDesiredSnapPosition(e.getSingleAxisViewportSize(getLayoutInfo()), getLayoutInfo().getBeforeContentPadding(), getLayoutInfo().getAfterContentPadding(), interfaceC0494p.getSize(), interfaceC0494p.getOffset(), interfaceC0494p.getIndex(), nVar, getLayoutInfo().getTotalItemsCount());
                    if (fCalculateDistanceToDesiredSnapPosition <= 0.0f && fCalculateDistanceToDesiredSnapPosition > f3) {
                        f3 = fCalculateDistanceToDesiredSnapPosition;
                    }
                    if (fCalculateDistanceToDesiredSnapPosition >= 0.0f && fCalculateDistanceToDesiredSnapPosition < f4) {
                        f4 = fCalculateDistanceToDesiredSnapPosition;
                    }
                }
            }
            return j.m872calculateFinalOffsetFhqu1e0(e.calculateFinalSnappingItem(this.$lazyListState.getDensity$foundation_release(), f2), f3, f4);
        }
    }

    public static final k SnapLayoutInfoProvider(O o2, n nVar) {
        return new a(o2, nVar);
    }

    public static /* synthetic */ k SnapLayoutInfoProvider$default(O o2, n nVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            nVar = l.INSTANCE;
        }
        return SnapLayoutInfoProvider(o2, nVar);
    }

    public static final int calculateFinalSnappingItem(InterfaceC1307d interfaceC1307d, float f2) {
        return Math.abs(f2) < interfaceC1307d.mo788toPx0680j_4(j.getMinFlingVelocityDp()) ? d.Companion.m869getClosestItembbeMdSM() : f2 > 0.0f ? d.Companion.m870getNextItembbeMdSM() : d.Companion.m871getPreviousItembbeMdSM();
    }

    public static final int getSingleAxisViewportSize(y yVar) {
        return (int) (yVar.getOrientation() == I.Vertical ? yVar.mo1046getViewportSizeYbymL2g() & 4294967295L : yVar.mo1046getViewportSizeYbymL2g() >> 32);
    }

    public static final InterfaceC0400y rememberSnapFlingBehavior(O o2, n nVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            nVar = l.INSTANCE;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-338621290, i2, -1, "androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior (LazyListSnapLayoutInfoProvider.kt:115)");
        }
        boolean z2 = (((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(o2)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = SnapLayoutInfoProvider(o2, nVar);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        i0 i0VarRememberSnapFlingBehavior = j.rememberSnapFlingBehavior((k) objRememberedValue, interfaceC0768p, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return i0VarRememberSnapFlingBehavior;
    }
}
