package androidx.compose.foundation.gestures.snapping;

import androidx.compose.animation.core.AbstractC0319l;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.foundation.gestures.Q;

/* JADX INFO: loaded from: classes.dex */
public final class p implements b {
    private final InterfaceC0313i animationSpec;

    public p(InterfaceC0313i interfaceC0313i) {
        this.animationSpec = interfaceC0313i;
    }

    @Override // androidx.compose.foundation.gestures.snapping.b
    public /* bridge */ /* synthetic */ Object approachAnimation(Q q2, Object obj, Object obj2, h1.c cVar, Y0.c cVar2) {
        return approachAnimation(q2, ((Number) obj).floatValue(), ((Number) obj2).floatValue(), cVar, cVar2);
    }

    public Object approachAnimation(Q q2, float f2, float f3, h1.c cVar, Y0.c cVar2) {
        Object objAnimateWithTarget = j.animateWithTarget(q2, Math.signum(f3) * Math.abs(f2), f2, AbstractC0319l.AnimationState$default(0.0f, f3, 0L, 0L, false, 28, null), this.animationSpec, cVar, cVar2);
        return objAnimateWithTarget == Z0.a.f1616b ? objAnimateWithTarget : (a) objAnimateWithTarget;
    }
}
