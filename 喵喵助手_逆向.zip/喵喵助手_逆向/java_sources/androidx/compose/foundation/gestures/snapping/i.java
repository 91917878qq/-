package androidx.compose.foundation.gestures.snapping;

import androidx.compose.animation.core.C0311h;
import androidx.compose.foundation.gestures.Q;
import kotlin.jvm.internal.B;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1746b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ float f1747c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ B f1748d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Q f1749e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ h1.c f1750f;

    public /* synthetic */ i(float f2, B b2, Q q2, h1.c cVar, int i2) {
        this.f1746b = i2;
        this.f1747c = f2;
        this.f1748d = b2;
        this.f1749e = q2;
        this.f1750f = cVar;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        C0311h c0311h = (C0311h) obj;
        switch (this.f1746b) {
            case 0:
                return j.animateDecay$lambda$1(this.f1747c, this.f1748d, this.f1749e, this.f1750f, c0311h);
            default:
                return j.animateWithTarget$lambda$3(this.f1747c, this.f1748d, this.f1749e, this.f1750f, c0311h);
        }
    }
}
