package androidx.compose.foundation.gestures.snapping;

import androidx.compose.animation.core.AbstractC0319l;
import androidx.compose.animation.core.InterfaceC0341y;
import androidx.compose.foundation.gestures.Q;

/* JADX INFO: loaded from: classes.dex */
public final class c implements b {
    private final InterfaceC0341y decayAnimationSpec;

    public c(InterfaceC0341y interfaceC0341y) {
        this.decayAnimationSpec = interfaceC0341y;
    }

    @Override // androidx.compose.foundation.gestures.snapping.b
    public /* bridge */ /* synthetic */ Object approachAnimation(Q q2, Object obj, Object obj2, h1.c cVar, Y0.c cVar2) {
        return approachAnimation(q2, ((Number) obj).floatValue(), ((Number) obj2).floatValue(), cVar, cVar2);
    }

    public Object approachAnimation(Q q2, float f2, float f3, h1.c cVar, Y0.c cVar2) {
        Object objAnimateDecay = j.animateDecay(q2, f2, AbstractC0319l.AnimationState$default(0.0f, f3, 0L, 0L, false, 28, null), this.decayAnimationSpec, cVar, cVar2);
        return objAnimateDecay == Z0.a.f1616b ? objAnimateDecay : (a) objAnimateDecay;
    }
}
