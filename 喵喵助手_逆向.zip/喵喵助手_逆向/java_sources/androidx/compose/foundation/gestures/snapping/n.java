package androidx.compose.foundation.gestures.snapping;

/* JADX INFO: loaded from: classes.dex */
public interface n {
    int position(int i2, int i3, int i4, int i5, int i6, int i7);
}
