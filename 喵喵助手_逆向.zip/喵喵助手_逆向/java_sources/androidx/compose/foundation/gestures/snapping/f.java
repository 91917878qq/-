package androidx.compose.foundation.gestures.snapping;

import androidx.compose.foundation.gestures.snapping.d;
import androidx.compose.foundation.pager.I;
import androidx.compose.foundation.pager.InterfaceC0510g;
import androidx.compose.foundation.pager.K;
import androidx.compose.foundation.pager.t;
import androidx.compose.foundation.pager.u;
import java.util.List;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    public static final class a implements k {
        final /* synthetic */ h1.f $calculateFinalSnappingBound;
        final /* synthetic */ I $pagerSnapDistance;
        final /* synthetic */ K $pagerState;

        public a(K k2, h1.f fVar, I i2) {
            this.$pagerState = k2;
            this.$calculateFinalSnappingBound = fVar;
            this.$pagerSnapDistance = i2;
        }

        private final U0.g searchForSnappingBounds(n nVar, float f2) {
            float f3;
            List<InterfaceC0510g> visiblePagesInfo = getLayoutInfo().getVisiblePagesInfo();
            K k2 = this.$pagerState;
            int size = visiblePagesInfo.size();
            int i2 = 0;
            float f4 = Float.NEGATIVE_INFINITY;
            float f5 = Float.POSITIVE_INFINITY;
            while (true) {
                f3 = 0.0f;
                if (i2 >= size) {
                    break;
                }
                InterfaceC0510g interfaceC0510g = visiblePagesInfo.get(i2);
                float fCalculateDistanceToDesiredSnapPosition = o.calculateDistanceToDesiredSnapPosition(u.getMainAxisViewportSize(getLayoutInfo()), getLayoutInfo().getBeforeContentPadding(), getLayoutInfo().getAfterContentPadding(), getLayoutInfo().getPageSize(), interfaceC0510g.getOffset(), interfaceC0510g.getIndex(), nVar, k2.getPageCount());
                if (fCalculateDistanceToDesiredSnapPosition <= 0.0f && fCalculateDistanceToDesiredSnapPosition > f4) {
                    f4 = fCalculateDistanceToDesiredSnapPosition;
                }
                if (fCalculateDistanceToDesiredSnapPosition >= 0.0f && fCalculateDistanceToDesiredSnapPosition < f5) {
                    f5 = fCalculateDistanceToDesiredSnapPosition;
                }
                i2++;
            }
            if (f4 == Float.NEGATIVE_INFINITY) {
                f4 = f5;
            }
            if (f5 == Float.POSITIVE_INFINITY) {
                f5 = f4;
            }
            if (!this.$pagerState.getCanScrollForward()) {
                if (f.isScrollingForward(this.$pagerState, f2)) {
                    f4 = 0.0f;
                    f5 = 0.0f;
                } else {
                    f5 = 0.0f;
                }
            }
            if (this.$pagerState.getCanScrollBackward()) {
                f3 = f4;
            } else if (!f.isScrollingForward(this.$pagerState, f2)) {
                f5 = 0.0f;
            }
            return new U0.g(Float.valueOf(f3), Float.valueOf(f5));
        }

        @Override // androidx.compose.foundation.gestures.snapping.k
        public float calculateApproachOffset(float f2, float f3) {
            int pageSpacing$foundation_release = this.$pagerState.getPageSpacing$foundation_release() + this.$pagerState.getPageSize$foundation_release();
            if (pageSpacing$foundation_release == 0) {
                return 0.0f;
            }
            int firstVisiblePage$foundation_release = f2 < 0.0f ? this.$pagerState.getFirstVisiblePage$foundation_release() + 1 : this.$pagerState.getFirstVisiblePage$foundation_release();
            int iAbs = Math.abs((j1.a.o(this.$pagerSnapDistance.calculateTargetPage(firstVisiblePage$foundation_release, j1.a.o(((int) (f3 / pageSpacing$foundation_release)) + firstVisiblePage$foundation_release, 0, this.$pagerState.getPageCount()), f2, this.$pagerState.getPageSize$foundation_release(), this.$pagerState.getPageSpacing$foundation_release()), 0, this.$pagerState.getPageCount()) - firstVisiblePage$foundation_release) * pageSpacing$foundation_release) - pageSpacing$foundation_release;
            int i2 = iAbs >= 0 ? iAbs : 0;
            if (i2 == 0) {
                return i2;
            }
            return Math.signum(f2) * i2;
        }

        @Override // androidx.compose.foundation.gestures.snapping.k
        public float calculateSnapOffset(float f2) {
            U0.g gVarSearchForSnappingBounds = searchForSnappingBounds(this.$pagerState.getLayoutInfo().getSnapPosition(), f2);
            float fFloatValue = ((Number) gVarSearchForSnappingBounds.f1511b).floatValue();
            float fFloatValue2 = ((Number) gVarSearchForSnappingBounds.f1512c).floatValue();
            float fFloatValue3 = ((Number) this.$calculateFinalSnappingBound.invoke(Float.valueOf(f2), Float.valueOf(fFloatValue), Float.valueOf(fFloatValue2))).floatValue();
            if (!(fFloatValue3 == fFloatValue || fFloatValue3 == fFloatValue2 || fFloatValue3 == 0.0f)) {
                AbstractC1403e.throwIllegalStateException("Final Snapping Offset Should Be one of " + fFloatValue + ", " + fFloatValue2 + " or 0.0");
            }
            if (isValidDistance(fFloatValue3)) {
                return fFloatValue3;
            }
            return 0.0f;
        }

        public final t getLayoutInfo() {
            return this.$pagerState.getLayoutInfo();
        }

        public final boolean isValidDistance(float f2) {
            return (f2 == Float.POSITIVE_INFINITY || f2 == Float.NEGATIVE_INFINITY) ? false : true;
        }
    }

    public static final k SnapLayoutInfoProvider(K k2, I i2, h1.f fVar) {
        return new a(k2, fVar, i2);
    }

    public static final float calculateFinalSnappingBound(K k2, e0.u uVar, float f2, float f3, float f4, float f5) {
        boolean zIsScrollingForward = isScrollingForward(k2, f3);
        if (k2.getLayoutInfo().getOrientation() != androidx.compose.foundation.gestures.I.Vertical && uVar != e0.u.Ltr) {
            zIsScrollingForward = !zIsScrollingForward;
        }
        int pageSize = k2.getLayoutInfo().getPageSize();
        float fDragGestureDelta = pageSize == 0 ? 0.0f : dragGestureDelta(k2) / pageSize;
        float f6 = fDragGestureDelta - ((int) fDragGestureDelta);
        int iCalculateFinalSnappingItem = e.calculateFinalSnappingItem(k2.getDensity$foundation_release(), f3);
        d.a aVar = d.Companion;
        if (d.m865equalsimpl0(iCalculateFinalSnappingItem, aVar.m869getClosestItembbeMdSM())) {
            if (Math.abs(f6) > f2) {
                if (!zIsScrollingForward) {
                    return f4;
                }
            } else if (Math.abs(fDragGestureDelta) >= Math.abs(k2.getPositionThresholdFraction$foundation_release())) {
                if (zIsScrollingForward) {
                    return f4;
                }
            } else if (Math.abs(f4) < Math.abs(f5)) {
                return f4;
            }
        } else if (!d.m865equalsimpl0(iCalculateFinalSnappingItem, aVar.m870getNextItembbeMdSM())) {
            if (d.m865equalsimpl0(iCalculateFinalSnappingItem, aVar.m871getPreviousItembbeMdSM())) {
                return f4;
            }
            return 0.0f;
        }
        return f5;
    }

    private static final void debugLog(h1.a aVar) {
    }

    private static final float dragGestureDelta(K k2) {
        return k2.getLayoutInfo().getOrientation() == androidx.compose.foundation.gestures.I.Horizontal ? Float.intBitsToFloat((int) (k2.m1127getUpDownDifferenceF1C5BW0$foundation_release() >> 32)) : Float.intBitsToFloat((int) (k2.m1127getUpDownDifferenceF1C5BW0$foundation_release() & 4294967295L));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean isScrollingForward(K k2, float f2) {
        boolean reverseLayout = k2.getLayoutInfo().getReverseLayout();
        boolean z2 = (k2.isNotGestureAction$foundation_release() ? -f2 : dragGestureDelta(k2)) > 0.0f;
        return (z2 && reverseLayout) || !(z2 || reverseLayout);
    }
}
