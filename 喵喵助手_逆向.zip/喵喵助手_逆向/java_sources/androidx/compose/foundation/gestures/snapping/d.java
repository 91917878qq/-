package androidx.compose.foundation.gestures.snapping;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class d {
    private final int value;
    public static final a Companion = new a(null);
    private static final int ClosestItem = m863constructorimpl(0);
    private static final int NextItem = m863constructorimpl(1);
    private static final int PreviousItem = m863constructorimpl(2);

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: renamed from: getClosestItem-bbeMdSM, reason: not valid java name */
        public final int m869getClosestItembbeMdSM() {
            return d.ClosestItem;
        }

        /* JADX INFO: renamed from: getNextItem-bbeMdSM, reason: not valid java name */
        public final int m870getNextItembbeMdSM() {
            return d.NextItem;
        }

        /* JADX INFO: renamed from: getPreviousItem-bbeMdSM, reason: not valid java name */
        public final int m871getPreviousItembbeMdSM() {
            return d.PreviousItem;
        }

        private a() {
        }
    }

    private /* synthetic */ d(int i2) {
        this.value = i2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ d m862boximpl(int i2) {
        return new d(i2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    public static int m863constructorimpl(int i2) {
        return i2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m864equalsimpl(int i2, Object obj) {
        return (obj instanceof d) && i2 == ((d) obj).m868unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m865equalsimpl0(int i2, int i3) {
        return i2 == i3;
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m866hashCodeimpl(int i2) {
        return Integer.hashCode(i2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m867toStringimpl(int i2) {
        return D0.d.o("FinalSnappingItem(value=", i2, ')');
    }

    public boolean equals(Object obj) {
        return m864equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m866hashCodeimpl(this.value);
    }

    public String toString() {
        return m867toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ int m868unboximpl() {
        return this.value;
    }
}
