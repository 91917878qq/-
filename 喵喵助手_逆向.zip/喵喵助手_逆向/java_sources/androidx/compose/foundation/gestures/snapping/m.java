package androidx.compose.foundation.gestures.snapping;

/* JADX INFO: loaded from: classes.dex */
public final class m implements n {
    public static final int $stable = 0;
    public static final m INSTANCE = new m();

    private m() {
    }

    @Override // androidx.compose.foundation.gestures.snapping.n
    public int position(int i2, int i3, int i4, int i5, int i6, int i7) {
        return 0;
    }

    public String toString() {
        return "Start";
    }
}
