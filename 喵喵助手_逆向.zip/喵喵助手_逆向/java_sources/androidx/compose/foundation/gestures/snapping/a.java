package androidx.compose.foundation.gestures.snapping;

import androidx.compose.animation.core.C0317k;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    private final C0317k currentAnimationState;
    private final Object remainingOffset;

    public a(Object obj, C0317k c0317k) {
        this.remainingOffset = obj;
        this.currentAnimationState = c0317k;
    }

    public final Object component1() {
        return this.remainingOffset;
    }

    public final C0317k component2() {
        return this.currentAnimationState;
    }

    public final C0317k getCurrentAnimationState() {
        return this.currentAnimationState;
    }

    public final Object getRemainingOffset() {
        return this.remainingOffset;
    }
}
