package androidx.compose.foundation.gestures.snapping;

import a.AbstractC0292a;
import androidx.compose.animation.core.A;
import androidx.compose.animation.core.AbstractC0319l;
import androidx.compose.animation.core.C0317k;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.animation.core.InterfaceC0341y;
import androidx.compose.foundation.gestures.Q;
import androidx.compose.foundation.gestures.Z;
import androidx.compose.foundation.gestures.i0;
import androidx.compose.foundation.gestures.snapping.g;
import androidx.compose.ui.B;
import o.AbstractC1403e;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class g implements i0 {
    public static final int $stable = 0;
    private final InterfaceC0341y decayAnimationSpec;
    private B motionScaleDuration = Z.getDefaultScrollMotionDurationScale();
    private final InterfaceC0313i snapAnimationSpec;
    private final k snapLayoutInfoProvider;

    public static final class a extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g.this.fling(null, 0.0f, null, this);
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ float $initialVelocity;
        final /* synthetic */ h1.c $onRemainingScrollOffsetUpdate;
        final /* synthetic */ Q $this_fling;
        Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(float f2, h1.c cVar, Q q2, Y0.c cVar2) {
            super(2, cVar2);
            this.$initialVelocity = f2;
            this.$onRemainingScrollOffsetUpdate = cVar;
            this.$this_fling = q2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$1(kotlin.jvm.internal.B b2, h1.c cVar, float f2) {
            float f3 = b2.f3115b - f2;
            b2.f3115b = f3;
            cVar.invoke(Float.valueOf(f3));
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$4(kotlin.jvm.internal.B b2, h1.c cVar, float f2) {
            float f3 = b2.f3115b - f2;
            b2.f3115b = f3;
            cVar.invoke(Float.valueOf(f3));
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return g.this.new b(this.$initialVelocity, this.$onRemainingScrollOffsetUpdate, this.$this_fling, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            final kotlin.jvm.internal.B b2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                float fCalculateApproachOffset = g.this.snapLayoutInfoProvider.calculateApproachOffset(this.$initialVelocity, A.calculateTargetValue(g.this.decayAnimationSpec, 0.0f, this.$initialVelocity));
                if (Float.isNaN(fCalculateApproachOffset)) {
                    AbstractC1403e.throwIllegalStateException("calculateApproachOffset returned NaN. Please use a valid value.");
                }
                b2 = new kotlin.jvm.internal.B();
                float fSignum = Math.signum(this.$initialVelocity) * Math.abs(fCalculateApproachOffset);
                b2.f3115b = fSignum;
                this.$onRemainingScrollOffsetUpdate.invoke(new Float(fSignum));
                g gVar = g.this;
                Q q2 = this.$this_fling;
                float f2 = b2.f3115b;
                float f3 = this.$initialVelocity;
                final h1.c cVar = this.$onRemainingScrollOffsetUpdate;
                final int i3 = 0;
                h1.c cVar2 = new h1.c() { // from class: androidx.compose.foundation.gestures.snapping.h
                    @Override // h1.c
                    public final Object invoke(Object obj2) {
                        int i4 = i3;
                        float fFloatValue = ((Float) obj2).floatValue();
                        switch (i4) {
                            case 0:
                                return g.b.invokeSuspend$lambda$1(b2, cVar, fFloatValue);
                            default:
                                return g.b.invokeSuspend$lambda$4(b2, cVar, fFloatValue);
                        }
                    }
                };
                this.L$0 = b2;
                this.label = 1;
                obj = gVar.tryApproach(q2, f2, f3, cVar2, this);
                if (obj == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    if (i2 == 2) {
                        AbstractC0292a.H(obj);
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                b2 = (kotlin.jvm.internal.B) this.L$0;
                AbstractC0292a.H(obj);
            }
            C0317k c0317k = (C0317k) obj;
            float fCalculateSnapOffset = g.this.snapLayoutInfoProvider.calculateSnapOffset(((Number) c0317k.getVelocity()).floatValue());
            if (Float.isNaN(fCalculateSnapOffset)) {
                AbstractC1403e.throwIllegalStateException("calculateSnapOffset returned NaN. Please use a valid value.");
            }
            b2.f3115b = fCalculateSnapOffset;
            Q q3 = this.$this_fling;
            C0317k c0317kCopy$default = AbstractC0319l.copy$default(c0317k, 0.0f, 0.0f, 0L, 0L, false, 30, (Object) null);
            InterfaceC0313i interfaceC0313i = g.this.snapAnimationSpec;
            final h1.c cVar3 = this.$onRemainingScrollOffsetUpdate;
            final int i4 = 1;
            h1.c cVar4 = new h1.c() { // from class: androidx.compose.foundation.gestures.snapping.h
                @Override // h1.c
                public final Object invoke(Object obj2) {
                    int i42 = i4;
                    float fFloatValue = ((Float) obj2).floatValue();
                    switch (i42) {
                        case 0:
                            return g.b.invokeSuspend$lambda$1(b2, cVar3, fFloatValue);
                        default:
                            return g.b.invokeSuspend$lambda$4(b2, cVar3, fFloatValue);
                    }
                }
            };
            this.L$0 = null;
            this.label = 2;
            obj = j.animateWithTarget(q3, fCalculateSnapOffset, fCalculateSnapOffset, c0317kCopy$default, interfaceC0313i, cVar4, this);
            return obj == aVar ? aVar : obj;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class c extends a1.c {
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g.this.performFling(null, 0.0f, null, this);
        }
    }

    public static final class d extends a1.c {
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g.this.tryApproach(null, 0.0f, 0.0f, null, this);
        }
    }

    public g(k kVar, InterfaceC0341y interfaceC0341y, InterfaceC0313i interfaceC0313i) {
        this.snapLayoutInfoProvider = kVar;
        this.decayAnimationSpec = interfaceC0341y;
        this.snapAnimationSpec = interfaceC0313i;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object fling(androidx.compose.foundation.gestures.Q r11, float r12, h1.c r13, Y0.c r14) throws java.lang.Throwable {
        /*
            r10 = this;
            boolean r0 = r14 instanceof androidx.compose.foundation.gestures.snapping.g.a
            if (r0 == 0) goto L13
            r0 = r14
            androidx.compose.foundation.gestures.snapping.g$a r0 = (androidx.compose.foundation.gestures.snapping.g.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.snapping.g$a r0 = new androidx.compose.foundation.gestures.snapping.g$a
            r0.<init>(r14)
        L18:
            java.lang.Object r14 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L34
            if (r2 != r3) goto L2c
            java.lang.Object r11 = r0.L$0
            r13 = r11
            h1.c r13 = (h1.c) r13
            a.AbstractC0292a.H(r14)
            goto L4f
        L2c:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r12)
            throw r11
        L34:
            a.AbstractC0292a.H(r14)
            androidx.compose.ui.B r14 = r10.motionScaleDuration
            androidx.compose.foundation.gestures.snapping.g$b r2 = new androidx.compose.foundation.gestures.snapping.g$b
            r9 = 0
            r4 = r2
            r5 = r10
            r6 = r12
            r7 = r13
            r8 = r11
            r4.<init>(r6, r7, r8, r9)
            r0.L$0 = r13
            r0.label = r3
            java.lang.Object r14 = r1.AbstractC1476z.A(r14, r2, r0)
            if (r14 != r1) goto L4f
            return r1
        L4f:
            androidx.compose.foundation.gestures.snapping.a r14 = (androidx.compose.foundation.gestures.snapping.a) r14
            java.lang.Float r11 = new java.lang.Float
            r12 = 0
            r11.<init>(r12)
            r13.invoke(r11)
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.g.fling(androidx.compose.foundation.gestures.Q, float, h1.c, Y0.c):java.lang.Object");
    }

    private final boolean isDecayApproachPossible(float f2, float f3) {
        return Math.abs(A.calculateTargetValue(this.decayAnimationSpec, 0.0f, f3)) >= Math.abs(f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object runApproach(Q q2, float f2, float f3, h1.c cVar, Y0.c cVar2) {
        return j.approach(q2, f2, f3, isDecayApproachPossible(f2, f3) ? new androidx.compose.foundation.gestures.snapping.c(this.decayAnimationSpec) : new p(this.snapAnimationSpec), cVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object tryApproach(androidx.compose.foundation.gestures.Q r19, float r20, float r21, h1.c r22, Y0.c r23) {
        /*
            r18 = this;
            r0 = r23
            boolean r1 = r0 instanceof androidx.compose.foundation.gestures.snapping.g.d
            if (r1 == 0) goto L18
            r1 = r0
            androidx.compose.foundation.gestures.snapping.g$d r1 = (androidx.compose.foundation.gestures.snapping.g.d) r1
            int r2 = r1.label
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L18
            int r2 = r2 - r3
            r1.label = r2
            r8 = r18
        L16:
            r7 = r1
            goto L20
        L18:
            androidx.compose.foundation.gestures.snapping.g$d r1 = new androidx.compose.foundation.gestures.snapping.g$d
            r8 = r18
            r1.<init>(r0)
            goto L16
        L20:
            java.lang.Object r0 = r7.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r7.label
            r3 = 1
            if (r2 == 0) goto L37
            if (r2 != r3) goto L2f
            a.AbstractC0292a.H(r0)
            goto L71
        L2f:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L37:
            a.AbstractC0292a.H(r0)
            float r0 = java.lang.Math.abs(r20)
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto L44
            goto L4c
        L44:
            float r0 = java.lang.Math.abs(r21)
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto L5e
        L4c:
            r16 = 28
            r17 = 0
            r11 = 0
            r13 = 0
            r15 = 0
            r9 = r20
            r10 = r21
            androidx.compose.animation.core.k r0 = androidx.compose.animation.core.AbstractC0319l.AnimationState$default(r9, r10, r11, r13, r15, r16, r17)
            goto L77
        L5e:
            r7.label = r3
            r2 = r18
            r3 = r19
            r4 = r20
            r5 = r21
            r6 = r22
            java.lang.Object r0 = r2.runApproach(r3, r4, r5, r6, r7)
            if (r0 != r1) goto L71
            return r1
        L71:
            androidx.compose.foundation.gestures.snapping.a r0 = (androidx.compose.foundation.gestures.snapping.a) r0
            androidx.compose.animation.core.k r0 = r0.getCurrentAnimationState()
        L77:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.g.tryApproach(androidx.compose.foundation.gestures.Q, float, float, h1.c, Y0.c):java.lang.Object");
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return kotlin.jvm.internal.o.a(gVar.snapAnimationSpec, this.snapAnimationSpec) && kotlin.jvm.internal.o.a(gVar.decayAnimationSpec, this.decayAnimationSpec) && kotlin.jvm.internal.o.a(gVar.snapLayoutInfoProvider, this.snapLayoutInfoProvider);
    }

    public final B getMotionScaleDuration$foundation_release() {
        return this.motionScaleDuration;
    }

    public int hashCode() {
        return this.snapLayoutInfoProvider.hashCode() + ((this.decayAnimationSpec.hashCode() + (this.snapAnimationSpec.hashCode() * 31)) * 31);
    }

    @Override // androidx.compose.foundation.gestures.i0, androidx.compose.foundation.gestures.InterfaceC0400y
    public /* bridge */ /* synthetic */ Object performFling(Q q2, float f2, Y0.c cVar) {
        return super.performFling(q2, f2, cVar);
    }

    public final void setMotionScaleDuration$foundation_release(B b2) {
        this.motionScaleDuration = b2;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // androidx.compose.foundation.gestures.i0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object performFling(androidx.compose.foundation.gestures.Q r5, float r6, h1.c r7, Y0.c r8) throws java.lang.Throwable {
        /*
            r4 = this;
            boolean r0 = r8 instanceof androidx.compose.foundation.gestures.snapping.g.c
            if (r0 == 0) goto L13
            r0 = r8
            androidx.compose.foundation.gestures.snapping.g$c r0 = (androidx.compose.foundation.gestures.snapping.g.c) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.snapping.g$c r0 = new androidx.compose.foundation.gestures.snapping.g$c
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 != r3) goto L27
            a.AbstractC0292a.H(r8)
            goto L3b
        L27:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L2f:
            a.AbstractC0292a.H(r8)
            r0.label = r3
            java.lang.Object r8 = r4.fling(r5, r6, r7, r0)
            if (r8 != r1) goto L3b
            return r1
        L3b:
            androidx.compose.foundation.gestures.snapping.a r8 = (androidx.compose.foundation.gestures.snapping.a) r8
            java.lang.Object r5 = r8.component1()
            java.lang.Number r5 = (java.lang.Number) r5
            float r5 = r5.floatValue()
            androidx.compose.animation.core.k r6 = r8.component2()
            r7 = 0
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 != 0) goto L51
            goto L5b
        L51:
            java.lang.Object r5 = r6.getVelocity()
            java.lang.Number r5 = (java.lang.Number) r5
            float r7 = r5.floatValue()
        L5b:
            java.lang.Float r5 = new java.lang.Float
            r5.<init>(r7)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.snapping.g.performFling(androidx.compose.foundation.gestures.Q, float, h1.c, Y0.c):java.lang.Object");
    }
}
