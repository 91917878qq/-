package androidx.compose.foundation.gestures;

import e0.AbstractC1303A;

/* JADX INFO: loaded from: classes.dex */
public final class F {
    private final Q.c xVelocityTracker = new Q.c(true);
    private final Q.c yVelocityTracker = new Q.c(true);

    /* JADX INFO: renamed from: addDelta-Uv8p0NA, reason: not valid java name */
    public final void m764addDeltaUv8p0NA(long j2, long j3) {
        this.xVelocityTracker.addDataPoint(j2, Float.intBitsToFloat((int) (j3 >> 32)));
        this.yVelocityTracker.addDataPoint(j2, Float.intBitsToFloat((int) (j3 & 4294967295L)));
    }

    /* JADX INFO: renamed from: calculateVelocity-9UxMQ8M, reason: not valid java name */
    public final long m765calculateVelocity9UxMQ8M() {
        return AbstractC1303A.Velocity(this.xVelocityTracker.calculateVelocity(Float.MAX_VALUE), this.yVelocityTracker.calculateVelocity(Float.MAX_VALUE));
    }
}
