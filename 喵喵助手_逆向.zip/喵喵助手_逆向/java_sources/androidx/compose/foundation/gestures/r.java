package androidx.compose.foundation.gestures;

import O0.C0218m;
import O0.C0228r0;
import O0.Z0;
import a.AbstractC0292a;
import androidx.compose.foundation.gestures.AbstractC0389m;
import androidx.compose.foundation.gestures.r;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.node.N0;
import e0.AbstractC1303A;
import java.util.concurrent.CancellationException;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public abstract class r extends androidx.compose.ui.node.r implements N0 {
    public static final int $stable = 8;
    private h1.c canDrag;
    private t1.g channel;
    private androidx.compose.foundation.interaction.b dragInteraction;
    private boolean enabled;
    private androidx.compose.foundation.interaction.n interactionSource;
    private boolean isListeningForEvents;
    private I orientationLock;
    private androidx.compose.ui.input.pointer.Z pointerInputNode;
    private final h1.c _canDrag = new C0218m(this, 8);
    private long nodeOffset = J.f.Companion.m66getZeroF1C5BW0();

    public static final class a implements PointerInputEventHandler {

        /* JADX INFO: renamed from: androidx.compose.foundation.gestures.r$a$a, reason: collision with other inner class name */
        public static final class C0032a extends a1.j implements h1.e {
            final /* synthetic */ h1.e $onDrag;
            final /* synthetic */ h1.a $onDragCancel;
            final /* synthetic */ h1.c $onDragEnd;
            final /* synthetic */ h1.f $onDragStart;
            final /* synthetic */ h1.a $shouldAwaitTouchSlop;
            final /* synthetic */ androidx.compose.ui.input.pointer.L $this_SuspendingPointerInputModifierNode;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ r this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0032a(androidx.compose.ui.input.pointer.L l2, r rVar, h1.f fVar, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
                super(2, cVar2);
                this.$this_SuspendingPointerInputModifierNode = l2;
                this.this$0 = rVar;
                this.$onDragStart = fVar;
                this.$onDragEnd = cVar;
                this.$onDragCancel = aVar;
                this.$shouldAwaitTouchSlop = aVar2;
                this.$onDrag = eVar;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                C0032a c0032a = new C0032a(this.$this_SuspendingPointerInputModifierNode, this.this$0, this.$onDragStart, this.$onDragEnd, this.$onDragCancel, this.$shouldAwaitTouchSlop, this.$onDrag, cVar);
                c0032a.L$0 = obj;
                return c0032a;
            }

            /* JADX WARN: Removed duplicated region for block: B:20:0x004c  */
            /* JADX WARN: Removed duplicated region for block: B:25:0x005a  */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final Object invokeSuspend(Object obj) {
                InterfaceC1474x interfaceC1474x;
                CancellationException e2;
                t1.g gVar;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    InterfaceC1474x interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                    try {
                        androidx.compose.ui.input.pointer.L l2 = this.$this_SuspendingPointerInputModifierNode;
                        I i3 = this.this$0.orientationLock;
                        h1.f fVar = this.$onDragStart;
                        h1.c cVar = this.$onDragEnd;
                        h1.a aVar2 = this.$onDragCancel;
                        h1.a aVar3 = this.$shouldAwaitTouchSlop;
                        h1.e eVar = this.$onDrag;
                        this.L$0 = interfaceC1474x2;
                        this.label = 1;
                        if (AbstractC0391o.detectDragGestures(l2, i3, fVar, cVar, aVar2, aVar3, eVar, this) == aVar) {
                            return aVar;
                        }
                    } catch (CancellationException e3) {
                        interfaceC1474x = interfaceC1474x2;
                        e2 = e3;
                        gVar = this.this$0.channel;
                        if (gVar != null) {
                            gVar.l(AbstractC0389m.a.INSTANCE);
                        }
                        if (!AbstractC1476z.p(interfaceC1474x)) {
                            throw e2;
                        }
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                    try {
                        AbstractC0292a.H(obj);
                    } catch (CancellationException e4) {
                        e2 = e4;
                        gVar = this.this$0.channel;
                        if (gVar != null) {
                        }
                        if (!AbstractC1476z.p(interfaceC1474x)) {
                        }
                    }
                }
                return U0.n.f1521a;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((C0032a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        public a() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$0(r rVar, Q.e eVar, androidx.compose.ui.input.pointer.C c2, androidx.compose.ui.input.pointer.C c3, J.f fVar) {
            rVar.nodeOffset = J.f.Companion.m66getZeroF1C5BW0();
            if (((Boolean) rVar.getCanDrag().invoke(c2)).booleanValue()) {
                if (!rVar.isListeningForEvents) {
                    if (rVar.channel == null) {
                        rVar.channel = t1.j.a(Integer.MAX_VALUE, 6, null);
                    }
                    rVar.startListeningForEvents();
                }
                Q.f.addPointerInputChange(eVar, c2);
                long jM54minusMKHz9U = J.f.m54minusMKHz9U(c3.m3659getPositionF1C5BW0(), fVar.m60unboximpl());
                t1.g gVar = rVar.channel;
                if (gVar != null) {
                    gVar.l(new AbstractC0389m.c(jM54minusMKHz9U, null));
                }
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$1(Q.e eVar, androidx.compose.ui.input.pointer.L l2, r rVar, androidx.compose.ui.input.pointer.C c2) {
            Q.f.addPointerInputChange(eVar, c2);
            float maximumFlingVelocity = l2.getViewConfiguration().getMaximumFlingVelocity();
            long jM532calculateVelocityAH228Gc = eVar.m532calculateVelocityAH228Gc(AbstractC1303A.Velocity(maximumFlingVelocity, maximumFlingVelocity));
            eVar.resetTracking();
            t1.g gVar = rVar.channel;
            if (gVar != null) {
                gVar.l(new AbstractC0389m.d(AbstractC0397v.m879toValidVelocityTH1AsA0(jM532calculateVelocityAH228Gc), null));
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$2(r rVar) {
            t1.g gVar = rVar.channel;
            if (gVar != null) {
                gVar.l(AbstractC0389m.a.INSTANCE);
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final boolean invoke$lambda$3(r rVar) {
            return !rVar.startDragImmediately();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invoke$lambda$4(r rVar, kotlin.jvm.internal.D d2, Q.e eVar, androidx.compose.ui.input.pointer.C c2, J.f fVar) {
            if (androidx.compose.foundation.A.isAdjustPointerInputChangeOffsetForVelocityTrackerEnabled) {
                long jPositionOnScreen = androidx.compose.ui.layout.K.positionOnScreen(AbstractC1009p.requireLayoutCoordinates(rVar));
                if (!J.f.m47equalsimpl0(jPositionOnScreen, d2.f3117b)) {
                    rVar.nodeOffset = J.f.m55plusMKHz9U(rVar.nodeOffset, J.f.m54minusMKHz9U(jPositionOnScreen, d2.f3117b));
                }
                d2.f3117b = jPositionOnScreen;
            }
            Q.f.m535addPointerInputChange0AR0LA0(eVar, c2, rVar.nodeOffset);
            t1.g gVar = rVar.channel;
            if (gVar != null) {
                gVar.l(new AbstractC0389m.b(fVar.m60unboximpl(), null));
            }
            return U0.n.f1521a;
        }

        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
        public final Object invoke(androidx.compose.ui.input.pointer.L l2, Y0.c cVar) {
            Q.e eVar = new Q.e();
            kotlin.jvm.internal.D d2 = new kotlin.jvm.internal.D();
            d2.f3117b = androidx.compose.foundation.A.isAdjustPointerInputChangeOffsetForVelocityTrackerEnabled ? androidx.compose.ui.layout.K.positionOnScreen(AbstractC1009p.requireLayoutCoordinates(r.this)) : J.f.Companion.m66getZeroF1C5BW0();
            final r rVar = r.this;
            Z0 z02 = new Z0(2, rVar, eVar);
            O0.Y y2 = new O0.Y(eVar, l2, rVar, 4);
            final int i2 = 0;
            h1.a aVar = new h1.a() { // from class: androidx.compose.foundation.gestures.q
                @Override // h1.a
                public final Object invoke() {
                    switch (i2) {
                        case 0:
                            return r.a.invoke$lambda$2(rVar);
                        default:
                            return Boolean.valueOf(r.a.invoke$lambda$3(rVar));
                    }
                }
            };
            final int i3 = 1;
            Object objE = AbstractC1476z.e(new C0032a(l2, rVar, z02, y2, aVar, new h1.a() { // from class: androidx.compose.foundation.gestures.q
                @Override // h1.a
                public final Object invoke() {
                    switch (i3) {
                        case 0:
                            return r.a.invoke$lambda$2(rVar);
                        default:
                            return Boolean.valueOf(r.a.invoke$lambda$3(rVar));
                    }
                }
            }, new C0228r0(rVar, d2, eVar, 3), null), cVar);
            return objE == Z0.a.f1616b ? objE : U0.n.f1521a;
        }
    }

    public static final class b extends a1.c {
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return r.this.processDragCancel(this);
        }
    }

    public static final class c extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return r.this.processDragStart(null, this);
        }
    }

    public static final class d extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return r.this.processDragStop(null, this);
        }
    }

    public static final class e extends a1.j implements h1.e {
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        int label;

        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ kotlin.jvm.internal.E $event;
            /* synthetic */ Object L$0;
            Object L$1;
            int label;
            final /* synthetic */ r this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(kotlin.jvm.internal.E e2, r rVar, Y0.c cVar) {
                super(2, cVar);
                this.$event = e2;
                this.this$0 = rVar;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$event, this.this$0, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(h1.c cVar, Y0.c cVar2) {
                return ((a) create(cVar, cVar2)).invokeSuspend(U0.n.f1521a);
            }

            /* JADX WARN: Removed duplicated region for block: B:11:0x002d  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0047 -> B:25:0x0059). Please report as a decompilation issue!!! */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0053 -> B:24:0x0056). Please report as a decompilation issue!!! */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final Object invokeSuspend(Object obj) {
                h1.c cVar;
                Object obj2;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    cVar = (h1.c) this.L$0;
                    obj2 = this.$event.f3118b;
                    if (obj2 instanceof AbstractC0389m.d) {
                    }
                    return U0.n.f1521a;
                }
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.jvm.internal.E e2 = (kotlin.jvm.internal.E) this.L$1;
                cVar = (h1.c) this.L$0;
                AbstractC0292a.H(obj);
                AbstractC0389m abstractC0389m = (AbstractC0389m) obj;
                e2.f3118b = abstractC0389m;
                obj2 = this.$event.f3118b;
                if (!(obj2 instanceof AbstractC0389m.d) || (obj2 instanceof AbstractC0389m.a)) {
                    return U0.n.f1521a;
                }
                abstractC0389m = null;
                AbstractC0389m.b bVar = obj2 instanceof AbstractC0389m.b ? (AbstractC0389m.b) obj2 : null;
                if (bVar != null) {
                    cVar.invoke(bVar);
                }
                e2 = this.$event;
                t1.g gVar = this.this$0.channel;
                if (gVar != null) {
                    this.L$0 = cVar;
                    this.L$1 = e2;
                    this.label = 1;
                    obj = gVar.a(this);
                    if (obj == aVar) {
                        return aVar;
                    }
                    AbstractC0389m abstractC0389m2 = (AbstractC0389m) obj;
                }
                e2.f3118b = abstractC0389m2;
                obj2 = this.$event.f3118b;
                if (obj2 instanceof AbstractC0389m.d) {
                }
                return U0.n.f1521a;
            }
        }

        public e(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            e eVar = r.this.new e(cVar);
            eVar.L$0 = obj;
            return eVar;
        }

        /* JADX WARN: Can't wrap try/catch for region: R(7:34|35|(1:37)|14|57|38|(2:44|(2:46|(1:48)))(2:40|(1:42))) */
        /* JADX WARN: Code restructure failed: missing block: B:43:0x00d5, code lost:
        
            r1 = r4;
         */
        /* JADX WARN: Removed duplicated region for block: B:21:0x0062  */
        /* JADX WARN: Removed duplicated region for block: B:31:0x008d  */
        /* JADX WARN: Removed duplicated region for block: B:37:0x00b7 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:40:0x00be A[Catch: CancellationException -> 0x00d5, TryCatch #1 {CancellationException -> 0x00d5, blocks: (B:38:0x00b8, B:40:0x00be, B:44:0x00d7, B:46:0x00db), top: B:57:0x00b8 }] */
        /* JADX WARN: Removed duplicated region for block: B:44:0x00d7 A[Catch: CancellationException -> 0x00d5, TryCatch #1 {CancellationException -> 0x00d5, blocks: (B:38:0x00b8, B:40:0x00be, B:44:0x00d7, B:46:0x00db), top: B:57:0x00b8 }] */
        /* JADX WARN: Removed duplicated region for block: B:51:0x00fa A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:52:0x00fb  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x008b -> B:19:0x005c). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:41:0x00d2 -> B:19:0x005c). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:45:0x00d9 -> B:19:0x005c). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:47:0x00e8 -> B:19:0x005c). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:50:0x00f8 -> B:11:0x0025). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC1474x interfaceC1474x;
            kotlin.jvm.internal.E e2;
            kotlin.jvm.internal.E e3;
            kotlin.jvm.internal.E e4;
            InterfaceC1474x interfaceC1474x2;
            InterfaceC1474x interfaceC1474x3;
            r rVar;
            Object obj2;
            r rVar2;
            a aVar;
            AbstractC0389m abstractC0389m;
            Object obj3;
            Z0.a aVar2 = Z0.a.f1616b;
            switch (this.label) {
                case 0:
                    AbstractC0292a.H(obj);
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                    if (AbstractC1476z.p(interfaceC1474x)) {
                        e2 = new kotlin.jvm.internal.E();
                        t1.g gVar = r.this.channel;
                        if (gVar != null) {
                            this.L$0 = interfaceC1474x;
                            this.L$1 = e2;
                            this.L$2 = e2;
                            this.label = 1;
                            obj = gVar.a(this);
                            if (obj == aVar2) {
                                return aVar2;
                            }
                            e3 = e2;
                            abstractC0389m = (AbstractC0389m) obj;
                            e2.f3118b = abstractC0389m;
                            obj3 = e3.f3118b;
                            if (obj3 instanceof AbstractC0389m.c) {
                                this.L$0 = interfaceC1474x;
                                this.L$1 = e3;
                                this.L$2 = null;
                                this.label = 2;
                                if (r.this.processDragStart((AbstractC0389m.c) obj3, this) == aVar2) {
                                    return aVar2;
                                }
                                e4 = e3;
                                interfaceC1474x2 = interfaceC1474x;
                                rVar2 = r.this;
                                aVar = new a(e4, rVar2, null);
                                this.L$0 = interfaceC1474x2;
                                this.L$1 = e4;
                                this.label = 3;
                                if (rVar2.drag(aVar, this) == aVar2) {
                                    return aVar2;
                                }
                                interfaceC1474x = interfaceC1474x2;
                                obj2 = e4.f3118b;
                                if (obj2 instanceof AbstractC0389m.d) {
                                    r rVar3 = r.this;
                                    kotlin.jvm.internal.o.c(obj2, "null cannot be cast to non-null type androidx.compose.foundation.gestures.DragEvent.DragStopped");
                                    this.L$0 = interfaceC1474x;
                                    this.L$1 = null;
                                    this.label = 4;
                                    if (rVar3.processDragStop((AbstractC0389m.d) obj2, this) == aVar2) {
                                        return aVar2;
                                    }
                                } else if (obj2 instanceof AbstractC0389m.a) {
                                    r rVar4 = r.this;
                                    this.L$0 = interfaceC1474x;
                                    this.L$1 = null;
                                    this.label = 5;
                                    if (rVar4.processDragCancel(this) == aVar2) {
                                        return aVar2;
                                    }
                                }
                            }
                            if (AbstractC1476z.p(interfaceC1474x)) {
                                return U0.n.f1521a;
                            }
                        } else {
                            e3 = e2;
                            abstractC0389m = null;
                            e2.f3118b = abstractC0389m;
                            obj3 = e3.f3118b;
                            if (obj3 instanceof AbstractC0389m.c) {
                            }
                            if (AbstractC1476z.p(interfaceC1474x)) {
                            }
                        }
                    }
                    break;
                case 1:
                    e2 = (kotlin.jvm.internal.E) this.L$2;
                    e3 = (kotlin.jvm.internal.E) this.L$1;
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    abstractC0389m = (AbstractC0389m) obj;
                    e2.f3118b = abstractC0389m;
                    obj3 = e3.f3118b;
                    if (obj3 instanceof AbstractC0389m.c) {
                    }
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                case 2:
                    e4 = (kotlin.jvm.internal.E) this.L$1;
                    interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    rVar2 = r.this;
                    aVar = new a(e4, rVar2, null);
                    this.L$0 = interfaceC1474x2;
                    this.L$1 = e4;
                    this.label = 3;
                    if (rVar2.drag(aVar, this) == aVar2) {
                    }
                    interfaceC1474x = interfaceC1474x2;
                    obj2 = e4.f3118b;
                    if (obj2 instanceof AbstractC0389m.d) {
                    }
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                case 3:
                    e4 = (kotlin.jvm.internal.E) this.L$1;
                    interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                    try {
                        AbstractC0292a.H(obj);
                    } catch (CancellationException unused) {
                        interfaceC1474x3 = interfaceC1474x2;
                        rVar = r.this;
                        this.L$0 = interfaceC1474x3;
                        this.L$1 = null;
                        this.label = 6;
                        if (rVar.processDragCancel(this) == aVar2) {
                        }
                        interfaceC1474x = interfaceC1474x3;
                        if (AbstractC1476z.p(interfaceC1474x)) {
                        }
                    }
                    interfaceC1474x = interfaceC1474x2;
                    obj2 = e4.f3118b;
                    if (obj2 instanceof AbstractC0389m.d) {
                    }
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                case 4:
                    interfaceC1474x3 = (InterfaceC1474x) this.L$0;
                    try {
                        AbstractC0292a.H(obj);
                    } catch (CancellationException unused2) {
                        rVar = r.this;
                        this.L$0 = interfaceC1474x3;
                        this.L$1 = null;
                        this.label = 6;
                        if (rVar.processDragCancel(this) == aVar2) {
                            return aVar2;
                        }
                    }
                    interfaceC1474x = interfaceC1474x3;
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                case 5:
                    interfaceC1474x3 = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    interfaceC1474x = interfaceC1474x3;
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                case 6:
                    interfaceC1474x3 = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    interfaceC1474x = interfaceC1474x3;
                    if (AbstractC1476z.p(interfaceC1474x)) {
                    }
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public r(h1.c cVar, boolean z2, androidx.compose.foundation.interaction.n nVar, I i2) {
        this.orientationLock = i2;
        this.canDrag = cVar;
        this.enabled = z2;
        this.interactionSource = nVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean _canDrag$lambda$0(r rVar, androidx.compose.ui.input.pointer.C c2) {
        return ((Boolean) rVar.canDrag.invoke(c2)).booleanValue();
    }

    private final androidx.compose.ui.input.pointer.Z initializePointerInputNode() {
        return androidx.compose.ui.input.pointer.X.SuspendingPointerInputModifierNode(new a());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object processDragCancel(Y0.c cVar) {
        b bVar;
        if (cVar instanceof b) {
            bVar = (b) cVar;
            int i2 = bVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                bVar.label = i2 - Integer.MIN_VALUE;
            } else {
                bVar = new b(cVar);
            }
        }
        Object obj = bVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = bVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            androidx.compose.foundation.interaction.b bVar2 = this.dragInteraction;
            if (bVar2 != null) {
                androidx.compose.foundation.interaction.n nVar = this.interactionSource;
                if (nVar != null) {
                    androidx.compose.foundation.interaction.a aVar2 = new androidx.compose.foundation.interaction.a(bVar2);
                    bVar.label = 1;
                    if (nVar.emit(aVar2, bVar) == aVar) {
                        return aVar;
                    }
                }
            }
            mo807onDragStoppedTH1AsA0(e0.z.Companion.m5317getZero9UxMQ8M());
            return U0.n.f1521a;
        }
        if (i3 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        AbstractC0292a.H(obj);
        this.dragInteraction = null;
        mo807onDragStoppedTH1AsA0(e0.z.Companion.m5317getZero9UxMQ8M());
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object processDragStart(AbstractC0389m.c cVar, Y0.c cVar2) {
        c cVar3;
        androidx.compose.foundation.interaction.n nVar;
        androidx.compose.foundation.interaction.b bVar;
        AbstractC0389m.c cVar4;
        androidx.compose.foundation.interaction.b bVar2;
        if (cVar2 instanceof c) {
            cVar3 = (c) cVar2;
            int i2 = cVar3.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                cVar3.label = i2 - Integer.MIN_VALUE;
            } else {
                cVar3 = new c(cVar2);
            }
        }
        Object obj = cVar3.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = cVar3.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            androidx.compose.foundation.interaction.b bVar3 = this.dragInteraction;
            if (bVar3 != null && (nVar = this.interactionSource) != null) {
                androidx.compose.foundation.interaction.a aVar2 = new androidx.compose.foundation.interaction.a(bVar3);
                cVar3.L$0 = cVar;
                cVar3.label = 1;
                if (nVar.emit(aVar2, cVar3) == aVar) {
                    return aVar;
                }
            }
        } else {
            if (i3 != 1) {
                if (i3 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                bVar2 = (androidx.compose.foundation.interaction.b) cVar3.L$1;
                cVar4 = (AbstractC0389m.c) cVar3.L$0;
                AbstractC0292a.H(obj);
                bVar = bVar2;
                cVar = cVar4;
                this.dragInteraction = bVar;
                mo806onDragStartedk4lQ0M(cVar.m839getStartPointF1C5BW0());
                return U0.n.f1521a;
            }
            cVar = (AbstractC0389m.c) cVar3.L$0;
            AbstractC0292a.H(obj);
        }
        bVar = new androidx.compose.foundation.interaction.b();
        androidx.compose.foundation.interaction.n nVar2 = this.interactionSource;
        if (nVar2 != null) {
            cVar3.L$0 = cVar;
            cVar3.L$1 = bVar;
            cVar3.label = 2;
            if (nVar2.emit(bVar, cVar3) == aVar) {
                return aVar;
            }
            cVar4 = cVar;
            bVar2 = bVar;
            bVar = bVar2;
            cVar = cVar4;
        }
        this.dragInteraction = bVar;
        mo806onDragStartedk4lQ0M(cVar.m839getStartPointF1C5BW0());
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object processDragStop(AbstractC0389m.d dVar, Y0.c cVar) {
        d dVar2;
        if (cVar instanceof d) {
            dVar2 = (d) cVar;
            int i2 = dVar2.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                dVar2.label = i2 - Integer.MIN_VALUE;
            } else {
                dVar2 = new d(cVar);
            }
        }
        Object obj = dVar2.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = dVar2.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            androidx.compose.foundation.interaction.b bVar = this.dragInteraction;
            if (bVar != null) {
                androidx.compose.foundation.interaction.n nVar = this.interactionSource;
                if (nVar != null) {
                    androidx.compose.foundation.interaction.c cVar2 = new androidx.compose.foundation.interaction.c(bVar);
                    dVar2.L$0 = dVar;
                    dVar2.label = 1;
                    if (nVar.emit(cVar2, dVar2) == aVar) {
                        return aVar;
                    }
                }
            }
            mo807onDragStoppedTH1AsA0(dVar.m840getVelocity9UxMQ8M());
            return U0.n.f1521a;
        }
        if (i3 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        dVar = (AbstractC0389m.d) dVar2.L$0;
        AbstractC0292a.H(obj);
        this.dragInteraction = null;
        mo807onDragStoppedTH1AsA0(dVar.m840getVelocity9UxMQ8M());
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void startListeningForEvents() {
        this.isListeningForEvents = true;
        AbstractC1476z.s(getCoroutineScope(), null, null, new e(null), 3);
    }

    public static /* synthetic */ void update$default(r rVar, h1.c cVar, boolean z2, androidx.compose.foundation.interaction.n nVar, I i2, boolean z3, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: update");
        }
        if ((i3 & 1) != 0) {
            cVar = rVar.canDrag;
        }
        if ((i3 & 2) != 0) {
            z2 = rVar.enabled;
        }
        boolean z4 = z2;
        if ((i3 & 4) != 0) {
            nVar = rVar.interactionSource;
        }
        androidx.compose.foundation.interaction.n nVar2 = nVar;
        if ((i3 & 8) != 0) {
            i2 = rVar.orientationLock;
        }
        I i4 = i2;
        if ((i3 & 16) != 0) {
            z3 = false;
        }
        rVar.update(cVar, z4, nVar2, i4, z3);
    }

    public final void disposeInteractionSource() {
        androidx.compose.foundation.interaction.b bVar = this.dragInteraction;
        if (bVar != null) {
            androidx.compose.foundation.interaction.n nVar = this.interactionSource;
            if (nVar != null) {
                nVar.tryEmit(new androidx.compose.foundation.interaction.a(bVar));
            }
            this.dragInteraction = null;
        }
    }

    public abstract Object drag(h1.e eVar, Y0.c cVar);

    public final h1.c getCanDrag() {
        return this.canDrag;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final androidx.compose.foundation.interaction.n getInteractionSource() {
        return this.interactionSource;
    }

    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.ui.node.N0
    public void onCancelPointerInput() {
        androidx.compose.ui.input.pointer.Z z2 = this.pointerInputNode;
        if (z2 != null) {
            z2.onCancelPointerInput();
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w
    public void onDetach() {
        this.isListeningForEvents = false;
        disposeInteractionSource();
        this.nodeOffset = J.f.Companion.m66getZeroF1C5BW0();
    }

    /* JADX INFO: renamed from: onDragStarted-k-4lQ0M */
    public abstract void mo806onDragStartedk4lQ0M(long j2);

    /* JADX INFO: renamed from: onDragStopped-TH1AsA0 */
    public abstract void mo807onDragStoppedTH1AsA0(long j2);

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    /* JADX INFO: renamed from: onPointerEvent-H0pRuoY */
    public void mo698onPointerEventH0pRuoY(C0918p c0918p, androidx.compose.ui.input.pointer.r rVar, long j2) {
        if (this.enabled && this.pointerInputNode == null) {
            this.pointerInputNode = (androidx.compose.ui.input.pointer.Z) delegate(initializePointerInputNode());
        }
        androidx.compose.ui.input.pointer.Z z2 = this.pointerInputNode;
        if (z2 != null) {
            z2.mo698onPointerEventH0pRuoY(c0918p, rVar, j2);
        }
    }

    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    public abstract boolean startDragImmediately();

    public final void update(h1.c cVar, boolean z2, androidx.compose.foundation.interaction.n nVar, I i2, boolean z3) {
        androidx.compose.ui.input.pointer.Z z4;
        this.canDrag = cVar;
        boolean z5 = true;
        if (this.enabled != z2) {
            this.enabled = z2;
            if (!z2) {
                disposeInteractionSource();
                androidx.compose.ui.input.pointer.Z z6 = this.pointerInputNode;
                if (z6 != null) {
                    undelegate(z6);
                }
                this.pointerInputNode = null;
            }
            z3 = true;
        }
        if (!kotlin.jvm.internal.o.a(this.interactionSource, nVar)) {
            disposeInteractionSource();
            this.interactionSource = nVar;
        }
        if (this.orientationLock != i2) {
            this.orientationLock = i2;
        } else {
            z5 = z3;
        }
        if (!z5 || (z4 = this.pointerInputNode) == null) {
            return;
        }
        z4.resetPointerInputHandler();
    }
}
