package androidx.compose.foundation.gestures;

import O0.C0218m;
import O0.C0233u;
import P.a;
import a.AbstractC0292a;
import android.view.KeyEvent;
import androidx.compose.foundation.EnumC0368c0;
import androidx.compose.foundation.gestures.AbstractC0389m;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.C0921t;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.node.InterfaceC1001l;
import androidx.compose.ui.node.S0;
import androidx.compose.ui.node.T0;
import java.util.List;
import kotlin.jvm.internal.AbstractC1372a;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class b0 extends r implements P.e, S0, InterfaceC1001l, H {
    public static final int $stable = 8;
    private final C0384h contentInViewNode;
    private final C0387k defaultFlingBehavior;
    private InterfaceC0400y flingBehavior;
    private E mouseWheelScrollingLogic;
    private final a0 nestedScrollConnection;
    private final androidx.compose.ui.input.nestedscroll.b nestedScrollDispatcher;
    private androidx.compose.foundation.i0 overscrollEffect;
    private h1.e scrollByAction;
    private h1.e scrollByOffsetAction;
    private final T scrollableContainerNode;
    private final e0 scrollingLogic;
    private final boolean shouldAutoInvalidate;

    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ h1.e $forEachDelta;
        final /* synthetic */ e0 $this_with;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(h1.e eVar, e0 e0Var, Y0.c cVar) {
            super(2, cVar);
            this.$forEachDelta = eVar;
            this.$this_with = e0Var;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(G g2, e0 e0Var, AbstractC0389m.b bVar) {
            g2.mo767scrollByWithOverscrollOzD1aCk(e0Var.m820singleAxisOffsetMKHz9U(bVar.m838getDeltaF1C5BW0()), androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI());
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            a aVar = new a(this.$forEachDelta, this.$this_with, cVar);
            aVar.L$0 = obj;
            return aVar;
        }

        @Override // h1.e
        public final Object invoke(G g2, Y0.c cVar) {
            return ((a) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                G g2 = (G) this.L$0;
                h1.e eVar = this.$forEachDelta;
                M0.m mVar = new M0.m(17, g2, this.$this_with);
                this.label = 1;
                if (eVar.invoke(mVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    public /* synthetic */ class b extends AbstractC1372a implements h1.e {
        public b(Object obj) {
            super(2, obj, b0.class, "onWheelScrollStopped", "onWheelScrollStopped-TH1AsA0(J)V", 4);
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return m808invokesFctU(((e0.z) obj).m5315unboximpl(), (Y0.c) obj2);
        }

        /* JADX INFO: renamed from: invoke-sF-c-tU, reason: not valid java name */
        public final Object m808invokesFctU(long j2, Y0.c cVar) {
            return b0.ensureMouseWheelScrollNodeInitialized$onWheelScrollStopped((b0) this.receiver, j2, cVar);
        }
    }

    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ long $velocity;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$velocity = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return b0.this.new c(this.$velocity, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0 e0Var = b0.this.scrollingLogic;
                long j2 = this.$velocity;
                this.label = 1;
                if (e0Var.m818onScrollStoppedBMRW4eQ(j2, false, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class d extends a1.j implements h1.e {
        final /* synthetic */ long $scrollAmount;
        int label;

        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ long $scrollAmount;
            private /* synthetic */ Object L$0;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(long j2, Y0.c cVar) {
                super(2, cVar);
                this.$scrollAmount = j2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$scrollAmount, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(G g2, Y0.c cVar) {
                return ((a) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                if (this.label != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
                ((G) this.L$0).mo766scrollByOzD1aCk(this.$scrollAmount, androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI());
                return U0.n.f1521a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$scrollAmount = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return b0.this.new d(this.$scrollAmount, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0 e0Var = b0.this.scrollingLogic;
                EnumC0368c0 enumC0368c0 = EnumC0368c0.UserInput;
                a aVar2 = new a(this.$scrollAmount, null);
                this.label = 1;
                if (e0Var.scroll(enumC0368c0, aVar2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((d) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class e extends a1.j implements h1.e {
        final /* synthetic */ long $velocity;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$velocity = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return b0.this.new e(this.$velocity, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0 e0Var = b0.this.scrollingLogic;
                long j2 = this.$velocity;
                this.label = 1;
                if (e0Var.m818onScrollStoppedBMRW4eQ(j2, true, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class f extends a1.j implements h1.e {
        final /* synthetic */ float $x;
        final /* synthetic */ float $y;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(float f2, float f3, Y0.c cVar) {
            super(2, cVar);
            this.$x = f2;
            this.$y = f3;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return b0.this.new f(this.$x, this.$y, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0 e0Var = b0.this.scrollingLogic;
                float f2 = this.$x;
                float f3 = this.$y;
                long jM42constructorimpl = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(f2)) << 32) | (((long) Float.floatToRawIntBits(f3)) & 4294967295L));
                this.label = 1;
                if (Z.m800semanticsScrollByd4ec7I(e0Var, jM42constructorimpl, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((f) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class g extends a1.j implements h1.e {
        /* synthetic */ long J$0;
        int label;

        public g(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            g gVar = b0.this.new g(cVar);
            gVar.J$0 = ((J.f) obj).m60unboximpl();
            return gVar;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return m809invoke3MmeM6k(((J.f) obj).m60unboximpl(), (Y0.c) obj2);
        }

        /* JADX INFO: renamed from: invoke-3MmeM6k, reason: not valid java name */
        public final Object m809invoke3MmeM6k(long j2, Y0.c cVar) {
            return ((g) create(J.f.m39boximpl(j2), cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                long j2 = this.J$0;
                e0 e0Var = b0.this.scrollingLogic;
                this.label = 1;
                obj = Z.m800semanticsScrollByd4ec7I(e0Var, j2, this);
                if (obj == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return obj;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public b0(c0 c0Var, androidx.compose.foundation.i0 i0Var, InterfaceC0400y interfaceC0400y, I i2, boolean z2, boolean z3, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e) {
        super(Z.getCanDragCalculation(), z2, nVar, i2);
        this.overscrollEffect = i0Var;
        this.flingBehavior = interfaceC0400y;
        androidx.compose.ui.input.nestedscroll.b bVar = new androidx.compose.ui.input.nestedscroll.b();
        this.nestedScrollDispatcher = bVar;
        this.scrollableContainerNode = (T) delegate(new T(z2));
        C0387k c0387k = new C0387k(androidx.compose.animation.Q.splineBasedDecay(Z.getUnityDensity()), null, 2, 0 == true ? 1 : 0);
        this.defaultFlingBehavior = c0387k;
        androidx.compose.foundation.i0 i0Var2 = this.overscrollEffect;
        InterfaceC0400y interfaceC0400y2 = this.flingBehavior;
        e0 e0Var = new e0(c0Var, i0Var2, interfaceC0400y2 == null ? c0387k : interfaceC0400y2, i2, z3, bVar, this, new E0.f(this, 10));
        this.scrollingLogic = e0Var;
        a0 a0Var = new a0(e0Var, z2);
        this.nestedScrollConnection = a0Var;
        C0384h c0384h = (C0384h) delegate(new C0384h(i2, e0Var, z3, interfaceC0381e));
        this.contentInViewNode = c0384h;
        delegate(androidx.compose.ui.input.nestedscroll.e.nestedScrollModifierNode(a0Var, bVar));
        delegate(androidx.compose.ui.focus.M.m2740FocusTargetModifierNodePYyLHbc$default(androidx.compose.ui.focus.V.Companion.m2763getNeverLCbbffg(), null, 2, null));
        delegate(new androidx.compose.foundation.relocation.h(c0384h));
        delegate(new androidx.compose.foundation.K(new C0218m(this, 9)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n _init_$lambda$1(b0 b0Var, androidx.compose.ui.layout.J j2) {
        b0Var.contentInViewNode.onFocusBoundsChanged(j2);
        return U0.n.f1521a;
    }

    private final void clearScrollSemanticsActions() {
        this.scrollByAction = null;
        this.scrollByOffsetAction = null;
    }

    private final void ensureMouseWheelScrollNodeInitialized() {
        if (this.mouseWheelScrollingLogic == null) {
            this.mouseWheelScrollingLogic = new E(this.scrollingLogic, AbstractC0378b.platformScrollConfig(this), new b(this), AbstractC1009p.requireDensity(this));
        }
        E e2 = this.mouseWheelScrollingLogic;
        if (e2 != null) {
            e2.startReceivingMouseWheelEvents(getCoroutineScope());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final /* synthetic */ Object ensureMouseWheelScrollNodeInitialized$onWheelScrollStopped(b0 b0Var, long j2, Y0.c cVar) {
        b0Var.m805onWheelScrollStoppedTH1AsA0(j2);
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: onWheelScrollStopped-TH1AsA0, reason: not valid java name */
    private final void m805onWheelScrollStoppedTH1AsA0(long j2) {
        AbstractC1476z.s(this.nestedScrollDispatcher.getCoroutineScope(), null, null, new e(j2, null), 3);
    }

    private final void setScrollSemanticsActions() {
        this.scrollByAction = new C0233u(this, 4);
        this.scrollByOffsetAction = new g(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean setScrollSemanticsActions$lambda$6(b0 b0Var, float f2, float f3) {
        AbstractC1476z.s(b0Var.getCoroutineScope(), null, null, b0Var.new f(f2, f3, null), 3);
        return true;
    }

    private final void updateDefaultFlingBehavior() {
        if (isAttached()) {
            this.defaultFlingBehavior.updateDensity(AbstractC1009p.requireDensity(this));
        }
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
        if (getEnabled() && (this.scrollByAction == null || this.scrollByOffsetAction == null)) {
            setScrollSemanticsActions();
        }
        h1.e eVar = this.scrollByAction;
        if (eVar != null) {
            androidx.compose.ui.semantics.C.scrollBy$default(e2, null, eVar, 1, null);
        }
        h1.e eVar2 = this.scrollByOffsetAction;
        if (eVar2 != null) {
            androidx.compose.ui.semantics.C.scrollByOffset(e2, eVar2);
        }
    }

    @Override // androidx.compose.foundation.gestures.H
    /* JADX INFO: renamed from: dispatchScrollDeltaInfo-k-4lQ0M */
    public void mo768dispatchScrollDeltaInfok4lQ0M(long j2) {
        if (isAttached()) {
            AbstractC1009p.m4084dispatchOnScrollChangedUv8p0NA(this, j2);
        }
    }

    @Override // androidx.compose.foundation.gestures.r
    public Object drag(h1.e eVar, Y0.c cVar) {
        e0 e0Var = this.scrollingLogic;
        Object objScroll = e0Var.scroll(EnumC0368c0.UserInput, new a(eVar, e0Var, null), cVar);
        return objScroll == Z0.a.f1616b ? objScroll : U0.n.f1521a;
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        updateDefaultFlingBehavior();
        E e2 = this.mouseWheelScrollingLogic;
        if (e2 != null) {
            e2.updateDensity(AbstractC1009p.requireDensity(this));
        }
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public void onDensityChange() {
        onCancelPointerInput();
        updateDefaultFlingBehavior();
        E e2 = this.mouseWheelScrollingLogic;
        if (e2 != null) {
            e2.updateDensity(AbstractC1009p.requireDensity(this));
        }
    }

    @Override // androidx.compose.foundation.gestures.r
    /* JADX INFO: renamed from: onDragStarted-k-4lQ0M, reason: not valid java name */
    public void mo806onDragStartedk4lQ0M(long j2) {
    }

    @Override // androidx.compose.foundation.gestures.r
    /* JADX INFO: renamed from: onDragStopped-TH1AsA0, reason: not valid java name */
    public void mo807onDragStoppedTH1AsA0(long j2) {
        AbstractC1476z.s(this.nestedScrollDispatcher.getCoroutineScope(), null, null, new c(j2, null), 3);
    }

    @Override // P.e
    /* JADX INFO: renamed from: onKeyEvent-ZmokQxo */
    public boolean mo522onKeyEventZmokQxo(KeyEvent keyEvent) {
        long jM42constructorimpl;
        if (getEnabled()) {
            long jM515getKeyZmokQxo = P.d.m515getKeyZmokQxo(keyEvent);
            a.C0003a c0003a = P.a.Companion;
            if ((P.a.m207equalsimpl0(jM515getKeyZmokQxo, c0003a.m395getPageDownEK5gGoQ()) || P.a.m207equalsimpl0(P.d.m515getKeyZmokQxo(keyEvent), c0003a.m396getPageUpEK5gGoQ())) && P.c.m508equalsimpl0(P.d.m516getTypeZmokQxo(keyEvent), P.c.Companion.m512getKeyDownCS__XNY()) && !P.d.m519isCtrlPressedZmokQxo(keyEvent)) {
                if (this.scrollingLogic.isVertical()) {
                    int iM832getViewportSizeYbymL2g$foundation_release = (int) (this.contentInViewNode.m832getViewportSizeYbymL2g$foundation_release() & 4294967295L);
                    jM42constructorimpl = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(0.0f)) << 32) | (((long) Float.floatToRawIntBits(P.a.m207equalsimpl0(P.d.m515getKeyZmokQxo(keyEvent), c0003a.m396getPageUpEK5gGoQ()) ? iM832getViewportSizeYbymL2g$foundation_release : -iM832getViewportSizeYbymL2g$foundation_release)) & 4294967295L));
                } else {
                    int iM832getViewportSizeYbymL2g$foundation_release2 = (int) (this.contentInViewNode.m832getViewportSizeYbymL2g$foundation_release() >> 32);
                    jM42constructorimpl = J.f.m42constructorimpl((((long) Float.floatToRawIntBits(0.0f)) & 4294967295L) | (((long) Float.floatToRawIntBits(P.a.m207equalsimpl0(P.d.m515getKeyZmokQxo(keyEvent), c0003a.m396getPageUpEK5gGoQ()) ? iM832getViewportSizeYbymL2g$foundation_release2 : -iM832getViewportSizeYbymL2g$foundation_release2)) << 32));
                }
                AbstractC1476z.s(getCoroutineScope(), null, null, new d(jM42constructorimpl, null), 3);
                return true;
            }
        }
        return false;
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: onPointerEvent-H0pRuoY */
    public void mo698onPointerEventH0pRuoY(C0918p c0918p, androidx.compose.ui.input.pointer.r rVar, long j2) {
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            if (((Boolean) getCanDrag().invoke(changes.get(i2))).booleanValue()) {
                super.mo698onPointerEventH0pRuoY(c0918p, rVar, j2);
                break;
            }
            i2++;
        }
        if (getEnabled()) {
            if (rVar == androidx.compose.ui.input.pointer.r.Initial && C0921t.m3774equalsimpl0(c0918p.m3767getType7fucELk(), C0921t.Companion.m3783getScroll7fucELk())) {
                ensureMouseWheelScrollNodeInitialized();
            }
            E e2 = this.mouseWheelScrollingLogic;
            if (e2 != null) {
                e2.m759onPointerEventH0pRuoY(c0918p, rVar, j2);
            }
        }
    }

    @Override // P.e
    /* JADX INFO: renamed from: onPreKeyEvent-ZmokQxo */
    public boolean mo523onPreKeyEventZmokQxo(KeyEvent keyEvent) {
        return false;
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    @Override // androidx.compose.foundation.gestures.r
    public boolean startDragImmediately() {
        return this.scrollingLogic.shouldScrollImmediately();
    }

    public final void update(c0 c0Var, I i2, androidx.compose.foundation.i0 i0Var, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e) {
        boolean z4;
        if (getEnabled() != z2) {
            this.nestedScrollConnection.setEnabled(z2);
            this.scrollableContainerNode.update(z2);
            z4 = true;
        } else {
            z4 = false;
        }
        boolean z5 = z4;
        boolean zUpdate = this.scrollingLogic.update(c0Var, i2, i0Var, z3, interfaceC0400y == null ? this.defaultFlingBehavior : interfaceC0400y, this.nestedScrollDispatcher);
        this.contentInViewNode.update(i2, z3, interfaceC0381e);
        this.overscrollEffect = i0Var;
        this.flingBehavior = interfaceC0400y;
        update(Z.getCanDragCalculation(), z2, nVar, this.scrollingLogic.isVertical() ? I.Vertical : I.Horizontal, zUpdate);
        if (z5) {
            clearScrollSemanticsActions();
            T0.invalidateSemantics(this);
        }
    }
}
