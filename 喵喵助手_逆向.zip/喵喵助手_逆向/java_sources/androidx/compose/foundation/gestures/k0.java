package androidx.compose.foundation.gestures;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class k0 {
    public static final int $stable = 8;
    private final I orientation;
    private long totalPositionChange;

    public /* synthetic */ k0(I i2, long j2, AbstractC1378g abstractC1378g) {
        this(i2, j2);
    }

    /* JADX INFO: renamed from: calculatePostSlopOffset-tuRUvjQ, reason: not valid java name */
    private final long m834calculatePostSlopOffsettuRUvjQ(float f2) {
        if (this.orientation == null) {
            long j2 = this.totalPositionChange;
            return J.f.m54minusMKHz9U(this.totalPositionChange, J.f.m57timestuRUvjQ(J.f.m45divtuRUvjQ(j2, J.f.m48getDistanceimpl(j2)), f2));
        }
        float fM837mainAxisk4lQ0M = m837mainAxisk4lQ0M(this.totalPositionChange) - (Math.signum(m837mainAxisk4lQ0M(this.totalPositionChange)) * f2);
        float fM836crossAxisk4lQ0M = m836crossAxisk4lQ0M(this.totalPositionChange);
        if (this.orientation == I.Horizontal) {
            return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(fM837mainAxisk4lQ0M)) << 32) | (((long) Float.floatToRawIntBits(fM836crossAxisk4lQ0M)) & 4294967295L));
        }
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(fM836crossAxisk4lQ0M)) << 32) | (((long) Float.floatToRawIntBits(fM837mainAxisk4lQ0M)) & 4294967295L));
    }

    /* JADX INFO: renamed from: addPointerInputChange-dBAh8RU, reason: not valid java name */
    public final long m835addPointerInputChangedBAh8RU(androidx.compose.ui.input.pointer.C c2, float f2) {
        long jM55plusMKHz9U = J.f.m55plusMKHz9U(this.totalPositionChange, J.f.m54minusMKHz9U(c2.m3659getPositionF1C5BW0(), c2.m3660getPreviousPositionF1C5BW0()));
        this.totalPositionChange = jM55plusMKHz9U;
        return (this.orientation == null ? J.f.m48getDistanceimpl(jM55plusMKHz9U) : Math.abs(m837mainAxisk4lQ0M(jM55plusMKHz9U))) >= f2 ? m834calculatePostSlopOffsettuRUvjQ(f2) : J.f.Companion.m65getUnspecifiedF1C5BW0();
    }

    /* JADX INFO: renamed from: crossAxis-k-4lQ0M, reason: not valid java name */
    public final float m836crossAxisk4lQ0M(long j2) {
        return Float.intBitsToFloat((int) (this.orientation == I.Horizontal ? j2 & 4294967295L : j2 >> 32));
    }

    public final I getOrientation() {
        return this.orientation;
    }

    /* JADX INFO: renamed from: mainAxis-k-4lQ0M, reason: not valid java name */
    public final float m837mainAxisk4lQ0M(long j2) {
        return Float.intBitsToFloat((int) (this.orientation == I.Horizontal ? j2 >> 32 : j2 & 4294967295L));
    }

    public final void reset() {
        this.totalPositionChange = J.f.Companion.m66getZeroF1C5BW0();
    }

    private k0(I i2, long j2) {
        this.orientation = i2;
        this.totalPositionChange = j2;
    }

    public /* synthetic */ k0(I i2, long j2, int i3, AbstractC1378g abstractC1378g) {
        this((i3 & 1) != 0 ? null : i2, (i3 & 2) != 0 ? J.f.Companion.m66getZeroF1C5BW0() : j2, null);
    }
}
