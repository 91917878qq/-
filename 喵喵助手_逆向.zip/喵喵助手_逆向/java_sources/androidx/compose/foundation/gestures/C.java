package androidx.compose.foundation.gestures;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class C {
    public static final int $stable = 0;

    public static final class a extends C {
        public static final int $stable = 0;
        public static final a INSTANCE = new a();

        private a() {
            super(null);
        }
    }

    public static final class b extends C {
        public static final int $stable = 0;
        private final androidx.compose.ui.input.pointer.C finalUpChange;

        public b(androidx.compose.ui.input.pointer.C c2) {
            super(null);
            this.finalUpChange = c2;
        }

        public final androidx.compose.ui.input.pointer.C getFinalUpChange() {
            return this.finalUpChange;
        }
    }

    public static final class c extends C {
        public static final int $stable = 0;
        public static final c INSTANCE = new c();

        private c() {
            super(null);
        }
    }

    public /* synthetic */ C(AbstractC1378g abstractC1378g) {
        this();
    }

    private C() {
    }
}
