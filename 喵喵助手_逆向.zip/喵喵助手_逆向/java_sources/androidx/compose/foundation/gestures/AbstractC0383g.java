package androidx.compose.foundation.gestures;

import android.content.Context;
import androidx.compose.animation.core.D0;
import androidx.compose.runtime.AbstractC0721c1;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0383g {
    private static final AbstractC0721c1 LocalBringIntoViewSpec = androidx.compose.runtime.D.compositionLocalWithComputedDefaultOf(new D0(11));
    private static final InterfaceC0381e PivotBringIntoViewSpec = new C0382f();

    /* JADX INFO: Access modifiers changed from: private */
    public static final InterfaceC0381e LocalBringIntoViewSpec$lambda$0(androidx.compose.runtime.B b2) {
        return !((Context) b2.getCurrentValue(AndroidCompositionLocals_androidKt.getLocalContext())).getPackageManager().hasSystemFeature("android.software.leanback") ? InterfaceC0381e.Companion.getDefaultBringIntoViewSpec$foundation_release() : PivotBringIntoViewSpec;
    }

    public static final AbstractC0721c1 getLocalBringIntoViewSpec() {
        return LocalBringIntoViewSpec;
    }

    public static /* synthetic */ void getLocalBringIntoViewSpec$annotations() {
    }

    public static final InterfaceC0381e getPivotBringIntoViewSpec() {
        return PivotBringIntoViewSpec;
    }

    public static /* synthetic */ void getPivotBringIntoViewSpec$annotations() {
    }
}
