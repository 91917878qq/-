package androidx.compose.foundation.gestures;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public interface J extends InterfaceC1307d {
    Object awaitRelease(Y0.c cVar);

    @Override // e0.InterfaceC1307d
    /* synthetic */ float getDensity();

    @Override // e0.InterfaceC1307d, e0.m
    /* synthetic */ float getFontScale();

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx--R2X_6o, reason: not valid java name */
    /* bridge */ /* synthetic */ default int mo781roundToPxR2X_6o(long j2) {
        return super.mo781roundToPxR2X_6o(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx-0680j_4, reason: not valid java name */
    /* bridge */ /* synthetic */ default int mo782roundToPx0680j_4(float f2) {
        return super.mo782roundToPx0680j_4(f2);
    }

    @Override // e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toDp-GaN1DYA, reason: not valid java name */
    /* bridge */ /* synthetic */ default float mo783toDpGaN1DYA(long j2) {
        return super.mo783toDpGaN1DYA(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM, reason: not valid java name */
    /* bridge */ /* synthetic */ default float mo784toDpu2uoSUM(float f2) {
        return super.mo784toDpu2uoSUM(f2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDpSize-k-rfVVM, reason: not valid java name */
    /* bridge */ /* synthetic */ default long mo786toDpSizekrfVVM(long j2) {
        return super.mo786toDpSizekrfVVM(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx--R2X_6o, reason: not valid java name */
    /* bridge */ /* synthetic */ default float mo787toPxR2X_6o(long j2) {
        return super.mo787toPxR2X_6o(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx-0680j_4, reason: not valid java name */
    /* bridge */ /* synthetic */ default float mo788toPx0680j_4(float f2) {
        return super.mo788toPx0680j_4(f2);
    }

    @Override // e0.InterfaceC1307d
    /* bridge */ /* synthetic */ default J.h toRect(e0.k kVar) {
        return super.toRect(kVar);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSize-XkaWNTQ, reason: not valid java name */
    /* bridge */ /* synthetic */ default long mo789toSizeXkaWNTQ(long j2) {
        return super.mo789toSizeXkaWNTQ(j2);
    }

    @Override // e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toSp-0xMU5do, reason: not valid java name */
    /* bridge */ /* synthetic */ default long mo790toSp0xMU5do(float f2) {
        return super.mo790toSp0xMU5do(f2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4, reason: not valid java name */
    /* bridge */ /* synthetic */ default long mo791toSpkPz2Gy4(float f2) {
        return super.mo791toSpkPz2Gy4(f2);
    }

    Object tryAwaitRelease(Y0.c cVar);

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM, reason: not valid java name */
    /* bridge */ /* synthetic */ default float mo785toDpu2uoSUM(int i2) {
        return super.mo785toDpu2uoSUM(i2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4, reason: not valid java name */
    /* bridge */ /* synthetic */ default long mo792toSpkPz2Gy4(int i2) {
        return super.mo792toSpkPz2Gy4(i2);
    }
}
