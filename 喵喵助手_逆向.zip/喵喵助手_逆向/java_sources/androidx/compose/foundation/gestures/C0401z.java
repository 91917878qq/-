package androidx.compose.foundation.gestures;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0401z extends o.g {
    public static final int $stable = 8;

    public C0401z() {
        super("The fling animation was cancelled");
    }
}
