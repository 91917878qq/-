package androidx.compose.foundation.gestures;

import android.view.ViewConfiguration;
import androidx.compose.ui.node.AbstractC1011q;
import androidx.compose.ui.node.InterfaceC1001l;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0378b {
    public static final M platformScrollConfig(InterfaceC1001l interfaceC1001l) {
        return new C0377a(ViewConfiguration.get(AbstractC1011q.requireView(interfaceC1001l).getContext()));
    }
}
