package androidx.compose.foundation.gestures;

import androidx.compose.foundation.gestures.C0384h;
import java.util.concurrent.CancellationException;
import o.AbstractC1403e;
import r1.InterfaceC1458g;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0379c {
    public static final int $stable = androidx.compose.runtime.collection.c.$stable;
    private final androidx.compose.runtime.collection.c requests = new androidx.compose.runtime.collection.c(new C0384h.a[16], 0);

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n enqueue$lambda$1(C0379c c0379c, C0384h.a aVar, Throwable th) {
        c0379c.requests.remove(aVar);
        return U0.n.f1521a;
    }

    public final void cancelAndRemoveAll(Throwable th) {
        androidx.compose.runtime.collection.c cVar = this.requests;
        int size = cVar.getSize();
        InterfaceC1458g[] interfaceC1458gArr = new InterfaceC1458g[size];
        for (int i2 = 0; i2 < size; i2++) {
            interfaceC1458gArr[i2] = ((C0384h.a) cVar.content[i2]).getContinuation();
        }
        for (int i3 = 0; i3 < size; i3++) {
            interfaceC1458gArr[i3].h(th);
        }
        if (this.requests.getSize() == 0) {
            return;
        }
        AbstractC1403e.throwIllegalStateException("uncancelled requests present");
    }

    public final boolean enqueue(C0384h.a aVar) {
        J.h hVar = (J.h) aVar.getCurrentBounds().invoke();
        if (hVar == null) {
            aVar.getContinuation().resumeWith(U0.n.f1521a);
            return false;
        }
        aVar.getContinuation().n(new M0.m(15, this, aVar));
        m1.e eVarH0 = j1.a.h0(0, this.requests.getSize());
        int i2 = eVarH0.f3189b;
        int i3 = eVarH0.f3190c;
        if (i2 <= i3) {
            while (true) {
                J.h hVar2 = (J.h) ((C0384h.a) this.requests.content[i3]).getCurrentBounds().invoke();
                if (hVar2 != null) {
                    J.h hVarIntersect = hVar.intersect(hVar2);
                    if (kotlin.jvm.internal.o.a(hVarIntersect, hVar)) {
                        this.requests.add(i3 + 1, aVar);
                        return true;
                    }
                    if (!kotlin.jvm.internal.o.a(hVarIntersect, hVar2)) {
                        CancellationException cancellationException = new CancellationException("bringIntoView call interrupted by a newer, non-overlapping call");
                        int size = this.requests.getSize() - 1;
                        if (size <= i3) {
                            while (true) {
                                ((C0384h.a) this.requests.content[i3]).getContinuation().h(cancellationException);
                                if (size == i3) {
                                    break;
                                }
                                size++;
                            }
                        }
                    }
                }
                if (i3 == i2) {
                    break;
                }
                i3--;
            }
        }
        this.requests.add(0, aVar);
        return true;
    }

    public final void forEachFromSmallest(h1.c cVar) {
        androidx.compose.runtime.collection.c cVar2 = this.requests;
        int size = cVar2.getSize() - 1;
        Object[] objArr = cVar2.content;
        if (size < objArr.length) {
            while (size >= 0) {
                cVar.invoke(((C0384h.a) objArr[size]).getCurrentBounds().invoke());
                size--;
            }
        }
    }

    public final int getSize() {
        return this.requests.getSize();
    }

    public final boolean isEmpty() {
        return this.requests.getSize() == 0;
    }

    public final void resumeAndRemoveAll() {
        m1.e eVarH0 = j1.a.h0(0, this.requests.getSize());
        int i2 = eVarH0.f3189b;
        int i3 = eVarH0.f3190c;
        if (i2 <= i3) {
            while (true) {
                ((C0384h.a) this.requests.content[i2]).getContinuation().resumeWith(U0.n.f1521a);
                if (i2 == i3) {
                    break;
                } else {
                    i2++;
                }
            }
        }
        this.requests.clear();
    }

    public final void resumeAndRemoveWhile(h1.c cVar) {
        while (this.requests.getSize() != 0 && ((Boolean) cVar.invoke(((C0384h.a) this.requests.last()).getCurrentBounds().invoke())).booleanValue()) {
            ((C0384h.a) this.requests.removeAt(this.requests.getSize() - 1)).getContinuation().resumeWith(U0.n.f1521a);
        }
    }
}
