package androidx.compose.foundation.gestures;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0389m {
    public static final int $stable = 0;

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.m$a */
    public static final class a extends AbstractC0389m {
        public static final int $stable = 0;
        public static final a INSTANCE = new a();

        private a() {
            super(null);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.m$b */
    public static final class b extends AbstractC0389m {
        public static final int $stable = 0;
        private final long delta;

        public /* synthetic */ b(long j2, AbstractC1378g abstractC1378g) {
            this(j2);
        }

        /* JADX INFO: renamed from: getDelta-F1C5BW0, reason: not valid java name */
        public final long m838getDeltaF1C5BW0() {
            return this.delta;
        }

        private b(long j2) {
            super(null);
            this.delta = j2;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.m$c */
    public static final class c extends AbstractC0389m {
        public static final int $stable = 0;
        private final long startPoint;

        public /* synthetic */ c(long j2, AbstractC1378g abstractC1378g) {
            this(j2);
        }

        /* JADX INFO: renamed from: getStartPoint-F1C5BW0, reason: not valid java name */
        public final long m839getStartPointF1C5BW0() {
            return this.startPoint;
        }

        private c(long j2) {
            super(null);
            this.startPoint = j2;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.m$d */
    public static final class d extends AbstractC0389m {
        public static final int $stable = 0;
        private final long velocity;

        public /* synthetic */ d(long j2, AbstractC1378g abstractC1378g) {
            this(j2);
        }

        /* JADX INFO: renamed from: getVelocity-9UxMQ8M, reason: not valid java name */
        public final long m840getVelocity9UxMQ8M() {
            return this.velocity;
        }

        private d(long j2) {
            super(null);
            this.velocity = j2;
        }
    }

    public /* synthetic */ AbstractC0389m(AbstractC1378g abstractC1378g) {
        this();
    }

    private AbstractC0389m() {
    }
}
