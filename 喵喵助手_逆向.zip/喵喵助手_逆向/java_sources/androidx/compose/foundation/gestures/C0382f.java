package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.InterfaceC0313i;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0382f implements InterfaceC0381e {
    private final float childFraction;
    private final float parentFraction = 0.3f;

    @Override // androidx.compose.foundation.gestures.InterfaceC0381e
    public float calculateScrollDistance(float f2, float f3, float f4) {
        float fAbs = Math.abs((f3 + f2) - f2);
        boolean z2 = fAbs <= f4;
        float f5 = (this.parentFraction * f4) - (this.childFraction * fAbs);
        float f6 = f4 - f5;
        if (z2 && f6 < fAbs) {
            f5 = f4 - fAbs;
        }
        return f2 - f5;
    }

    public final float getChildFraction() {
        return this.childFraction;
    }

    public final float getParentFraction() {
        return this.parentFraction;
    }

    @Override // androidx.compose.foundation.gestures.InterfaceC0381e
    @U0.a
    public /* bridge */ /* synthetic */ InterfaceC0313i getScrollAnimationSpec() {
        return super.getScrollAnimationSpec();
    }
}
