package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0395t extends a1.j implements h1.f {
    int label;

    public C0395t(Y0.c cVar) {
        super(3, cVar);
    }

    @Override // h1.f
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
        return m873invoked4ec7I((InterfaceC1474x) obj, ((J.f) obj2).m60unboximpl(), (Y0.c) obj3);
    }

    /* JADX INFO: renamed from: invoke-d-4ec7I, reason: not valid java name */
    public final Object m873invoked4ec7I(InterfaceC1474x interfaceC1474x, long j2, Y0.c cVar) {
        return new C0395t(cVar).invokeSuspend(U0.n.f1521a);
    }

    @Override // a1.a
    public final Object invokeSuspend(Object obj) {
        Z0.a aVar = Z0.a.f1616b;
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        AbstractC0292a.H(obj);
        return U0.n.f1521a;
    }
}
