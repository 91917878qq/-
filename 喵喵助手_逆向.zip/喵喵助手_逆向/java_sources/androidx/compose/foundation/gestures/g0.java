package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.foundation.gestures.C;
import androidx.compose.ui.input.pointer.AbstractC0919q;
import androidx.compose.ui.input.pointer.AbstractC0922u;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.C0920s;
import androidx.compose.ui.input.pointer.InterfaceC0905c;
import java.util.List;
import r1.AbstractC1476z;
import r1.EnumC1475y;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public abstract class g0 {
    private static final h1.f NoPressGesture = new f0(null);

    public static final class a extends a1.c {
        Object L$0;
        Object L$1;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g0.awaitFirstDown(null, false, null, this);
        }
    }

    public static final class b extends a1.c {
        Object L$0;
        Object L$1;
        boolean Z$0;
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g0.awaitPrimaryFirstDown(null, false, null, this);
        }
    }

    public static final class c extends a1.i implements h1.e {
        final /* synthetic */ androidx.compose.ui.input.pointer.C $firstUp;
        long J$0;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(androidx.compose.ui.input.pointer.C c2, Y0.c cVar) {
            super(cVar);
            this.$firstUp = c2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            c cVar2 = new c(this.$firstUp, cVar);
            cVar2.L$0 = obj;
            return cVar2;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((c) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:11:0x0045 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:14:0x0050 A[RETURN] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0043 -> B:12:0x0046). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r14) {
            /*
                r13 = this;
                Z0.a r0 = Z0.a.f1616b
                int r1 = r13.label
                r2 = 1
                if (r1 == 0) goto L1b
                if (r1 != r2) goto L13
                long r3 = r13.J$0
                java.lang.Object r1 = r13.L$0
                androidx.compose.ui.input.pointer.c r1 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r1
                a.AbstractC0292a.H(r14)
                goto L46
            L13:
                java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r14.<init>(r0)
                throw r14
            L1b:
                a.AbstractC0292a.H(r14)
                java.lang.Object r14 = r13.L$0
                androidx.compose.ui.input.pointer.c r14 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r14
                androidx.compose.ui.input.pointer.C r1 = r13.$firstUp
                long r3 = r1.getUptimeMillis()
                androidx.compose.ui.platform.W1 r1 = r14.getViewConfiguration()
                long r5 = r1.getDoubleTapMinTimeMillis()
                long r5 = r5 + r3
                r1 = r14
                r3 = r5
            L33:
                r13.L$0 = r1
                r13.J$0 = r3
                r13.label = r2
                r8 = 0
                r9 = 0
                r11 = 3
                r12 = 0
                r7 = r1
                r10 = r13
                java.lang.Object r14 = androidx.compose.foundation.gestures.g0.awaitFirstDown$default(r7, r8, r9, r10, r11, r12)
                if (r14 != r0) goto L46
                return r0
            L46:
                androidx.compose.ui.input.pointer.C r14 = (androidx.compose.ui.input.pointer.C) r14
                long r5 = r14.getUptimeMillis()
                int r5 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
                if (r5 < 0) goto L33
                return r14
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.g0.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public static final class d extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g0.consumeUntilUp(null, this);
        }
    }

    public static final class e extends a1.j implements h1.e {
        final /* synthetic */ h1.f $onPress;
        final /* synthetic */ h1.c $onTap;
        final /* synthetic */ K $pressScope;
        final /* synthetic */ androidx.compose.ui.input.pointer.L $this_detectTapAndPress;
        private /* synthetic */ Object L$0;
        int label;

        public static final class a extends a1.i implements h1.e {
            final /* synthetic */ InterfaceC1474x $$this$coroutineScope;
            final /* synthetic */ h1.f $onPress;
            final /* synthetic */ h1.c $onTap;
            final /* synthetic */ K $pressScope;
            private /* synthetic */ Object L$0;
            Object L$1;
            int label;

            /* JADX INFO: renamed from: androidx.compose.foundation.gestures.g0$e$a$a, reason: collision with other inner class name */
            public static final class C0027a extends a1.j implements h1.e {
                final /* synthetic */ androidx.compose.ui.input.pointer.C $down;
                final /* synthetic */ h1.f $onPress;
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0027a(h1.f fVar, K k2, androidx.compose.ui.input.pointer.C c2, Y0.c cVar) {
                    super(2, cVar);
                    this.$onPress = fVar;
                    this.$pressScope = k2;
                    this.$down = c2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new C0027a(this.$onPress, this.$pressScope, this.$down, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        h1.f fVar = this.$onPress;
                        K k2 = this.$pressScope;
                        J.f fVarM39boximpl = J.f.m39boximpl(this.$down.m3659getPositionF1C5BW0());
                        this.label = 1;
                        if (fVar.invoke(k2, fVarM39boximpl, this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((C0027a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class b extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new b(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.cancel();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class c extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public c(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new c(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.release();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class d extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public d(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new d(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        K k2 = this.$pressScope;
                        this.label = 1;
                        if (k2.reset(this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((d) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(InterfaceC1474x interfaceC1474x, h1.f fVar, h1.c cVar, K k2, Y0.c cVar2) {
                super(cVar2);
                this.$$this$coroutineScope = interfaceC1474x;
                this.$onPress = fVar;
                this.$onTap = cVar;
                this.$pressScope = k2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$$this$coroutineScope, this.$onPress, this.$onTap, this.$pressScope, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
                return ((a) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
            }

            /* JADX WARN: Removed duplicated region for block: B:23:0x008a  */
            /* JADX WARN: Removed duplicated region for block: B:24:0x009a  */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final Object invokeSuspend(Object obj) {
                InterfaceC1451b0 interfaceC1451b0S;
                InterfaceC0905c interfaceC0905c;
                InterfaceC1451b0 interfaceC1451b0;
                androidx.compose.ui.input.pointer.C c2;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    InterfaceC0905c interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                    interfaceC1451b0S = AbstractC1476z.s(this.$$this$coroutineScope, null, g0.getCoroutineStartForCurrentDispatchBehavior(), new d(this.$pressScope, null), 1);
                    this.L$0 = interfaceC0905c2;
                    this.L$1 = interfaceC1451b0S;
                    this.label = 1;
                    Object objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c2, false, null, this, 3, null);
                    if (objAwaitFirstDown$default == aVar) {
                        return aVar;
                    }
                    interfaceC0905c = interfaceC0905c2;
                    obj = objAwaitFirstDown$default;
                } else {
                    if (i2 != 1) {
                        if (i2 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        InterfaceC1451b0 interfaceC1451b02 = (InterfaceC1451b0) this.L$0;
                        AbstractC0292a.H(obj);
                        interfaceC1451b0 = interfaceC1451b02;
                        c2 = (androidx.compose.ui.input.pointer.C) obj;
                        if (c2 != null) {
                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0, null, new b(this.$pressScope, null), 2, null);
                        } else {
                            c2.consume();
                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0, null, new c(this.$pressScope, null), 2, null);
                            h1.c cVar = this.$onTap;
                            if (cVar != null) {
                                cVar.invoke(J.f.m39boximpl(c2.m3659getPositionF1C5BW0()));
                            }
                        }
                        return U0.n.f1521a;
                    }
                    interfaceC1451b0S = (InterfaceC1451b0) this.L$1;
                    InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) this.L$0;
                    AbstractC0292a.H(obj);
                    interfaceC0905c = interfaceC0905c3;
                }
                androidx.compose.ui.input.pointer.C c3 = (androidx.compose.ui.input.pointer.C) obj;
                c3.consume();
                if (this.$onPress != g0.NoPressGesture) {
                    g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0S, null, new C0027a(this.$onPress, this.$pressScope, c3, null), 2, null);
                }
                this.L$0 = interfaceC1451b0S;
                this.L$1 = null;
                this.label = 2;
                obj = g0.waitForUpOrCancellation$default(interfaceC0905c, null, this, 1, null);
                if (obj == aVar) {
                    return aVar;
                }
                interfaceC1451b0 = interfaceC1451b0S;
                c2 = (androidx.compose.ui.input.pointer.C) obj;
                if (c2 != null) {
                }
                return U0.n.f1521a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(androidx.compose.ui.input.pointer.L l2, h1.f fVar, h1.c cVar, K k2, Y0.c cVar2) {
            super(2, cVar2);
            this.$this_detectTapAndPress = l2;
            this.$onPress = fVar;
            this.$onTap = cVar;
            this.$pressScope = k2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            e eVar = new e(this.$this_detectTapAndPress, this.$onPress, this.$onTap, this.$pressScope, cVar);
            eVar.L$0 = obj;
            return eVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                androidx.compose.ui.input.pointer.L l2 = this.$this_detectTapAndPress;
                a aVar2 = new a(interfaceC1474x, this.$onPress, this.$onTap, this.$pressScope, null);
                this.label = 1;
                if (A.awaitEachGesture(l2, aVar2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class f extends a1.j implements h1.e {
        final /* synthetic */ h1.c $onDoubleTap;
        final /* synthetic */ h1.c $onLongPress;
        final /* synthetic */ h1.f $onPress;
        final /* synthetic */ h1.c $onTap;
        final /* synthetic */ androidx.compose.ui.input.pointer.L $this_detectTapGestures;
        private /* synthetic */ Object L$0;
        int label;

        public static final class a extends a1.i implements h1.e {
            final /* synthetic */ InterfaceC1474x $$this$coroutineScope;
            final /* synthetic */ h1.c $onDoubleTap;
            final /* synthetic */ h1.c $onLongPress;
            final /* synthetic */ h1.f $onPress;
            final /* synthetic */ h1.c $onTap;
            final /* synthetic */ K $pressScope;
            private /* synthetic */ Object L$0;
            Object L$1;
            Object L$2;
            Object L$3;
            int label;

            /* JADX INFO: renamed from: androidx.compose.foundation.gestures.g0$f$a$a, reason: collision with other inner class name */
            public static final class C0028a extends a1.j implements h1.e {
                final /* synthetic */ androidx.compose.ui.input.pointer.C $down;
                final /* synthetic */ h1.f $onPress;
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0028a(h1.f fVar, K k2, androidx.compose.ui.input.pointer.C c2, Y0.c cVar) {
                    super(2, cVar);
                    this.$onPress = fVar;
                    this.$pressScope = k2;
                    this.$down = c2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new C0028a(this.$onPress, this.$pressScope, this.$down, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        h1.f fVar = this.$onPress;
                        K k2 = this.$pressScope;
                        J.f fVarM39boximpl = J.f.m39boximpl(this.$down.m3659getPositionF1C5BW0());
                        this.label = 1;
                        if (fVar.invoke(k2, fVarM39boximpl, this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((C0028a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class b extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new b(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.release();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class c extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public c(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new c(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.cancel();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class d extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public d(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new d(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.release();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((d) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class e extends a1.j implements h1.e {
                final /* synthetic */ InterfaceC1451b0 $cancelOrReleaseJob;
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public e(InterfaceC1451b0 interfaceC1451b0, K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$cancelOrReleaseJob = interfaceC1451b0;
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new e(this.$cancelOrReleaseJob, this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        InterfaceC1451b0 interfaceC1451b0 = this.$cancelOrReleaseJob;
                        this.label = 1;
                        if (interfaceC1451b0.d(this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            if (i2 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            AbstractC0292a.H(obj);
                            return U0.n.f1521a;
                        }
                        AbstractC0292a.H(obj);
                    }
                    K k2 = this.$pressScope;
                    this.label = 2;
                    if (k2.reset(this) == aVar) {
                        return aVar;
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            /* JADX INFO: renamed from: androidx.compose.foundation.gestures.g0$f$a$f, reason: collision with other inner class name */
            public static final class C0029f extends a1.j implements h1.e {
                final /* synthetic */ h1.f $onPress;
                final /* synthetic */ K $pressScope;
                final /* synthetic */ androidx.compose.ui.input.pointer.C $secondDown;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0029f(h1.f fVar, K k2, androidx.compose.ui.input.pointer.C c2, Y0.c cVar) {
                    super(2, cVar);
                    this.$onPress = fVar;
                    this.$pressScope = k2;
                    this.$secondDown = c2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new C0029f(this.$onPress, this.$pressScope, this.$secondDown, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        h1.f fVar = this.$onPress;
                        K k2 = this.$pressScope;
                        J.f fVarM39boximpl = J.f.m39boximpl(this.$secondDown.m3659getPositionF1C5BW0());
                        this.label = 1;
                        if (fVar.invoke(k2, fVarM39boximpl, this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((C0029f) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class g extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public g(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new g(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.release();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((g) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class h extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public h(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new h(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.cancel();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((h) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class i extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public i(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new i(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        K k2 = this.$pressScope;
                        this.label = 1;
                        if (k2.reset(this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((i) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            public static final class j extends a1.j implements h1.e {
                final /* synthetic */ K $pressScope;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public j(K k2, Y0.c cVar) {
                    super(2, cVar);
                    this.$pressScope = k2;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new j(this.$pressScope, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    this.$pressScope.release();
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((j) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(InterfaceC1474x interfaceC1474x, h1.f fVar, h1.c cVar, h1.c cVar2, h1.c cVar3, K k2, Y0.c cVar4) {
                super(cVar4);
                this.$$this$coroutineScope = interfaceC1474x;
                this.$onPress = fVar;
                this.$onLongPress = cVar;
                this.$onDoubleTap = cVar2;
                this.$onTap = cVar3;
                this.$pressScope = k2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$$this$coroutineScope, this.$onPress, this.$onLongPress, this.$onDoubleTap, this.$onTap, this.$pressScope, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
                return ((a) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
            }

            /* JADX WARN: Removed duplicated region for block: B:21:0x00c9  */
            /* JADX WARN: Removed duplicated region for block: B:24:0x00e0  */
            /* JADX WARN: Removed duplicated region for block: B:29:0x00f2  */
            /* JADX WARN: Removed duplicated region for block: B:34:0x010c  */
            /* JADX WARN: Removed duplicated region for block: B:39:0x0139  */
            /* JADX WARN: Removed duplicated region for block: B:46:0x014c  */
            /* JADX WARN: Removed duplicated region for block: B:47:0x015e  */
            /* JADX WARN: Removed duplicated region for block: B:49:0x0174  */
            /* JADX WARN: Removed duplicated region for block: B:59:0x019d  */
            /* JADX WARN: Removed duplicated region for block: B:62:0x01ae  */
            /* JADX WARN: Removed duplicated region for block: B:78:0x021d  */
            /* JADX WARN: Removed duplicated region for block: B:84:0x024e  */
            /* JADX WARN: Removed duplicated region for block: B:91:0x0265  */
            /* JADX WARN: Removed duplicated region for block: B:92:0x0285  */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final Object invokeSuspend(Object obj) {
                Object objAwaitFirstDown$default;
                InterfaceC0905c interfaceC0905c;
                androidx.compose.ui.input.pointer.C c2;
                InterfaceC1451b0 interfaceC1451b0S;
                Object objWaitForLongPress$default;
                Object objWaitForUpOrCancellation$default;
                androidx.compose.ui.input.pointer.C finalUpChange;
                InterfaceC1451b0 interfaceC1451b0LaunchAwaitingReset$default;
                Object objAwaitSecondDown;
                C c3;
                androidx.compose.ui.input.pointer.C c4;
                Object objWaitForLongPress$default2;
                InterfaceC1451b0 interfaceC1451b0;
                androidx.compose.ui.input.pointer.C c5;
                InterfaceC0905c interfaceC0905c2;
                Object objWaitForUpOrCancellation$default2;
                InterfaceC1451b0 interfaceC1451b02;
                androidx.compose.ui.input.pointer.C c6;
                androidx.compose.ui.input.pointer.C finalUpChange2;
                InterfaceC1451b0 interfaceC1451b03;
                C c7;
                InterfaceC1451b0 interfaceC1451b04;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                U0.n nVar = U0.n.f1521a;
                switch (i2) {
                    case 0:
                        AbstractC0292a.H(obj);
                        InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) this.L$0;
                        this.L$0 = interfaceC0905c3;
                        this.label = 1;
                        objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c3, false, null, this, 3, null);
                        if (objAwaitFirstDown$default == aVar) {
                            return aVar;
                        }
                        interfaceC0905c = interfaceC0905c3;
                        c2 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown$default;
                        c2.consume();
                        interfaceC1451b0S = AbstractC1476z.s(this.$$this$coroutineScope, null, g0.getCoroutineStartForCurrentDispatchBehavior(), new i(this.$pressScope, null), 1);
                        if (this.$onPress != g0.NoPressGesture) {
                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0S, null, new C0028a(this.$onPress, this.$pressScope, c2, null), 2, null);
                        }
                        if (this.$onLongPress == null) {
                            this.L$0 = interfaceC0905c;
                            this.L$1 = c2;
                            this.L$2 = interfaceC1451b0S;
                            this.label = 3;
                            objWaitForLongPress$default = g0.waitForLongPress$default(interfaceC0905c, null, this, 1, null);
                            if (objWaitForLongPress$default == aVar) {
                                return aVar;
                            }
                            c3 = (C) objWaitForLongPress$default;
                            if (kotlin.jvm.internal.o.a(c3, C.c.INSTANCE)) {
                                if (c3 instanceof C.b) {
                                    finalUpChange = ((C.b) c3).getFinalUpChange();
                                } else {
                                    if (!(c3 instanceof C.a)) {
                                        throw new H0.c();
                                    }
                                    finalUpChange = null;
                                }
                                InterfaceC1451b0 interfaceC1451b05 = interfaceC1451b0S;
                                if (finalUpChange == null) {
                                }
                                if (finalUpChange != null) {
                                }
                                return nVar;
                            }
                            this.$onLongPress.invoke(J.f.m39boximpl(c2.m3659getPositionF1C5BW0()));
                            this.L$0 = interfaceC1451b0S;
                            this.L$1 = null;
                            this.L$2 = null;
                            this.label = 4;
                            if (g0.consumeUntilUp(interfaceC0905c, this) == aVar) {
                                return aVar;
                            }
                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0S, null, new b(this.$pressScope, null), 2, null);
                            return nVar;
                        }
                        this.L$0 = interfaceC0905c;
                        this.L$1 = interfaceC1451b0S;
                        this.label = 2;
                        objWaitForUpOrCancellation$default = g0.waitForUpOrCancellation$default(interfaceC0905c, null, this, 1, null);
                        if (objWaitForUpOrCancellation$default == aVar) {
                            return aVar;
                        }
                        finalUpChange = (androidx.compose.ui.input.pointer.C) objWaitForUpOrCancellation$default;
                        InterfaceC1451b0 interfaceC1451b052 = interfaceC1451b0S;
                        if (finalUpChange == null) {
                            interfaceC1451b0LaunchAwaitingReset$default = g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b052, null, new c(this.$pressScope, null), 2, null);
                        } else {
                            finalUpChange.consume();
                            interfaceC1451b0LaunchAwaitingReset$default = g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b052, null, new d(this.$pressScope, null), 2, null);
                        }
                        if (finalUpChange != null) {
                            if (this.$onDoubleTap == null) {
                                h1.c cVar = this.$onTap;
                                if (cVar != null) {
                                    cVar.invoke(J.f.m39boximpl(finalUpChange.m3659getPositionF1C5BW0()));
                                }
                            } else {
                                this.L$0 = interfaceC0905c;
                                this.L$1 = finalUpChange;
                                this.L$2 = interfaceC1451b0LaunchAwaitingReset$default;
                                this.label = 5;
                                objAwaitSecondDown = g0.awaitSecondDown(interfaceC0905c, finalUpChange, this);
                                if (objAwaitSecondDown == aVar) {
                                    return aVar;
                                }
                                c4 = (androidx.compose.ui.input.pointer.C) objAwaitSecondDown;
                                if (c4 != null) {
                                    h1.c cVar2 = this.$onTap;
                                    if (cVar2 != null) {
                                        cVar2.invoke(J.f.m39boximpl(finalUpChange.m3659getPositionF1C5BW0()));
                                    }
                                } else {
                                    r1.C cS = AbstractC1476z.s(this.$$this$coroutineScope, null, g0.getCoroutineStartForCurrentDispatchBehavior(), new e(interfaceC1451b0LaunchAwaitingReset$default, this.$pressScope, null), 1);
                                    if (this.$onPress != g0.NoPressGesture) {
                                        g0.launchAwaitingReset$default(this.$$this$coroutineScope, cS, null, new C0029f(this.$onPress, this.$pressScope, c4, null), 2, null);
                                    }
                                    if (this.$onLongPress == null) {
                                        this.L$0 = cS;
                                        this.L$1 = finalUpChange;
                                        this.L$2 = null;
                                        this.label = 6;
                                        objWaitForUpOrCancellation$default2 = g0.waitForUpOrCancellation$default(interfaceC0905c, null, this, 1, null);
                                        if (objWaitForUpOrCancellation$default2 == aVar) {
                                            return aVar;
                                        }
                                        androidx.compose.ui.input.pointer.C c8 = finalUpChange;
                                        interfaceC1451b02 = cS;
                                        c6 = c8;
                                        finalUpChange2 = (androidx.compose.ui.input.pointer.C) objWaitForUpOrCancellation$default2;
                                        interfaceC1451b03 = interfaceC1451b02;
                                        if (finalUpChange2 != null) {
                                            finalUpChange2.consume();
                                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b03, null, new g(this.$pressScope, null), 2, null);
                                            this.$onDoubleTap.invoke(J.f.m39boximpl(finalUpChange2.m3659getPositionF1C5BW0()));
                                        } else {
                                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b03, null, new h(this.$pressScope, null), 2, null);
                                            h1.c cVar3 = this.$onTap;
                                            if (cVar3 != null) {
                                                cVar3.invoke(J.f.m39boximpl(c6.m3659getPositionF1C5BW0()));
                                            }
                                        }
                                    } else {
                                        this.L$0 = interfaceC0905c;
                                        this.L$1 = cS;
                                        this.L$2 = finalUpChange;
                                        this.L$3 = c4;
                                        this.label = 7;
                                        objWaitForLongPress$default2 = g0.waitForLongPress$default(interfaceC0905c, null, this, 1, null);
                                        if (objWaitForLongPress$default2 == aVar) {
                                            return aVar;
                                        }
                                        InterfaceC0905c interfaceC0905c4 = interfaceC0905c;
                                        interfaceC1451b0 = cS;
                                        c5 = c4;
                                        interfaceC0905c2 = interfaceC0905c4;
                                        c7 = (C) objWaitForLongPress$default2;
                                        if (!kotlin.jvm.internal.o.a(c7, C.c.INSTANCE)) {
                                            this.$onLongPress.invoke(J.f.m39boximpl(c5.m3659getPositionF1C5BW0()));
                                            this.L$0 = interfaceC1451b0;
                                            this.L$1 = null;
                                            this.L$2 = null;
                                            this.L$3 = null;
                                            this.label = 8;
                                            if (g0.consumeUntilUp(interfaceC0905c2, this) == aVar) {
                                                return aVar;
                                            }
                                            interfaceC1451b04 = interfaceC1451b0;
                                            g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b04, null, new j(this.$pressScope, null), 2, null);
                                            return nVar;
                                        }
                                        if (c7 instanceof C.b) {
                                            interfaceC1451b03 = interfaceC1451b0;
                                            finalUpChange2 = ((C.b) c7).getFinalUpChange();
                                            c6 = finalUpChange;
                                        } else {
                                            if (!(c7 instanceof C.a)) {
                                                throw new H0.c();
                                            }
                                            c6 = finalUpChange;
                                            interfaceC1451b03 = interfaceC1451b0;
                                            finalUpChange2 = null;
                                        }
                                        if (finalUpChange2 != null) {
                                        }
                                    }
                                }
                            }
                        }
                        return nVar;
                    case 1:
                        InterfaceC0905c interfaceC0905c5 = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        interfaceC0905c = interfaceC0905c5;
                        objAwaitFirstDown$default = obj;
                        c2 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown$default;
                        c2.consume();
                        interfaceC1451b0S = AbstractC1476z.s(this.$$this$coroutineScope, null, g0.getCoroutineStartForCurrentDispatchBehavior(), new i(this.$pressScope, null), 1);
                        if (this.$onPress != g0.NoPressGesture) {
                        }
                        if (this.$onLongPress == null) {
                        }
                        break;
                    case 2:
                        interfaceC1451b0S = (InterfaceC1451b0) this.L$1;
                        InterfaceC0905c interfaceC0905c6 = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        interfaceC0905c = interfaceC0905c6;
                        objWaitForUpOrCancellation$default = obj;
                        finalUpChange = (androidx.compose.ui.input.pointer.C) objWaitForUpOrCancellation$default;
                        InterfaceC1451b0 interfaceC1451b0522 = interfaceC1451b0S;
                        if (finalUpChange == null) {
                        }
                        if (finalUpChange != null) {
                        }
                        return nVar;
                    case 3:
                        interfaceC1451b0S = (InterfaceC1451b0) this.L$2;
                        c2 = (androidx.compose.ui.input.pointer.C) this.L$1;
                        interfaceC0905c = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        objWaitForLongPress$default = obj;
                        c3 = (C) objWaitForLongPress$default;
                        if (kotlin.jvm.internal.o.a(c3, C.c.INSTANCE)) {
                        }
                        break;
                    case 4:
                        interfaceC1451b0S = (InterfaceC1451b0) this.L$0;
                        AbstractC0292a.H(obj);
                        g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b0S, null, new b(this.$pressScope, null), 2, null);
                        return nVar;
                    case 5:
                        interfaceC1451b0LaunchAwaitingReset$default = (InterfaceC1451b0) this.L$2;
                        finalUpChange = (androidx.compose.ui.input.pointer.C) this.L$1;
                        interfaceC0905c = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        objAwaitSecondDown = obj;
                        c4 = (androidx.compose.ui.input.pointer.C) objAwaitSecondDown;
                        if (c4 != null) {
                        }
                        break;
                    case 6:
                        c6 = (androidx.compose.ui.input.pointer.C) this.L$1;
                        interfaceC1451b02 = (InterfaceC1451b0) this.L$0;
                        AbstractC0292a.H(obj);
                        objWaitForUpOrCancellation$default2 = obj;
                        finalUpChange2 = (androidx.compose.ui.input.pointer.C) objWaitForUpOrCancellation$default2;
                        interfaceC1451b03 = interfaceC1451b02;
                        if (finalUpChange2 != null) {
                        }
                        return nVar;
                    case 7:
                        c5 = (androidx.compose.ui.input.pointer.C) this.L$3;
                        finalUpChange = (androidx.compose.ui.input.pointer.C) this.L$2;
                        interfaceC1451b0 = (InterfaceC1451b0) this.L$1;
                        interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        objWaitForLongPress$default2 = obj;
                        c7 = (C) objWaitForLongPress$default2;
                        if (!kotlin.jvm.internal.o.a(c7, C.c.INSTANCE)) {
                        }
                        break;
                    case 8:
                        InterfaceC1451b0 interfaceC1451b06 = (InterfaceC1451b0) this.L$0;
                        AbstractC0292a.H(obj);
                        interfaceC1451b04 = interfaceC1451b06;
                        g0.launchAwaitingReset$default(this.$$this$coroutineScope, interfaceC1451b04, null, new j(this.$pressScope, null), 2, null);
                        return nVar;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(androidx.compose.ui.input.pointer.L l2, h1.f fVar, h1.c cVar, h1.c cVar2, h1.c cVar3, Y0.c cVar4) {
            super(2, cVar4);
            this.$this_detectTapGestures = l2;
            this.$onPress = fVar;
            this.$onLongPress = cVar;
            this.$onDoubleTap = cVar2;
            this.$onTap = cVar3;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            f fVar = new f(this.$this_detectTapGestures, this.$onPress, this.$onLongPress, this.$onDoubleTap, this.$onTap, cVar);
            fVar.L$0 = obj;
            return fVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                K k2 = new K(this.$this_detectTapGestures);
                androidx.compose.ui.input.pointer.L l2 = this.$this_detectTapGestures;
                a aVar2 = new a(interfaceC1474x, this.$onPress, this.$onLongPress, this.$onDoubleTap, this.$onTap, k2, null);
                this.label = 1;
                if (A.awaitEachGesture(l2, aVar2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((f) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class g extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ InterfaceC1451b0 $resetJob;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(InterfaceC1451b0 interfaceC1451b0, h1.e eVar, Y0.c cVar) {
            super(2, cVar);
            this.$resetJob = interfaceC1451b0;
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            g gVar = new g(this.$resetJob, this.$block, cVar);
            gVar.L$0 = obj;
            return gVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            InterfaceC1474x interfaceC1474x;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                interfaceC1474x = (InterfaceC1474x) this.L$0;
                if (androidx.compose.foundation.A.isDetectTapGesturesImmediateCoroutineDispatchEnabled) {
                    InterfaceC1451b0 interfaceC1451b0 = this.$resetJob;
                    this.L$0 = interfaceC1474x;
                    this.label = 1;
                    if (interfaceC1451b0.d(this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                    return U0.n.f1521a;
                }
                interfaceC1474x = (InterfaceC1474x) this.L$0;
                AbstractC0292a.H(obj);
            }
            h1.e eVar = this.$block;
            this.L$0 = null;
            this.label = 2;
            if (eVar.invoke(interfaceC1474x, this) == aVar) {
                return aVar;
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((g) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class h extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public h(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g0.waitForLongPress(null, null, this);
        }
    }

    public static final class i extends a1.i implements h1.e {
        final /* synthetic */ androidx.compose.ui.input.pointer.r $pass;
        final /* synthetic */ kotlin.jvm.internal.E $result;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(androidx.compose.ui.input.pointer.r rVar, kotlin.jvm.internal.E e2, Y0.c cVar) {
            super(cVar);
            this.$pass = rVar;
            this.$result = e2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            i iVar = new i(this.$pass, this.$result, cVar);
            iVar.L$0 = obj;
            return iVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((i) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:20:0x005a, code lost:
        
            if (androidx.compose.foundation.gestures.h0.isDeepPress(r14) == false) goto L22;
         */
        /* JADX WARN: Code restructure failed: missing block: B:21:0x005c, code lost:
        
            r13.$result.f3118b = androidx.compose.foundation.gestures.C.c.INSTANCE;
         */
        /* JADX WARN: Code restructure failed: missing block: B:22:0x0064, code lost:
        
            r14 = r14.getChanges();
            r5 = r14.size();
            r6 = 0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:23:0x006d, code lost:
        
            if (r6 >= r5) goto L49;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x006f, code lost:
        
            r7 = r14.get(r6);
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x0079, code lost:
        
            if (r7.isConsumed() != false) goto L50;
         */
        /* JADX WARN: Code restructure failed: missing block: B:27:0x0087, code lost:
        
            if (androidx.compose.ui.input.pointer.AbstractC0919q.m3770isOutOfBoundsjwHxaWs(r7, r1.mo3734getSizeYbymL2g(), r1.mo3733getExtendedTouchPaddingNHjbRc()) == false) goto L29;
         */
        /* JADX WARN: Code restructure failed: missing block: B:29:0x008a, code lost:
        
            r6 = r6 + 1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:30:0x008d, code lost:
        
            r13.$result.f3118b = androidx.compose.foundation.gestures.C.a.INSTANCE;
         */
        /* JADX WARN: Code restructure failed: missing block: B:31:0x0094, code lost:
        
            r14 = androidx.compose.ui.input.pointer.r.Final;
            r13.L$0 = r1;
            r13.label = 2;
            r14 = r1.awaitPointerEvent(r14, r13);
         */
        /* JADX WARN: Code restructure failed: missing block: B:32:0x009e, code lost:
        
            if (r14 != r0) goto L34;
         */
        /* JADX WARN: Code restructure failed: missing block: B:33:0x00a0, code lost:
        
            return r0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:38:0x00ba, code lost:
        
            r13.$result.f3118b = androidx.compose.foundation.gestures.C.a.INSTANCE;
         */
        /* JADX WARN: Code restructure failed: missing block: B:44:0x00e0, code lost:
        
            return U0.n.f1521a;
         */
        /* JADX WARN: Removed duplicated region for block: B:13:0x0039 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:14:0x003a  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x004a  */
        /* JADX WARN: Removed duplicated region for block: B:47:0x00cb A[SYNTHETIC] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x009e -> B:34:0x00a1). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            InterfaceC0905c interfaceC0905c2;
            int size;
            int i2;
            Object objAwaitPointerEvent;
            Z0.a aVar = Z0.a.f1616b;
            int i3 = this.label;
            if (i3 == 0) {
                AbstractC0292a.H(obj);
                interfaceC0905c = (InterfaceC0905c) this.L$0;
                androidx.compose.ui.input.pointer.r rVar = this.$pass;
                this.L$0 = interfaceC0905c;
                this.label = 1;
                objAwaitPointerEvent = interfaceC0905c.awaitPointerEvent(rVar, this);
                if (objAwaitPointerEvent != aVar) {
                }
            } else if (i3 == 1) {
                interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i2 = 0;
                while (true) {
                    if (i2 >= size) {
                    }
                    i2++;
                }
            } else {
                if (i3 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
                List<androidx.compose.ui.input.pointer.C> changes2 = ((C0918p) obj).getChanges();
                int size2 = changes2.size();
                for (int i4 = 0; i4 < size2; i4++) {
                    if (changes2.get(i4).isConsumed()) {
                        break;
                    }
                }
                interfaceC0905c = interfaceC0905c2;
                androidx.compose.ui.input.pointer.r rVar2 = this.$pass;
                this.L$0 = interfaceC0905c;
                this.label = 1;
                objAwaitPointerEvent = interfaceC0905c.awaitPointerEvent(rVar2, this);
                if (objAwaitPointerEvent != aVar) {
                    return aVar;
                }
                interfaceC0905c2 = interfaceC0905c;
                obj = objAwaitPointerEvent;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                size = changes3.size();
                i2 = 0;
                while (true) {
                    if (i2 >= size) {
                        this.$result.f3118b = new C.b(c0918p2.getChanges().get(0));
                        break;
                    }
                    if (!AbstractC0919q.changedToUp(changes3.get(i2))) {
                        break;
                    }
                    i2++;
                }
            }
        }
    }

    public static final class j extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public j(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return g0.waitForUpOrCancellation(null, null, this);
        }
    }

    @U0.a
    public static final /* synthetic */ Object awaitFirstDown(InterfaceC0905c interfaceC0905c, boolean z2, Y0.c cVar) {
        return awaitFirstDown(interfaceC0905c, z2, androidx.compose.ui.input.pointer.r.Main, cVar);
    }

    public static /* synthetic */ Object awaitFirstDown$default(InterfaceC0905c interfaceC0905c, boolean z2, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        return awaitFirstDown(interfaceC0905c, z2, cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x004e A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x004c -> B:18:0x004f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final java.lang.Object awaitPrimaryFirstDown(androidx.compose.ui.input.pointer.InterfaceC0905c r5, boolean r6, androidx.compose.ui.input.pointer.r r7, Y0.c r8) {
        /*
            boolean r0 = r8 instanceof androidx.compose.foundation.gestures.g0.b
            if (r0 == 0) goto L13
            r0 = r8
            androidx.compose.foundation.gestures.g0$b r0 = (androidx.compose.foundation.gestures.g0.b) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.g0$b r0 = new androidx.compose.foundation.gestures.g0$b
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L3d
            if (r2 != r3) goto L35
            boolean r5 = r0.Z$0
            java.lang.Object r6 = r0.L$1
            androidx.compose.ui.input.pointer.r r6 = (androidx.compose.ui.input.pointer.r) r6
            java.lang.Object r7 = r0.L$0
            androidx.compose.ui.input.pointer.c r7 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r7
            a.AbstractC0292a.H(r8)
            r4 = r6
            r6 = r5
            r5 = r7
            r7 = r4
            goto L4f
        L35:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L3d:
            a.AbstractC0292a.H(r8)
        L40:
            r0.L$0 = r5
            r0.L$1 = r7
            r0.Z$0 = r6
            r0.label = r3
            java.lang.Object r8 = r5.awaitPointerEvent(r7, r0)
            if (r8 != r1) goto L4f
            return r1
        L4f:
            androidx.compose.ui.input.pointer.p r8 = (androidx.compose.ui.input.pointer.C0918p) r8
            boolean r2 = isChangedToDown(r8, r6, r3)
            if (r2 == 0) goto L40
            java.util.List r5 = r8.getChanges()
            r6 = 0
            java.lang.Object r5 = r5.get(r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.g0.awaitPrimaryFirstDown(androidx.compose.ui.input.pointer.c, boolean, androidx.compose.ui.input.pointer.r, Y0.c):java.lang.Object");
    }

    public static /* synthetic */ Object awaitPrimaryFirstDown$default(InterfaceC0905c interfaceC0905c, boolean z2, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        if ((i2 & 2) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Main;
        }
        return awaitPrimaryFirstDown(interfaceC0905c, z2, rVar, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object awaitSecondDown(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.C c2, Y0.c cVar) {
        return interfaceC0905c.withTimeoutOrNull(interfaceC0905c.getViewConfiguration().getDoubleTapTimeoutMillis(), new c(c2, null), cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0041 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0050 A[LOOP:0: B:19:0x004e->B:20:0x0050, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x003f -> B:18:0x0042). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object consumeUntilUp(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
        d dVar;
        int size;
        int i2;
        int i3;
        int size2;
        if (cVar instanceof d) {
            dVar = (d) cVar;
            int i4 = dVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                dVar.label = i4 - Integer.MIN_VALUE;
            } else {
                dVar = new d(cVar);
            }
        }
        Object objAwaitPointerEvent$default = dVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = dVar.label;
        if (i5 == 0) {
            AbstractC0292a.H(objAwaitPointerEvent$default);
            dVar.L$0 = interfaceC0905c;
            dVar.label = 1;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, dVar, 1, null);
            if (objAwaitPointerEvent$default == aVar) {
            }
            C0918p c0918p = (C0918p) objAwaitPointerEvent$default;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            size = changes.size();
            i2 = 0;
            while (i3 < size) {
            }
            List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
            size2 = changes2.size();
            while (i2 < size2) {
            }
            return U0.n.f1521a;
        }
        if (i5 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        interfaceC0905c = (InterfaceC0905c) dVar.L$0;
        AbstractC0292a.H(objAwaitPointerEvent$default);
        C0918p c0918p2 = (C0918p) objAwaitPointerEvent$default;
        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
        size = changes3.size();
        i2 = 0;
        for (i3 = 0; i3 < size; i3++) {
            changes3.get(i3).consume();
        }
        List<androidx.compose.ui.input.pointer.C> changes22 = c0918p2.getChanges();
        size2 = changes22.size();
        while (i2 < size2) {
            if (changes22.get(i2).getPressed()) {
                dVar.L$0 = interfaceC0905c;
                dVar.label = 1;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, dVar, 1, null);
                if (objAwaitPointerEvent$default == aVar) {
                    return aVar;
                }
                C0918p c0918p22 = (C0918p) objAwaitPointerEvent$default;
                List<androidx.compose.ui.input.pointer.C> changes32 = c0918p22.getChanges();
                size = changes32.size();
                i2 = 0;
                while (i3 < size) {
                }
                List<androidx.compose.ui.input.pointer.C> changes222 = c0918p22.getChanges();
                size2 = changes222.size();
                while (i2 < size2) {
                }
            } else {
                i2++;
            }
        }
        return U0.n.f1521a;
    }

    public static final Object detectTapAndPress(androidx.compose.ui.input.pointer.L l2, h1.f fVar, h1.c cVar, Y0.c cVar2) {
        Object objE = AbstractC1476z.e(new e(l2, fVar, cVar, new K(l2), null), cVar2);
        return objE == Z0.a.f1616b ? objE : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectTapAndPress$default(androidx.compose.ui.input.pointer.L l2, h1.f fVar, h1.c cVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            fVar = NoPressGesture;
        }
        if ((i2 & 2) != 0) {
            cVar = null;
        }
        return detectTapAndPress(l2, fVar, cVar, cVar2);
    }

    public static final Object detectTapGestures(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.c cVar2, h1.f fVar, h1.c cVar3, Y0.c cVar4) {
        Object objE = AbstractC1476z.e(new f(l2, fVar, cVar2, cVar, cVar3, null), cVar4);
        return objE == Z0.a.f1616b ? objE : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectTapGestures$default(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.c cVar2, h1.f fVar, h1.c cVar3, Y0.c cVar4, int i2, Object obj) {
        h1.c cVar5 = (i2 & 1) != 0 ? null : cVar;
        h1.c cVar6 = (i2 & 2) != 0 ? null : cVar2;
        if ((i2 & 4) != 0) {
            fVar = NoPressGesture;
        }
        return detectTapGestures(l2, cVar5, cVar6, fVar, (i2 & 8) != 0 ? null : cVar3, cVar4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final EnumC1475y getCoroutineStartForCurrentDispatchBehavior() {
        return androidx.compose.foundation.A.isDetectTapGesturesImmediateCoroutineDispatchEnabled ? EnumC1475y.f3408e : EnumC1475y.f3405b;
    }

    private static /* synthetic */ void getCoroutineStartForCurrentDispatchBehavior$annotations() {
    }

    public static final boolean getDetectTapGesturesEnableNewDispatchingBehavior() {
        return androidx.compose.foundation.A.isDetectTapGesturesImmediateCoroutineDispatchEnabled;
    }

    @U0.a
    public static /* synthetic */ void getDetectTapGesturesEnableNewDispatchingBehavior$annotations() {
    }

    public static final boolean isChangedToDown(C0918p c0918p, boolean z2, boolean z3) {
        if (z3) {
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i2 = 0;
            while (true) {
                if (i2 < size) {
                    if (!androidx.compose.ui.input.pointer.Q.m3711equalsimpl0(changes.get(i2).m3662getTypeT8wyACA(), androidx.compose.ui.input.pointer.Q.Companion.m3716getMouseT8wyACA())) {
                        break;
                    }
                    i2++;
                } else if (!AbstractC0922u.m3798isPrimaryPressedaHzCxE(c0918p.m3765getButtonsry648PA())) {
                    return false;
                }
            }
        }
        List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
        int size2 = changes2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            androidx.compose.ui.input.pointer.C c2 = changes2.get(i3);
            if (!(z2 ? AbstractC0919q.changedToDown(c2) : AbstractC0919q.changedToDownIgnoreConsumed(c2))) {
                return false;
            }
        }
        return true;
    }

    public static /* synthetic */ boolean isChangedToDown$default(C0918p c0918p, boolean z2, boolean z3, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z3 = h0.firstDownRefersToPrimaryMouseButtonOnly();
        }
        return isChangedToDown(c0918p, z2, z3);
    }

    private static final InterfaceC1451b0 launchAwaitingReset(InterfaceC1474x interfaceC1474x, InterfaceC1451b0 interfaceC1451b0, EnumC1475y enumC1475y, h1.e eVar) {
        return AbstractC1476z.s(interfaceC1474x, null, enumC1475y, new g(interfaceC1451b0, eVar, null), 1);
    }

    public static /* synthetic */ InterfaceC1451b0 launchAwaitingReset$default(InterfaceC1474x interfaceC1474x, InterfaceC1451b0 interfaceC1451b0, EnumC1475y enumC1475y, h1.e eVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            enumC1475y = getCoroutineStartForCurrentDispatchBehavior();
        }
        return launchAwaitingReset(interfaceC1474x, interfaceC1451b0, enumC1475y, eVar);
    }

    public static final void setDetectTapGesturesEnableNewDispatchingBehavior(boolean z2) {
        androidx.compose.foundation.A.isDetectTapGesturesImmediateCoroutineDispatchEnabled = z2;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object waitForLongPress(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar) {
        h hVar;
        kotlin.jvm.internal.E e2;
        if (cVar instanceof h) {
            hVar = (h) cVar;
            int i2 = hVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                hVar.label = i2 - Integer.MIN_VALUE;
            } else {
                hVar = new h(cVar);
            }
        }
        Object obj = hVar.result;
        Object obj2 = Z0.a.f1616b;
        int i3 = hVar.label;
        try {
            if (i3 == 0) {
                AbstractC0292a.H(obj);
                kotlin.jvm.internal.E e3 = new kotlin.jvm.internal.E();
                e3.f3118b = C.a.INSTANCE;
                long longPressTimeoutMillis = interfaceC0905c.getViewConfiguration().getLongPressTimeoutMillis();
                h1.e iVar = new i(rVar, e3, null);
                hVar.L$0 = e3;
                hVar.label = 1;
                if (interfaceC0905c.withTimeout(longPressTimeoutMillis, iVar, hVar) == obj2) {
                    return obj2;
                }
                e2 = e3;
            } else {
                if (i3 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                e2 = (kotlin.jvm.internal.E) hVar.L$0;
                AbstractC0292a.H(obj);
            }
            return e2.f3118b;
        } catch (C0920s unused) {
            return C.c.INSTANCE;
        }
    }

    public static /* synthetic */ Object waitForLongPress$default(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Main;
        }
        return waitForLongPress(interfaceC0905c, rVar, cVar);
    }

    public static /* synthetic */ Object waitForUpOrCancellation$default(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Main;
        }
        return waitForUpOrCancellation(interfaceC0905c, rVar, cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x004e A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x004c -> B:18:0x004f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final java.lang.Object awaitFirstDown(androidx.compose.ui.input.pointer.InterfaceC0905c r7, boolean r8, androidx.compose.ui.input.pointer.r r9, Y0.c r10) {
        /*
            boolean r0 = r10 instanceof androidx.compose.foundation.gestures.g0.a
            if (r0 == 0) goto L13
            r0 = r10
            androidx.compose.foundation.gestures.g0$a r0 = (androidx.compose.foundation.gestures.g0.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.g0$a r0 = new androidx.compose.foundation.gestures.g0$a
            r0.<init>(r10)
        L18:
            java.lang.Object r10 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L3d
            if (r2 != r3) goto L35
            boolean r7 = r0.Z$0
            java.lang.Object r8 = r0.L$1
            androidx.compose.ui.input.pointer.r r8 = (androidx.compose.ui.input.pointer.r) r8
            java.lang.Object r9 = r0.L$0
            androidx.compose.ui.input.pointer.c r9 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r9
            a.AbstractC0292a.H(r10)
            r6 = r8
            r8 = r7
            r7 = r9
            r9 = r6
            goto L4f
        L35:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L3d:
            a.AbstractC0292a.H(r10)
        L40:
            r0.L$0 = r7
            r0.L$1 = r9
            r0.Z$0 = r8
            r0.label = r3
            java.lang.Object r10 = r7.awaitPointerEvent(r9, r0)
            if (r10 != r1) goto L4f
            return r1
        L4f:
            androidx.compose.ui.input.pointer.p r10 = (androidx.compose.ui.input.pointer.C0918p) r10
            r2 = 2
            r4 = 0
            r5 = 0
            boolean r2 = isChangedToDown$default(r10, r8, r5, r2, r4)
            if (r2 == 0) goto L40
            java.util.List r7 = r10.getChanges()
            java.lang.Object r7 = r7.get(r5)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.g0.awaitFirstDown(androidx.compose.ui.input.pointer.c, boolean, androidx.compose.ui.input.pointer.r, Y0.c):java.lang.Object");
    }

    public static /* synthetic */ Object awaitFirstDown$default(InterfaceC0905c interfaceC0905c, boolean z2, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        if ((i2 & 2) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Main;
        }
        return awaitFirstDown(interfaceC0905c, z2, rVar, cVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b1, code lost:
    
        return null;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0064 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x00be -> B:13:0x0035). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object waitForUpOrCancellation(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar) {
        j jVar;
        InterfaceC0905c interfaceC0905c2;
        j jVar2;
        androidx.compose.ui.input.pointer.r rVar2;
        InterfaceC0905c interfaceC0905c3;
        androidx.compose.ui.input.pointer.r rVar3;
        int size;
        int i2;
        Object objAwaitPointerEvent;
        if (cVar instanceof j) {
            jVar = (j) cVar;
            int i3 = jVar.label;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                jVar.label = i3 - Integer.MIN_VALUE;
            } else {
                jVar = new j(cVar);
            }
        }
        Object objAwaitPointerEvent2 = jVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i4 = jVar.label;
        if (i4 != 0) {
            if (i4 == 1) {
                rVar3 = (androidx.compose.ui.input.pointer.r) jVar.L$1;
                interfaceC0905c3 = (InterfaceC0905c) jVar.L$0;
                AbstractC0292a.H(objAwaitPointerEvent2);
                C0918p c0918p = (C0918p) objAwaitPointerEvent2;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                while (i2 < size) {
                }
                return c0918p.getChanges().get(0);
            }
            if (i4 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            rVar3 = (androidx.compose.ui.input.pointer.r) jVar.L$1;
            interfaceC0905c3 = (InterfaceC0905c) jVar.L$0;
            AbstractC0292a.H(objAwaitPointerEvent2);
            androidx.compose.ui.input.pointer.r rVar4 = rVar3;
            jVar2 = jVar;
            rVar2 = rVar4;
            List<androidx.compose.ui.input.pointer.C> changes2 = ((C0918p) objAwaitPointerEvent2).getChanges();
            int size2 = changes2.size();
            for (int i5 = 0; i5 < size2; i5++) {
                if (changes2.get(i5).isConsumed()) {
                    return null;
                }
            }
            interfaceC0905c2 = interfaceC0905c3;
            jVar2.L$0 = interfaceC0905c2;
            jVar2.L$1 = rVar2;
            jVar2.label = 1;
            objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar2, jVar2);
            if (objAwaitPointerEvent == aVar) {
                return aVar;
            }
            interfaceC0905c3 = interfaceC0905c2;
            objAwaitPointerEvent2 = objAwaitPointerEvent;
            j jVar3 = jVar2;
            rVar3 = rVar2;
            jVar = jVar3;
            C0918p c0918p2 = (C0918p) objAwaitPointerEvent2;
            List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
            size = changes3.size();
            for (i2 = 0; i2 < size; i2++) {
                if (!AbstractC0919q.changedToUp(changes3.get(i2))) {
                    List<androidx.compose.ui.input.pointer.C> changes4 = c0918p2.getChanges();
                    int size3 = changes4.size();
                    for (int i6 = 0; i6 < size3; i6++) {
                        androidx.compose.ui.input.pointer.C c2 = changes4.get(i6);
                        if (c2.isConsumed() || AbstractC0919q.m3770isOutOfBoundsjwHxaWs(c2, interfaceC0905c3.mo3734getSizeYbymL2g(), interfaceC0905c3.mo3733getExtendedTouchPaddingNHjbRc())) {
                            break;
                        }
                    }
                    androidx.compose.ui.input.pointer.r rVar5 = androidx.compose.ui.input.pointer.r.Final;
                    jVar.L$0 = interfaceC0905c3;
                    jVar.L$1 = rVar3;
                    jVar.label = 2;
                    objAwaitPointerEvent2 = interfaceC0905c3.awaitPointerEvent(rVar5, jVar);
                    if (objAwaitPointerEvent2 == aVar) {
                        return aVar;
                    }
                    androidx.compose.ui.input.pointer.r rVar42 = rVar3;
                    jVar2 = jVar;
                    rVar2 = rVar42;
                    List<androidx.compose.ui.input.pointer.C> changes22 = ((C0918p) objAwaitPointerEvent2).getChanges();
                    int size22 = changes22.size();
                    while (i5 < size22) {
                    }
                    interfaceC0905c2 = interfaceC0905c3;
                    jVar2.L$0 = interfaceC0905c2;
                    jVar2.L$1 = rVar2;
                    jVar2.label = 1;
                    objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar2, jVar2);
                    if (objAwaitPointerEvent == aVar) {
                    }
                }
            }
            return c0918p2.getChanges().get(0);
        }
        AbstractC0292a.H(objAwaitPointerEvent2);
        interfaceC0905c2 = interfaceC0905c;
        jVar2 = jVar;
        rVar2 = rVar;
        jVar2.L$0 = interfaceC0905c2;
        jVar2.L$1 = rVar2;
        jVar2.label = 1;
        objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar2, jVar2);
        if (objAwaitPointerEvent == aVar) {
        }
    }
}
