package androidx.compose.foundation.gestures;

import e0.C1311h;

/* JADX INFO: loaded from: classes.dex */
public abstract class D {
    private static final int MaxAnimationDuration = 100;
    private static final long ScrollProgressTimeout = 50;
    private static final float AnimationThreshold = C1311h.m5076constructorimpl(6);
    private static final float AnimationSpeed = C1311h.m5076constructorimpl(1);

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean isLowScrollingDelta(float f2) {
        return Float.isNaN(f2) || Math.abs(f2) < 0.5f;
    }
}
