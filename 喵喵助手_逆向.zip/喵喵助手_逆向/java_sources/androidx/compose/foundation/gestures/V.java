package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.InterfaceC0341y;
import androidx.compose.foundation.AbstractC0371e;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.node.InterfaceC1007o;

/* JADX INFO: loaded from: classes.dex */
public final class V {
    public static final int $stable = 0;
    public static final V INSTANCE = new V();

    public static final class a implements androidx.compose.foundation.i0 {
        public static final a INSTANCE = new a();

        /* JADX INFO: renamed from: androidx.compose.foundation.gestures.V$a$a, reason: collision with other inner class name */
        public static final class C0026a extends androidx.compose.ui.w {
            @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
            public /* bridge */ /* synthetic */ void onDensityChange() {
                super.onDensityChange();
            }

            @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
            public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
                super.onLayoutDirectionChange();
            }
        }

        private a() {
        }

        @Override // androidx.compose.foundation.i0
        /* JADX INFO: renamed from: applyToFling-BMRW4eQ */
        public Object mo694applyToFlingBMRW4eQ(long j2, h1.e eVar, Y0.c cVar) {
            Object objInvoke = eVar.invoke(e0.z.m5297boximpl(j2), cVar);
            return objInvoke == Z0.a.f1616b ? objInvoke : U0.n.f1521a;
        }

        @Override // androidx.compose.foundation.i0
        /* JADX INFO: renamed from: applyToScroll-Rhakbz0 */
        public long mo695applyToScrollRhakbz0(long j2, int i2, h1.c cVar) {
            return ((J.f) cVar.invoke(J.f.m39boximpl(j2))).m60unboximpl();
        }

        @Override // androidx.compose.foundation.i0
        public /* bridge */ /* synthetic */ androidx.compose.ui.x getEffectModifier() {
            return super.getEffectModifier();
        }

        @Override // androidx.compose.foundation.i0
        public InterfaceC1007o getNode() {
            return new C0026a();
        }

        @Override // androidx.compose.foundation.i0
        public boolean isInProgress() {
            return false;
        }
    }

    private V() {
    }

    public final InterfaceC0400y flingBehavior(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1107739818, i2, -1, "androidx.compose.foundation.gestures.ScrollableDefaults.flingBehavior (Scrollable.kt:546)");
        }
        InterfaceC0341y interfaceC0341yRememberSplineBasedDecay = androidx.compose.animation.T.rememberSplineBasedDecay(interfaceC0768p, 0);
        boolean zChanged = interfaceC0768p.changed(interfaceC0341yRememberSplineBasedDecay);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = new C0387k(interfaceC0341yRememberSplineBasedDecay, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        C0387k c0387k = (C0387k) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return c0387k;
    }

    @U0.a
    public final androidx.compose.foundation.i0 overscrollEffect(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1809802212, i2, -1, "androidx.compose.foundation.gestures.ScrollableDefaults.overscrollEffect (Scrollable.kt:566)");
        }
        androidx.compose.foundation.i0 i0VarRememberPlatformOverscrollEffect = AbstractC0371e.rememberPlatformOverscrollEffect(interfaceC0768p, 0);
        if (i0VarRememberPlatformOverscrollEffect == null) {
            i0VarRememberPlatformOverscrollEffect = a.INSTANCE;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return i0VarRememberPlatformOverscrollEffect;
    }

    public final boolean reverseDirection(e0.u uVar, I i2, boolean z2) {
        return (uVar != e0.u.Rtl || i2 == I.Vertical) ? !z2 : z2;
    }
}
