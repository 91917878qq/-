package androidx.compose.foundation.gestures;

import androidx.compose.ui.node.a1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class T extends androidx.compose.ui.w implements a1 {
    private boolean enabled;
    private final Object traverseKey = TraverseKey;
    public static final a TraverseKey = new a(null);
    public static final int $stable = 8;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        private a() {
        }
    }

    public T(boolean z2) {
        this.enabled = z2;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    @Override // androidx.compose.ui.node.a1
    public Object getTraverseKey() {
        return this.traverseKey;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void update(boolean z2) {
        this.enabled = z2;
    }
}
