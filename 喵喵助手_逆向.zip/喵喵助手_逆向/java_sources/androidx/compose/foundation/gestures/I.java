package androidx.compose.foundation.gestures;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class I {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ I[] $VALUES;
    public static final I Vertical = new I("Vertical", 0);
    public static final I Horizontal = new I("Horizontal", 1);

    private static final /* synthetic */ I[] $values() {
        return new I[]{Vertical, Horizontal};
    }

    static {
        I[] iArr$values = $values();
        $VALUES = iArr$values;
        $ENTRIES = AbstractC0292a.q(iArr$values);
    }

    private I(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static I valueOf(String str) {
        return (I) Enum.valueOf(I.class, str);
    }

    public static I[] values() {
        return (I[]) $VALUES.clone();
    }
}
