package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0396u extends a1.j implements h1.f {
    int label;

    public C0396u(Y0.c cVar) {
        super(3, cVar);
    }

    @Override // h1.f
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
        return invoke((InterfaceC1474x) obj, ((Number) obj2).floatValue(), (Y0.c) obj3);
    }

    @Override // a1.a
    public final Object invokeSuspend(Object obj) {
        Z0.a aVar = Z0.a.f1616b;
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        AbstractC0292a.H(obj);
        return U0.n.f1521a;
    }

    public final Object invoke(InterfaceC1474x interfaceC1474x, float f2, Y0.c cVar) {
        return new C0396u(cVar).invokeSuspend(U0.n.f1521a);
    }
}
