package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.InterfaceC0313i;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0380d {
    static final /* synthetic */ C0380d $$INSTANCE = new C0380d();
    private static final InterfaceC0313i DefaultScrollAnimationSpec = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
    private static final InterfaceC0381e DefaultBringIntoViewSpec = new a();

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.d$a */
    public static final class a implements InterfaceC0381e {
        @Override // androidx.compose.foundation.gestures.InterfaceC0381e
        public /* bridge */ /* synthetic */ float calculateScrollDistance(float f2, float f3, float f4) {
            return super.calculateScrollDistance(f2, f3, f4);
        }

        @Override // androidx.compose.foundation.gestures.InterfaceC0381e
        @U0.a
        public /* bridge */ /* synthetic */ InterfaceC0313i getScrollAnimationSpec() {
            return super.getScrollAnimationSpec();
        }
    }

    private C0380d() {
    }

    public final float defaultCalculateScrollDistance$foundation_release(float f2, float f3, float f4) {
        float f5 = f3 + f2;
        if ((f2 >= 0.0f && f5 <= f4) || (f2 < 0.0f && f5 > f4)) {
            return 0.0f;
        }
        float f6 = f5 - f4;
        return Math.abs(f2) < Math.abs(f6) ? f2 : f6;
    }

    public final InterfaceC0381e getDefaultBringIntoViewSpec$foundation_release() {
        return DefaultBringIntoViewSpec;
    }

    public final InterfaceC0313i getDefaultScrollAnimationSpec$foundation_release() {
        return DefaultScrollAnimationSpec;
    }
}
