package androidx.compose.foundation.gestures;

import androidx.compose.foundation.EnumC0368c0;

/* JADX INFO: loaded from: classes.dex */
public interface c0 {
    static /* synthetic */ Object scroll$default(c0 c0Var, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: scroll");
        }
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return c0Var.scroll(enumC0368c0, eVar, cVar);
    }

    float dispatchRawDelta(float f2);

    default boolean getCanScrollBackward() {
        return true;
    }

    default boolean getCanScrollForward() {
        return true;
    }

    default boolean getLastScrolledBackward() {
        return false;
    }

    default boolean getLastScrolledForward() {
        return false;
    }

    boolean isScrollInProgress();

    Object scroll(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar);
}
