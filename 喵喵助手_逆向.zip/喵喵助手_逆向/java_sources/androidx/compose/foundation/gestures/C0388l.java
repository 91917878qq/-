package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.foundation.C0372e0;
import androidx.compose.foundation.EnumC0368c0;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.V1;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0388l implements c0 {
    private final B0 isLastScrollBackwardState;
    private final B0 isLastScrollForwardState;
    private final B0 isScrollingState;
    private final h1.c onDelta;
    private final Q scrollScope = new b();
    private final C0372e0 scrollMutex = new C0372e0();

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.l$a */
    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ EnumC0368c0 $scrollPriority;
        int label;

        /* JADX INFO: renamed from: androidx.compose.foundation.gestures.l$a$a, reason: collision with other inner class name */
        public static final class C0030a extends a1.j implements h1.e {
            final /* synthetic */ h1.e $block;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0388l this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0030a(C0388l c0388l, h1.e eVar, Y0.c cVar) {
                super(2, cVar);
                this.this$0 = c0388l;
                this.$block = eVar;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                C0030a c0030a = new C0030a(this.this$0, this.$block, cVar);
                c0030a.L$0 = obj;
                return c0030a;
            }

            @Override // h1.e
            public final Object invoke(Q q2, Y0.c cVar) {
                return ((C0030a) create(q2, cVar)).invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                try {
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        Q q2 = (Q) this.L$0;
                        this.this$0.isScrollingState.setValue(Boolean.TRUE);
                        h1.e eVar = this.$block;
                        this.label = 1;
                        if (eVar.invoke(q2, this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    this.this$0.isScrollingState.setValue(Boolean.FALSE);
                    return U0.n.f1521a;
                } catch (Throwable th) {
                    this.this$0.isScrollingState.setValue(Boolean.FALSE);
                    throw th;
                }
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
            super(2, cVar);
            this.$scrollPriority = enumC0368c0;
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return C0388l.this.new a(this.$scrollPriority, this.$block, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                C0372e0 c0372e0 = C0388l.this.scrollMutex;
                Q q2 = C0388l.this.scrollScope;
                EnumC0368c0 enumC0368c0 = this.$scrollPriority;
                C0030a c0030a = new C0030a(C0388l.this, this.$block, null);
                this.label = 1;
                if (c0372e0.mutateWith(q2, enumC0368c0, c0030a, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.l$b */
    public static final class b implements Q {
        public b() {
        }

        @Override // androidx.compose.foundation.gestures.Q
        public float scrollBy(float f2) {
            if (Float.isNaN(f2)) {
                return 0.0f;
            }
            float fFloatValue = ((Number) C0388l.this.getOnDelta().invoke(Float.valueOf(f2))).floatValue();
            C0388l.this.isLastScrollForwardState.setValue(Boolean.valueOf(fFloatValue > 0.0f));
            C0388l.this.isLastScrollBackwardState.setValue(Boolean.valueOf(fFloatValue < 0.0f));
            return fFloatValue;
        }
    }

    public C0388l(h1.c cVar) {
        this.onDelta = cVar;
        Boolean bool = Boolean.FALSE;
        this.isScrollingState = V1.mutableStateOf$default(bool, null, 2, null);
        this.isLastScrollForwardState = V1.mutableStateOf$default(bool, null, 2, null);
        this.isLastScrollBackwardState = V1.mutableStateOf$default(bool, null, 2, null);
    }

    @Override // androidx.compose.foundation.gestures.c0
    public float dispatchRawDelta(float f2) {
        return ((Number) this.onDelta.invoke(Float.valueOf(f2))).floatValue();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public /* bridge */ /* synthetic */ boolean getCanScrollBackward() {
        return super.getCanScrollBackward();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public /* bridge */ /* synthetic */ boolean getCanScrollForward() {
        return super.getCanScrollForward();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getLastScrolledBackward() {
        return ((Boolean) this.isLastScrollBackwardState.getValue()).booleanValue();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean getLastScrolledForward() {
        return ((Boolean) this.isLastScrollForwardState.getValue()).booleanValue();
    }

    public final h1.c getOnDelta() {
        return this.onDelta;
    }

    @Override // androidx.compose.foundation.gestures.c0
    public boolean isScrollInProgress() {
        return ((Boolean) this.isScrollingState.getValue()).booleanValue();
    }

    @Override // androidx.compose.foundation.gestures.c0
    public Object scroll(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
        Object objE = AbstractC1476z.e(new a(enumC0368c0, eVar, null), cVar);
        return objE == Z0.a.f1616b ? objE : U0.n.f1521a;
    }
}
