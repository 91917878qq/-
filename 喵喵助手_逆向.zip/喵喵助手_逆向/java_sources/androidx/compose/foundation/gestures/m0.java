package androidx.compose.foundation.gestures;

import android.view.ViewConfiguration;

/* JADX INFO: loaded from: classes.dex */
public final class m0 {
    public static final m0 INSTANCE = new m0();

    private m0() {
    }

    public final float getHorizontalScrollFactor(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public final float getVerticalScrollFactor(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }
}
