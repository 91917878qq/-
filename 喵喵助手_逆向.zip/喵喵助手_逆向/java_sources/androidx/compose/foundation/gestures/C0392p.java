package androidx.compose.foundation.gestures;

import androidx.compose.foundation.gestures.AbstractC0391o;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0392p implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1739b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ kotlin.jvm.internal.B f1740c;

    public /* synthetic */ C0392p(kotlin.jvm.internal.B b2, int i2) {
        this.f1739b = i2;
        this.f1740c = b2;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        int i2 = this.f1739b;
        androidx.compose.ui.input.pointer.C c2 = (androidx.compose.ui.input.pointer.C) obj;
        float fFloatValue = ((Float) obj2).floatValue();
        switch (i2) {
            case 0:
                return AbstractC0391o.C0031o.invokeSuspend$lambda$0(this.f1740c, c2, fFloatValue);
            default:
                return AbstractC0391o.p.invokeSuspend$lambda$0(this.f1740c, c2, fFloatValue);
        }
    }
}
