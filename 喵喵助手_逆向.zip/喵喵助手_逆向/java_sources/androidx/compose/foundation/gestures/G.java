package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public interface G {
    /* JADX INFO: renamed from: scrollBy-OzD1aCk, reason: not valid java name */
    long mo766scrollByOzD1aCk(long j2, int i2);

    /* JADX INFO: renamed from: scrollByWithOverscroll-OzD1aCk, reason: not valid java name */
    long mo767scrollByWithOverscrollOzD1aCk(long j2, int i2);
}
