package androidx.compose.foundation.gestures;

import O0.F0;
import a.AbstractC0292a;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.AbstractC0319l;
import androidx.compose.animation.core.AbstractC0333s0;
import androidx.compose.animation.core.C0311h;
import androidx.compose.animation.core.C0317k;
import androidx.compose.animation.core.D0;
import androidx.compose.foundation.EnumC0368c0;
import androidx.compose.runtime.AbstractC0801u0;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.C0921t;
import e0.InterfaceC1307d;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;
import r1.s0;

/* JADX INFO: loaded from: classes.dex */
public final class E {
    public static final int $stable = 8;
    private InterfaceC1307d density;
    private boolean isScrolling;
    private final M mouseWheelScrollConfig;
    private final h1.e onScrollStopped;
    private InterfaceC1451b0 receivingMouseWheelEventsJob;
    private final e0 scrollingLogic;
    private final t1.g channel = t1.j.a(Integer.MAX_VALUE, 6, null);
    private final F velocityTracker = new F();

    public static final class a {
        private final boolean shouldApplyImmediately;
        private final long timeMillis;
        private final long value;

        public /* synthetic */ a(long j2, long j3, boolean z2, AbstractC1378g abstractC1378g) {
            this(j2, j3, z2);
        }

        /* JADX INFO: renamed from: copy-9KIMszo$default, reason: not valid java name */
        public static /* synthetic */ a m760copy9KIMszo$default(a aVar, long j2, long j3, boolean z2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                j2 = aVar.value;
            }
            long j4 = j2;
            if ((i2 & 2) != 0) {
                j3 = aVar.timeMillis;
            }
            long j5 = j3;
            if ((i2 & 4) != 0) {
                z2 = aVar.shouldApplyImmediately;
            }
            return aVar.m762copy9KIMszo(j4, j5, z2);
        }

        /* JADX INFO: renamed from: component1-F1C5BW0, reason: not valid java name */
        public final long m761component1F1C5BW0() {
            return this.value;
        }

        public final long component2() {
            return this.timeMillis;
        }

        public final boolean component3() {
            return this.shouldApplyImmediately;
        }

        /* JADX INFO: renamed from: copy-9KIMszo, reason: not valid java name */
        public final a m762copy9KIMszo(long j2, long j3, boolean z2) {
            return new a(j2, j3, z2, null);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return J.f.m47equalsimpl0(this.value, aVar.value) && this.timeMillis == aVar.timeMillis && this.shouldApplyImmediately == aVar.shouldApplyImmediately;
        }

        public final boolean getShouldApplyImmediately() {
            return this.shouldApplyImmediately;
        }

        public final long getTimeMillis() {
            return this.timeMillis;
        }

        /* JADX INFO: renamed from: getValue-F1C5BW0, reason: not valid java name */
        public final long m763getValueF1C5BW0() {
            return this.value;
        }

        public int hashCode() {
            return Boolean.hashCode(this.shouldApplyImmediately) + ((Long.hashCode(this.timeMillis) + (J.f.m52hashCodeimpl(this.value) * 31)) * 31);
        }

        public final a plus(a aVar) {
            return new a(J.f.m55plusMKHz9U(this.value, aVar.value), Math.max(this.timeMillis, aVar.timeMillis), this.shouldApplyImmediately, null);
        }

        public String toString() {
            return "MouseWheelScrollDelta(value=" + ((Object) J.f.m58toStringimpl(this.value)) + ", timeMillis=" + this.timeMillis + ", shouldApplyImmediately=" + this.shouldApplyImmediately + ')';
        }

        private a(long j2, long j3, boolean z2) {
            this.value = j2;
            this.timeMillis = j3;
            this.shouldApplyImmediately = z2;
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ t1.g $this_busyReceive;
        private /* synthetic */ Object L$0;
        int label;

        public static final class a extends a1.j implements h1.e {
            private /* synthetic */ Object L$0;
            int label;

            public a(Y0.c cVar) {
                super(2, cVar);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final U0.n invokeSuspend$lambda$0(long j2) {
                return U0.n.f1521a;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                InterfaceC1474x interfaceC1474x;
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                }
                while (AbstractC1476z.o(interfaceC1474x.getCoroutineContext())) {
                    D0 d02 = new D0(18);
                    this.L$0 = interfaceC1474x;
                    this.label = 1;
                    if (AbstractC0801u0.withFrameNanos(d02, this) == aVar) {
                        return aVar;
                    }
                }
                return U0.n.f1521a;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(t1.g gVar, Y0.c cVar) {
            super(2, cVar);
            this.$this_busyReceive = gVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = new b(this.$this_busyReceive, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            InterfaceC1451b0 interfaceC1451b0;
            Throwable th;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                r1.C cS = AbstractC1476z.s((InterfaceC1474x) this.L$0, null, null, new a(null), 3);
                try {
                    t1.g gVar = this.$this_busyReceive;
                    this.L$0 = cS;
                    this.label = 1;
                    Object objA = gVar.a(this);
                    if (objA == aVar) {
                        return aVar;
                    }
                    interfaceC1451b0 = cS;
                    obj = objA;
                } catch (Throwable th2) {
                    interfaceC1451b0 = cS;
                    th = th2;
                    interfaceC1451b0.cancel(null);
                    throw th;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                interfaceC1451b0 = (InterfaceC1451b0) this.L$0;
                try {
                    AbstractC0292a.H(obj);
                } catch (Throwable th3) {
                    th = th3;
                    interfaceC1451b0.cancel(null);
                    throw th;
                }
            }
            a aVar2 = (a) obj;
            interfaceC1451b0.cancel(null);
            return aVar2;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class c extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return E.this.dispatchMouseWheelScroll(null, null, 0.0f, 0.0f, this);
        }
    }

    public static final class d extends a1.j implements h1.e {
        final /* synthetic */ kotlin.jvm.internal.E $animationState;
        final /* synthetic */ float $speed;
        final /* synthetic */ kotlin.jvm.internal.E $targetScrollDelta;
        final /* synthetic */ kotlin.jvm.internal.B $targetValue;
        final /* synthetic */ e0 $this_dispatchMouseWheelScroll;
        final /* synthetic */ float $threshold;
        int I$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        int label;
        final /* synthetic */ E this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(kotlin.jvm.internal.B b2, kotlin.jvm.internal.E e2, kotlin.jvm.internal.E e3, float f2, E e4, float f3, e0 e0Var, Y0.c cVar) {
            super(2, cVar);
            this.$targetValue = b2;
            this.$animationState = e2;
            this.$targetScrollDelta = e3;
            this.$threshold = f2;
            this.this$0 = e4;
            this.$speed = f3;
            this.$this_dispatchMouseWheelScroll = e0Var;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final boolean invokeSuspend$lambda$0(E e2, kotlin.jvm.internal.E e3, kotlin.jvm.internal.B b2, e0 e0Var, kotlin.jvm.internal.A a2, float f2) {
            a aVarSumOrNull = e2.sumOrNull(e2.channel);
            if (aVarSumOrNull != null) {
                e2.trackVelocity(aVarSumOrNull);
                a aVarPlus = ((a) e3.f3118b).plus(aVarSumOrNull);
                e3.f3118b = aVarPlus;
                b2.f3115b = e0Var.m821toFloatk4lQ0M(e0Var.m819reverseIfNeededMKHz9U(aVarPlus.m763getValueF1C5BW0()));
                a2.f3114b = !D.isLowScrollingDelta(r2 - f2);
            }
            return aVarSumOrNull != null;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            d dVar = new d(this.$targetValue, this.$animationState, this.$targetScrollDelta, this.$threshold, this.this$0, this.$speed, this.$this_dispatchMouseWheelScroll, cVar);
            dVar.L$0 = obj;
            return dVar;
        }

        @Override // h1.e
        public final Object invoke(G g2, Y0.c cVar) {
            return ((d) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:30:0x0134  */
        /* JADX WARN: Removed duplicated region for block: B:35:0x0167  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x0159 -> B:34:0x015b). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x0167 -> B:13:0x0067). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            G g2;
            kotlin.jvm.internal.A a2;
            G g3;
            kotlin.jvm.internal.A a3;
            int i2;
            Object objDispatchMouseWheelScroll$waitNextScrollDelta;
            Z0.a aVar = Z0.a.f1616b;
            int i3 = this.label;
            int i4 = 2;
            if (i3 == 0) {
                AbstractC0292a.H(obj);
                G g4 = (G) this.L$0;
                kotlin.jvm.internal.A a4 = new kotlin.jvm.internal.A();
                a4.f3114b = true;
                g2 = g4;
                a2 = a4;
            } else if (i3 == 1) {
                kotlin.jvm.internal.A a5 = (kotlin.jvm.internal.A) this.L$2;
                kotlin.jvm.internal.A a6 = (kotlin.jvm.internal.A) this.L$1;
                G g5 = (G) this.L$0;
                AbstractC0292a.H(obj);
                a2 = a6;
                g2 = g5;
                a5.f3114b = ((Boolean) obj).booleanValue();
                i4 = 2;
            } else if (i3 == 2) {
                i2 = this.I$0;
                kotlin.jvm.internal.A a7 = (kotlin.jvm.internal.A) this.L$1;
                G g6 = (G) this.L$0;
                AbstractC0292a.H(obj);
                a3 = a7;
                g3 = g6;
                if (a3.f3114b) {
                    this.L$0 = g3;
                    this.L$1 = a3;
                    this.L$2 = a3;
                    this.label = 3;
                    objDispatchMouseWheelScroll$waitNextScrollDelta = E.dispatchMouseWheelScroll$waitNextScrollDelta(this.this$0, this.$targetScrollDelta, this.$targetValue, this.$this_dispatchMouseWheelScroll, this.$animationState, 50 - ((long) i2), this);
                    if (objDispatchMouseWheelScroll$waitNextScrollDelta == aVar) {
                        return aVar;
                    }
                    a2 = a3;
                    g2 = g3;
                    a3.f3114b = ((Boolean) objDispatchMouseWheelScroll$waitNextScrollDelta).booleanValue();
                    i4 = 2;
                } else {
                    a2 = a3;
                    g2 = g3;
                }
            } else {
                if (i3 != 3) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.jvm.internal.A a8 = (kotlin.jvm.internal.A) this.L$2;
                kotlin.jvm.internal.A a9 = (kotlin.jvm.internal.A) this.L$1;
                G g7 = (G) this.L$0;
                AbstractC0292a.H(obj);
                a3 = a8;
                a2 = a9;
                g2 = g7;
                objDispatchMouseWheelScroll$waitNextScrollDelta = obj;
                a3.f3114b = ((Boolean) objDispatchMouseWheelScroll$waitNextScrollDelta).booleanValue();
                i4 = 2;
            }
            while (a2.f3114b) {
                a2.f3114b = false;
                float fFloatValue = this.$targetValue.f3115b - ((Number) ((C0317k) this.$animationState.f3118b).getValue()).floatValue();
                if (((a) this.$targetScrollDelta.f3118b).getShouldApplyImmediately() || Math.abs(fFloatValue) < this.$threshold) {
                    G g8 = g2;
                    this.this$0.dispatchMouseWheelScroll(g8, fFloatValue);
                    E e2 = this.this$0;
                    kotlin.jvm.internal.E e3 = this.$targetScrollDelta;
                    kotlin.jvm.internal.B b2 = this.$targetValue;
                    e0 e0Var = this.$this_dispatchMouseWheelScroll;
                    kotlin.jvm.internal.E e4 = this.$animationState;
                    this.L$0 = g8;
                    this.L$1 = a2;
                    this.L$2 = a2;
                    this.label = 1;
                    kotlin.jvm.internal.A a10 = a2;
                    Object objDispatchMouseWheelScroll$waitNextScrollDelta2 = E.dispatchMouseWheelScroll$waitNextScrollDelta(e2, e3, b2, e0Var, e4, 50L, this);
                    if (objDispatchMouseWheelScroll$waitNextScrollDelta2 == aVar) {
                        return aVar;
                    }
                    a2 = a10;
                    g2 = g8;
                    a10.f3114b = ((Boolean) objDispatchMouseWheelScroll$waitNextScrollDelta2).booleanValue();
                    i4 = 2;
                } else {
                    float fSignum = Math.signum(fFloatValue) * this.$threshold;
                    this.this$0.dispatchMouseWheelScroll(g2, fSignum);
                    kotlin.jvm.internal.E e5 = this.$animationState;
                    C0317k c0317k = (C0317k) e5.f3118b;
                    e5.f3118b = AbstractC0319l.copy$default(c0317k, ((Number) c0317k.getValue()).floatValue() + fSignum, 0.0f, 0L, 0L, false, 30, (Object) null);
                    int iT = j1.a.T(Math.abs(this.$targetValue.f3115b - ((Number) ((C0317k) this.$animationState.f3118b).getValue()).floatValue()) / this.$speed);
                    int i5 = iT > 100 ? 100 : iT;
                    E e6 = this.this$0;
                    C0317k c0317k2 = (C0317k) this.$animationState.f3118b;
                    kotlin.jvm.internal.B b3 = this.$targetValue;
                    float f2 = b3.f3115b;
                    F0 f02 = new F0(e6, this.$targetScrollDelta, b3, this.$this_dispatchMouseWheelScroll, a2, 1);
                    this.L$0 = g2;
                    this.L$1 = a2;
                    this.L$2 = null;
                    this.I$0 = i5;
                    this.label = i4;
                    int i6 = i5;
                    g3 = g2;
                    if (e6.animateMouseWheelScroll(g2, c0317k2, f2, i5, f02, this) == aVar) {
                        return aVar;
                    }
                    i2 = i6;
                    a3 = a2;
                    if (a3.f3114b) {
                    }
                }
            }
            return U0.n.f1521a;
        }
    }

    public static final class e extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public e(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return E.dispatchMouseWheelScroll$waitNextScrollDelta(null, null, null, null, null, 0L, this);
        }
    }

    public static final class f extends a1.j implements h1.e {
        int label;

        public f(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return E.this.new f(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                E e2 = E.this;
                t1.g gVar = e2.channel;
                this.label = 1;
                obj = e2.busyReceive(gVar, this);
                if (obj == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return obj;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((f) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class g extends a1.j implements h1.e {
        private /* synthetic */ Object L$0;
        int label;

        public g(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            g gVar = E.this.new g(cVar);
            gVar.L$0 = obj;
            return gVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:19:0x0039 A[Catch: all -> 0x0016, TryCatch #0 {all -> 0x0016, blocks: (B:7:0x0011, B:17:0x002f, B:19:0x0039, B:23:0x004d, B:14:0x0024), top: B:30:0x0007 }] */
        /* JADX WARN: Removed duplicated region for block: B:25:0x007d A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:26:0x007e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x007b -> B:8:0x0014). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC1474x interfaceC1474x;
            InterfaceC1474x interfaceC1474x2;
            a aVar;
            float fMo788toPx0680j_4;
            float fMo788toPx0680j_42;
            E e2;
            e0 e0Var;
            Z0.a aVar2 = Z0.a.f1616b;
            int i2 = this.label;
            try {
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    interfaceC1474x = (InterfaceC1474x) this.L$0;
                    if (!AbstractC1476z.o(interfaceC1474x.getCoroutineContext())) {
                    }
                } else if (i2 == 1) {
                    interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    aVar = (a) obj;
                    fMo788toPx0680j_4 = E.this.density.mo788toPx0680j_4(D.AnimationThreshold);
                    fMo788toPx0680j_42 = E.this.density.mo788toPx0680j_4(D.AnimationSpeed);
                    e2 = E.this;
                    e0Var = e2.scrollingLogic;
                    this.L$0 = interfaceC1474x2;
                    this.label = 2;
                    if (e2.dispatchMouseWheelScroll(e0Var, aVar, fMo788toPx0680j_4, fMo788toPx0680j_42, this) == aVar2) {
                    }
                    interfaceC1474x = interfaceC1474x2;
                    if (!AbstractC1476z.o(interfaceC1474x.getCoroutineContext())) {
                    }
                } else {
                    if (i2 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                    AbstractC0292a.H(obj);
                    interfaceC1474x = interfaceC1474x2;
                    if (!AbstractC1476z.o(interfaceC1474x.getCoroutineContext())) {
                        t1.g gVar = E.this.channel;
                        this.L$0 = interfaceC1474x;
                        this.label = 1;
                        Object objA = gVar.a(this);
                        if (objA == aVar2) {
                            return aVar2;
                        }
                        interfaceC1474x2 = interfaceC1474x;
                        obj = objA;
                        aVar = (a) obj;
                        fMo788toPx0680j_4 = E.this.density.mo788toPx0680j_4(D.AnimationThreshold);
                        fMo788toPx0680j_42 = E.this.density.mo788toPx0680j_4(D.AnimationSpeed);
                        e2 = E.this;
                        e0Var = e2.scrollingLogic;
                        this.L$0 = interfaceC1474x2;
                        this.label = 2;
                        if (e2.dispatchMouseWheelScroll(e0Var, aVar, fMo788toPx0680j_4, fMo788toPx0680j_42, this) == aVar2) {
                            return aVar2;
                        }
                        interfaceC1474x = interfaceC1474x2;
                        if (!AbstractC1476z.o(interfaceC1474x.getCoroutineContext())) {
                            E.this.receivingMouseWheelEventsJob = null;
                            return U0.n.f1521a;
                        }
                    }
                }
            } catch (Throwable th) {
                E.this.receivingMouseWheelEventsJob = null;
                throw th;
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((g) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class h extends a1.i implements h1.e {
        final /* synthetic */ h1.a $builderAction;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(h1.a aVar, Y0.c cVar) {
            super(cVar);
            this.$builderAction = aVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            h hVar = new h(this.$builderAction, cVar);
            hVar.L$0 = obj;
            return hVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:11:0x002b  */
        /* JADX WARN: Removed duplicated region for block: B:13:0x0037  */
        /* JADX WARN: Removed duplicated region for block: B:15:0x003a  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:13:0x0037 -> B:14:0x0038). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            o1.g gVar;
            Object objInvoke;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                gVar = (o1.g) this.L$0;
                objInvoke = this.$builderAction.invoke();
                if (objInvoke != null) {
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                Object obj2 = this.L$1;
                gVar = (o1.g) this.L$0;
                AbstractC0292a.H(obj);
                if (obj2 == null) {
                    return U0.n.f1521a;
                }
                objInvoke = this.$builderAction.invoke();
                if (objInvoke != null) {
                    this.L$0 = gVar;
                    this.L$1 = objInvoke;
                    this.label = 1;
                    gVar.a(this, objInvoke);
                    Z0.a aVar2 = Z0.a.f1616b;
                    return aVar;
                }
                obj2 = null;
                if (obj2 == null) {
                }
                objInvoke = this.$builderAction.invoke();
                if (objInvoke != null) {
                }
            }
        }

        @Override // h1.e
        public final Object invoke(o1.g gVar, Y0.c cVar) {
            return ((h) create(gVar, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class i extends a1.c {
        int label;
        /* synthetic */ Object result;

        public i(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return E.this.userScroll(null, null, this);
        }
    }

    public static final class j extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ e0 $this_userScroll;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(e0 e0Var, h1.e eVar, Y0.c cVar) {
            super(2, cVar);
            this.$this_userScroll = e0Var;
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new j(this.$this_userScroll, this.$block, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0 e0Var = this.$this_userScroll;
                EnumC0368c0 enumC0368c0 = EnumC0368c0.UserInput;
                h1.e eVar = this.$block;
                this.label = 1;
                if (e0Var.scroll(enumC0368c0, eVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((j) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public E(e0 e0Var, M m2, h1.e eVar, InterfaceC1307d interfaceC1307d) {
        this.scrollingLogic = e0Var;
        this.mouseWheelScrollConfig = m2;
        this.onScrollStopped = eVar;
        this.density = interfaceC1307d;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object animateMouseWheelScroll(G g2, C0317k c0317k, float f2, int i2, h1.c cVar, Y0.c cVar2) {
        kotlin.jvm.internal.B b2 = new kotlin.jvm.internal.B();
        b2.f3115b = ((Number) c0317k.getValue()).floatValue();
        Object objAnimateTo = AbstractC0333s0.animateTo(c0317k, new Float(f2), AbstractC0315j.tween$default(i2, 0, androidx.compose.animation.core.E.getLinearEasing(), 2, null), true, new M0.q(b2, this, g2, cVar, 7), cVar2);
        return objAnimateTo == Z0.a.f1616b ? objAnimateTo : U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateMouseWheelScroll$lambda$7(kotlin.jvm.internal.B b2, E e2, G g2, h1.c cVar, C0311h c0311h) {
        float fFloatValue = ((Number) c0311h.getValue()).floatValue() - b2.f3115b;
        boolean zIsLowScrollingDelta = D.isLowScrollingDelta(fFloatValue);
        U0.n nVar = U0.n.f1521a;
        if (!zIsLowScrollingDelta) {
            if (!D.isLowScrollingDelta(fFloatValue - e2.dispatchMouseWheelScroll(g2, fFloatValue))) {
                c0311h.cancelAnimation();
                return nVar;
            }
            b2.f3115b += fFloatValue;
        }
        if (((Boolean) cVar.invoke(Float.valueOf(b2.f3115b))).booleanValue()) {
            c0311h.cancelAnimation();
        }
        return nVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object busyReceive(t1.g gVar, Y0.c cVar) {
        return AbstractC1476z.e(new b(gVar, null), cVar);
    }

    /* JADX INFO: renamed from: canConsumeDelta-Uv8p0NA, reason: not valid java name */
    private final boolean m757canConsumeDeltaUv8p0NA(e0 e0Var, long j2) {
        float fM821toFloatk4lQ0M = e0Var.m821toFloatk4lQ0M(e0Var.m819reverseIfNeededMKHz9U(j2));
        if (fM821toFloatk4lQ0M == 0.0f) {
            return false;
        }
        return fM821toFloatk4lQ0M > 0.0f ? e0Var.getScrollableState().getCanScrollForward() : e0Var.getScrollableState().getCanScrollBackward();
    }

    private final void consume(C0918p c0918p) {
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        for (int i2 = 0; i2 < size; i2++) {
            changes.get(i2).consume();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object dispatchMouseWheelScroll(e0 e0Var, a aVar, float f2, float f3, Y0.c cVar) {
        c cVar2;
        float f4;
        kotlin.jvm.internal.B b2;
        e0 e0Var2 = e0Var;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i2 = cVar2.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                cVar2.label = i2 - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(cVar);
            }
        }
        c cVar3 = cVar2;
        Object obj = cVar3.result;
        Object obj2 = Z0.a.f1616b;
        int i3 = cVar3.label;
        U0.n nVar = U0.n.f1521a;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            kotlin.jvm.internal.E e2 = new kotlin.jvm.internal.E();
            e2.f3118b = aVar;
            trackVelocity(aVar);
            a aVarSumOrNull = sumOrNull(this.channel);
            if (aVarSumOrNull != null) {
                trackVelocity(aVarSumOrNull);
                e2.f3118b = ((a) e2.f3118b).plus(aVarSumOrNull);
            }
            kotlin.jvm.internal.B b3 = new kotlin.jvm.internal.B();
            float fM821toFloatk4lQ0M = e0Var2.m821toFloatk4lQ0M(e0Var2.m819reverseIfNeededMKHz9U(((a) e2.f3118b).m763getValueF1C5BW0()));
            b3.f3115b = fM821toFloatk4lQ0M;
            if (D.isLowScrollingDelta(fM821toFloatk4lQ0M)) {
                return nVar;
            }
            kotlin.jvm.internal.E e3 = new kotlin.jvm.internal.E();
            e3.f3118b = AbstractC0319l.AnimationState$default(0.0f, 0.0f, 0L, 0L, false, 30, null);
            h1.e dVar = new d(b3, e3, e2, f2, this, f3, e0Var, null);
            cVar3.L$0 = e0Var2;
            cVar3.L$1 = b3;
            f4 = f3;
            cVar3.F$0 = f4;
            cVar3.label = 1;
            if (userScroll(e0Var2, dVar, cVar3) == obj2) {
                return obj2;
            }
            b2 = b3;
        } else {
            if (i3 != 1) {
                if (i3 == 2) {
                    AbstractC0292a.H(obj);
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f4 = cVar3.F$0;
            b2 = (kotlin.jvm.internal.B) cVar3.L$1;
            e0 e0Var3 = (e0) cVar3.L$0;
            AbstractC0292a.H(obj);
            e0Var2 = e0Var3;
        }
        long jM765calculateVelocity9UxMQ8M = this.velocityTracker.m765calculateVelocity9UxMQ8M();
        if (e0.z.m5305equalsimpl0(jM765calculateVelocity9UxMQ8M, e0.z.Companion.m5317getZero9UxMQ8M())) {
            jM765calculateVelocity9UxMQ8M = e0Var2.m823toVelocityadjELrA(e0Var2.reverseIfNeeded(Math.signum(b2.f3115b)) * Math.min(Math.abs(b2.f3115b) / 100, f4) * 1000);
        }
        h1.e eVar = this.onScrollStopped;
        e0.z zVarM5297boximpl = e0.z.m5297boximpl(jM765calculateVelocity9UxMQ8M);
        cVar3.L$0 = null;
        cVar3.L$1 = null;
        cVar3.label = 2;
        return eVar.invoke(zVarM5297boximpl, cVar3) == obj2 ? obj2 : nVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object dispatchMouseWheelScroll$waitNextScrollDelta(E e2, kotlin.jvm.internal.E e3, kotlin.jvm.internal.B b2, e0 e0Var, kotlin.jvm.internal.E e4, long j2, Y0.c cVar) {
        e eVar;
        kotlin.jvm.internal.B b3;
        e0 e0Var2;
        kotlin.jvm.internal.E e5;
        kotlin.jvm.internal.E e6;
        boolean z2;
        E e7 = e2;
        if (cVar instanceof e) {
            eVar = (e) cVar;
            int i2 = eVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                eVar.label = i2 - Integer.MIN_VALUE;
            } else {
                eVar = new e(cVar);
            }
        }
        Object objB = eVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = eVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(objB);
            if (j2 < 0) {
                return Boolean.FALSE;
            }
            f fVar = e7.new f(null);
            eVar.L$0 = e7;
            eVar.L$1 = e3;
            b3 = b2;
            eVar.L$2 = b3;
            e0Var2 = e0Var;
            eVar.L$3 = e0Var2;
            e5 = e4;
            eVar.L$4 = e5;
            eVar.label = 1;
            objB = AbstractC1476z.B(j2, fVar, eVar);
            if (objB == aVar) {
                return aVar;
            }
            e6 = e3;
        } else {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.jvm.internal.E e8 = (kotlin.jvm.internal.E) eVar.L$4;
            e0 e0Var3 = (e0) eVar.L$3;
            kotlin.jvm.internal.B b4 = (kotlin.jvm.internal.B) eVar.L$2;
            e6 = (kotlin.jvm.internal.E) eVar.L$1;
            E e9 = (E) eVar.L$0;
            AbstractC0292a.H(objB);
            e5 = e8;
            e0Var2 = e0Var3;
            b3 = b4;
            e7 = e9;
        }
        a aVar2 = (a) objB;
        if (aVar2 != null) {
            a aVarM760copy9KIMszo$default = a.m760copy9KIMszo$default(aVar2, 0L, 0L, ((a) e6.f3118b).getShouldApplyImmediately(), 3, null);
            e6.f3118b = aVarM760copy9KIMszo$default;
            b3.f3115b = e0Var2.m821toFloatk4lQ0M(e0Var2.m819reverseIfNeededMKHz9U(aVarM760copy9KIMszo$default.m763getValueF1C5BW0()));
            e5.f3118b = AbstractC0319l.AnimationState$default(0.0f, 0.0f, 0L, 0L, false, 30, null);
            e7.trackVelocity(aVar2);
            z2 = !D.isLowScrollingDelta(b3.f3115b);
        } else {
            z2 = false;
        }
        return Boolean.valueOf(z2);
    }

    private final boolean isConsumed(C0918p c0918p) {
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (changes.get(i2).isConsumed()) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: onMouseWheel-O0kMr_c, reason: not valid java name */
    private final boolean m758onMouseWheelO0kMr_c(C0918p c0918p, long j2) {
        if (m757canConsumeDeltaUv8p0NA(this.scrollingLogic, this.mouseWheelScrollConfig.mo793calculateMouseWheelScroll8xgXZGE(this.density, c0918p, j2))) {
            return !(this.channel.l(new a(r3, ((androidx.compose.ui.input.pointer.C) V0.t.u0(c0918p.getChanges())).getUptimeMillis(), !this.mouseWheelScrollConfig.isSmoothScrollingEnabled() || this.mouseWheelScrollConfig.isPreciseWheelScroll(c0918p), null)) instanceof t1.i);
        }
        return this.isScrolling;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final a sumOrNull(t1.g gVar) {
        a aVarPlus = null;
        for (a aVar : untilNull(new E0.f(gVar, 9))) {
            aVarPlus = aVarPlus == null ? aVar : aVarPlus.plus(aVar);
        }
        return aVarPlus;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final a sumOrNull$lambda$4(t1.g gVar) {
        Object objJ = gVar.j();
        if (objJ instanceof t1.i) {
            objJ = null;
        }
        return (a) objJ;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void trackVelocity(a aVar) {
        this.velocityTracker.m764addDeltaUv8p0NA(aVar.getTimeMillis(), aVar.m763getValueF1C5BW0());
    }

    private final <E> o1.e untilNull(h1.a aVar) {
        return new f1.k(new h(aVar, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object userScroll(e0 e0Var, h1.e eVar, Y0.c cVar) {
        i iVar;
        if (cVar instanceof i) {
            iVar = (i) cVar;
            int i2 = iVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                iVar.label = i2 - Integer.MIN_VALUE;
            } else {
                iVar = new i(cVar);
            }
        }
        Object obj = iVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = iVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            this.isScrolling = true;
            j jVar = new j(e0Var, eVar, null);
            iVar.label = 1;
            s0 s0Var = new s0(iVar.getContext(), iVar);
            if (AbstractC0292a.G(s0Var, s0Var, jVar) == aVar) {
                return aVar;
            }
        } else {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
        }
        this.isScrolling = false;
        return U0.n.f1521a;
    }

    /* JADX INFO: renamed from: onPointerEvent-H0pRuoY, reason: not valid java name */
    public final void m759onPointerEventH0pRuoY(C0918p c0918p, androidx.compose.ui.input.pointer.r rVar, long j2) {
        if (rVar == androidx.compose.ui.input.pointer.r.Main && C0921t.m3774equalsimpl0(c0918p.m3767getType7fucELk(), C0921t.Companion.m3783getScroll7fucELk())) {
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (changes.get(i2).isConsumed()) {
                    return;
                }
            }
            if (m758onMouseWheelO0kMr_c(c0918p, j2)) {
                consume(c0918p);
            }
        }
    }

    public final void startReceivingMouseWheelEvents(InterfaceC1474x interfaceC1474x) {
        if (this.receivingMouseWheelEventsJob == null) {
            this.receivingMouseWheelEventsJob = AbstractC1476z.s(interfaceC1474x, null, null, new g(null), 3);
        }
    }

    public final void updateDensity(InterfaceC1307d interfaceC1307d) {
        this.density = interfaceC1307d;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dispatchMouseWheelScroll(G g2, float f2) {
        e0 e0Var = this.scrollingLogic;
        return e0Var.m821toFloatk4lQ0M(e0Var.m819reverseIfNeededMKHz9U(g2.mo766scrollByOzD1aCk(e0Var.m822toOffsettuRUvjQ(e0Var.reverseIfNeeded(f2)), androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI())));
    }
}
