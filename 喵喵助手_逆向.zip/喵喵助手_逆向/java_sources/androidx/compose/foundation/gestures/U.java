package androidx.compose.foundation.gestures;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public interface U extends InterfaceC0400y {
    @Override // androidx.compose.foundation.gestures.InterfaceC0400y
    /* synthetic */ Object performFling(Q q2, float f2, Y0.c cVar);

    default void updateDensity(InterfaceC1307d interfaceC1307d) {
    }
}
