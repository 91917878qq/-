package androidx.compose.foundation.gestures;

import androidx.compose.foundation.EnumC0368c0;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0399x {
    static /* synthetic */ Object drag$default(InterfaceC0399x interfaceC0399x, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: drag");
        }
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return interfaceC0399x.drag(enumC0368c0, eVar, cVar);
    }

    void dispatchRawDelta(float f2);

    Object drag(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar);
}
