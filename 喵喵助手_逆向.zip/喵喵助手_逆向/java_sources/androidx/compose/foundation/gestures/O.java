package androidx.compose.foundation.gestures;

import androidx.compose.foundation.gestures.N;
import androidx.compose.foundation.text.selection.I;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class O implements h1.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1735b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ kotlin.jvm.internal.D f1736c;

    public /* synthetic */ O(kotlin.jvm.internal.D d2, int i2) {
        this.f1735b = i2;
        this.f1736c = d2;
    }

    @Override // h1.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1735b) {
            case 0:
                return N.d.invokeSuspend$lambda$0(this.f1736c, null, (J.f) obj, (J.f) obj2);
            default:
                return I.i.invokeSuspend$lambda$0(this.f1736c, (androidx.compose.ui.input.pointer.C) obj, (J.f) obj2);
        }
    }
}
