package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.foundation.C0372e0;
import androidx.compose.foundation.EnumC0368c0;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0386j implements InterfaceC0399x {
    private final h1.c onDelta;
    private final InterfaceC0394s dragScope = new b();
    private final C0372e0 scrollMutex = new C0372e0();

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.j$a */
    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ EnumC0368c0 $dragPriority;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
            super(2, cVar);
            this.$dragPriority = enumC0368c0;
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return C0386j.this.new a(this.$dragPriority, this.$block, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                C0372e0 c0372e0 = C0386j.this.scrollMutex;
                InterfaceC0394s interfaceC0394s = C0386j.this.dragScope;
                EnumC0368c0 enumC0368c0 = this.$dragPriority;
                h1.e eVar = this.$block;
                this.label = 1;
                if (c0372e0.mutateWith(interfaceC0394s, enumC0368c0, eVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.j$b */
    public static final class b implements InterfaceC0394s {
        public b() {
        }

        @Override // androidx.compose.foundation.gestures.InterfaceC0394s
        public void dragBy(float f2) {
            C0386j.this.getOnDelta().invoke(Float.valueOf(f2));
        }
    }

    public C0386j(h1.c cVar) {
        this.onDelta = cVar;
    }

    @Override // androidx.compose.foundation.gestures.InterfaceC0399x
    public void dispatchRawDelta(float f2) {
        this.onDelta.invoke(Float.valueOf(f2));
    }

    @Override // androidx.compose.foundation.gestures.InterfaceC0399x
    public Object drag(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
        Object objE = AbstractC1476z.e(new a(enumC0368c0, eVar, null), cVar);
        return objE == Z0.a.f1616b ? objE : U0.n.f1521a;
    }

    public final h1.c getOnDelta() {
        return this.onDelta;
    }
}
