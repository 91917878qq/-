package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.animation.core.C0331r0;
import androidx.compose.animation.core.D0;
import androidx.compose.ui.input.pointer.AbstractC0919q;
import androidx.compose.ui.input.pointer.C0918p;
import androidx.compose.ui.input.pointer.C0920s;
import androidx.compose.ui.input.pointer.InterfaceC0905c;
import androidx.compose.ui.platform.W1;
import e0.C1311h;
import java.util.List;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0391o {
    private static final float defaultTouchSlop;
    private static final float mouseSlop;
    private static final float mouseToTouchSlopRatio;

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$a */
    public static final class a extends a1.c {
        float F$0;
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.awaitAllPointersUpWithSlopDetection(null, null, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$b */
    public static final class b extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m842awaitDragOrCancellationrnUCldI(null, 0L, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$c */
    public static final class c extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m844awaitHorizontalDragOrCancellationrnUCldI(null, 0L, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$d */
    public static final class d extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m845awaitHorizontalPointerSlopOrCancellationgDDlDlE(null, 0L, 0, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$e */
    public static final class e extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public e(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m846awaitHorizontalTouchSlopOrCancellationjO51t88(null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$f */
    public static final class f extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        public f(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m847awaitLongPressOrCancellationrnUCldI(null, 0L, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$g */
    public static final class g extends a1.i implements h1.e {
        final /* synthetic */ kotlin.jvm.internal.E $currentDown;
        final /* synthetic */ kotlin.jvm.internal.A $deepPress;
        final /* synthetic */ kotlin.jvm.internal.E $longPress;
        int I$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(kotlin.jvm.internal.A a2, kotlin.jvm.internal.E e2, kotlin.jvm.internal.E e3, Y0.c cVar) {
            super(cVar);
            this.$deepPress = a2;
            this.$currentDown = e2;
            this.$longPress = e3;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            g gVar = new g(this.$deepPress, this.$currentDown, this.$longPress, cVar);
            gVar.L$0 = obj;
            return gVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((g) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:30:0x0098, code lost:
        
            r2 = r6 ? 1 : 0;
         */
        /* JADX WARN: Removed duplicated region for block: B:12:0x003f  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x005d  */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0079  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x009f  */
        /* JADX WARN: Removed duplicated region for block: B:36:0x00b4 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:37:0x00b5  */
        /* JADX WARN: Removed duplicated region for block: B:40:0x00c5  */
        /* JADX WARN: Removed duplicated region for block: B:46:0x00e6  */
        /* JADX WARN: Removed duplicated region for block: B:57:0x0115  */
        /* JADX WARN: Removed duplicated region for block: B:66:0x014e  */
        /* JADX WARN: Removed duplicated region for block: B:68:0x00d6 A[EDGE_INSN: B:68:0x00d6->B:44:0x00d6 BREAK  A[LOOP:0: B:39:0x00c3->B:43:0x00d3], SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:72:0x006d A[SYNTHETIC] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:37:0x00b5 -> B:38:0x00b8). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            int i2;
            Object objAwaitPointerEvent;
            C0918p c0918p;
            int size;
            int i3;
            int size2;
            int i4;
            Object objAwaitPointerEvent2;
            androidx.compose.ui.input.pointer.C c2;
            androidx.compose.ui.input.pointer.C c3;
            Z0.a aVar = Z0.a.f1616b;
            int i5 = this.label;
            Object obj2 = null;
            boolean z2 = true;
            z2 = true;
            z2 = true;
            if (i5 == 0) {
                AbstractC0292a.H(obj);
                interfaceC0905c = (InterfaceC0905c) this.L$0;
                i2 = 0;
                if (i2 != 0) {
                }
            } else if (i5 == 1) {
                i2 = this.I$0;
                interfaceC0905c = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
                objAwaitPointerEvent = obj;
                c0918p = (C0918p) objAwaitPointerEvent;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i3 = 0;
                while (true) {
                    if (i3 >= size) {
                    }
                    i3++;
                }
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                size2 = changes2.size();
                while (i4 < size2) {
                }
                if (h0.isDeepPress(c0918p)) {
                }
                androidx.compose.ui.input.pointer.r rVar = androidx.compose.ui.input.pointer.r.Final;
                this.L$0 = interfaceC0905c;
                this.L$1 = c0918p;
                this.I$0 = i2;
                this.label = 2;
                objAwaitPointerEvent2 = interfaceC0905c.awaitPointerEvent(rVar, this);
                if (objAwaitPointerEvent2 != aVar) {
                }
            } else {
                if (i5 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                i2 = this.I$0;
                C0918p c0918p2 = (C0918p) this.L$1;
                InterfaceC0905c interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
                objAwaitPointerEvent2 = obj;
                List<androidx.compose.ui.input.pointer.C> changes3 = ((C0918p) objAwaitPointerEvent2).getChanges();
                int size3 = changes3.size();
                int i6 = 0;
                while (true) {
                    if (i6 >= size3) {
                        break;
                    }
                    if (changes3.get(i6).isConsumed()) {
                        i2 = z2 ? 1 : 0;
                        break;
                    }
                    i6++;
                }
                if (!AbstractC0391o.m859isPointerUpDmW0f2w(c0918p2, ((androidx.compose.ui.input.pointer.C) this.$currentDown.f3118b).m3657getIdJ3iCeTQ())) {
                    List<androidx.compose.ui.input.pointer.C> changes4 = c0918p2.getChanges();
                    int size4 = changes4.size();
                    int i7 = 0;
                    while (true) {
                        if (i7 >= size4) {
                            c3 = null;
                            break;
                        }
                        c3 = changes4.get(i7);
                        if (c3.getPressed()) {
                            break;
                        }
                        i7++;
                    }
                    androidx.compose.ui.input.pointer.C c4 = c3;
                    if (c4 != null) {
                        this.$currentDown.f3118b = c4;
                        this.$longPress.f3118b = c4;
                    } else {
                        i2 = z2 ? 1 : 0;
                        interfaceC0905c = interfaceC0905c2;
                        obj2 = null;
                        if (i2 != 0) {
                            return U0.n.f1521a;
                        }
                        androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Main;
                        this.L$0 = interfaceC0905c;
                        this.L$1 = obj2;
                        this.I$0 = i2;
                        this.label = z2 ? 1 : 0;
                        objAwaitPointerEvent = interfaceC0905c.awaitPointerEvent(rVar2, this);
                        if (objAwaitPointerEvent == aVar) {
                            return aVar;
                        }
                        c0918p = (C0918p) objAwaitPointerEvent;
                        List<androidx.compose.ui.input.pointer.C> changes5 = c0918p.getChanges();
                        size = changes5.size();
                        i3 = 0;
                        while (true) {
                            if (i3 >= size) {
                                i2 = z2 ? 1 : 0;
                                break;
                            }
                            if (!AbstractC0919q.changedToUpIgnoreConsumed(changes5.get(i3))) {
                                break;
                            }
                            i3++;
                        }
                        List<androidx.compose.ui.input.pointer.C> changes22 = c0918p.getChanges();
                        size2 = changes22.size();
                        for (i4 = 0; i4 < size2; i4++) {
                            androidx.compose.ui.input.pointer.C c5 = changes22.get(i4);
                            if (c5.isConsumed() || AbstractC0919q.m3770isOutOfBoundsjwHxaWs(c5, interfaceC0905c.mo3734getSizeYbymL2g(), interfaceC0905c.mo3733getExtendedTouchPaddingNHjbRc())) {
                                break;
                            }
                        }
                        if (h0.isDeepPress(c0918p)) {
                            this.$deepPress.f3114b = z2;
                            i2 = z2 ? 1 : 0;
                        }
                        androidx.compose.ui.input.pointer.r rVar3 = androidx.compose.ui.input.pointer.r.Final;
                        this.L$0 = interfaceC0905c;
                        this.L$1 = c0918p;
                        this.I$0 = i2;
                        this.label = 2;
                        objAwaitPointerEvent2 = interfaceC0905c.awaitPointerEvent(rVar3, this);
                        if (objAwaitPointerEvent2 != aVar) {
                            return aVar;
                        }
                        interfaceC0905c2 = interfaceC0905c;
                        c0918p2 = c0918p;
                        List<androidx.compose.ui.input.pointer.C> changes32 = ((C0918p) objAwaitPointerEvent2).getChanges();
                        int size32 = changes32.size();
                        int i62 = 0;
                        while (true) {
                            if (i62 >= size32) {
                            }
                            i62++;
                        }
                        if (!AbstractC0391o.m859isPointerUpDmW0f2w(c0918p2, ((androidx.compose.ui.input.pointer.C) this.$currentDown.f3118b).m3657getIdJ3iCeTQ())) {
                            kotlin.jvm.internal.E e2 = this.$longPress;
                            List<androidx.compose.ui.input.pointer.C> changes6 = c0918p2.getChanges();
                            kotlin.jvm.internal.E e3 = this.$currentDown;
                            int size5 = changes6.size();
                            int i8 = 0;
                            while (true) {
                                if (i8 >= size5) {
                                    c2 = null;
                                    break;
                                }
                                c2 = changes6.get(i8);
                                kotlin.jvm.internal.E e4 = e3;
                                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), ((androidx.compose.ui.input.pointer.C) e3.f3118b).m3657getIdJ3iCeTQ())) {
                                    break;
                                }
                                i8++;
                                e3 = e4;
                            }
                            e2.f3118b = c2;
                        }
                    }
                }
                interfaceC0905c = interfaceC0905c2;
                obj2 = null;
                z2 = true;
                if (i2 != 0) {
                }
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$h */
    public static final class h extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public h(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m848awaitPointerSlopOrCancellation6ksA65w(null, 0L, 0, null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$i */
    public static final class i extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public i(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m851awaitTouchSlopOrCancellationjO51t88(null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$j */
    public static final class j extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public j(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m852awaitVerticalDragOrCancellationrnUCldI(null, 0L, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$k */
    public static final class k extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public k(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m853awaitVerticalPointerSlopOrCancellationgDDlDlE(null, 0L, 0, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$l */
    public static final class l extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public l(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m854awaitVerticalTouchSlopOrCancellationjO51t88(null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$m */
    public static final class m extends a1.i implements h1.e {
        final /* synthetic */ h1.e $onDrag;
        final /* synthetic */ h1.a $onDragCancel;
        final /* synthetic */ h1.c $onDragEnd;
        final /* synthetic */ h1.f $onDragStart;
        final /* synthetic */ I $orientationLock;
        final /* synthetic */ kotlin.jvm.internal.D $overSlop;
        final /* synthetic */ h1.a $shouldAwaitTouchSlop;
        float F$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        boolean Z$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public m(h1.a aVar, kotlin.jvm.internal.D d2, I i2, h1.f fVar, h1.e eVar, h1.a aVar2, h1.c cVar, Y0.c cVar2) {
            super(cVar2);
            this.$shouldAwaitTouchSlop = aVar;
            this.$overSlop = d2;
            this.$orientationLock = i2;
            this.$onDragStart = fVar;
            this.$onDrag = eVar;
            this.$onDragCancel = aVar2;
            this.$onDragEnd = cVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            m mVar = new m(this.$shouldAwaitTouchSlop, this.$overSlop, this.$orientationLock, this.$onDragStart, this.$onDrag, this.$onDragCancel, this.$onDragEnd, cVar);
            mVar.L$0 = obj;
            return mVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((m) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:169:0x04b3, code lost:
        
            if (androidx.compose.foundation.gestures.AbstractC0391o.m859isPointerUpDmW0f2w(r2.getCurrentEvent(), r0) != false) goto L170;
         */
        /* JADX WARN: Code restructure failed: missing block: B:211:0x0565, code lost:
        
            if (r6 == false) goto L212;
         */
        /* JADX WARN: Code restructure failed: missing block: B:26:0x0161, code lost:
        
            if (r15 == false) goto L80;
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Path cross not found for [B:127:0x03ba, B:128:0x03be], limit reached: 234 */
        /* JADX WARN: Path cross not found for [B:131:0x03c5, B:127:0x03ba], limit reached: 234 */
        /* JADX WARN: Path cross not found for [B:187:0x0513, B:199:0x053e], limit reached: 234 */
        /* JADX WARN: Path cross not found for [B:43:0x01e4, B:44:0x01e8], limit reached: 234 */
        /* JADX WARN: Path cross not found for [B:47:0x01ef, B:43:0x01e4], limit reached: 234 */
        /* JADX WARN: Removed duplicated region for block: B:104:0x0303  */
        /* JADX WARN: Removed duplicated region for block: B:117:0x0382 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:120:0x0390  */
        /* JADX WARN: Removed duplicated region for block: B:128:0x03be  */
        /* JADX WARN: Removed duplicated region for block: B:133:0x03cb  */
        /* JADX WARN: Removed duplicated region for block: B:144:0x03ff  */
        /* JADX WARN: Removed duplicated region for block: B:158:0x0457  */
        /* JADX WARN: Removed duplicated region for block: B:159:0x045c  */
        /* JADX WARN: Removed duplicated region for block: B:164:0x0483  */
        /* JADX WARN: Removed duplicated region for block: B:170:0x04b5  */
        /* JADX WARN: Removed duplicated region for block: B:174:0x04dd A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:177:0x04eb  */
        /* JADX WARN: Removed duplicated region for block: B:184:0x050b  */
        /* JADX WARN: Removed duplicated region for block: B:185:0x050d  */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0139  */
        /* JADX WARN: Removed duplicated region for block: B:219:0x0579  */
        /* JADX WARN: Removed duplicated region for block: B:223:0x058c  */
        /* JADX WARN: Removed duplicated region for block: B:228:0x0505 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:234:0x02f8 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:238:0x046c A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:23:0x0152 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:240:0x03b0 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:244:0x01dc A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0153  */
        /* JADX WARN: Removed duplicated region for block: B:29:0x017f  */
        /* JADX WARN: Removed duplicated region for block: B:30:0x0182  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x01b1 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:36:0x01bf  */
        /* JADX WARN: Removed duplicated region for block: B:44:0x01e8  */
        /* JADX WARN: Removed duplicated region for block: B:49:0x01f5  */
        /* JADX WARN: Removed duplicated region for block: B:60:0x021e  */
        /* JADX WARN: Removed duplicated region for block: B:75:0x0271  */
        /* JADX WARN: Removed duplicated region for block: B:79:0x027d  */
        /* JADX WARN: Removed duplicated region for block: B:82:0x0284 A[ADDED_TO_REGION] */
        /* JADX WARN: Removed duplicated region for block: B:85:0x0295  */
        /* JADX WARN: Removed duplicated region for block: B:93:0x02ce  */
        /* JADX WARN: Type inference failed for: r0v34 */
        /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.Object] */
        /* JADX WARN: Type inference failed for: r0v45, types: [h1.e] */
        /* JADX WARN: Type inference failed for: r0v47 */
        /* JADX WARN: Type inference failed for: r0v66 */
        /* JADX WARN: Type inference failed for: r0v67 */
        /* JADX WARN: Type inference failed for: r14v23 */
        /* JADX WARN: Type inference failed for: r14v5, types: [androidx.compose.ui.input.pointer.r, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r14v6 */
        /* JADX WARN: Type inference failed for: r1v12 */
        /* JADX WARN: Type inference failed for: r1v15 */
        /* JADX WARN: Type inference failed for: r1v16, types: [androidx.compose.ui.input.pointer.C] */
        /* JADX WARN: Type inference failed for: r1v19 */
        /* JADX WARN: Type inference failed for: r1v35, types: [androidx.compose.ui.input.pointer.C, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r1v39 */
        /* JADX WARN: Type inference failed for: r1v4 */
        /* JADX WARN: Type inference failed for: r1v45 */
        /* JADX WARN: Type inference failed for: r1v46 */
        /* JADX WARN: Type inference failed for: r1v48, types: [androidx.compose.ui.input.pointer.C, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r1v50, types: [androidx.compose.ui.input.pointer.C] */
        /* JADX WARN: Type inference failed for: r1v53 */
        /* JADX WARN: Type inference failed for: r1v6 */
        /* JADX WARN: Type inference failed for: r1v61 */
        /* JADX WARN: Type inference failed for: r1v62 */
        /* JADX WARN: Type inference failed for: r1v63 */
        /* JADX WARN: Type inference failed for: r20v3 */
        /* JADX WARN: Type inference failed for: r3v33, types: [h1.f] */
        /* JADX WARN: Type inference failed for: r8v14 */
        /* JADX WARN: Type inference failed for: r8v15, types: [androidx.compose.foundation.gestures.k0, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r8v16, types: [java.lang.Object] */
        /* JADX WARN: Type inference failed for: r8v23, types: [androidx.compose.foundation.gestures.k0] */
        /* JADX WARN: Type inference failed for: r8v32 */
        /* JADX WARN: Type inference failed for: r8v35 */
        /* JADX WARN: Type inference failed for: r8v40 */
        /* JADX WARN: Type inference failed for: r8v41 */
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:148:0x0421 -> B:80:0x0280). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:155:0x0450 -> B:156:0x0451). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:161:0x046c -> B:80:0x0280). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:173:0x04db -> B:175:0x04de). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x017f -> B:74:0x026f). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x0182 -> B:31:0x0198). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:59:0x0217 -> B:66:0x0243). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:65:0x0240 -> B:66:0x0243). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:70:0x0264 -> B:71:0x0267). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:98:0x02ef -> B:88:0x02a6). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            Object objAwaitFirstDown;
            boolean zBooleanValue;
            Object objAwaitFirstDown$default;
            InterfaceC0905c interfaceC0905c2;
            androidx.compose.ui.input.pointer.C c2;
            androidx.compose.ui.input.pointer.C c3;
            kotlin.jvm.internal.D d2;
            k0 k0Var;
            kotlin.jvm.internal.D d3;
            InterfaceC0905c interfaceC0905c3;
            androidx.compose.ui.input.pointer.C c4;
            InterfaceC0905c interfaceC0905c4;
            float f2;
            androidx.compose.ui.input.pointer.C c5;
            androidx.compose.ui.input.pointer.C c6;
            int i2;
            ?? r14;
            androidx.compose.ui.input.pointer.C c7;
            Object objAwaitPointerEvent;
            float fM860pointerSlopE8SPZFQ;
            kotlin.jvm.internal.D d4;
            kotlin.jvm.internal.D d5;
            InterfaceC0905c interfaceC0905c5;
            ?? k0Var2;
            Object objAwaitPointerEvent$default;
            int size;
            int i3;
            androidx.compose.ui.input.pointer.C c8;
            InterfaceC0905c interfaceC0905c6;
            androidx.compose.ui.input.pointer.C c9;
            androidx.compose.ui.input.pointer.C c10;
            androidx.compose.ui.input.pointer.r rVar;
            androidx.compose.ui.input.pointer.C c11;
            ?? r02;
            int size2;
            int i4;
            int size3;
            int i5;
            long jM3657getIdJ3iCeTQ;
            h1.e eVar;
            I i6;
            ?? r12;
            androidx.compose.ui.input.pointer.C c12;
            androidx.compose.ui.input.pointer.C c13;
            androidx.compose.ui.input.pointer.C c14;
            m mVar = this;
            Z0.a aVar = Z0.a.f1616b;
            int i7 = 0;
            int i8 = 1;
            AbstractC1378g abstractC1378g = null;
            switch (mVar.label) {
                case 0:
                    AbstractC0292a.H(obj);
                    interfaceC0905c = (InterfaceC0905c) mVar.L$0;
                    androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Initial;
                    mVar.L$0 = interfaceC0905c;
                    mVar.label = 1;
                    objAwaitFirstDown = g0.awaitFirstDown(interfaceC0905c, false, rVar2, mVar);
                    if (objAwaitFirstDown == aVar) {
                        return aVar;
                    }
                    InterfaceC0905c interfaceC0905c7 = interfaceC0905c;
                    androidx.compose.ui.input.pointer.C c15 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown;
                    zBooleanValue = ((Boolean) mVar.$shouldAwaitTouchSlop.invoke()).booleanValue();
                    if (!zBooleanValue) {
                        c15.consume();
                    }
                    mVar.L$0 = interfaceC0905c7;
                    mVar.L$1 = c15;
                    mVar.Z$0 = zBooleanValue;
                    mVar.label = 2;
                    objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c7, false, null, this, 2, null);
                    if (objAwaitFirstDown$default != aVar) {
                        return aVar;
                    }
                    interfaceC0905c2 = interfaceC0905c7;
                    c2 = c15;
                    c3 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown$default;
                    mVar.$overSlop.f3117b = J.f.Companion.m66getZeroF1C5BW0();
                    break;
                    break;
                case 1:
                    interfaceC0905c = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    objAwaitFirstDown = obj;
                    InterfaceC0905c interfaceC0905c72 = interfaceC0905c;
                    androidx.compose.ui.input.pointer.C c152 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown;
                    zBooleanValue = ((Boolean) mVar.$shouldAwaitTouchSlop.invoke()).booleanValue();
                    if (!zBooleanValue) {
                    }
                    mVar.L$0 = interfaceC0905c72;
                    mVar.L$1 = c152;
                    mVar.Z$0 = zBooleanValue;
                    mVar.label = 2;
                    objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c72, false, null, this, 2, null);
                    if (objAwaitFirstDown$default != aVar) {
                    }
                    break;
                case 2:
                    boolean z2 = mVar.Z$0;
                    androidx.compose.ui.input.pointer.C c16 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    interfaceC0905c2 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    zBooleanValue = z2;
                    objAwaitFirstDown$default = obj;
                    c2 = c16;
                    c3 = (androidx.compose.ui.input.pointer.C) objAwaitFirstDown$default;
                    mVar.$overSlop.f3117b = J.f.Companion.m66getZeroF1C5BW0();
                    break;
                case 3:
                    float f3 = mVar.F$0;
                    k0 k0Var3 = (k0) mVar.L$5;
                    kotlin.jvm.internal.D d6 = (kotlin.jvm.internal.D) mVar.L$4;
                    kotlin.jvm.internal.D d7 = (kotlin.jvm.internal.D) mVar.L$3;
                    InterfaceC0905c interfaceC0905c8 = (InterfaceC0905c) mVar.L$2;
                    androidx.compose.ui.input.pointer.C c17 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    InterfaceC0905c interfaceC0905c9 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    d2 = d6;
                    interfaceC0905c2 = interfaceC0905c8;
                    k0Var = k0Var3;
                    float fM860pointerSlopE8SPZFQ2 = f3;
                    c3 = c17;
                    Object objAwaitPointerEvent$default2 = obj;
                    d3 = d7;
                    interfaceC0905c3 = interfaceC0905c9;
                    C0918p c0918p = (C0918p) objAwaitPointerEvent$default2;
                    List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                    int size4 = changes.size();
                    int i9 = i7;
                    while (true) {
                        if (i9 < size4) {
                            c4 = changes.get(i9);
                            i2 = i9;
                            if (!androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c4.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                                i9 = i2 + 1;
                            }
                        } else {
                            c4 = null;
                        }
                    }
                    androidx.compose.ui.input.pointer.C c18 = c4;
                    if (c18 != null && !c18.isConsumed()) {
                        if (AbstractC0919q.changedToUpIgnoreConsumed(c18)) {
                            long jM835addPointerInputChangedBAh8RU = k0Var.m835addPointerInputChangedBAh8RU(c18, fM860pointerSlopE8SPZFQ2);
                            if ((jM835addPointerInputChangedBAh8RU & 9223372034707292159L) != 9205357640488583168L) {
                                c18.consume();
                                d3.f3117b = jM835addPointerInputChangedBAh8RU;
                                if (c18.isConsumed()) {
                                    interfaceC0905c2 = interfaceC0905c3;
                                    c2 = c18;
                                    if (c2 != 0 && !c2.isConsumed()) {
                                        i7 = 0;
                                        i8 = 1;
                                        abstractC1378g = null;
                                        long jM3657getIdJ3iCeTQ2 = c3.m3657getIdJ3iCeTQ();
                                        int iM3662getTypeT8wyACA = c3.m3662getTypeT8wyACA();
                                        I i10 = mVar.$orientationLock;
                                        d3 = mVar.$overSlop;
                                        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
                                        if (!AbstractC0391o.m859isPointerUpDmW0f2w(interfaceC0905c2.getCurrentEvent(), jM3657getIdJ3iCeTQ2)) {
                                            c2 = abstractC1378g;
                                            if (c2 != 0) {
                                                i7 = 0;
                                                i8 = 1;
                                                abstractC1378g = null;
                                                long jM3657getIdJ3iCeTQ22 = c3.m3657getIdJ3iCeTQ();
                                                int iM3662getTypeT8wyACA2 = c3.m3662getTypeT8wyACA();
                                                I i102 = mVar.$orientationLock;
                                                d3 = mVar.$overSlop;
                                                long jM66getZeroF1C5BW02 = J.f.Companion.m66getZeroF1C5BW0();
                                                if (!AbstractC0391o.m859isPointerUpDmW0f2w(interfaceC0905c2.getCurrentEvent(), jM3657getIdJ3iCeTQ22)) {
                                                    fM860pointerSlopE8SPZFQ2 = AbstractC0391o.m860pointerSlopE8SPZFQ(interfaceC0905c2.getViewConfiguration(), iM3662getTypeT8wyACA2);
                                                    d2 = new kotlin.jvm.internal.D();
                                                    d2.f3117b = jM3657getIdJ3iCeTQ22;
                                                    k0Var = new k0(i102, jM66getZeroF1C5BW02, abstractC1378g);
                                                    interfaceC0905c3 = interfaceC0905c2;
                                                    r14 = abstractC1378g;
                                                    mVar.L$0 = interfaceC0905c3;
                                                    mVar.L$1 = c3;
                                                    mVar.L$2 = interfaceC0905c2;
                                                    mVar.L$3 = d3;
                                                    mVar.L$4 = d2;
                                                    mVar.L$5 = k0Var;
                                                    mVar.L$6 = r14;
                                                    mVar.F$0 = fM860pointerSlopE8SPZFQ2;
                                                    mVar.label = 3;
                                                    objAwaitPointerEvent$default2 = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, r14, mVar, i8, r14);
                                                    if (objAwaitPointerEvent$default2 == aVar) {
                                                        return aVar;
                                                    }
                                                    C0918p c0918p2 = (C0918p) objAwaitPointerEvent$default2;
                                                    List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                                                    int size42 = changes2.size();
                                                    int i92 = i7;
                                                    while (true) {
                                                        if (i92 < size42) {
                                                        }
                                                        i92 = i2 + 1;
                                                    }
                                                    androidx.compose.ui.input.pointer.C c182 = c4;
                                                    if (c182 != null) {
                                                        if (AbstractC0919q.changedToUpIgnoreConsumed(c182)) {
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (androidx.compose.foundation.A.DragGesturePickUpEnabled && c2 == 0) {
                                        List<androidx.compose.ui.input.pointer.C> changes3 = interfaceC0905c2.getCurrentEvent().getChanges();
                                        int size5 = changes3.size();
                                        int i11 = 0;
                                        while (i11 < size5) {
                                            if (changes3.get(i11).getPressed()) {
                                                ?? r20 = c2;
                                                c7 = c3;
                                                r02 = r20;
                                                androidx.compose.ui.input.pointer.r rVar3 = androidx.compose.ui.input.pointer.r.Final;
                                                mVar.L$0 = interfaceC0905c2;
                                                mVar.L$1 = c7;
                                                mVar.L$2 = r02;
                                                mVar.L$3 = null;
                                                mVar.L$4 = null;
                                                mVar.L$5 = null;
                                                mVar.L$6 = null;
                                                mVar.label = 5;
                                                objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar3, mVar);
                                                r02 = r02;
                                                if (objAwaitPointerEvent == aVar) {
                                                    return aVar;
                                                }
                                                C0918p c0918p3 = (C0918p) objAwaitPointerEvent;
                                                List<androidx.compose.ui.input.pointer.C> changes4 = c0918p3.getChanges();
                                                size2 = changes4.size();
                                                i4 = 0;
                                                while (true) {
                                                    if (i4 < size2) {
                                                        if (changes4.get(i4).isConsumed()) {
                                                            List<androidx.compose.ui.input.pointer.C> changes5 = c0918p3.getChanges();
                                                            int size6 = changes5.size();
                                                            for (int i12 = 0; i12 < size6; i12++) {
                                                                if (!changes5.get(i12).getPressed()) {
                                                                }
                                                            }
                                                        } else {
                                                            i4++;
                                                        }
                                                    }
                                                }
                                                List<androidx.compose.ui.input.pointer.C> changes6 = c0918p3.getChanges();
                                                size3 = changes6.size();
                                                i5 = 0;
                                                while (true) {
                                                    if (i5 >= size3) {
                                                        androidx.compose.ui.input.pointer.C c19 = c7;
                                                        c2 = r02;
                                                        c3 = c19;
                                                    } else if (changes6.get(i5).getPressed()) {
                                                        androidx.compose.ui.input.pointer.C c20 = (androidx.compose.ui.input.pointer.C) V0.t.v0(c0918p3.getChanges());
                                                        long jM54minusMKHz9U = J.f.m54minusMKHz9U(c20 != null ? c20.m3659getPositionF1C5BW0() : J.f.Companion.m66getZeroF1C5BW0(), c7.m3659getPositionF1C5BW0());
                                                        long jM3657getIdJ3iCeTQ3 = c7.m3657getIdJ3iCeTQ();
                                                        int iM3662getTypeT8wyACA3 = c7.m3662getTypeT8wyACA();
                                                        I i13 = mVar.$orientationLock;
                                                        d5 = mVar.$overSlop;
                                                        if (AbstractC0391o.m859isPointerUpDmW0f2w(interfaceC0905c2.getCurrentEvent(), jM3657getIdJ3iCeTQ3)) {
                                                            c3 = c7;
                                                            c2 = 0;
                                                        } else {
                                                            fM860pointerSlopE8SPZFQ = AbstractC0391o.m860pointerSlopE8SPZFQ(interfaceC0905c2.getViewConfiguration(), iM3662getTypeT8wyACA3);
                                                            d4 = new kotlin.jvm.internal.D();
                                                            d4.f3117b = jM3657getIdJ3iCeTQ3;
                                                            rVar = null;
                                                            k0Var2 = new k0(i13, jM54minusMKHz9U, false ? 1 : 0);
                                                            interfaceC0905c5 = interfaceC0905c2;
                                                        }
                                                    } else {
                                                        i5++;
                                                    }
                                                }
                                                mVar.L$0 = interfaceC0905c5;
                                                mVar.L$1 = c7;
                                                mVar.L$2 = interfaceC0905c2;
                                                mVar.L$3 = d5;
                                                mVar.L$4 = d4;
                                                mVar.L$5 = k0Var2;
                                                mVar.L$6 = rVar;
                                                mVar.F$0 = fM860pointerSlopE8SPZFQ;
                                                mVar.label = 6;
                                                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, mVar, 1, rVar);
                                                k0Var2 = k0Var2;
                                                if (objAwaitPointerEvent$default == aVar) {
                                                    return aVar;
                                                }
                                                C0918p c0918p4 = (C0918p) objAwaitPointerEvent$default;
                                                List<androidx.compose.ui.input.pointer.C> changes7 = c0918p4.getChanges();
                                                size = changes7.size();
                                                i3 = 0;
                                                while (true) {
                                                    if (i3 < size) {
                                                        androidx.compose.ui.input.pointer.C c21 = changes7.get(i3);
                                                        c8 = c7;
                                                        interfaceC0905c6 = interfaceC0905c2;
                                                        if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c21.m3657getIdJ3iCeTQ(), d4.f3117b)) {
                                                            c9 = c21;
                                                        } else {
                                                            i3++;
                                                            c7 = c8;
                                                            interfaceC0905c2 = interfaceC0905c6;
                                                        }
                                                    } else {
                                                        c8 = c7;
                                                        interfaceC0905c6 = interfaceC0905c2;
                                                        c9 = null;
                                                    }
                                                }
                                                c2 = c9;
                                                if (c2 != 0 && !c2.isConsumed()) {
                                                    if (AbstractC0919q.changedToUpIgnoreConsumed(c2)) {
                                                        if ((k0Var2.m835addPointerInputChangedBAh8RU(c2, fM860pointerSlopE8SPZFQ) & 9223372034707292159L) != 9205357640488583168L) {
                                                            c2.consume();
                                                            d5.f3117b = AbstractC0919q.positionChange(c2);
                                                            if (c2.isConsumed()) {
                                                                interfaceC0905c2 = interfaceC0905c5;
                                                                c3 = c8;
                                                                if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                                                                    List<androidx.compose.ui.input.pointer.C> changes32 = interfaceC0905c2.getCurrentEvent().getChanges();
                                                                    int size52 = changes32.size();
                                                                    int i112 = 0;
                                                                    while (i112 < size52) {
                                                                    }
                                                                }
                                                            } else {
                                                                k0Var2.reset();
                                                            }
                                                        } else {
                                                            androidx.compose.ui.input.pointer.r rVar4 = androidx.compose.ui.input.pointer.r.Final;
                                                            mVar.L$0 = interfaceC0905c5;
                                                            c10 = c8;
                                                            mVar.L$1 = c10;
                                                            InterfaceC0905c interfaceC0905c10 = interfaceC0905c6;
                                                            mVar.L$2 = interfaceC0905c10;
                                                            mVar.L$3 = d5;
                                                            mVar.L$4 = d4;
                                                            mVar.L$5 = k0Var2;
                                                            mVar.L$6 = c2;
                                                            mVar.F$0 = fM860pointerSlopE8SPZFQ;
                                                            mVar.label = 7;
                                                            if (interfaceC0905c10.awaitPointerEvent(rVar4, mVar) == aVar) {
                                                                return aVar;
                                                            }
                                                            interfaceC0905c2 = interfaceC0905c10;
                                                            r12 = c2;
                                                            k0Var2 = k0Var2;
                                                            if (r12.isConsumed()) {
                                                                c7 = c10;
                                                                rVar = null;
                                                                mVar.L$0 = interfaceC0905c5;
                                                                mVar.L$1 = c7;
                                                                mVar.L$2 = interfaceC0905c2;
                                                                mVar.L$3 = d5;
                                                                mVar.L$4 = d4;
                                                                mVar.L$5 = k0Var2;
                                                                mVar.L$6 = rVar;
                                                                mVar.F$0 = fM860pointerSlopE8SPZFQ;
                                                                mVar.label = 6;
                                                                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, mVar, 1, rVar);
                                                                k0Var2 = k0Var2;
                                                                if (objAwaitPointerEvent$default == aVar) {
                                                                }
                                                                C0918p c0918p42 = (C0918p) objAwaitPointerEvent$default;
                                                                List<androidx.compose.ui.input.pointer.C> changes72 = c0918p42.getChanges();
                                                                size = changes72.size();
                                                                i3 = 0;
                                                                while (true) {
                                                                    if (i3 < size) {
                                                                    }
                                                                    i3++;
                                                                    c7 = c8;
                                                                    interfaceC0905c2 = interfaceC0905c6;
                                                                }
                                                                c2 = c9;
                                                                if (c2 != 0) {
                                                                    if (AbstractC0919q.changedToUpIgnoreConsumed(c2)) {
                                                                        List<androidx.compose.ui.input.pointer.C> changes8 = c0918p42.getChanges();
                                                                        int size7 = changes8.size();
                                                                        int i14 = 0;
                                                                        while (true) {
                                                                            if (i14 < size7) {
                                                                                androidx.compose.ui.input.pointer.C c22 = changes8.get(i14);
                                                                                if (c22.getPressed()) {
                                                                                    c11 = c22;
                                                                                } else {
                                                                                    i14++;
                                                                                }
                                                                            } else {
                                                                                c11 = null;
                                                                            }
                                                                        }
                                                                        androidx.compose.ui.input.pointer.C c23 = c11;
                                                                        if (c23 != null) {
                                                                            d4.f3117b = c23.m3657getIdJ3iCeTQ();
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                interfaceC0905c2 = interfaceC0905c5;
                                                                c3 = c10;
                                                                c2 = 0;
                                                                if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                                                                }
                                                            }
                                                        }
                                                    }
                                                    c7 = c8;
                                                    interfaceC0905c2 = interfaceC0905c6;
                                                    rVar = null;
                                                    mVar.L$0 = interfaceC0905c5;
                                                    mVar.L$1 = c7;
                                                    mVar.L$2 = interfaceC0905c2;
                                                    mVar.L$3 = d5;
                                                    mVar.L$4 = d4;
                                                    mVar.L$5 = k0Var2;
                                                    mVar.L$6 = rVar;
                                                    mVar.F$0 = fM860pointerSlopE8SPZFQ;
                                                    mVar.label = 6;
                                                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, mVar, 1, rVar);
                                                    k0Var2 = k0Var2;
                                                    if (objAwaitPointerEvent$default == aVar) {
                                                    }
                                                    C0918p c0918p422 = (C0918p) objAwaitPointerEvent$default;
                                                    List<androidx.compose.ui.input.pointer.C> changes722 = c0918p422.getChanges();
                                                    size = changes722.size();
                                                    i3 = 0;
                                                    while (true) {
                                                        if (i3 < size) {
                                                        }
                                                        i3++;
                                                        c7 = c8;
                                                        interfaceC0905c2 = interfaceC0905c6;
                                                    }
                                                    c2 = c9;
                                                    if (c2 != 0) {
                                                    }
                                                }
                                                interfaceC0905c2 = interfaceC0905c5;
                                                c3 = c8;
                                                c2 = 0;
                                                if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                                                }
                                            } else {
                                                i112++;
                                            }
                                        }
                                    }
                                    if (c2 != 0) {
                                        mVar.$onDragStart.invoke(c3, c2, J.f.m39boximpl(mVar.$overSlop.f3117b));
                                        mVar.$onDrag.invoke(c2, J.f.m39boximpl(mVar.$overSlop.f3117b));
                                        jM3657getIdJ3iCeTQ = c2.m3657getIdJ3iCeTQ();
                                        eVar = mVar.$onDrag;
                                        i6 = androidx.compose.foundation.A.DragGesturePickUpEnabled ? null : mVar.$orientationLock;
                                        break;
                                    }
                                    return U0.n.f1521a;
                                }
                                k0Var.reset();
                            } else {
                                androidx.compose.ui.input.pointer.r rVar5 = androidx.compose.ui.input.pointer.r.Final;
                                mVar.L$0 = interfaceC0905c3;
                                mVar.L$1 = c3;
                                mVar.L$2 = interfaceC0905c2;
                                mVar.L$3 = d3;
                                mVar.L$4 = d2;
                                mVar.L$5 = k0Var;
                                mVar.L$6 = c182;
                                mVar.F$0 = fM860pointerSlopE8SPZFQ2;
                                mVar.label = 4;
                                if (interfaceC0905c2.awaitPointerEvent(rVar5, mVar) == aVar) {
                                    return aVar;
                                }
                                interfaceC0905c4 = interfaceC0905c2;
                                f2 = fM860pointerSlopE8SPZFQ2;
                                c5 = c182;
                                if (!c5.isConsumed()) {
                                    fM860pointerSlopE8SPZFQ2 = f2;
                                    interfaceC0905c2 = interfaceC0905c4;
                                }
                            }
                        } else {
                            List<androidx.compose.ui.input.pointer.C> changes9 = c0918p2.getChanges();
                            int size8 = changes9.size();
                            int i15 = 0;
                            while (true) {
                                if (i15 < size8) {
                                    c6 = changes9.get(i15);
                                    if (!c6.getPressed()) {
                                        i15++;
                                    }
                                } else {
                                    c6 = null;
                                }
                            }
                            androidx.compose.ui.input.pointer.C c24 = c6;
                            if (c24 != null) {
                                d2.f3117b = c24.m3657getIdJ3iCeTQ();
                            }
                        }
                        i7 = 0;
                        i8 = 1;
                        r14 = 0;
                        mVar.L$0 = interfaceC0905c3;
                        mVar.L$1 = c3;
                        mVar.L$2 = interfaceC0905c2;
                        mVar.L$3 = d3;
                        mVar.L$4 = d2;
                        mVar.L$5 = k0Var;
                        mVar.L$6 = r14;
                        mVar.F$0 = fM860pointerSlopE8SPZFQ2;
                        mVar.label = 3;
                        objAwaitPointerEvent$default2 = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, r14, mVar, i8, r14);
                        if (objAwaitPointerEvent$default2 == aVar) {
                        }
                        C0918p c0918p22 = (C0918p) objAwaitPointerEvent$default2;
                        List<androidx.compose.ui.input.pointer.C> changes22 = c0918p22.getChanges();
                        int size422 = changes22.size();
                        int i922 = i7;
                        while (true) {
                            if (i922 < size422) {
                            }
                            i922 = i2 + 1;
                        }
                        androidx.compose.ui.input.pointer.C c1822 = c4;
                        if (c1822 != null) {
                        }
                    }
                    interfaceC0905c2 = interfaceC0905c3;
                    c2 = 0;
                    if (c2 != 0) {
                    }
                    if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                    }
                    if (c2 != 0) {
                    }
                    return U0.n.f1521a;
                case 4:
                    float f4 = mVar.F$0;
                    c5 = (androidx.compose.ui.input.pointer.C) mVar.L$6;
                    k0 k0Var4 = (k0) mVar.L$5;
                    kotlin.jvm.internal.D d8 = (kotlin.jvm.internal.D) mVar.L$4;
                    kotlin.jvm.internal.D d9 = (kotlin.jvm.internal.D) mVar.L$3;
                    interfaceC0905c4 = (InterfaceC0905c) mVar.L$2;
                    androidx.compose.ui.input.pointer.C c25 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    InterfaceC0905c interfaceC0905c11 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    f2 = f4;
                    c3 = c25;
                    d3 = d9;
                    k0Var = k0Var4;
                    d2 = d8;
                    interfaceC0905c3 = interfaceC0905c11;
                    if (!c5.isConsumed()) {
                    }
                    interfaceC0905c2 = interfaceC0905c3;
                    c2 = 0;
                    if (c2 != 0) {
                    }
                    if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                    }
                    if (c2 != 0) {
                    }
                    return U0.n.f1521a;
                case 5:
                    androidx.compose.ui.input.pointer.C c26 = (androidx.compose.ui.input.pointer.C) mVar.L$2;
                    c7 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    interfaceC0905c2 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    objAwaitPointerEvent = obj;
                    r02 = c26;
                    C0918p c0918p32 = (C0918p) objAwaitPointerEvent;
                    List<androidx.compose.ui.input.pointer.C> changes42 = c0918p32.getChanges();
                    size2 = changes42.size();
                    i4 = 0;
                    while (true) {
                        if (i4 < size2) {
                        }
                        i4++;
                    }
                    List<androidx.compose.ui.input.pointer.C> changes62 = c0918p32.getChanges();
                    size3 = changes62.size();
                    i5 = 0;
                    while (true) {
                        if (i5 >= size3) {
                        }
                        i5++;
                    }
                    mVar.L$0 = interfaceC0905c5;
                    mVar.L$1 = c7;
                    mVar.L$2 = interfaceC0905c2;
                    mVar.L$3 = d5;
                    mVar.L$4 = d4;
                    mVar.L$5 = k0Var2;
                    mVar.L$6 = rVar;
                    mVar.F$0 = fM860pointerSlopE8SPZFQ;
                    mVar.label = 6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, mVar, 1, rVar);
                    k0Var2 = k0Var2;
                    if (objAwaitPointerEvent$default == aVar) {
                    }
                    C0918p c0918p4222 = (C0918p) objAwaitPointerEvent$default;
                    List<androidx.compose.ui.input.pointer.C> changes7222 = c0918p4222.getChanges();
                    size = changes7222.size();
                    i3 = 0;
                    while (true) {
                        if (i3 < size) {
                        }
                        i3++;
                        c7 = c8;
                        interfaceC0905c2 = interfaceC0905c6;
                    }
                    c2 = c9;
                    if (c2 != 0) {
                    }
                    interfaceC0905c2 = interfaceC0905c5;
                    c3 = c8;
                    c2 = 0;
                    if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                    }
                    if (c2 != 0) {
                    }
                    return U0.n.f1521a;
                case 6:
                    fM860pointerSlopE8SPZFQ = mVar.F$0;
                    k0 k0Var5 = (k0) mVar.L$5;
                    kotlin.jvm.internal.D d10 = (kotlin.jvm.internal.D) mVar.L$4;
                    kotlin.jvm.internal.D d11 = (kotlin.jvm.internal.D) mVar.L$3;
                    InterfaceC0905c interfaceC0905c12 = (InterfaceC0905c) mVar.L$2;
                    androidx.compose.ui.input.pointer.C c27 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    InterfaceC0905c interfaceC0905c13 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    d4 = d10;
                    d5 = d11;
                    interfaceC0905c2 = interfaceC0905c12;
                    interfaceC0905c5 = interfaceC0905c13;
                    k0Var2 = k0Var5;
                    c7 = c27;
                    objAwaitPointerEvent$default = obj;
                    C0918p c0918p42222 = (C0918p) objAwaitPointerEvent$default;
                    List<androidx.compose.ui.input.pointer.C> changes72222 = c0918p42222.getChanges();
                    size = changes72222.size();
                    i3 = 0;
                    while (true) {
                        if (i3 < size) {
                        }
                        i3++;
                        c7 = c8;
                        interfaceC0905c2 = interfaceC0905c6;
                    }
                    c2 = c9;
                    if (c2 != 0) {
                    }
                    interfaceC0905c2 = interfaceC0905c5;
                    c3 = c8;
                    c2 = 0;
                    if (androidx.compose.foundation.A.DragGesturePickUpEnabled) {
                    }
                    if (c2 != 0) {
                    }
                    return U0.n.f1521a;
                case 7:
                    fM860pointerSlopE8SPZFQ = mVar.F$0;
                    androidx.compose.ui.input.pointer.C c28 = (androidx.compose.ui.input.pointer.C) mVar.L$6;
                    k0 k0Var6 = (k0) mVar.L$5;
                    kotlin.jvm.internal.D d12 = (kotlin.jvm.internal.D) mVar.L$4;
                    kotlin.jvm.internal.D d13 = (kotlin.jvm.internal.D) mVar.L$3;
                    InterfaceC0905c interfaceC0905c14 = (InterfaceC0905c) mVar.L$2;
                    androidx.compose.ui.input.pointer.C c29 = (androidx.compose.ui.input.pointer.C) mVar.L$1;
                    InterfaceC0905c interfaceC0905c15 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    d4 = d12;
                    d5 = d13;
                    interfaceC0905c5 = interfaceC0905c15;
                    k0Var2 = k0Var6;
                    interfaceC0905c2 = interfaceC0905c14;
                    c10 = c29;
                    r12 = c28;
                    if (r12.isConsumed()) {
                    }
                    break;
                case 8:
                    kotlin.jvm.internal.D d14 = (kotlin.jvm.internal.D) mVar.L$4;
                    InterfaceC0905c interfaceC0905c16 = (InterfaceC0905c) mVar.L$3;
                    I i16 = (I) mVar.L$2;
                    eVar = (h1.e) mVar.L$1;
                    InterfaceC0905c interfaceC0905c17 = (InterfaceC0905c) mVar.L$0;
                    AbstractC0292a.H(obj);
                    Object objAwaitPointerEvent$default3 = obj;
                    boolean z3 = true;
                    C0918p c0918p5 = (C0918p) objAwaitPointerEvent$default3;
                    List<androidx.compose.ui.input.pointer.C> changes10 = c0918p5.getChanges();
                    int size9 = changes10.size();
                    int i17 = 0;
                    while (true) {
                        if (i17 < size9) {
                            c13 = changes10.get(i17);
                            if (!androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c13.m3657getIdJ3iCeTQ(), d14.f3117b)) {
                                i17++;
                            }
                        } else {
                            c13 = null;
                        }
                    }
                    androidx.compose.ui.input.pointer.C c30 = c13;
                    if (c30 == null) {
                        if (!AbstractC0919q.changedToUpIgnoreConsumed(c30)) {
                            long jPositionChangeIgnoreConsumed = AbstractC0919q.positionChangeIgnoreConsumed(c30);
                            break;
                        } else {
                            List<androidx.compose.ui.input.pointer.C> changes11 = c0918p5.getChanges();
                            int size10 = changes11.size();
                            int i18 = 0;
                            while (true) {
                                if (i18 < size10) {
                                    c14 = changes11.get(i18);
                                    if (!c14.getPressed()) {
                                        i18++;
                                    }
                                } else {
                                    c14 = null;
                                }
                            }
                            androidx.compose.ui.input.pointer.C c31 = c14;
                            if (c31 != null) {
                                d14.f3117b = c31.m3657getIdJ3iCeTQ();
                                mVar = this;
                                mVar.L$0 = interfaceC0905c17;
                                mVar.L$1 = eVar;
                                mVar.L$2 = i16;
                                mVar.L$3 = interfaceC0905c16;
                                mVar.L$4 = d14;
                                mVar.L$5 = null;
                                mVar.L$6 = null;
                                mVar.label = 8;
                                z3 = true;
                                objAwaitPointerEvent$default3 = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c16, null, mVar, 1, null);
                                if (objAwaitPointerEvent$default3 == aVar) {
                                    return aVar;
                                }
                                C0918p c0918p52 = (C0918p) objAwaitPointerEvent$default3;
                                List<androidx.compose.ui.input.pointer.C> changes102 = c0918p52.getChanges();
                                int size92 = changes102.size();
                                int i172 = 0;
                                while (true) {
                                    if (i172 < size92) {
                                    }
                                    i172++;
                                }
                                androidx.compose.ui.input.pointer.C c302 = c13;
                                if (c302 == null) {
                                    c302 = null;
                                }
                            }
                        }
                    }
                    if (c302 == null && !c302.isConsumed()) {
                        if (AbstractC0919q.changedToUpIgnoreConsumed(c302)) {
                            mVar = this;
                            eVar.invoke(c302, J.f.m39boximpl(AbstractC0919q.positionChange(c302)));
                            c302.consume();
                            jM3657getIdJ3iCeTQ = c302.m3657getIdJ3iCeTQ();
                            InterfaceC0905c interfaceC0905c18 = interfaceC0905c17;
                            i6 = i16;
                            interfaceC0905c2 = interfaceC0905c18;
                            kotlin.jvm.internal.D d15 = new kotlin.jvm.internal.D();
                            d15.f3117b = jM3657getIdJ3iCeTQ;
                            interfaceC0905c16 = interfaceC0905c2;
                            d14 = d15;
                            i16 = i6;
                            interfaceC0905c17 = interfaceC0905c16;
                            mVar.L$0 = interfaceC0905c17;
                            mVar.L$1 = eVar;
                            mVar.L$2 = i16;
                            mVar.L$3 = interfaceC0905c16;
                            mVar.L$4 = d14;
                            mVar.L$5 = null;
                            mVar.L$6 = null;
                            mVar.label = 8;
                            z3 = true;
                            objAwaitPointerEvent$default3 = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c16, null, mVar, 1, null);
                            if (objAwaitPointerEvent$default3 == aVar) {
                            }
                            C0918p c0918p522 = (C0918p) objAwaitPointerEvent$default3;
                            List<androidx.compose.ui.input.pointer.C> changes1022 = c0918p522.getChanges();
                            int size922 = changes1022.size();
                            int i1722 = 0;
                            while (true) {
                                if (i1722 < size922) {
                                }
                                i1722++;
                            }
                            androidx.compose.ui.input.pointer.C c3022 = c13;
                            if (c3022 == null) {
                            }
                            if (c3022 == null) {
                                c12 = null;
                            } else if (AbstractC0919q.changedToUpIgnoreConsumed(c3022)) {
                            }
                            return U0.n.f1521a;
                        }
                        c12 = c3022;
                    }
                    if (c12 == null) {
                        this.$onDragCancel.invoke();
                    } else {
                        this.$onDragEnd.invoke(c12);
                    }
                    return U0.n.f1521a;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$n */
    public static final class n extends a1.i implements h1.e {
        final /* synthetic */ h1.e $onDrag;
        final /* synthetic */ h1.a $onDragCancel;
        final /* synthetic */ h1.a $onDragEnd;
        final /* synthetic */ h1.c $onDragStart;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public n(h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
            super(cVar2);
            this.$onDragStart = cVar;
            this.$onDragEnd = aVar;
            this.$onDragCancel = aVar2;
            this.$onDrag = eVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(h1.e eVar, androidx.compose.ui.input.pointer.C c2) {
            eVar.invoke(c2, J.f.m39boximpl(AbstractC0919q.positionChange(c2)));
            c2.consume();
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            n nVar = new n(this.$onDragStart, this.$onDragEnd, this.$onDragCancel, this.$onDrag, cVar);
            nVar.L$0 = obj;
            return nVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((n) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:29:0x0061 A[Catch: CancellationException -> 0x0018, TryCatch #0 {CancellationException -> 0x0018, blocks: (B:8:0x0013, B:33:0x0086, B:35:0x008e, B:37:0x009d, B:39:0x00a9, B:40:0x00ac, B:41:0x00af, B:42:0x00b5, B:15:0x0027, B:27:0x005d, B:29:0x0061, B:18:0x002f, B:24:0x004c, B:21:0x003b), top: B:47:0x0007 }] */
        /* JADX WARN: Removed duplicated region for block: B:35:0x008e A[Catch: CancellationException -> 0x0018, TryCatch #0 {CancellationException -> 0x0018, blocks: (B:8:0x0013, B:33:0x0086, B:35:0x008e, B:37:0x009d, B:39:0x00a9, B:40:0x00ac, B:41:0x00af, B:42:0x00b5, B:15:0x0027, B:27:0x005d, B:29:0x0061, B:18:0x002f, B:24:0x004c, B:21:0x003b), top: B:47:0x0007 }] */
        /* JADX WARN: Removed duplicated region for block: B:42:0x00b5 A[Catch: CancellationException -> 0x0018, TRY_LEAVE, TryCatch #0 {CancellationException -> 0x0018, blocks: (B:8:0x0013, B:33:0x0086, B:35:0x008e, B:37:0x009d, B:39:0x00a9, B:40:0x00ac, B:41:0x00af, B:42:0x00b5, B:15:0x0027, B:27:0x005d, B:29:0x0061, B:18:0x002f, B:24:0x004c, B:21:0x003b), top: B:47:0x0007 }] */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            androidx.compose.ui.input.pointer.C c2;
            InterfaceC0905c interfaceC0905c2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            try {
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    interfaceC0905c = (InterfaceC0905c) this.L$0;
                    this.L$0 = interfaceC0905c;
                    this.label = 1;
                    obj = g0.awaitFirstDown$default(interfaceC0905c, false, null, this, 2, null);
                    if (obj == aVar) {
                        return aVar;
                    }
                } else {
                    if (i2 != 1) {
                        if (i2 != 2) {
                            if (i2 != 3) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                            AbstractC0292a.H(obj);
                            if (((Boolean) obj).booleanValue()) {
                                this.$onDragCancel.invoke();
                            } else {
                                List<androidx.compose.ui.input.pointer.C> changes = interfaceC0905c2.getCurrentEvent().getChanges();
                                int size = changes.size();
                                for (int i3 = 0; i3 < size; i3++) {
                                    androidx.compose.ui.input.pointer.C c3 = changes.get(i3);
                                    if (AbstractC0919q.changedToUp(c3)) {
                                        c3.consume();
                                    }
                                }
                                this.$onDragEnd.invoke();
                            }
                            return U0.n.f1521a;
                        }
                        interfaceC0905c = (InterfaceC0905c) this.L$0;
                        AbstractC0292a.H(obj);
                        c2 = (androidx.compose.ui.input.pointer.C) obj;
                        if (c2 != null) {
                            this.$onDragStart.invoke(J.f.m39boximpl(c2.m3659getPositionF1C5BW0()));
                            long jM3657getIdJ3iCeTQ = c2.m3657getIdJ3iCeTQ();
                            C0331r0 c0331r0 = new C0331r0(1, this.$onDrag);
                            this.L$0 = interfaceC0905c;
                            this.label = 3;
                            obj = AbstractC0391o.m857dragjO51t88(interfaceC0905c, jM3657getIdJ3iCeTQ, c0331r0, this);
                            if (obj == aVar) {
                                return aVar;
                            }
                            interfaceC0905c2 = interfaceC0905c;
                            if (((Boolean) obj).booleanValue()) {
                            }
                        }
                        return U0.n.f1521a;
                    }
                    interfaceC0905c = (InterfaceC0905c) this.L$0;
                    AbstractC0292a.H(obj);
                }
                long jM3657getIdJ3iCeTQ2 = ((androidx.compose.ui.input.pointer.C) obj).m3657getIdJ3iCeTQ();
                this.L$0 = interfaceC0905c;
                this.label = 2;
                obj = AbstractC0391o.m847awaitLongPressOrCancellationrnUCldI(interfaceC0905c, jM3657getIdJ3iCeTQ2, this);
                if (obj == aVar) {
                    return aVar;
                }
                c2 = (androidx.compose.ui.input.pointer.C) obj;
                if (c2 != null) {
                }
                return U0.n.f1521a;
            } catch (CancellationException e2) {
                this.$onDragCancel.invoke();
                throw e2;
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$o, reason: collision with other inner class name */
    public static final class C0031o extends a1.i implements h1.e {
        final /* synthetic */ h1.a $onDragCancel;
        final /* synthetic */ h1.a $onDragEnd;
        final /* synthetic */ h1.c $onDragStart;
        final /* synthetic */ h1.e $onHorizontalDrag;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0031o(h1.c cVar, h1.e eVar, h1.a aVar, h1.a aVar2, Y0.c cVar2) {
            super(cVar2);
            this.$onDragStart = cVar;
            this.$onHorizontalDrag = eVar;
            this.$onDragEnd = aVar;
            this.$onDragCancel = aVar2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.B b2, androidx.compose.ui.input.pointer.C c2, float f2) {
            c2.consume();
            b2.f3115b = f2;
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$1(h1.e eVar, androidx.compose.ui.input.pointer.C c2) {
            eVar.invoke(c2, Float.valueOf(Float.intBitsToFloat((int) (AbstractC0919q.positionChange(c2) >> 32))));
            c2.consume();
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            C0031o c0031o = new C0031o(this.$onDragStart, this.$onHorizontalDrag, this.$onDragEnd, this.$onDragCancel, cVar);
            c0031o.L$0 = obj;
            return c0031o;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((C0031o) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
        /* JADX WARN: Removed duplicated region for block: B:27:0x00b0  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x00b6  */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            InterfaceC0905c interfaceC0905c2;
            kotlin.jvm.internal.B b2;
            androidx.compose.ui.input.pointer.C c2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) this.L$0;
                this.L$0 = interfaceC0905c3;
                this.label = 1;
                Object objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c3, false, null, this, 2, null);
                if (objAwaitFirstDown$default == aVar) {
                    return aVar;
                }
                interfaceC0905c = interfaceC0905c3;
                obj = objAwaitFirstDown$default;
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                        if (((Boolean) obj).booleanValue()) {
                            this.$onDragCancel.invoke();
                        } else {
                            this.$onDragEnd.invoke();
                        }
                        return U0.n.f1521a;
                    }
                    b2 = (kotlin.jvm.internal.B) this.L$1;
                    interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                    AbstractC0292a.H(obj);
                    c2 = (androidx.compose.ui.input.pointer.C) obj;
                    if (c2 != null) {
                        this.$onDragStart.invoke(J.f.m39boximpl(c2.m3659getPositionF1C5BW0()));
                        this.$onHorizontalDrag.invoke(c2, new Float(b2.f3115b));
                        long jM3657getIdJ3iCeTQ = c2.m3657getIdJ3iCeTQ();
                        C0331r0 c0331r0 = new C0331r0(2, this.$onHorizontalDrag);
                        this.L$0 = null;
                        this.L$1 = null;
                        this.label = 3;
                        obj = AbstractC0391o.m858horizontalDragjO51t88(interfaceC0905c2, jM3657getIdJ3iCeTQ, c0331r0, this);
                        if (obj == aVar) {
                            return aVar;
                        }
                        if (((Boolean) obj).booleanValue()) {
                        }
                    }
                    return U0.n.f1521a;
                }
                interfaceC0905c = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
            }
            androidx.compose.ui.input.pointer.C c3 = (androidx.compose.ui.input.pointer.C) obj;
            kotlin.jvm.internal.B b3 = new kotlin.jvm.internal.B();
            long jM3657getIdJ3iCeTQ2 = c3.m3657getIdJ3iCeTQ();
            int iM3662getTypeT8wyACA = c3.m3662getTypeT8wyACA();
            C0392p c0392p = new C0392p(b3, 0);
            this.L$0 = interfaceC0905c;
            this.L$1 = b3;
            this.label = 2;
            obj = AbstractC0391o.m845awaitHorizontalPointerSlopOrCancellationgDDlDlE(interfaceC0905c, jM3657getIdJ3iCeTQ2, iM3662getTypeT8wyACA, c0392p, this);
            if (obj == aVar) {
                return aVar;
            }
            interfaceC0905c2 = interfaceC0905c;
            b2 = b3;
            c2 = (androidx.compose.ui.input.pointer.C) obj;
            if (c2 != null) {
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$p */
    public static final class p extends a1.i implements h1.e {
        final /* synthetic */ h1.a $onDragCancel;
        final /* synthetic */ h1.a $onDragEnd;
        final /* synthetic */ h1.c $onDragStart;
        final /* synthetic */ h1.e $onVerticalDrag;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public p(h1.c cVar, h1.e eVar, h1.a aVar, h1.a aVar2, Y0.c cVar2) {
            super(cVar2);
            this.$onDragStart = cVar;
            this.$onVerticalDrag = eVar;
            this.$onDragEnd = aVar;
            this.$onDragCancel = aVar2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.B b2, androidx.compose.ui.input.pointer.C c2, float f2) {
            c2.consume();
            b2.f3115b = f2;
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$1(h1.e eVar, androidx.compose.ui.input.pointer.C c2) {
            eVar.invoke(c2, Float.valueOf(Float.intBitsToFloat((int) (AbstractC0919q.positionChange(c2) & 4294967295L))));
            c2.consume();
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            p pVar = new p(this.$onDragStart, this.$onVerticalDrag, this.$onDragEnd, this.$onDragCancel, cVar);
            pVar.L$0 = obj;
            return pVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((p) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
        /* JADX WARN: Removed duplicated region for block: B:27:0x00b0  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x00b6  */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            InterfaceC0905c interfaceC0905c;
            InterfaceC0905c interfaceC0905c2;
            kotlin.jvm.internal.B b2;
            androidx.compose.ui.input.pointer.C c2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) this.L$0;
                this.L$0 = interfaceC0905c3;
                this.label = 1;
                Object objAwaitFirstDown$default = g0.awaitFirstDown$default(interfaceC0905c3, false, null, this, 2, null);
                if (objAwaitFirstDown$default == aVar) {
                    return aVar;
                }
                interfaceC0905c = interfaceC0905c3;
                obj = objAwaitFirstDown$default;
            } else {
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                        if (((Boolean) obj).booleanValue()) {
                            this.$onDragCancel.invoke();
                        } else {
                            this.$onDragEnd.invoke();
                        }
                        return U0.n.f1521a;
                    }
                    b2 = (kotlin.jvm.internal.B) this.L$1;
                    interfaceC0905c2 = (InterfaceC0905c) this.L$0;
                    AbstractC0292a.H(obj);
                    c2 = (androidx.compose.ui.input.pointer.C) obj;
                    if (c2 != null) {
                        this.$onDragStart.invoke(J.f.m39boximpl(c2.m3659getPositionF1C5BW0()));
                        this.$onVerticalDrag.invoke(c2, new Float(b2.f3115b));
                        long jM3657getIdJ3iCeTQ = c2.m3657getIdJ3iCeTQ();
                        C0331r0 c0331r0 = new C0331r0(3, this.$onVerticalDrag);
                        this.L$0 = null;
                        this.L$1 = null;
                        this.label = 3;
                        obj = AbstractC0391o.m861verticalDragjO51t88(interfaceC0905c2, jM3657getIdJ3iCeTQ, c0331r0, this);
                        if (obj == aVar) {
                            return aVar;
                        }
                        if (((Boolean) obj).booleanValue()) {
                        }
                    }
                    return U0.n.f1521a;
                }
                interfaceC0905c = (InterfaceC0905c) this.L$0;
                AbstractC0292a.H(obj);
            }
            androidx.compose.ui.input.pointer.C c3 = (androidx.compose.ui.input.pointer.C) obj;
            kotlin.jvm.internal.B b3 = new kotlin.jvm.internal.B();
            long jM3657getIdJ3iCeTQ2 = c3.m3657getIdJ3iCeTQ();
            int iM3662getTypeT8wyACA = c3.m3662getTypeT8wyACA();
            C0392p c0392p = new C0392p(b3, 1);
            this.L$0 = interfaceC0905c;
            this.L$1 = b3;
            this.label = 2;
            obj = AbstractC0391o.m853awaitVerticalPointerSlopOrCancellationgDDlDlE(interfaceC0905c, jM3657getIdJ3iCeTQ2, iM3662getTypeT8wyACA, c0392p, this);
            if (obj == aVar) {
                return aVar;
            }
            interfaceC0905c2 = interfaceC0905c;
            b2 = b3;
            c2 = (androidx.compose.ui.input.pointer.C) obj;
            if (c2 != null) {
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$q */
    public static final class q extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public q(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m857dragjO51t88(null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$r */
    public static final class r extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        int label;
        /* synthetic */ Object result;

        public r(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m855dragVnAYq1g(null, 0L, null, null, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$s */
    public static final class s extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public s(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m858horizontalDragjO51t88(null, 0L, null, this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.o$t */
    public static final class t extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        int label;
        /* synthetic */ Object result;

        public t(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0391o.m861verticalDragjO51t88(null, 0L, null, this);
        }
    }

    static {
        float fM5076constructorimpl = C1311h.m5076constructorimpl((float) 0.125d);
        mouseSlop = fM5076constructorimpl;
        float fM5076constructorimpl2 = C1311h.m5076constructorimpl(18);
        defaultTouchSlop = fM5076constructorimpl2;
        mouseToTouchSlopRatio = fM5076constructorimpl / fM5076constructorimpl2;
    }

    /* JADX WARN: Path cross not found for [B:32:0x00c6, B:38:0x00e2], limit reached: 69 */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0094 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00c1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00ff A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0095 -> B:23:0x0097). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object awaitAllPointersUpWithSlopDetection(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.C c2, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar) {
        a aVar;
        k0 k0Var;
        kotlin.jvm.internal.D d2;
        float f2;
        int i2;
        InterfaceC0905c interfaceC0905c2;
        a aVar2;
        androidx.compose.ui.input.pointer.r rVar2;
        Object objAwaitPointerEvent;
        androidx.compose.ui.input.pointer.C c3;
        int size;
        int i3;
        androidx.compose.ui.input.pointer.C c4;
        androidx.compose.ui.input.pointer.C c5;
        if (cVar instanceof a) {
            aVar = (a) cVar;
            int i4 = aVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                aVar.label = i4 - Integer.MIN_VALUE;
            } else {
                aVar = new a(cVar);
            }
        }
        Object obj = aVar.result;
        Z0.a aVar3 = Z0.a.f1616b;
        int i5 = aVar.label;
        int i6 = 1;
        if (i5 != 0) {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f3 = aVar.F$0;
            int i7 = aVar.I$0;
            k0 k0Var2 = (k0) aVar.L$3;
            d2 = (kotlin.jvm.internal.D) aVar.L$2;
            androidx.compose.ui.input.pointer.r rVar3 = (androidx.compose.ui.input.pointer.r) aVar.L$1;
            InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) aVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var2;
            i2 = i7;
            f2 = f3;
            aVar2 = aVar;
            rVar2 = rVar3;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size2 = changes.size();
            int i8 = 0;
            while (true) {
                if (i8 < size2) {
                    c3 = null;
                    break;
                }
                androidx.compose.ui.input.pointer.C c6 = changes.get(i8);
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c6.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                    c3 = c6;
                    break;
                }
                i8++;
            }
            androidx.compose.ui.input.pointer.C c7 = c3;
            if (c7 != null || AbstractC0919q.changedToUpIgnoreConsumed(c7)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                size = changes2.size();
                i3 = 0;
                while (true) {
                    if (i3 < size) {
                        c4 = null;
                        break;
                    }
                    androidx.compose.ui.input.pointer.C c8 = changes2.get(i3);
                    if (c8.getPressed()) {
                        c4 = c8;
                        break;
                    }
                    i3++;
                }
                c5 = c4;
                if (c5 != null) {
                    return Boolean.valueOf(i2 != 0);
                }
                d2.f3117b = c5.m3657getIdJ3iCeTQ();
            } else if ((k0Var.m835addPointerInputChangedBAh8RU(c7, f2) & 9223372034707292159L) != 9205357640488583168L) {
                i2 = 1;
            }
            List<androidx.compose.ui.input.pointer.C> changes3 = c0918p.getChanges();
            int size3 = changes3.size();
            for (int i9 = 0; i9 < size3; i9++) {
                if (changes3.get(i9).getPressed()) {
                    interfaceC0905c2 = interfaceC0905c3;
                    i6 = 1;
                    aVar2.L$0 = interfaceC0905c2;
                    aVar2.L$1 = rVar2;
                    aVar2.L$2 = d2;
                    aVar2.L$3 = k0Var;
                    aVar2.I$0 = i2;
                    aVar2.F$0 = f2;
                    aVar2.label = i6;
                    objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar2, aVar2);
                    if (objAwaitPointerEvent != aVar3) {
                        return aVar3;
                    }
                    interfaceC0905c3 = interfaceC0905c2;
                    obj = objAwaitPointerEvent;
                    C0918p c0918p2 = (C0918p) obj;
                    List<androidx.compose.ui.input.pointer.C> changes4 = c0918p2.getChanges();
                    int size22 = changes4.size();
                    int i82 = 0;
                    while (true) {
                        if (i82 < size22) {
                        }
                        i82++;
                    }
                    androidx.compose.ui.input.pointer.C c72 = c3;
                    if (c72 != null) {
                    }
                    List<androidx.compose.ui.input.pointer.C> changes22 = c0918p2.getChanges();
                    size = changes22.size();
                    i3 = 0;
                    while (true) {
                        if (i3 < size) {
                        }
                        i3++;
                    }
                    c5 = c4;
                    if (c5 != null) {
                    }
                }
            }
            return Boolean.valueOf(i2 != 0);
        }
        AbstractC0292a.H(obj);
        if (A.allPointersUp(interfaceC0905c)) {
            return Boolean.FALSE;
        }
        kotlin.jvm.internal.D d3 = new kotlin.jvm.internal.D();
        d3.f3117b = c2.m3657getIdJ3iCeTQ();
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), c2.m3662getTypeT8wyACA());
        k0Var = new k0(null, 0L, 3, null);
        d2 = d3;
        f2 = fM860pointerSlopE8SPZFQ;
        i2 = 0;
        interfaceC0905c2 = interfaceC0905c;
        aVar2 = aVar;
        rVar2 = rVar;
        aVar2.L$0 = interfaceC0905c2;
        aVar2.L$1 = rVar2;
        aVar2.L$2 = d2;
        aVar2.L$3 = k0Var;
        aVar2.I$0 = i2;
        aVar2.F$0 = f2;
        aVar2.label = i6;
        objAwaitPointerEvent = interfaceC0905c2.awaitPointerEvent(rVar2, aVar2);
        if (objAwaitPointerEvent != aVar3) {
        }
    }

    public static /* synthetic */ Object awaitAllPointersUpWithSlopDetection$default(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.C c2, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Main;
        }
        return awaitAllPointersUpWithSlopDetection(interfaceC0905c, c2, rVar, cVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:46:0x00c8, code lost:
    
        if (androidx.compose.ui.input.pointer.AbstractC0919q.positionChangedIgnoreConsumed(r11) != false) goto L47;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0064 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x008f A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0065 -> B:22:0x006a). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitDragOrCancellation-rnUCldI, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m842awaitDragOrCancellationrnUCldI(InterfaceC0905c interfaceC0905c, long j2, Y0.c cVar) {
        b bVar;
        kotlin.jvm.internal.D d2;
        InterfaceC0905c interfaceC0905c2;
        Object objAwaitPointerEvent$default;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        if (cVar instanceof b) {
            bVar = (b) cVar;
            int i2 = bVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                bVar.label = i2 - Integer.MIN_VALUE;
            } else {
                bVar = new b(cVar);
            }
        }
        Object obj = bVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = bVar.label;
        if (i3 != 0) {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) bVar.L$1;
            InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) bVar.L$0;
            AbstractC0292a.H(obj);
            kotlin.jvm.internal.D d4 = d3;
            interfaceC0905c2 = interfaceC0905c3;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i4 = 0;
            int i5 = 0;
            while (true) {
                if (i5 < size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i5);
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d4.f3117b)) {
                    break;
                }
                i5++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                    List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                    int size2 = changes2.size();
                    while (true) {
                        if (i4 >= size2) {
                            c3 = null;
                            break;
                        }
                        c3 = changes2.get(i4);
                        if (c3.getPressed()) {
                            break;
                        }
                        i4++;
                    }
                    androidx.compose.ui.input.pointer.C c5 = c3;
                    if (c5 != null) {
                        d4.f3117b = c5.m3657getIdJ3iCeTQ();
                        d2 = d4;
                    }
                }
                bVar.L$0 = interfaceC0905c2;
                bVar.L$1 = d2;
                bVar.label = 1;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, bVar, 1, null);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                kotlin.jvm.internal.D d5 = d2;
                obj = objAwaitPointerEvent$default;
                d4 = d5;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                int size3 = changes3.size();
                int i42 = 0;
                int i52 = 0;
                while (true) {
                    if (i52 < size3) {
                    }
                    i52++;
                }
                androidx.compose.ui.input.pointer.C c42 = c2;
                if (c42 == null) {
                    c42 = null;
                }
            }
            if (c42 == null || c42.isConsumed()) {
                return null;
            }
            return c42;
        }
        AbstractC0292a.H(obj);
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        interfaceC0905c2 = interfaceC0905c;
        bVar.L$0 = interfaceC0905c2;
        bVar.L$1 = d2;
        bVar.label = 1;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, bVar, 1, null);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX INFO: renamed from: awaitDragOrUp-jO51t88, reason: not valid java name */
    private static final Object m843awaitDragOrUpjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, Y0.c cVar2) {
        androidx.compose.ui.input.pointer.C c2;
        while (true) {
            androidx.compose.ui.input.pointer.C c3 = null;
            C0918p c0918p = (C0918p) InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, cVar2, 1, null);
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i2 = 0;
            int i3 = 0;
            while (true) {
                if (i3 >= size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i3);
                if (Boolean.valueOf(androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), j2)).booleanValue()) {
                    break;
                }
                i3++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                while (true) {
                    if (i2 >= size2) {
                        break;
                    }
                    androidx.compose.ui.input.pointer.C c5 = changes2.get(i2);
                    if (Boolean.valueOf(c5.getPressed()).booleanValue()) {
                        c3 = c5;
                        break;
                    }
                    i2++;
                }
                androidx.compose.ui.input.pointer.C c6 = c3;
                if (c6 == null) {
                    return c4;
                }
                j2 = c6.m3657getIdJ3iCeTQ();
            } else if (((Boolean) cVar.invoke(c4)).booleanValue()) {
                return c4;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:48:0x00d6, code lost:
    
        if ((java.lang.Float.intBitsToFloat((int) (androidx.compose.ui.input.pointer.AbstractC0919q.positionChangeIgnoreConsumed(r11) >> 32)) == 0.0f ? 1 : 0) == 0) goto L49;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0064 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x008f A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0065 -> B:22:0x006a). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitHorizontalDragOrCancellation-rnUCldI, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m844awaitHorizontalDragOrCancellationrnUCldI(InterfaceC0905c interfaceC0905c, long j2, Y0.c cVar) {
        c cVar2;
        kotlin.jvm.internal.D d2;
        InterfaceC0905c interfaceC0905c2;
        Object objAwaitPointerEvent$default;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i2 = cVar2.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                cVar2.label = i2 - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(cVar);
            }
        }
        Object obj = cVar2.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = cVar2.label;
        if (i3 != 0) {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) cVar2.L$1;
            InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) cVar2.L$0;
            AbstractC0292a.H(obj);
            kotlin.jvm.internal.D d4 = d3;
            interfaceC0905c2 = interfaceC0905c3;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i4 = 0;
            while (true) {
                if (i4 < size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i4);
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d4.f3117b)) {
                    break;
                }
                i4++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                    List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                    int size2 = changes2.size();
                    while (true) {
                        if (i >= size2) {
                            c3 = null;
                            break;
                        }
                        c3 = changes2.get(i);
                        if (c3.getPressed()) {
                            break;
                        }
                        i++;
                    }
                    androidx.compose.ui.input.pointer.C c5 = c3;
                    if (c5 != null) {
                        d4.f3117b = c5.m3657getIdJ3iCeTQ();
                        d2 = d4;
                    }
                }
                cVar2.L$0 = interfaceC0905c2;
                cVar2.L$1 = d2;
                cVar2.label = 1;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, cVar2, 1, null);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                kotlin.jvm.internal.D d5 = d2;
                obj = objAwaitPointerEvent$default;
                d4 = d5;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                int size3 = changes3.size();
                int i42 = 0;
                while (true) {
                    if (i42 < size3) {
                    }
                    i42++;
                }
                androidx.compose.ui.input.pointer.C c42 = c2;
                if (c42 == null) {
                    c42 = null;
                }
            }
            if (c42 == null || c42.isConsumed()) {
                return null;
            }
            return c42;
        }
        AbstractC0292a.H(obj);
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        interfaceC0905c2 = interfaceC0905c;
        cVar2.L$0 = interfaceC0905c2;
        cVar2.L$1 = d2;
        cVar2.label = 1;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, cVar2, 1, null);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00b6 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0181  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00e7 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x0172 -> B:61:0x0178). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitHorizontalPointerSlopOrCancellation-gDDlDlE, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m845awaitHorizontalPointerSlopOrCancellationgDDlDlE(InterfaceC0905c interfaceC0905c, long j2, int i2, h1.e eVar, Y0.c cVar) {
        d dVar;
        float fM860pointerSlopE8SPZFQ;
        kotlin.jvm.internal.D d2;
        h1.e eVar2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        float f2;
        d dVar2;
        k0 k0Var2;
        int size;
        int i3;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        int i4;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof d) {
            dVar = (d) cVar;
            int i5 = dVar.label;
            if ((i5 & Integer.MIN_VALUE) != 0) {
                dVar.label = i5 - Integer.MIN_VALUE;
            } else {
                dVar = new d(cVar);
            }
        }
        Object obj = dVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i6 = dVar.label;
        int i7 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        if (i6 != 0) {
            if (i6 == 1) {
                float f3 = dVar.F$0;
                k0 k0Var3 = (k0) dVar.L$3;
                kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) dVar.L$2;
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) dVar.L$1;
                h1.e eVar3 = (h1.e) dVar.L$0;
                AbstractC0292a.H(obj);
                d2 = d3;
                dVar2 = dVar;
                k0Var2 = k0Var3;
                eVar2 = eVar3;
                f2 = f3;
                interfaceC0905c2 = interfaceC0905c3;
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i3 = 0;
                while (true) {
                    if (i3 < size) {
                    }
                    i3 = i4 + 1;
                }
                c3 = c2;
                if (c3 != null) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                    }
                    dVar.L$0 = eVar2;
                    dVar.L$1 = interfaceC0905c2;
                    dVar.L$2 = d2;
                    dVar.L$3 = k0Var;
                    dVar.L$4 = rVar;
                    dVar.F$0 = fM860pointerSlopE8SPZFQ;
                    dVar.label = i7;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, dVar, i7, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
                return null;
            }
            if (i6 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f4 = dVar.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) dVar.L$4;
            k0 k0Var4 = (k0) dVar.L$3;
            kotlin.jvm.internal.D d4 = (kotlin.jvm.internal.D) dVar.L$2;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) dVar.L$1;
            h1.e eVar4 = (h1.e) dVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            fM860pointerSlopE8SPZFQ = f4;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                eVar2 = eVar4;
                i7 = 1;
                rVar = null;
                d2 = d4;
                dVar.L$0 = eVar2;
                dVar.L$1 = interfaceC0905c2;
                dVar.L$2 = d2;
                dVar.L$3 = k0Var;
                dVar.L$4 = rVar;
                dVar.F$0 = fM860pointerSlopE8SPZFQ;
                dVar.label = i7;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, dVar, i7, rVar);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                d dVar3 = dVar;
                k0Var2 = k0Var;
                obj = objAwaitPointerEvent$default;
                f2 = fM860pointerSlopE8SPZFQ;
                dVar2 = dVar3;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                size = changes2.size();
                i3 = 0;
                while (true) {
                    if (i3 < size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes2.get(i3);
                    i4 = i3;
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                        break;
                    }
                    i3 = i4 + 1;
                }
                c3 = c2;
                if (c3 != null && !c3.isConsumed()) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                        long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f2);
                        if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                            eVar2.invoke(c3, new Float(Float.intBitsToFloat((int) (jM835addPointerInputChangedBAh8RU >> 32))));
                            if (c3.isConsumed()) {
                                return c3;
                            }
                            k0Var2.reset();
                            k0Var = k0Var2;
                            dVar = dVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            i7 = 1;
                            rVar = null;
                        } else {
                            androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                            dVar2.L$0 = eVar2;
                            dVar2.L$1 = interfaceC0905c2;
                            dVar2.L$2 = d2;
                            dVar2.L$3 = k0Var2;
                            dVar2.L$4 = c3;
                            dVar2.F$0 = f2;
                            dVar2.label = 2;
                            if (interfaceC0905c2.awaitPointerEvent(rVar2, dVar2) == aVar) {
                                return aVar;
                            }
                            k0Var = k0Var2;
                            dVar = dVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            d4 = d2;
                            eVar4 = eVar2;
                            c5 = c3;
                            if (!c5.isConsumed()) {
                            }
                        }
                    } else {
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size2 = changes3.size();
                        int i8 = 0;
                        while (true) {
                            if (i8 >= size2) {
                                c4 = null;
                                break;
                            }
                            c4 = changes3.get(i8);
                            if (c4.getPressed()) {
                                break;
                            }
                            i8++;
                        }
                        androidx.compose.ui.input.pointer.C c6 = c4;
                        if (c6 != null) {
                            d2.f3117b = c6.m3657getIdJ3iCeTQ();
                            k0Var = k0Var2;
                            dVar = dVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            i7 = 1;
                            rVar = null;
                        }
                    }
                    dVar.L$0 = eVar2;
                    dVar.L$1 = interfaceC0905c2;
                    dVar.L$2 = d2;
                    dVar.L$3 = k0Var;
                    dVar.L$4 = rVar;
                    dVar.F$0 = fM860pointerSlopE8SPZFQ;
                    dVar.label = i7;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, dVar, i7, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
            }
            return null;
        }
        AbstractC0292a.H(obj);
        I i9 = I.Horizontal;
        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), i2);
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        eVar2 = eVar;
        k0Var = new k0(i9, jM66getZeroF1C5BW0, objArr == true ? 1 : 0);
        interfaceC0905c2 = interfaceC0905c;
        dVar.L$0 = eVar2;
        dVar.L$1 = interfaceC0905c2;
        dVar.L$2 = d2;
        dVar.L$3 = k0Var;
        dVar.L$4 = rVar;
        dVar.F$0 = fM860pointerSlopE8SPZFQ;
        dVar.label = i7;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, dVar, i7, rVar);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00ba A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00bb  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0185  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00eb A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x0176 -> B:61:0x017c). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitHorizontalTouchSlopOrCancellation-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m846awaitHorizontalTouchSlopOrCancellationjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.e eVar, Y0.c cVar) {
        e eVar2;
        kotlin.jvm.internal.D d2;
        h1.e eVar3;
        e eVar4;
        float f2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        e eVar5;
        float f3;
        k0 k0Var2;
        int size;
        int i2;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        int i3;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof e) {
            eVar2 = (e) cVar;
            int i4 = eVar2.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                eVar2.label = i4 - Integer.MIN_VALUE;
            } else {
                eVar2 = new e(cVar);
            }
        }
        Object obj = eVar2.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = eVar2.label;
        int i6 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        if (i5 != 0) {
            if (i5 == 1) {
                float f4 = eVar2.F$0;
                k0 k0Var3 = (k0) eVar2.L$3;
                kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) eVar2.L$2;
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) eVar2.L$1;
                h1.e eVar6 = (h1.e) eVar2.L$0;
                AbstractC0292a.H(obj);
                d2 = d3;
                f3 = f4;
                interfaceC0905c2 = interfaceC0905c3;
                eVar5 = eVar2;
                k0Var2 = k0Var3;
                eVar3 = eVar6;
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                    }
                    eVar4.L$0 = eVar3;
                    eVar4.L$1 = interfaceC0905c2;
                    eVar4.L$2 = d2;
                    eVar4.L$3 = k0Var;
                    eVar4.L$4 = rVar;
                    eVar4.F$0 = f2;
                    eVar4.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, eVar4, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
                return null;
            }
            if (i5 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f5 = eVar2.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) eVar2.L$4;
            k0 k0Var4 = (k0) eVar2.L$3;
            kotlin.jvm.internal.D d4 = (kotlin.jvm.internal.D) eVar2.L$2;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) eVar2.L$1;
            h1.e eVar7 = (h1.e) eVar2.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            eVar4 = eVar2;
            f2 = f5;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                eVar3 = eVar7;
                i6 = 1;
                rVar = null;
                d2 = d4;
                eVar4.L$0 = eVar3;
                eVar4.L$1 = interfaceC0905c2;
                eVar4.L$2 = d2;
                eVar4.L$3 = k0Var;
                eVar4.L$4 = rVar;
                eVar4.F$0 = f2;
                eVar4.label = i6;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, eVar4, i6, rVar);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                float f6 = f2;
                k0Var2 = k0Var;
                obj = objAwaitPointerEvent$default;
                eVar5 = eVar4;
                f3 = f6;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                size = changes2.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes2.get(i2);
                    i3 = i2;
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                        break;
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null && !c3.isConsumed()) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                        long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f3);
                        if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                            eVar3.invoke(c3, new Float(Float.intBitsToFloat((int) (jM835addPointerInputChangedBAh8RU >> 32))));
                            if (c3.isConsumed()) {
                                return c3;
                            }
                            k0Var2.reset();
                            k0Var = k0Var2;
                            f2 = f3;
                            eVar4 = eVar5;
                            i6 = 1;
                            rVar = null;
                        } else {
                            androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                            eVar5.L$0 = eVar3;
                            eVar5.L$1 = interfaceC0905c2;
                            eVar5.L$2 = d2;
                            eVar5.L$3 = k0Var2;
                            eVar5.L$4 = c3;
                            eVar5.F$0 = f3;
                            eVar5.label = 2;
                            if (interfaceC0905c2.awaitPointerEvent(rVar2, eVar5) == aVar) {
                                return aVar;
                            }
                            k0Var = k0Var2;
                            f2 = f3;
                            eVar4 = eVar5;
                            d4 = d2;
                            eVar7 = eVar3;
                            c5 = c3;
                            if (!c5.isConsumed()) {
                            }
                        }
                    } else {
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size2 = changes3.size();
                        int i7 = 0;
                        while (true) {
                            if (i7 >= size2) {
                                c4 = null;
                                break;
                            }
                            c4 = changes3.get(i7);
                            if (c4.getPressed()) {
                                break;
                            }
                            i7++;
                        }
                        androidx.compose.ui.input.pointer.C c6 = c4;
                        if (c6 != null) {
                            d2.f3117b = c6.m3657getIdJ3iCeTQ();
                            k0Var = k0Var2;
                            f2 = f3;
                            eVar4 = eVar5;
                            i6 = 1;
                            rVar = null;
                        }
                    }
                    eVar4.L$0 = eVar3;
                    eVar4.L$1 = interfaceC0905c2;
                    eVar4.L$2 = d2;
                    eVar4.L$3 = k0Var;
                    eVar4.L$4 = rVar;
                    eVar4.F$0 = f2;
                    eVar4.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, eVar4, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
            }
            return null;
        }
        AbstractC0292a.H(obj);
        int iM3718getTouchT8wyACA = androidx.compose.ui.input.pointer.Q.Companion.m3718getTouchT8wyACA();
        I i8 = I.Horizontal;
        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), iM3718getTouchT8wyACA);
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        k0 k0Var5 = new k0(i8, jM66getZeroF1C5BW0, objArr == true ? 1 : 0);
        eVar3 = eVar;
        eVar4 = eVar2;
        f2 = fM860pointerSlopE8SPZFQ;
        k0Var = k0Var5;
        interfaceC0905c2 = interfaceC0905c;
        eVar4.L$0 = eVar3;
        eVar4.L$1 = interfaceC0905c2;
        eVar4.L$2 = d2;
        eVar4.L$3 = k0Var;
        eVar4.L$4 = rVar;
        eVar4.F$0 = f2;
        eVar4.label = i6;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, eVar4, i6, rVar);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r10v3, types: [kotlin.jvm.internal.E] */
    /* JADX WARN: Type inference failed for: r10v7 */
    /* JADX WARN: Type inference failed for: r10v8 */
    /* JADX INFO: renamed from: awaitLongPressOrCancellation-rnUCldI, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m847awaitLongPressOrCancellationrnUCldI(InterfaceC0905c interfaceC0905c, long j2, Y0.c cVar) {
        f fVar;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        kotlin.jvm.internal.A a2;
        if (cVar instanceof f) {
            fVar = (f) cVar;
            int i2 = fVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                fVar.label = i2 - Integer.MIN_VALUE;
            } else {
                fVar = new f(cVar);
            }
        }
        Object obj = fVar.result;
        Object obj2 = Z0.a.f1616b;
        int i3 = fVar.label;
        try {
            if (i3 == 0) {
                AbstractC0292a.H(obj);
                if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
                    return null;
                }
                List<androidx.compose.ui.input.pointer.C> changes = interfaceC0905c.getCurrentEvent().getChanges();
                int size = changes.size();
                int i4 = 0;
                while (true) {
                    if (i4 >= size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes.get(i4);
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), j2)) {
                        break;
                    }
                    i4++;
                }
                c3 = c2;
                if (c3 == null) {
                    return null;
                }
                kotlin.jvm.internal.E e2 = new kotlin.jvm.internal.E();
                kotlin.jvm.internal.E e3 = new kotlin.jvm.internal.E();
                e3.f3118b = c3;
                long longPressTimeoutMillis = interfaceC0905c.getViewConfiguration().getLongPressTimeoutMillis();
                kotlin.jvm.internal.A a3 = new kotlin.jvm.internal.A();
                h1.e gVar = new g(a3, e3, e2, null);
                fVar.L$0 = c3;
                fVar.L$1 = e2;
                fVar.L$2 = a3;
                fVar.label = 1;
                if (interfaceC0905c.withTimeout(longPressTimeoutMillis, gVar, fVar) == obj2) {
                    return obj2;
                }
                a2 = a3;
                j2 = e2;
            } else {
                if (i3 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                a2 = (kotlin.jvm.internal.A) fVar.L$2;
                kotlin.jvm.internal.E e4 = (kotlin.jvm.internal.E) fVar.L$1;
                c3 = (androidx.compose.ui.input.pointer.C) fVar.L$0;
                AbstractC0292a.H(obj);
                j2 = e4;
            }
            if (!a2.f3114b) {
                return null;
            }
            androidx.compose.ui.input.pointer.C c4 = (androidx.compose.ui.input.pointer.C) j2.f3118b;
            if (c4 != null) {
                return c4;
            }
        } catch (C0920s unused) {
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) j2.f3118b;
            if (c5 != null) {
                return c5;
            }
        }
        return c3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00b9 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0184 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0186  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00ef A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:62:0x0178 -> B:63:0x017e). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitPointerSlopOrCancellation-6ksA65w, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m848awaitPointerSlopOrCancellation6ksA65w(InterfaceC0905c interfaceC0905c, long j2, int i2, I i3, long j3, h1.e eVar, Y0.c cVar) {
        h hVar;
        h1.e eVar2;
        kotlin.jvm.internal.D d2;
        h hVar2;
        float f2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        kotlin.jvm.internal.D d3;
        h hVar3;
        float f3;
        k0 k0Var2;
        int size;
        int i4;
        h hVar4;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof h) {
            hVar = (h) cVar;
            int i5 = hVar.label;
            if ((i5 & Integer.MIN_VALUE) != 0) {
                hVar.label = i5 - Integer.MIN_VALUE;
            } else {
                hVar = new h(cVar);
            }
        }
        Object obj = hVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i6 = hVar.label;
        int i7 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        if (i6 == 0) {
            AbstractC0292a.H(obj);
            if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
                return null;
            }
            float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), i2);
            kotlin.jvm.internal.D d4 = new kotlin.jvm.internal.D();
            d4.f3117b = j2;
            eVar2 = eVar;
            d2 = d4;
            hVar2 = hVar;
            f2 = fM860pointerSlopE8SPZFQ;
            k0Var = new k0(i3, j3, objArr == true ? 1 : 0);
            interfaceC0905c2 = interfaceC0905c;
            hVar2.L$0 = interfaceC0905c2;
            hVar2.L$1 = eVar2;
            hVar2.L$2 = d2;
            hVar2.L$3 = k0Var;
            hVar2.L$4 = rVar;
            hVar2.F$0 = f2;
            hVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, hVar2, i7, rVar);
            if (objAwaitPointerEvent$default != aVar) {
            }
        } else if (i6 == 1) {
            float f4 = hVar.F$0;
            k0 k0Var3 = (k0) hVar.L$3;
            kotlin.jvm.internal.D d5 = (kotlin.jvm.internal.D) hVar.L$2;
            h1.e eVar3 = (h1.e) hVar.L$1;
            InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) hVar.L$0;
            AbstractC0292a.H(obj);
            f3 = f4;
            interfaceC0905c2 = interfaceC0905c3;
            d3 = d5;
            h hVar5 = hVar;
            k0Var2 = k0Var3;
            eVar2 = eVar3;
            hVar3 = hVar5;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            size = changes.size();
            int i8 = 0;
            i4 = 0;
            while (true) {
                if (i4 < size) {
                }
                i4++;
                hVar3 = hVar4;
            }
            c3 = c2;
            if (c3 != null) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
            }
            hVar2.L$0 = interfaceC0905c2;
            hVar2.L$1 = eVar2;
            hVar2.L$2 = d2;
            hVar2.L$3 = k0Var;
            hVar2.L$4 = rVar;
            hVar2.F$0 = f2;
            hVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, hVar2, i7, rVar);
            if (objAwaitPointerEvent$default != aVar) {
            }
        } else {
            if (i6 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f5 = hVar.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) hVar.L$4;
            k0 k0Var4 = (k0) hVar.L$3;
            d2 = (kotlin.jvm.internal.D) hVar.L$2;
            h1.e eVar4 = (h1.e) hVar.L$1;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) hVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            char c6 = 2;
            hVar2 = hVar;
            f2 = f5;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                return null;
            }
            eVar2 = eVar4;
            i7 = 1;
            rVar = null;
            hVar2.L$0 = interfaceC0905c2;
            hVar2.L$1 = eVar2;
            hVar2.L$2 = d2;
            hVar2.L$3 = k0Var;
            hVar2.L$4 = rVar;
            hVar2.F$0 = f2;
            hVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, hVar2, i7, rVar);
            if (objAwaitPointerEvent$default != aVar) {
                return aVar;
            }
            float f6 = f2;
            k0Var2 = k0Var;
            obj = objAwaitPointerEvent$default;
            d3 = d2;
            hVar3 = hVar2;
            f3 = f6;
            C0918p c0918p2 = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
            size = changes2.size();
            int i82 = 0;
            i4 = 0;
            while (true) {
                if (i4 < size) {
                    hVar4 = hVar3;
                    c2 = null;
                    break;
                }
                c2 = changes2.get(i4);
                hVar4 = hVar3;
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d3.f3117b)) {
                    break;
                }
                i4++;
                hVar3 = hVar4;
            }
            c3 = c2;
            if (c3 != null || c3.isConsumed()) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f3);
                if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                    eVar2.invoke(c3, J.f.m39boximpl(jM835addPointerInputChangedBAh8RU));
                    if (c3.isConsumed()) {
                        return c3;
                    }
                    k0Var2.reset();
                    k0Var = k0Var2;
                    f2 = f3;
                    d2 = d3;
                    i7 = 1;
                    rVar = null;
                    hVar2 = hVar4;
                } else {
                    androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                    h hVar6 = hVar4;
                    hVar6.L$0 = interfaceC0905c2;
                    hVar6.L$1 = eVar2;
                    hVar6.L$2 = d3;
                    hVar6.L$3 = k0Var2;
                    hVar6.L$4 = c3;
                    hVar6.F$0 = f3;
                    c6 = 2;
                    hVar6.label = 2;
                    if (interfaceC0905c2.awaitPointerEvent(rVar2, hVar6) == aVar) {
                        return aVar;
                    }
                    k0Var = k0Var2;
                    f2 = f3;
                    hVar2 = hVar6;
                    d2 = d3;
                    eVar4 = eVar2;
                    c5 = c3;
                    if (!c5.isConsumed()) {
                    }
                }
            } else {
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                int size2 = changes3.size();
                while (true) {
                    if (i82 >= size2) {
                        c4 = null;
                        break;
                    }
                    c4 = changes3.get(i82);
                    if (c4.getPressed()) {
                        break;
                    }
                    i82++;
                }
                androidx.compose.ui.input.pointer.C c7 = c4;
                if (c7 == null) {
                    return null;
                }
                d3.f3117b = c7.m3657getIdJ3iCeTQ();
                k0Var = k0Var2;
                f2 = f3;
                d2 = d3;
                i7 = 1;
                rVar = null;
                hVar2 = hVar4;
            }
            hVar2.L$0 = interfaceC0905c2;
            hVar2.L$1 = eVar2;
            hVar2.L$2 = d2;
            hVar2.L$3 = k0Var;
            hVar2.L$4 = rVar;
            hVar2.F$0 = f2;
            hVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, hVar2, i7, rVar);
            if (objAwaitPointerEvent$default != aVar) {
            }
        }
    }

    /* JADX INFO: renamed from: awaitPointerSlopOrCancellation-6ksA65w$$forInline, reason: not valid java name */
    private static final Object m849awaitPointerSlopOrCancellation6ksA65w$$forInline(InterfaceC0905c interfaceC0905c, long j2, int i2, I i3, long j3, h1.e eVar, Y0.c cVar) {
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        AbstractC1378g abstractC1378g = null;
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), i2);
        k0 k0Var = new k0(i3, j3, abstractC1378g);
        while (true) {
            C0918p c0918p = (C0918p) InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, cVar, 1, null);
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i4 = 0;
            int i5 = 0;
            while (true) {
                if (i5 >= size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i5);
                if (Boolean.valueOf(androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), j2)).booleanValue()) {
                    break;
                }
                i5++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null || c4.isConsumed()) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                while (true) {
                    if (i4 >= size2) {
                        c3 = null;
                        break;
                    }
                    c3 = changes2.get(i4);
                    if (Boolean.valueOf(c3.getPressed()).booleanValue()) {
                        break;
                    }
                    i4++;
                }
                androidx.compose.ui.input.pointer.C c5 = c3;
                if (c5 == null) {
                    return null;
                }
                j2 = c5.m3657getIdJ3iCeTQ();
            } else {
                long jM835addPointerInputChangedBAh8RU = k0Var.m835addPointerInputChangedBAh8RU(c4, fM860pointerSlopE8SPZFQ);
                if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                    eVar.invoke(c4, J.f.m39boximpl(jM835addPointerInputChangedBAh8RU));
                    if (c4.isConsumed()) {
                        return c4;
                    }
                    k0Var.reset();
                } else {
                    interfaceC0905c.awaitPointerEvent(androidx.compose.ui.input.pointer.r.Final, cVar);
                    if (c4.isConsumed()) {
                        break;
                    }
                }
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: awaitPointerSlopOrCancellation-6ksA65w$default, reason: not valid java name */
    public static /* synthetic */ Object m850awaitPointerSlopOrCancellation6ksA65w$default(InterfaceC0905c interfaceC0905c, long j2, int i2, I i3, long j3, h1.e eVar, Y0.c cVar, int i4, Object obj) {
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        if ((i4 & 8) != 0) {
            j3 = J.f.Companion.m66getZeroF1C5BW0();
        }
        AbstractC1378g abstractC1378g = null;
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), i2);
        k0 k0Var = new k0(i3, j3, abstractC1378g);
        while (true) {
            C0918p c0918p = (C0918p) InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, cVar, 1, null);
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i5 = 0;
            int i6 = 0;
            while (true) {
                if (i6 >= size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i6);
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), j2)) {
                    break;
                }
                i6++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null || c4.isConsumed()) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                while (true) {
                    if (i5 >= size2) {
                        c3 = null;
                        break;
                    }
                    c3 = changes2.get(i5);
                    if (c3.getPressed()) {
                        break;
                    }
                    i5++;
                }
                androidx.compose.ui.input.pointer.C c5 = c3;
                if (c5 == null) {
                    return null;
                }
                j2 = c5.m3657getIdJ3iCeTQ();
            } else {
                long jM835addPointerInputChangedBAh8RU = k0Var.m835addPointerInputChangedBAh8RU(c4, fM860pointerSlopE8SPZFQ);
                if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                    eVar.invoke(c4, J.f.m39boximpl(jM835addPointerInputChangedBAh8RU));
                    if (c4.isConsumed()) {
                        return c4;
                    }
                    k0Var.reset();
                } else {
                    interfaceC0905c.awaitPointerEvent(androidx.compose.ui.input.pointer.r.Final, cVar);
                    if (c4.isConsumed()) {
                        break;
                    }
                }
            }
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00bc A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00d2  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0180  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00ee A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:61:0x0171 -> B:62:0x0177). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitTouchSlopOrCancellation-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m851awaitTouchSlopOrCancellationjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.e eVar, Y0.c cVar) {
        i iVar;
        h1.e eVar2;
        kotlin.jvm.internal.D d2;
        i iVar2;
        float f2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        kotlin.jvm.internal.D d3;
        i iVar3;
        float f3;
        k0 k0Var2;
        int size;
        int i2;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        int i3;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof i) {
            iVar = (i) cVar;
            int i4 = iVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                iVar.label = i4 - Integer.MIN_VALUE;
            } else {
                iVar = new i(cVar);
            }
        }
        Object obj = iVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = iVar.label;
        int i6 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        Object[] objArr2 = 0;
        if (i5 != 0) {
            if (i5 == 1) {
                float f4 = iVar.F$0;
                k0 k0Var3 = (k0) iVar.L$3;
                kotlin.jvm.internal.D d4 = (kotlin.jvm.internal.D) iVar.L$2;
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) iVar.L$1;
                h1.e eVar3 = (h1.e) iVar.L$0;
                AbstractC0292a.H(obj);
                f3 = f4;
                interfaceC0905c2 = interfaceC0905c3;
                iVar3 = iVar;
                k0Var2 = k0Var3;
                eVar2 = eVar3;
                d3 = d4;
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                    }
                    i6 = 1;
                    rVar = null;
                    iVar2.L$0 = eVar2;
                    iVar2.L$1 = interfaceC0905c2;
                    iVar2.L$2 = d2;
                    iVar2.L$3 = k0Var;
                    iVar2.L$4 = rVar;
                    iVar2.F$0 = f2;
                    iVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, iVar2, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
                return null;
            }
            if (i5 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f5 = iVar.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) iVar.L$4;
            k0 k0Var4 = (k0) iVar.L$3;
            d2 = (kotlin.jvm.internal.D) iVar.L$2;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) iVar.L$1;
            h1.e eVar4 = (h1.e) iVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            iVar2 = iVar;
            f2 = f5;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                eVar2 = eVar4;
                i6 = 1;
                rVar = null;
                iVar2.L$0 = eVar2;
                iVar2.L$1 = interfaceC0905c2;
                iVar2.L$2 = d2;
                iVar2.L$3 = k0Var;
                iVar2.L$4 = rVar;
                iVar2.F$0 = f2;
                iVar2.label = i6;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, iVar2, i6, rVar);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                float f6 = f2;
                k0Var2 = k0Var;
                obj = objAwaitPointerEvent$default;
                d3 = d2;
                iVar3 = iVar2;
                f3 = f6;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                size = changes2.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes2.get(i2);
                    i3 = i2;
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d3.f3117b)) {
                        break;
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null && !c3.isConsumed()) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                        long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f3);
                        if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                            eVar2.invoke(c3, J.f.m39boximpl(jM835addPointerInputChangedBAh8RU));
                            if (c3.isConsumed()) {
                                return c3;
                            }
                            k0Var2.reset();
                            k0Var = k0Var2;
                            f2 = f3;
                            iVar2 = iVar3;
                            d2 = d3;
                        } else {
                            androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                            iVar3.L$0 = eVar2;
                            iVar3.L$1 = interfaceC0905c2;
                            iVar3.L$2 = d3;
                            iVar3.L$3 = k0Var2;
                            iVar3.L$4 = c3;
                            iVar3.F$0 = f3;
                            iVar3.label = 2;
                            if (interfaceC0905c2.awaitPointerEvent(rVar2, iVar3) == aVar) {
                                return aVar;
                            }
                            eVar4 = eVar2;
                            k0Var = k0Var2;
                            f2 = f3;
                            c5 = c3;
                            iVar2 = iVar3;
                            d2 = d3;
                            if (!c5.isConsumed()) {
                            }
                        }
                    } else {
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size2 = changes3.size();
                        int i7 = 0;
                        while (true) {
                            if (i7 >= size2) {
                                c4 = null;
                                break;
                            }
                            c4 = changes3.get(i7);
                            if (c4.getPressed()) {
                                break;
                            }
                            i7++;
                        }
                        androidx.compose.ui.input.pointer.C c6 = c4;
                        if (c6 != null) {
                            d3.f3117b = c6.m3657getIdJ3iCeTQ();
                            k0Var = k0Var2;
                            f2 = f3;
                            iVar2 = iVar3;
                            d2 = d3;
                        }
                    }
                    i6 = 1;
                    rVar = null;
                    iVar2.L$0 = eVar2;
                    iVar2.L$1 = interfaceC0905c2;
                    iVar2.L$2 = d2;
                    iVar2.L$3 = k0Var;
                    iVar2.L$4 = rVar;
                    iVar2.F$0 = f2;
                    iVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, iVar2, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
            }
            return null;
        }
        AbstractC0292a.H(obj);
        int iM3718getTouchT8wyACA = androidx.compose.ui.input.pointer.Q.Companion.m3718getTouchT8wyACA();
        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), iM3718getTouchT8wyACA);
        kotlin.jvm.internal.D d5 = new kotlin.jvm.internal.D();
        d5.f3117b = j2;
        k0 k0Var5 = new k0(objArr2 == true ? 1 : 0, jM66getZeroF1C5BW0, objArr == true ? 1 : 0);
        eVar2 = eVar;
        d2 = d5;
        iVar2 = iVar;
        f2 = fM860pointerSlopE8SPZFQ;
        k0Var = k0Var5;
        interfaceC0905c2 = interfaceC0905c;
        iVar2.L$0 = eVar2;
        iVar2.L$1 = interfaceC0905c2;
        iVar2.L$2 = d2;
        iVar2.L$3 = k0Var;
        iVar2.L$4 = rVar;
        iVar2.F$0 = f2;
        iVar2.label = i6;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, iVar2, i6, rVar);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:48:0x00d9, code lost:
    
        if ((java.lang.Float.intBitsToFloat((int) (androidx.compose.ui.input.pointer.AbstractC0919q.positionChangeIgnoreConsumed(r11) & 4294967295L)) == 0.0f ? 1 : 0) == 0) goto L49;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0064 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x008f A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0065 -> B:22:0x006a). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitVerticalDragOrCancellation-rnUCldI, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m852awaitVerticalDragOrCancellationrnUCldI(InterfaceC0905c interfaceC0905c, long j2, Y0.c cVar) {
        j jVar;
        kotlin.jvm.internal.D d2;
        InterfaceC0905c interfaceC0905c2;
        Object objAwaitPointerEvent$default;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        if (cVar instanceof j) {
            jVar = (j) cVar;
            int i2 = jVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                jVar.label = i2 - Integer.MIN_VALUE;
            } else {
                jVar = new j(cVar);
            }
        }
        Object obj = jVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = jVar.label;
        if (i3 != 0) {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) jVar.L$1;
            InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) jVar.L$0;
            AbstractC0292a.H(obj);
            kotlin.jvm.internal.D d4 = d3;
            interfaceC0905c2 = interfaceC0905c3;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i4 = 0;
            while (true) {
                if (i4 < size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i4);
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d4.f3117b)) {
                    break;
                }
                i4++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                    List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                    int size2 = changes2.size();
                    while (true) {
                        if (i >= size2) {
                            c3 = null;
                            break;
                        }
                        c3 = changes2.get(i);
                        if (c3.getPressed()) {
                            break;
                        }
                        i++;
                    }
                    androidx.compose.ui.input.pointer.C c5 = c3;
                    if (c5 != null) {
                        d4.f3117b = c5.m3657getIdJ3iCeTQ();
                        d2 = d4;
                    }
                }
                jVar.L$0 = interfaceC0905c2;
                jVar.L$1 = d2;
                jVar.label = 1;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, jVar, 1, null);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                kotlin.jvm.internal.D d5 = d2;
                obj = objAwaitPointerEvent$default;
                d4 = d5;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                int size3 = changes3.size();
                int i42 = 0;
                while (true) {
                    if (i42 < size3) {
                    }
                    i42++;
                }
                androidx.compose.ui.input.pointer.C c42 = c2;
                if (c42 == null) {
                    c42 = null;
                }
            }
            if (c42 == null || c42.isConsumed()) {
                return null;
            }
            return c42;
        }
        AbstractC0292a.H(obj);
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        interfaceC0905c2 = interfaceC0905c;
        jVar.L$0 = interfaceC0905c2;
        jVar.L$1 = d2;
        jVar.label = 1;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, null, jVar, 1, null);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00b6 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0184  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00e7 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x0175 -> B:61:0x017b). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitVerticalPointerSlopOrCancellation-gDDlDlE, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m853awaitVerticalPointerSlopOrCancellationgDDlDlE(InterfaceC0905c interfaceC0905c, long j2, int i2, h1.e eVar, Y0.c cVar) {
        k kVar;
        float fM860pointerSlopE8SPZFQ;
        kotlin.jvm.internal.D d2;
        h1.e eVar2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        float f2;
        k kVar2;
        k0 k0Var2;
        int size;
        int i3;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        int i4;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof k) {
            kVar = (k) cVar;
            int i5 = kVar.label;
            if ((i5 & Integer.MIN_VALUE) != 0) {
                kVar.label = i5 - Integer.MIN_VALUE;
            } else {
                kVar = new k(cVar);
            }
        }
        Object obj = kVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i6 = kVar.label;
        int i7 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        if (i6 != 0) {
            if (i6 == 1) {
                float f3 = kVar.F$0;
                k0 k0Var3 = (k0) kVar.L$3;
                kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) kVar.L$2;
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) kVar.L$1;
                h1.e eVar3 = (h1.e) kVar.L$0;
                AbstractC0292a.H(obj);
                d2 = d3;
                kVar2 = kVar;
                k0Var2 = k0Var3;
                eVar2 = eVar3;
                f2 = f3;
                interfaceC0905c2 = interfaceC0905c3;
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i3 = 0;
                while (true) {
                    if (i3 < size) {
                    }
                    i3 = i4 + 1;
                }
                c3 = c2;
                if (c3 != null) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                    }
                    kVar.L$0 = eVar2;
                    kVar.L$1 = interfaceC0905c2;
                    kVar.L$2 = d2;
                    kVar.L$3 = k0Var;
                    kVar.L$4 = rVar;
                    kVar.F$0 = fM860pointerSlopE8SPZFQ;
                    kVar.label = i7;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, kVar, i7, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
                return null;
            }
            if (i6 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f4 = kVar.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) kVar.L$4;
            k0 k0Var4 = (k0) kVar.L$3;
            kotlin.jvm.internal.D d4 = (kotlin.jvm.internal.D) kVar.L$2;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) kVar.L$1;
            h1.e eVar4 = (h1.e) kVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            fM860pointerSlopE8SPZFQ = f4;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                eVar2 = eVar4;
                i7 = 1;
                rVar = null;
                d2 = d4;
                kVar.L$0 = eVar2;
                kVar.L$1 = interfaceC0905c2;
                kVar.L$2 = d2;
                kVar.L$3 = k0Var;
                kVar.L$4 = rVar;
                kVar.F$0 = fM860pointerSlopE8SPZFQ;
                kVar.label = i7;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, kVar, i7, rVar);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                k kVar3 = kVar;
                k0Var2 = k0Var;
                obj = objAwaitPointerEvent$default;
                f2 = fM860pointerSlopE8SPZFQ;
                kVar2 = kVar3;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                size = changes2.size();
                i3 = 0;
                while (true) {
                    if (i3 < size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes2.get(i3);
                    i4 = i3;
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                        break;
                    }
                    i3 = i4 + 1;
                }
                c3 = c2;
                if (c3 != null && !c3.isConsumed()) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                        long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f2);
                        if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                            eVar2.invoke(c3, new Float(Float.intBitsToFloat((int) (jM835addPointerInputChangedBAh8RU & 4294967295L))));
                            if (c3.isConsumed()) {
                                return c3;
                            }
                            k0Var2.reset();
                            k0Var = k0Var2;
                            kVar = kVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            i7 = 1;
                            rVar = null;
                        } else {
                            androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                            kVar2.L$0 = eVar2;
                            kVar2.L$1 = interfaceC0905c2;
                            kVar2.L$2 = d2;
                            kVar2.L$3 = k0Var2;
                            kVar2.L$4 = c3;
                            kVar2.F$0 = f2;
                            kVar2.label = 2;
                            if (interfaceC0905c2.awaitPointerEvent(rVar2, kVar2) == aVar) {
                                return aVar;
                            }
                            k0Var = k0Var2;
                            kVar = kVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            d4 = d2;
                            eVar4 = eVar2;
                            c5 = c3;
                            if (!c5.isConsumed()) {
                            }
                        }
                    } else {
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size2 = changes3.size();
                        int i8 = 0;
                        while (true) {
                            if (i8 >= size2) {
                                c4 = null;
                                break;
                            }
                            c4 = changes3.get(i8);
                            if (c4.getPressed()) {
                                break;
                            }
                            i8++;
                        }
                        androidx.compose.ui.input.pointer.C c6 = c4;
                        if (c6 != null) {
                            d2.f3117b = c6.m3657getIdJ3iCeTQ();
                            k0Var = k0Var2;
                            kVar = kVar2;
                            fM860pointerSlopE8SPZFQ = f2;
                            i7 = 1;
                            rVar = null;
                        }
                    }
                    kVar.L$0 = eVar2;
                    kVar.L$1 = interfaceC0905c2;
                    kVar.L$2 = d2;
                    kVar.L$3 = k0Var;
                    kVar.L$4 = rVar;
                    kVar.F$0 = fM860pointerSlopE8SPZFQ;
                    kVar.label = i7;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, kVar, i7, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
            }
            return null;
        }
        AbstractC0292a.H(obj);
        I i9 = I.Vertical;
        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), i2);
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        eVar2 = eVar;
        k0Var = new k0(i9, jM66getZeroF1C5BW0, objArr == true ? 1 : 0);
        interfaceC0905c2 = interfaceC0905c;
        kVar.L$0 = eVar2;
        kVar.L$1 = interfaceC0905c2;
        kVar.L$2 = d2;
        kVar.L$3 = k0Var;
        kVar.L$4 = rVar;
        kVar.F$0 = fM860pointerSlopE8SPZFQ;
        kVar.label = i7;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, kVar, i7, rVar);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00ba A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00bb  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0188  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00eb A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x0179 -> B:61:0x017f). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: awaitVerticalTouchSlopOrCancellation-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m854awaitVerticalTouchSlopOrCancellationjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.e eVar, Y0.c cVar) {
        l lVar;
        kotlin.jvm.internal.D d2;
        h1.e eVar2;
        l lVar2;
        float f2;
        k0 k0Var;
        InterfaceC0905c interfaceC0905c2;
        l lVar3;
        float f3;
        k0 k0Var2;
        int size;
        int i2;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        androidx.compose.ui.input.pointer.C c4;
        int i3;
        Object objAwaitPointerEvent$default;
        if (cVar instanceof l) {
            lVar = (l) cVar;
            int i4 = lVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                lVar.label = i4 - Integer.MIN_VALUE;
            } else {
                lVar = new l(cVar);
            }
        }
        Object obj = lVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = lVar.label;
        int i6 = 1;
        androidx.compose.ui.input.pointer.r rVar = null;
        Object[] objArr = 0;
        if (i5 != 0) {
            if (i5 == 1) {
                float f4 = lVar.F$0;
                k0 k0Var3 = (k0) lVar.L$3;
                kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) lVar.L$2;
                InterfaceC0905c interfaceC0905c3 = (InterfaceC0905c) lVar.L$1;
                h1.e eVar3 = (h1.e) lVar.L$0;
                AbstractC0292a.H(obj);
                d2 = d3;
                f3 = f4;
                interfaceC0905c2 = interfaceC0905c3;
                lVar3 = lVar;
                k0Var2 = k0Var3;
                eVar2 = eVar3;
                C0918p c0918p = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
                size = changes.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                    }
                    lVar2.L$0 = eVar2;
                    lVar2.L$1 = interfaceC0905c2;
                    lVar2.L$2 = d2;
                    lVar2.L$3 = k0Var;
                    lVar2.L$4 = rVar;
                    lVar2.F$0 = f2;
                    lVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, lVar2, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
                return null;
            }
            if (i5 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            float f5 = lVar.F$0;
            androidx.compose.ui.input.pointer.C c5 = (androidx.compose.ui.input.pointer.C) lVar.L$4;
            k0 k0Var4 = (k0) lVar.L$3;
            kotlin.jvm.internal.D d4 = (kotlin.jvm.internal.D) lVar.L$2;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) lVar.L$1;
            h1.e eVar4 = (h1.e) lVar.L$0;
            AbstractC0292a.H(obj);
            k0Var = k0Var4;
            lVar2 = lVar;
            f2 = f5;
            interfaceC0905c2 = interfaceC0905c4;
            if (!c5.isConsumed()) {
                eVar2 = eVar4;
                i6 = 1;
                rVar = null;
                d2 = d4;
                lVar2.L$0 = eVar2;
                lVar2.L$1 = interfaceC0905c2;
                lVar2.L$2 = d2;
                lVar2.L$3 = k0Var;
                lVar2.L$4 = rVar;
                lVar2.F$0 = f2;
                lVar2.label = i6;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, lVar2, i6, rVar);
                if (objAwaitPointerEvent$default != aVar) {
                    return aVar;
                }
                float f6 = f2;
                k0Var2 = k0Var;
                obj = objAwaitPointerEvent$default;
                lVar3 = lVar2;
                f3 = f6;
                C0918p c0918p2 = (C0918p) obj;
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p2.getChanges();
                size = changes2.size();
                i2 = 0;
                while (true) {
                    if (i2 < size) {
                        c2 = null;
                        break;
                    }
                    c2 = changes2.get(i2);
                    i3 = i2;
                    if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                        break;
                    }
                    i2 = i3 + 1;
                }
                c3 = c2;
                if (c3 != null && !c3.isConsumed()) {
                    if (AbstractC0919q.changedToUpIgnoreConsumed(c3)) {
                        long jM835addPointerInputChangedBAh8RU = k0Var2.m835addPointerInputChangedBAh8RU(c3, f3);
                        if ((9223372034707292159L & jM835addPointerInputChangedBAh8RU) != 9205357640488583168L) {
                            eVar2.invoke(c3, new Float(Float.intBitsToFloat((int) (jM835addPointerInputChangedBAh8RU & 4294967295L))));
                            if (c3.isConsumed()) {
                                return c3;
                            }
                            k0Var2.reset();
                            k0Var = k0Var2;
                            f2 = f3;
                            lVar2 = lVar3;
                            i6 = 1;
                            rVar = null;
                        } else {
                            androidx.compose.ui.input.pointer.r rVar2 = androidx.compose.ui.input.pointer.r.Final;
                            lVar3.L$0 = eVar2;
                            lVar3.L$1 = interfaceC0905c2;
                            lVar3.L$2 = d2;
                            lVar3.L$3 = k0Var2;
                            lVar3.L$4 = c3;
                            lVar3.F$0 = f3;
                            lVar3.label = 2;
                            if (interfaceC0905c2.awaitPointerEvent(rVar2, lVar3) == aVar) {
                                return aVar;
                            }
                            k0Var = k0Var2;
                            f2 = f3;
                            lVar2 = lVar3;
                            d4 = d2;
                            eVar4 = eVar2;
                            c5 = c3;
                            if (!c5.isConsumed()) {
                            }
                        }
                    } else {
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size2 = changes3.size();
                        int i7 = 0;
                        while (true) {
                            if (i7 >= size2) {
                                c4 = null;
                                break;
                            }
                            c4 = changes3.get(i7);
                            if (c4.getPressed()) {
                                break;
                            }
                            i7++;
                        }
                        androidx.compose.ui.input.pointer.C c6 = c4;
                        if (c6 != null) {
                            d2.f3117b = c6.m3657getIdJ3iCeTQ();
                            k0Var = k0Var2;
                            f2 = f3;
                            lVar2 = lVar3;
                            i6 = 1;
                            rVar = null;
                        }
                    }
                    lVar2.L$0 = eVar2;
                    lVar2.L$1 = interfaceC0905c2;
                    lVar2.L$2 = d2;
                    lVar2.L$3 = k0Var;
                    lVar2.L$4 = rVar;
                    lVar2.F$0 = f2;
                    lVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, lVar2, i6, rVar);
                    if (objAwaitPointerEvent$default != aVar) {
                    }
                }
            }
            return null;
        }
        AbstractC0292a.H(obj);
        int iM3718getTouchT8wyACA = androidx.compose.ui.input.pointer.Q.Companion.m3718getTouchT8wyACA();
        I i8 = I.Vertical;
        long jM66getZeroF1C5BW0 = J.f.Companion.m66getZeroF1C5BW0();
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), j2)) {
            return null;
        }
        float fM860pointerSlopE8SPZFQ = m860pointerSlopE8SPZFQ(interfaceC0905c.getViewConfiguration(), iM3718getTouchT8wyACA);
        d2 = new kotlin.jvm.internal.D();
        d2.f3117b = j2;
        k0 k0Var5 = new k0(i8, jM66getZeroF1C5BW0, objArr == true ? 1 : 0);
        eVar2 = eVar;
        lVar2 = lVar;
        f2 = fM860pointerSlopE8SPZFQ;
        k0Var = k0Var5;
        interfaceC0905c2 = interfaceC0905c;
        lVar2.L$0 = eVar2;
        lVar2.L$1 = interfaceC0905c2;
        lVar2.L$2 = d2;
        lVar2.L$3 = k0Var;
        lVar2.L$4 = rVar;
        lVar2.F$0 = f2;
        lVar2.label = i6;
        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c2, rVar, lVar2, i6, rVar);
        if (objAwaitPointerEvent$default != aVar) {
        }
    }

    public static final Object detectDragGestures(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
        Object objDetectDragGestures = detectDragGestures(l2, null, new O0.T(1, cVar), new C0390n(aVar, 0), aVar2, new F0.a(21), eVar, cVar2);
        return objDetectDragGestures == Z0.a.f1616b ? objDetectDragGestures : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectDragGestures$default(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            cVar = new D0(14);
        }
        h1.c cVar3 = cVar;
        if ((i2 & 2) != 0) {
            aVar = new F0.a(15);
        }
        h1.a aVar3 = aVar;
        if ((i2 & 4) != 0) {
            aVar2 = new F0.a(16);
        }
        return detectDragGestures(l2, cVar3, aVar3, aVar2, eVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGestures$lambda$1(J.f fVar) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean detectDragGestures$lambda$10() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGestures$lambda$4(h1.c cVar, androidx.compose.ui.input.pointer.C c2, androidx.compose.ui.input.pointer.C c3, J.f fVar) {
        cVar.invoke(J.f.m39boximpl(c3.m3659getPositionF1C5BW0()));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGestures$lambda$5(h1.a aVar, androidx.compose.ui.input.pointer.C c2) {
        aVar.invoke();
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean detectDragGestures$lambda$6() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGestures$lambda$7(androidx.compose.ui.input.pointer.C c2, androidx.compose.ui.input.pointer.C c3, J.f fVar) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGestures$lambda$8(androidx.compose.ui.input.pointer.C c2) {
        return U0.n.f1521a;
    }

    public static final Object detectDragGesturesAfterLongPress(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
        Object objAwaitEachGesture = A.awaitEachGesture(l2, new n(cVar, aVar, aVar2, eVar, null), cVar2);
        return objAwaitEachGesture == Z0.a.f1616b ? objAwaitEachGesture : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectDragGesturesAfterLongPress$default(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            cVar = new D0(13);
        }
        h1.c cVar3 = cVar;
        if ((i2 & 2) != 0) {
            aVar = new F0.a(13);
        }
        h1.a aVar3 = aVar;
        if ((i2 & 4) != 0) {
            aVar2 = new F0.a(14);
        }
        return detectDragGesturesAfterLongPress(l2, cVar3, aVar3, aVar2, eVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectDragGesturesAfterLongPress$lambda$11(J.f fVar) {
        return U0.n.f1521a;
    }

    public static final Object detectHorizontalDragGestures(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
        Object objAwaitEachGesture = A.awaitEachGesture(l2, new C0031o(cVar, eVar, aVar, aVar2, null), cVar2);
        return objAwaitEachGesture == Z0.a.f1616b ? objAwaitEachGesture : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectHorizontalDragGestures$default(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            cVar = new D0(12);
        }
        h1.c cVar3 = cVar;
        if ((i2 & 2) != 0) {
            aVar = new F0.a(19);
        }
        h1.a aVar3 = aVar;
        if ((i2 & 4) != 0) {
            aVar2 = new F0.a(20);
        }
        return detectHorizontalDragGestures(l2, cVar3, aVar3, aVar2, eVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectHorizontalDragGestures$lambda$25(J.f fVar) {
        return U0.n.f1521a;
    }

    public static final Object detectVerticalDragGestures(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
        Object objAwaitEachGesture = A.awaitEachGesture(l2, new p(cVar, eVar, aVar, aVar2, null), cVar2);
        return objAwaitEachGesture == Z0.a.f1616b ? objAwaitEachGesture : U0.n.f1521a;
    }

    public static /* synthetic */ Object detectVerticalDragGestures$default(androidx.compose.ui.input.pointer.L l2, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            cVar = new D0(15);
        }
        h1.c cVar3 = cVar;
        if ((i2 & 2) != 0) {
            aVar = new F0.a(17);
        }
        h1.a aVar3 = aVar;
        if ((i2 & 4) != 0) {
            aVar2 = new F0.a(18);
        }
        return detectVerticalDragGestures(l2, cVar3, aVar3, aVar2, eVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n detectVerticalDragGestures$lambda$18(J.f fVar) {
        return U0.n.f1521a;
    }

    /* JADX WARN: Code restructure failed: missing block: B:58:0x011c, code lost:
    
        if (((r3 != null ? r3 == androidx.compose.foundation.gestures.I.Vertical ? java.lang.Float.intBitsToFloat((int) (r4 & 4294967295L)) : java.lang.Float.intBitsToFloat((int) (r4 >> 32)) : J.f.m48getDistanceimpl(r4)) == 0.0f) == false) goto L59;
     */
    /* JADX WARN: Path cross not found for [B:35:0x00c7, B:47:0x00f1], limit reached: 70 */
    /* JADX WARN: Removed duplicated region for block: B:21:0x008a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x009e  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00c1  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00ba A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x008b -> B:23:0x0091). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: drag-VnAYq1g, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m855dragVnAYq1g(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, I i2, h1.c cVar2, Y0.c cVar3) {
        r rVar;
        long jM3657getIdJ3iCeTQ;
        InterfaceC0905c interfaceC0905c2;
        I i3;
        h1.c cVar4;
        r rVar2;
        h1.c cVar5;
        kotlin.jvm.internal.D d2;
        InterfaceC0905c interfaceC0905c3;
        Object objAwaitPointerEvent$default;
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        int i4;
        if (cVar3 instanceof r) {
            rVar = (r) cVar3;
            int i5 = rVar.label;
            if ((i5 & Integer.MIN_VALUE) != 0) {
                rVar.label = i5 - Integer.MIN_VALUE;
            } else {
                rVar = new r(cVar3);
            }
        }
        Object obj = rVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i6 = rVar.label;
        int i7 = 1;
        androidx.compose.ui.input.pointer.r rVar3 = null;
        if (i6 == 0) {
            AbstractC0292a.H(obj);
            jM3657getIdJ3iCeTQ = j2;
            if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), jM3657getIdJ3iCeTQ)) {
                return null;
            }
            interfaceC0905c2 = interfaceC0905c;
            i3 = i2;
            cVar4 = cVar2;
            rVar2 = rVar;
            cVar5 = cVar;
            d2 = new kotlin.jvm.internal.D();
            d2.f3117b = jM3657getIdJ3iCeTQ;
            interfaceC0905c3 = interfaceC0905c2;
            rVar2.L$0 = interfaceC0905c2;
            rVar2.L$1 = cVar5;
            rVar2.L$2 = i3;
            rVar2.L$3 = cVar4;
            rVar2.L$4 = interfaceC0905c3;
            rVar2.L$5 = d2;
            rVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar3, rVar2, i7, rVar3);
            if (objAwaitPointerEvent$default == aVar) {
            }
        } else {
            if (i6 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.jvm.internal.D d3 = (kotlin.jvm.internal.D) rVar.L$5;
            interfaceC0905c3 = (InterfaceC0905c) rVar.L$4;
            h1.c cVar6 = (h1.c) rVar.L$3;
            I i8 = (I) rVar.L$2;
            h1.c cVar7 = (h1.c) rVar.L$1;
            InterfaceC0905c interfaceC0905c4 = (InterfaceC0905c) rVar.L$0;
            AbstractC0292a.H(obj);
            rVar2 = rVar;
            cVar5 = cVar7;
            kotlin.jvm.internal.D d4 = d3;
            i3 = i8;
            cVar4 = cVar6;
            C0918p c0918p = (C0918p) obj;
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i9 = 0;
            while (true) {
                if (i9 < size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i9);
                i4 = i9;
                if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d4.f3117b)) {
                    break;
                }
                i9 = i4 + 1;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                    List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                    int size2 = changes2.size();
                    int i10 = 0;
                    while (true) {
                        if (i10 >= size2) {
                            c3 = null;
                            break;
                        }
                        c3 = changes2.get(i10);
                        if (c3.getPressed()) {
                            break;
                        }
                        i10++;
                    }
                    androidx.compose.ui.input.pointer.C c5 = c3;
                    if (c5 != null) {
                        d4.f3117b = c5.m3657getIdJ3iCeTQ();
                        rVar3 = null;
                        interfaceC0905c2 = interfaceC0905c4;
                        i7 = 1;
                        d2 = d4;
                        rVar2.L$0 = interfaceC0905c2;
                        rVar2.L$1 = cVar5;
                        rVar2.L$2 = i3;
                        rVar2.L$3 = cVar4;
                        rVar2.L$4 = interfaceC0905c3;
                        rVar2.L$5 = d2;
                        rVar2.label = i7;
                        objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar3, rVar2, i7, rVar3);
                        if (objAwaitPointerEvent$default == aVar) {
                            return aVar;
                        }
                        kotlin.jvm.internal.D d5 = d2;
                        interfaceC0905c4 = interfaceC0905c2;
                        obj = objAwaitPointerEvent$default;
                        d4 = d5;
                        C0918p c0918p2 = (C0918p) obj;
                        List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                        int size3 = changes3.size();
                        int i92 = 0;
                        while (true) {
                            if (i92 < size3) {
                            }
                            i92 = i4 + 1;
                        }
                        androidx.compose.ui.input.pointer.C c42 = c2;
                        if (c42 == null) {
                            c42 = null;
                        }
                    }
                } else {
                    long jPositionChangeIgnoreConsumed = AbstractC0919q.positionChangeIgnoreConsumed(c42);
                }
            }
            if (c42 == null || ((Boolean) cVar4.invoke(c42)).booleanValue()) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c42)) {
                return c42;
            }
            cVar5.invoke(c42);
            jM3657getIdJ3iCeTQ = c42.m3657getIdJ3iCeTQ();
            rVar3 = null;
            interfaceC0905c2 = interfaceC0905c4;
            i7 = 1;
            d2 = new kotlin.jvm.internal.D();
            d2.f3117b = jM3657getIdJ3iCeTQ;
            interfaceC0905c3 = interfaceC0905c2;
            rVar2.L$0 = interfaceC0905c2;
            rVar2.L$1 = cVar5;
            rVar2.L$2 = i3;
            rVar2.L$3 = cVar4;
            rVar2.L$4 = interfaceC0905c3;
            rVar2.L$5 = d2;
            rVar2.label = i7;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar3, rVar2, i7, rVar3);
            if (objAwaitPointerEvent$default == aVar) {
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: drag-VnAYq1g$$forInline, reason: not valid java name */
    private static final Object m856dragVnAYq1g$$forInline(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, I i2, h1.c cVar2, Y0.c cVar3) {
        androidx.compose.ui.input.pointer.C c2;
        androidx.compose.ui.input.pointer.C c3;
        long jM3657getIdJ3iCeTQ = j2;
        if (m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), jM3657getIdJ3iCeTQ)) {
            return null;
        }
        while (true) {
            C0918p c0918p = (C0918p) InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c, null, cVar3, 1, null);
            List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
            int size = changes.size();
            int i3 = 0;
            while (true) {
                if (i3 >= size) {
                    c2 = null;
                    break;
                }
                c2 = changes.get(i3);
                if (Boolean.valueOf(androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), jM3657getIdJ3iCeTQ)).booleanValue()) {
                    break;
                }
                i3++;
            }
            androidx.compose.ui.input.pointer.C c4 = c2;
            if (c4 == null) {
                c4 = null;
            } else if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                while (true) {
                    if (i >= size2) {
                        c3 = null;
                        break;
                    }
                    c3 = changes2.get(i);
                    if (Boolean.valueOf(c3.getPressed()).booleanValue()) {
                        break;
                    }
                    i++;
                }
                androidx.compose.ui.input.pointer.C c5 = c3;
                if (c5 != null) {
                    jM3657getIdJ3iCeTQ = c5.m3657getIdJ3iCeTQ();
                }
            } else {
                long jPositionChangeIgnoreConsumed = AbstractC0919q.positionChangeIgnoreConsumed(c4);
                if (!Boolean.valueOf(1 ^ ((i2 == null ? J.f.m48getDistanceimpl(jPositionChangeIgnoreConsumed) : i2 == I.Vertical ? Float.intBitsToFloat((int) (jPositionChangeIgnoreConsumed & 4294967295L)) : Float.intBitsToFloat((int) (jPositionChangeIgnoreConsumed >> 32))) == 0.0f ? 1 : 0)).booleanValue()) {
                    continue;
                }
            }
            if (c4 == null || ((Boolean) cVar2.invoke(c4)).booleanValue()) {
                return null;
            }
            if (AbstractC0919q.changedToUpIgnoreConsumed(c4)) {
                return c4;
            }
            cVar.invoke(c4);
            jM3657getIdJ3iCeTQ = c4.m3657getIdJ3iCeTQ();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0048 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0046 -> B:18:0x0049). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: drag-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m857dragjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, Y0.c cVar2) {
        q qVar;
        androidx.compose.ui.input.pointer.C c2;
        if (cVar2 instanceof q) {
            qVar = (q) cVar2;
            int i2 = qVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                qVar.label = i2 - Integer.MIN_VALUE;
            } else {
                qVar = new q(cVar2);
            }
        }
        Object objM842awaitDragOrCancellationrnUCldI = qVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = qVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(objM842awaitDragOrCancellationrnUCldI);
            qVar.L$0 = interfaceC0905c;
            qVar.L$1 = cVar;
            qVar.label = 1;
            objM842awaitDragOrCancellationrnUCldI = m842awaitDragOrCancellationrnUCldI(interfaceC0905c, j2, qVar);
            if (objM842awaitDragOrCancellationrnUCldI == aVar) {
            }
            c2 = (androidx.compose.ui.input.pointer.C) objM842awaitDragOrCancellationrnUCldI;
            if (c2 == null) {
            }
        } else {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            h1.c cVar3 = (h1.c) qVar.L$1;
            InterfaceC0905c interfaceC0905c2 = (InterfaceC0905c) qVar.L$0;
            AbstractC0292a.H(objM842awaitDragOrCancellationrnUCldI);
            cVar = cVar3;
            interfaceC0905c = interfaceC0905c2;
            c2 = (androidx.compose.ui.input.pointer.C) objM842awaitDragOrCancellationrnUCldI;
            if (c2 == null) {
                if (AbstractC0919q.changedToUpIgnoreConsumed(c2)) {
                    return Boolean.TRUE;
                }
                cVar.invoke(c2);
                j2 = c2.m3657getIdJ3iCeTQ();
                qVar.L$0 = interfaceC0905c;
                qVar.L$1 = cVar;
                qVar.label = 1;
                objM842awaitDragOrCancellationrnUCldI = m842awaitDragOrCancellationrnUCldI(interfaceC0905c, j2, qVar);
                if (objM842awaitDragOrCancellationrnUCldI == aVar) {
                    return aVar;
                }
                c2 = (androidx.compose.ui.input.pointer.C) objM842awaitDragOrCancellationrnUCldI;
                if (c2 == null) {
                    return Boolean.FALSE;
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:58:0x0110, code lost:
    
        if ((r0 == 0.0f) == false) goto L59;
     */
    /* JADX WARN: Path cross not found for [B:35:0x00c0, B:46:0x00e9], limit reached: 73 */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0080 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0128  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00b1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0081 -> B:23:0x0087). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: horizontalDrag-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m858horizontalDragjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, Y0.c cVar2) {
        s sVar;
        long jM3657getIdJ3iCeTQ;
        I i2;
        s sVar2;
        InterfaceC0905c interfaceC0905c2;
        h1.c cVar3;
        I i3;
        InterfaceC0905c interfaceC0905c3;
        kotlin.jvm.internal.D d2;
        Object objAwaitPointerEvent$default;
        InterfaceC0905c interfaceC0905c4;
        androidx.compose.ui.input.pointer.C c2;
        float fIntBitsToFloat;
        androidx.compose.ui.input.pointer.C c3;
        if (cVar2 instanceof s) {
            sVar = (s) cVar2;
            int i4 = sVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                sVar.label = i4 - Integer.MIN_VALUE;
            } else {
                sVar = new s(cVar2);
            }
        }
        Object obj = sVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = sVar.label;
        int i6 = 1;
        androidx.compose.ui.input.pointer.C c4 = null;
        androidx.compose.ui.input.pointer.r rVar = null;
        if (i5 == 0) {
            AbstractC0292a.H(obj);
            I i7 = I.Horizontal;
            jM3657getIdJ3iCeTQ = j2;
            if (!m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), jM3657getIdJ3iCeTQ)) {
                i2 = i7;
                sVar2 = sVar;
                interfaceC0905c2 = interfaceC0905c;
                cVar3 = cVar;
                kotlin.jvm.internal.D d3 = new kotlin.jvm.internal.D();
                d3.f3117b = jM3657getIdJ3iCeTQ;
                interfaceC0905c3 = interfaceC0905c2;
                i3 = i2;
                d2 = d3;
                sVar2.L$0 = cVar3;
                sVar2.L$1 = interfaceC0905c2;
                sVar2.L$2 = i3;
                sVar2.L$3 = interfaceC0905c3;
                sVar2.L$4 = d2;
                sVar2.label = i6;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, sVar2, i6, rVar);
                if (objAwaitPointerEvent$default == aVar) {
                }
            }
            return Boolean.valueOf(c4 == null);
        }
        if (i5 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        d2 = (kotlin.jvm.internal.D) sVar.L$4;
        interfaceC0905c3 = (InterfaceC0905c) sVar.L$3;
        i3 = (I) sVar.L$2;
        InterfaceC0905c interfaceC0905c5 = (InterfaceC0905c) sVar.L$1;
        h1.c cVar4 = (h1.c) sVar.L$0;
        AbstractC0292a.H(obj);
        s sVar3 = sVar;
        cVar3 = cVar4;
        C0918p c0918p = (C0918p) obj;
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        int i8 = 0;
        while (true) {
            if (i8 < size) {
                interfaceC0905c4 = interfaceC0905c3;
                c2 = null;
                break;
            }
            c2 = changes.get(i8);
            interfaceC0905c4 = interfaceC0905c3;
            if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                break;
            }
            i8++;
            interfaceC0905c3 = interfaceC0905c4;
        }
        androidx.compose.ui.input.pointer.C c5 = c2;
        if (c5 == null) {
            if (AbstractC0919q.changedToUpIgnoreConsumed(c5)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                int i9 = 0;
                while (true) {
                    if (i9 >= size2) {
                        c3 = null;
                        break;
                    }
                    c3 = changes2.get(i9);
                    if (c3.getPressed()) {
                        break;
                    }
                    i9++;
                }
                androidx.compose.ui.input.pointer.C c6 = c3;
                if (c6 != null) {
                    d2.f3117b = c6.m3657getIdJ3iCeTQ();
                    interfaceC0905c3 = interfaceC0905c4;
                    interfaceC0905c2 = interfaceC0905c5;
                    sVar2 = sVar3;
                    i6 = 1;
                    rVar = null;
                    sVar2.L$0 = cVar3;
                    sVar2.L$1 = interfaceC0905c2;
                    sVar2.L$2 = i3;
                    sVar2.L$3 = interfaceC0905c3;
                    sVar2.L$4 = d2;
                    sVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, sVar2, i6, rVar);
                    if (objAwaitPointerEvent$default == aVar) {
                        return aVar;
                    }
                    s sVar4 = sVar2;
                    interfaceC0905c5 = interfaceC0905c2;
                    obj = objAwaitPointerEvent$default;
                    sVar3 = sVar4;
                    C0918p c0918p2 = (C0918p) obj;
                    List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                    int size3 = changes3.size();
                    int i82 = 0;
                    while (true) {
                        if (i82 < size3) {
                        }
                        i82++;
                        interfaceC0905c3 = interfaceC0905c4;
                    }
                    androidx.compose.ui.input.pointer.C c52 = c2;
                    if (c52 == null) {
                        c52 = null;
                    }
                }
            } else {
                long jPositionChangeIgnoreConsumed = AbstractC0919q.positionChangeIgnoreConsumed(c52);
                if (i3 != null) {
                    fIntBitsToFloat = Float.intBitsToFloat((int) (i3 == I.Vertical ? jPositionChangeIgnoreConsumed & 4294967295L : jPositionChangeIgnoreConsumed >> 32));
                } else {
                    fIntBitsToFloat = J.f.m48getDistanceimpl(jPositionChangeIgnoreConsumed);
                }
            }
        }
        if (c52 == null || c52.isConsumed()) {
            c4 = null;
        } else if (AbstractC0919q.changedToUpIgnoreConsumed(c52)) {
            c4 = c52;
        } else {
            cVar3.invoke(c52);
            interfaceC0905c2 = interfaceC0905c5;
            sVar2 = sVar3;
            i6 = 1;
            rVar = null;
            i2 = i3;
            jM3657getIdJ3iCeTQ = c52.m3657getIdJ3iCeTQ();
            kotlin.jvm.internal.D d32 = new kotlin.jvm.internal.D();
            d32.f3117b = jM3657getIdJ3iCeTQ;
            interfaceC0905c3 = interfaceC0905c2;
            i3 = i2;
            d2 = d32;
            sVar2.L$0 = cVar3;
            sVar2.L$1 = interfaceC0905c2;
            sVar2.L$2 = i3;
            sVar2.L$3 = interfaceC0905c3;
            sVar2.L$4 = d2;
            sVar2.label = i6;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, sVar2, i6, rVar);
            if (objAwaitPointerEvent$default == aVar) {
            }
        }
        return Boolean.valueOf(c4 == null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: isPointerUp-DmW0f2w, reason: not valid java name */
    public static final boolean m859isPointerUpDmW0f2w(C0918p c0918p, long j2) {
        androidx.compose.ui.input.pointer.C c2;
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        boolean z2 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                c2 = null;
                break;
            }
            c2 = changes.get(i2);
            if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), j2)) {
                break;
            }
            i2++;
        }
        androidx.compose.ui.input.pointer.C c3 = c2;
        if (c3 != null && c3.getPressed()) {
            z2 = true;
        }
        return true ^ z2;
    }

    /* JADX INFO: renamed from: pointerSlop-E8SPZFQ, reason: not valid java name */
    public static final float m860pointerSlopE8SPZFQ(W1 w12, int i2) {
        return androidx.compose.ui.input.pointer.Q.m3711equalsimpl0(i2, androidx.compose.ui.input.pointer.Q.Companion.m3716getMouseT8wyACA()) ? w12.getTouchSlop() * mouseToTouchSlopRatio : w12.getTouchSlop();
    }

    /* JADX WARN: Code restructure failed: missing block: B:58:0x0110, code lost:
    
        if ((r0 == 0.0f) == false) goto L59;
     */
    /* JADX WARN: Path cross not found for [B:35:0x00c0, B:46:0x00e9], limit reached: 73 */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0080 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0128  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00b1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0081 -> B:23:0x0087). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: verticalDrag-jO51t88, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object m861verticalDragjO51t88(InterfaceC0905c interfaceC0905c, long j2, h1.c cVar, Y0.c cVar2) {
        t tVar;
        long jM3657getIdJ3iCeTQ;
        I i2;
        t tVar2;
        InterfaceC0905c interfaceC0905c2;
        h1.c cVar3;
        I i3;
        InterfaceC0905c interfaceC0905c3;
        kotlin.jvm.internal.D d2;
        Object objAwaitPointerEvent$default;
        InterfaceC0905c interfaceC0905c4;
        androidx.compose.ui.input.pointer.C c2;
        float fIntBitsToFloat;
        androidx.compose.ui.input.pointer.C c3;
        if (cVar2 instanceof t) {
            tVar = (t) cVar2;
            int i4 = tVar.label;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                tVar.label = i4 - Integer.MIN_VALUE;
            } else {
                tVar = new t(cVar2);
            }
        }
        Object obj = tVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i5 = tVar.label;
        int i6 = 1;
        androidx.compose.ui.input.pointer.C c4 = null;
        androidx.compose.ui.input.pointer.r rVar = null;
        if (i5 == 0) {
            AbstractC0292a.H(obj);
            I i7 = I.Vertical;
            jM3657getIdJ3iCeTQ = j2;
            if (!m859isPointerUpDmW0f2w(interfaceC0905c.getCurrentEvent(), jM3657getIdJ3iCeTQ)) {
                i2 = i7;
                tVar2 = tVar;
                interfaceC0905c2 = interfaceC0905c;
                cVar3 = cVar;
                kotlin.jvm.internal.D d3 = new kotlin.jvm.internal.D();
                d3.f3117b = jM3657getIdJ3iCeTQ;
                interfaceC0905c3 = interfaceC0905c2;
                i3 = i2;
                d2 = d3;
                tVar2.L$0 = cVar3;
                tVar2.L$1 = interfaceC0905c2;
                tVar2.L$2 = i3;
                tVar2.L$3 = interfaceC0905c3;
                tVar2.L$4 = d2;
                tVar2.label = i6;
                objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, tVar2, i6, rVar);
                if (objAwaitPointerEvent$default == aVar) {
                }
            }
            return Boolean.valueOf(c4 == null);
        }
        if (i5 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        d2 = (kotlin.jvm.internal.D) tVar.L$4;
        interfaceC0905c3 = (InterfaceC0905c) tVar.L$3;
        i3 = (I) tVar.L$2;
        InterfaceC0905c interfaceC0905c5 = (InterfaceC0905c) tVar.L$1;
        h1.c cVar4 = (h1.c) tVar.L$0;
        AbstractC0292a.H(obj);
        t tVar3 = tVar;
        cVar3 = cVar4;
        C0918p c0918p = (C0918p) obj;
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        int size = changes.size();
        int i8 = 0;
        while (true) {
            if (i8 < size) {
                interfaceC0905c4 = interfaceC0905c3;
                c2 = null;
                break;
            }
            c2 = changes.get(i8);
            interfaceC0905c4 = interfaceC0905c3;
            if (androidx.compose.ui.input.pointer.B.m3641equalsimpl0(c2.m3657getIdJ3iCeTQ(), d2.f3117b)) {
                break;
            }
            i8++;
            interfaceC0905c3 = interfaceC0905c4;
        }
        androidx.compose.ui.input.pointer.C c5 = c2;
        if (c5 == null) {
            if (AbstractC0919q.changedToUpIgnoreConsumed(c5)) {
                List<androidx.compose.ui.input.pointer.C> changes2 = c0918p.getChanges();
                int size2 = changes2.size();
                int i9 = 0;
                while (true) {
                    if (i9 >= size2) {
                        c3 = null;
                        break;
                    }
                    c3 = changes2.get(i9);
                    if (c3.getPressed()) {
                        break;
                    }
                    i9++;
                }
                androidx.compose.ui.input.pointer.C c6 = c3;
                if (c6 != null) {
                    d2.f3117b = c6.m3657getIdJ3iCeTQ();
                    interfaceC0905c3 = interfaceC0905c4;
                    interfaceC0905c2 = interfaceC0905c5;
                    tVar2 = tVar3;
                    i6 = 1;
                    rVar = null;
                    tVar2.L$0 = cVar3;
                    tVar2.L$1 = interfaceC0905c2;
                    tVar2.L$2 = i3;
                    tVar2.L$3 = interfaceC0905c3;
                    tVar2.L$4 = d2;
                    tVar2.label = i6;
                    objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, tVar2, i6, rVar);
                    if (objAwaitPointerEvent$default == aVar) {
                        return aVar;
                    }
                    t tVar4 = tVar2;
                    interfaceC0905c5 = interfaceC0905c2;
                    obj = objAwaitPointerEvent$default;
                    tVar3 = tVar4;
                    C0918p c0918p2 = (C0918p) obj;
                    List<androidx.compose.ui.input.pointer.C> changes3 = c0918p2.getChanges();
                    int size3 = changes3.size();
                    int i82 = 0;
                    while (true) {
                        if (i82 < size3) {
                        }
                        i82++;
                        interfaceC0905c3 = interfaceC0905c4;
                    }
                    androidx.compose.ui.input.pointer.C c52 = c2;
                    if (c52 == null) {
                        c52 = null;
                    }
                }
            } else {
                long jPositionChangeIgnoreConsumed = AbstractC0919q.positionChangeIgnoreConsumed(c52);
                if (i3 != null) {
                    fIntBitsToFloat = Float.intBitsToFloat((int) (i3 == I.Vertical ? jPositionChangeIgnoreConsumed & 4294967295L : jPositionChangeIgnoreConsumed >> 32));
                } else {
                    fIntBitsToFloat = J.f.m48getDistanceimpl(jPositionChangeIgnoreConsumed);
                }
            }
        }
        if (c52 == null || c52.isConsumed()) {
            c4 = null;
        } else if (AbstractC0919q.changedToUpIgnoreConsumed(c52)) {
            c4 = c52;
        } else {
            cVar3.invoke(c52);
            interfaceC0905c2 = interfaceC0905c5;
            tVar2 = tVar3;
            i6 = 1;
            rVar = null;
            i2 = i3;
            jM3657getIdJ3iCeTQ = c52.m3657getIdJ3iCeTQ();
            kotlin.jvm.internal.D d32 = new kotlin.jvm.internal.D();
            d32.f3117b = jM3657getIdJ3iCeTQ;
            interfaceC0905c3 = interfaceC0905c2;
            i3 = i2;
            d2 = d32;
            tVar2.L$0 = cVar3;
            tVar2.L$1 = interfaceC0905c2;
            tVar2.L$2 = i3;
            tVar2.L$3 = interfaceC0905c3;
            tVar2.L$4 = d2;
            tVar2.label = i6;
            objAwaitPointerEvent$default = InterfaceC0905c.awaitPointerEvent$default(interfaceC0905c3, rVar, tVar2, i6, rVar);
            if (objAwaitPointerEvent$default == aVar) {
            }
        }
        return Boolean.valueOf(c4 == null);
    }

    public static final Object detectDragGestures(androidx.compose.ui.input.pointer.L l2, I i2, h1.f fVar, h1.c cVar, h1.a aVar, h1.a aVar2, h1.e eVar, Y0.c cVar2) {
        Object objAwaitEachGesture = A.awaitEachGesture(l2, new m(aVar2, new kotlin.jvm.internal.D(), i2, fVar, eVar, aVar, cVar, null), cVar2);
        return objAwaitEachGesture == Z0.a.f1616b ? objAwaitEachGesture : U0.n.f1521a;
    }
}
