package androidx.compose.foundation.gestures;

import android.os.Build;
import android.view.ViewConfiguration;
import androidx.compose.ui.input.pointer.C0918p;
import e0.C1311h;
import e0.InterfaceC1307d;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0377a implements M {
    public static final int $stable = 8;
    private final ViewConfiguration viewConfiguration;

    public C0377a(ViewConfiguration viewConfiguration) {
        this.viewConfiguration = viewConfiguration;
    }

    @Override // androidx.compose.foundation.gestures.M
    /* JADX INFO: renamed from: calculateMouseWheelScroll-8xgXZGE */
    public long mo793calculateMouseWheelScroll8xgXZGE(InterfaceC1307d interfaceC1307d, C0918p c0918p, long j2) {
        float f2 = -getVerticalScrollFactor$foundation_release(interfaceC1307d);
        float f3 = -getHorizontalScrollFactor$foundation_release(interfaceC1307d);
        List<androidx.compose.ui.input.pointer.C> changes = c0918p.getChanges();
        J.f fVarM39boximpl = J.f.m39boximpl(J.f.Companion.m66getZeroF1C5BW0());
        int size = changes.size();
        for (int i2 = 0; i2 < size; i2++) {
            fVarM39boximpl = J.f.m39boximpl(J.f.m55plusMKHz9U(fVarM39boximpl.m60unboximpl(), changes.get(i2).m3661getScrollDeltaF1C5BW0()));
        }
        long jM60unboximpl = fVarM39boximpl.m60unboximpl();
        float fIntBitsToFloat = Float.intBitsToFloat((int) (jM60unboximpl >> 32)) * f3;
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (jM60unboximpl & 4294967295L)) * f2;
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L));
    }

    public final float getHorizontalScrollFactor$foundation_release(InterfaceC1307d interfaceC1307d) {
        return Build.VERSION.SDK_INT > 26 ? m0.INSTANCE.getHorizontalScrollFactor(this.viewConfiguration) : interfaceC1307d.mo788toPx0680j_4(C1311h.m5076constructorimpl(64));
    }

    public final float getVerticalScrollFactor$foundation_release(InterfaceC1307d interfaceC1307d) {
        return Build.VERSION.SDK_INT > 26 ? m0.INSTANCE.getVerticalScrollFactor(this.viewConfiguration) : interfaceC1307d.mo788toPx0680j_4(C1311h.m5076constructorimpl(64));
    }

    public final ViewConfiguration getViewConfiguration() {
        return this.viewConfiguration;
    }

    @Override // androidx.compose.foundation.gestures.M
    public /* bridge */ /* synthetic */ boolean isPreciseWheelScroll(C0918p c0918p) {
        return super.isPreciseWheelScroll(c0918p);
    }

    @Override // androidx.compose.foundation.gestures.M
    public /* bridge */ /* synthetic */ boolean isSmoothScrollingEnabled() {
        return super.isSmoothScrollingEnabled();
    }
}
