package androidx.compose.foundation.gestures;

import O0.C0227q0;
import a.AbstractC0292a;
import androidx.compose.foundation.EnumC0368c0;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.AbstractC1009p;
import androidx.compose.ui.node.InterfaceC1001l;
import java.util.concurrent.CancellationException;
import o.AbstractC1403e;
import r1.AbstractC1473w;
import r1.AbstractC1476z;
import r1.C1459h;
import r1.EnumC1475y;
import r1.InterfaceC1451b0;
import r1.InterfaceC1458g;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0384h extends androidx.compose.ui.w implements androidx.compose.foundation.relocation.g, InterfaceC1001l, androidx.compose.ui.node.L {
    public static final int $stable = 8;
    private InterfaceC0381e bringIntoViewSpec;
    private boolean childWasMaxVisibleBeforeViewportShrunk;
    private androidx.compose.ui.layout.J focusedChild;
    private boolean isAnimationRunning;
    private I orientation;
    private boolean reverseDirection;
    private final e0 scrollingLogic;
    private final boolean shouldAutoInvalidate;
    private boolean trackingFocusedChild;
    private final C0379c bringIntoViewRequests = new C0379c();
    private long viewportSize = e0.s.Companion.m5244getZeroYbymL2g();

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.h$a */
    public static final class a {
        public static final int $stable = 8;
        private final InterfaceC1458g continuation;
        private final h1.a currentBounds;

        public a(h1.a aVar, InterfaceC1458g interfaceC1458g) {
            this.currentBounds = aVar;
            this.continuation = interfaceC1458g;
        }

        public final InterfaceC1458g getContinuation() {
            return this.continuation;
        }

        public final h1.a getCurrentBounds() {
            return this.currentBounds;
        }

        public String toString() {
            if (this.continuation.getContext().get(AbstractC1473w.f3402b) != null) {
                throw new ClassCastException();
            }
            StringBuilder sb = new StringBuilder("Request@");
            int iHashCode = hashCode();
            j1.a.i(16);
            String string = Integer.toString(iHashCode, 16);
            kotlin.jvm.internal.o.d(string, "toString(...)");
            sb.append(string);
            sb.append("(currentBounds()=");
            sb.append(this.currentBounds.invoke());
            sb.append(", continuation=");
            sb.append(this.continuation);
            sb.append(')');
            return sb.toString();
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.h$b */
    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ l0 $animationState;
        final /* synthetic */ InterfaceC0381e $bringIntoViewSpec;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX INFO: renamed from: androidx.compose.foundation.gestures.h$b$a */
        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ InterfaceC1451b0 $animationJob;
            final /* synthetic */ l0 $animationState;
            final /* synthetic */ InterfaceC0381e $bringIntoViewSpec;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0384h this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(l0 l0Var, C0384h c0384h, InterfaceC0381e interfaceC0381e, InterfaceC1451b0 interfaceC1451b0, Y0.c cVar) {
                super(2, cVar);
                this.$animationState = l0Var;
                this.this$0 = c0384h;
                this.$bringIntoViewSpec = interfaceC0381e;
                this.$animationJob = interfaceC1451b0;
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final U0.n invokeSuspend$lambda$1(C0384h c0384h, l0 l0Var, InterfaceC1451b0 interfaceC1451b0, G g2, float f2) {
                float f3 = c0384h.reverseDirection ? 1.0f : -1.0f;
                e0 e0Var = c0384h.scrollingLogic;
                float fM821toFloatk4lQ0M = e0Var.m821toFloatk4lQ0M(e0Var.m819reverseIfNeededMKHz9U(g2.mo766scrollByOzD1aCk(e0Var.m819reverseIfNeededMKHz9U(e0Var.m822toOffsettuRUvjQ(f3 * f2)), androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI()))) * f3;
                if (Math.abs(fM821toFloatk4lQ0M) < Math.abs(f2)) {
                    CancellationException cancellationException = new CancellationException("Scroll animation cancelled because scroll was not consumed (" + fM821toFloatk4lQ0M + " < " + f2 + ')');
                    cancellationException.initCause(null);
                    interfaceC1451b0.cancel(cancellationException);
                }
                return U0.n.f1521a;
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final U0.n invokeSuspend$lambda$4(C0384h c0384h, l0 l0Var, InterfaceC0381e interfaceC0381e) {
                U0.n nVar;
                C0379c c0379c = c0384h.bringIntoViewRequests;
                while (true) {
                    int size = c0379c.requests.getSize();
                    nVar = U0.n.f1521a;
                    if (size != 0) {
                        J.h hVar = (J.h) ((a) c0379c.requests.last()).getCurrentBounds().invoke();
                        if (!(hVar == null ? true : C0384h.m830isMaxVisibleO0kMr_c$default(c0384h, hVar, 0L, 1, null))) {
                            break;
                        }
                        ((a) c0379c.requests.removeAt(c0379c.requests.getSize() - 1)).getContinuation().resumeWith(nVar);
                    } else {
                        break;
                    }
                }
                if (c0384h.trackingFocusedChild) {
                    J.h focusedChildBounds = c0384h.getFocusedChildBounds();
                    if (focusedChildBounds != null && C0384h.m830isMaxVisibleO0kMr_c$default(c0384h, focusedChildBounds, 0L, 1, null)) {
                        c0384h.trackingFocusedChild = false;
                    }
                }
                l0Var.setValue(c0384h.calculateScrollDelta(interfaceC0381e));
                return nVar;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$animationState, this.this$0, this.$bringIntoViewSpec, this.$animationJob, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // h1.e
            public final Object invoke(G g2, Y0.c cVar) {
                return ((a) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    G g2 = (G) this.L$0;
                    this.$animationState.setValue(this.this$0.calculateScrollDelta(this.$bringIntoViewSpec));
                    l0 l0Var = this.$animationState;
                    C0384h c0384h = this.this$0;
                    M0.q qVar = new M0.q(c0384h, l0Var, this.$animationJob, g2, 5);
                    C0227q0 c0227q0 = new C0227q0(c0384h, l0Var, this.$bringIntoViewSpec, 2);
                    this.label = 1;
                    if (l0Var.animateToZero(qVar, c0227q0, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                }
                return U0.n.f1521a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(l0 l0Var, InterfaceC0381e interfaceC0381e, Y0.c cVar) {
            super(2, cVar);
            this.$animationState = l0Var;
            this.$bringIntoViewSpec = interfaceC0381e;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = C0384h.this.new b(this.$animationState, this.$bringIntoViewSpec, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            CancellationException cancellationException = null;
            try {
                try {
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        InterfaceC1451b0 interfaceC1451b0K = AbstractC1476z.k(((InterfaceC1474x) this.L$0).getCoroutineContext());
                        C0384h.this.isAnimationRunning = true;
                        e0 e0Var = C0384h.this.scrollingLogic;
                        EnumC0368c0 enumC0368c0 = EnumC0368c0.Default;
                        a aVar2 = new a(this.$animationState, C0384h.this, this.$bringIntoViewSpec, interfaceC1451b0K, null);
                        this.label = 1;
                        if (e0Var.scroll(enumC0368c0, aVar2, this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    C0384h.this.bringIntoViewRequests.resumeAndRemoveAll();
                    C0384h.this.isAnimationRunning = false;
                    C0384h.this.bringIntoViewRequests.cancelAndRemoveAll(null);
                    C0384h.this.trackingFocusedChild = false;
                    return U0.n.f1521a;
                } catch (CancellationException e2) {
                    cancellationException = e2;
                    throw cancellationException;
                }
            } catch (Throwable th) {
                C0384h.this.isAnimationRunning = false;
                C0384h.this.bringIntoViewRequests.cancelAndRemoveAll(cancellationException);
                C0384h.this.trackingFocusedChild = false;
                throw th;
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public C0384h(I i2, e0 e0Var, boolean z2, InterfaceC0381e interfaceC0381e) {
        this.orientation = i2;
        this.scrollingLogic = e0Var;
        this.reverseDirection = z2;
        this.bringIntoViewSpec = interfaceC0381e;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float calculateScrollDelta(InterfaceC0381e interfaceC0381e) {
        if (e0.s.m5237equalsimpl0(this.viewportSize, e0.s.Companion.m5244getZeroYbymL2g())) {
            return 0.0f;
        }
        J.h hVarFindBringIntoViewRequest = findBringIntoViewRequest();
        if (hVarFindBringIntoViewRequest == null) {
            hVarFindBringIntoViewRequest = this.trackingFocusedChild ? getFocusedChildBounds() : null;
            if (hVarFindBringIntoViewRequest == null) {
                return 0.0f;
            }
        }
        long jM5251toSizeozmzZPI = e0.t.m5251toSizeozmzZPI(this.viewportSize);
        int i2 = AbstractC0385i.$EnumSwitchMapping$0[this.orientation.ordinal()];
        if (i2 == 1) {
            return interfaceC0381e.calculateScrollDistance(hVarFindBringIntoViewRequest.getTop(), hVarFindBringIntoViewRequest.getBottom() - hVarFindBringIntoViewRequest.getTop(), Float.intBitsToFloat((int) (jM5251toSizeozmzZPI & 4294967295L)));
        }
        if (i2 == 2) {
            return interfaceC0381e.calculateScrollDistance(hVarFindBringIntoViewRequest.getLeft(), hVarFindBringIntoViewRequest.getRight() - hVarFindBringIntoViewRequest.getLeft(), Float.intBitsToFloat((int) (jM5251toSizeozmzZPI >> 32)));
        }
        throw new H0.c();
    }

    /* JADX INFO: renamed from: compareTo-TemP2vQ, reason: not valid java name */
    private final int m826compareToTemP2vQ(long j2, long j3) {
        int i2 = AbstractC0385i.$EnumSwitchMapping$0[this.orientation.ordinal()];
        if (i2 == 1) {
            return kotlin.jvm.internal.o.f((int) (j2 & 4294967295L), (int) (j3 & 4294967295L));
        }
        if (i2 == 2) {
            return kotlin.jvm.internal.o.f((int) (j2 >> 32), (int) (j3 >> 32));
        }
        throw new H0.c();
    }

    /* JADX INFO: renamed from: compareTo-iLBOSCw, reason: not valid java name */
    private final int m827compareToiLBOSCw(long j2, long j3) {
        int i2 = AbstractC0385i.$EnumSwitchMapping$0[this.orientation.ordinal()];
        if (i2 == 1) {
            return Float.compare(Float.intBitsToFloat((int) (j2 & 4294967295L)), Float.intBitsToFloat((int) (j3 & 4294967295L)));
        }
        if (i2 == 2) {
            return Float.compare(Float.intBitsToFloat((int) (j2 >> 32)), Float.intBitsToFloat((int) (j3 >> 32)));
        }
        throw new H0.c();
    }

    /* JADX INFO: renamed from: computeDestination-O0kMr_c, reason: not valid java name */
    private final J.h m828computeDestinationO0kMr_c(J.h hVar, long j2) {
        return hVar.m87translatek4lQ0M(J.f.m42constructorimpl(m831relocationOffsetBMxPBkI(hVar, j2) ^ e0.n.DualFloatSignBit));
    }

    private final J.h findBringIntoViewRequest() {
        androidx.compose.runtime.collection.c cVar = this.bringIntoViewRequests.requests;
        int size = cVar.getSize() - 1;
        Object[] objArr = cVar.content;
        J.h hVar = null;
        if (size < objArr.length) {
            while (size >= 0) {
                J.h hVar2 = (J.h) ((a) objArr[size]).getCurrentBounds().invoke();
                if (hVar2 != null) {
                    if (m827compareToiLBOSCw(hVar2.m83getSizeNHjbRc(), e0.t.m5251toSizeozmzZPI(this.viewportSize)) > 0) {
                        return hVar == null ? hVar2 : hVar;
                    }
                    hVar = hVar2;
                }
                size--;
            }
        }
        return hVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final J.h getFocusedChildBounds() {
        if (!isAttached()) {
            return null;
        }
        androidx.compose.ui.layout.J jRequireLayoutCoordinates = AbstractC1009p.requireLayoutCoordinates(this);
        androidx.compose.ui.layout.J j2 = this.focusedChild;
        if (j2 != null) {
            if (!j2.isAttached()) {
                j2 = null;
            }
            if (j2 != null) {
                return jRequireLayoutCoordinates.localBoundingBoxOf(j2, false);
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: isMaxVisible-O0kMr_c, reason: not valid java name */
    private final boolean m829isMaxVisibleO0kMr_c(J.h hVar, long j2) {
        long jM831relocationOffsetBMxPBkI = m831relocationOffsetBMxPBkI(hVar, j2);
        return Math.abs(Float.intBitsToFloat((int) (jM831relocationOffsetBMxPBkI >> 32))) <= 0.5f && Math.abs(Float.intBitsToFloat((int) (jM831relocationOffsetBMxPBkI & 4294967295L))) <= 0.5f;
    }

    /* JADX INFO: renamed from: isMaxVisible-O0kMr_c$default, reason: not valid java name */
    public static /* synthetic */ boolean m830isMaxVisibleO0kMr_c$default(C0384h c0384h, J.h hVar, long j2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            j2 = c0384h.viewportSize;
        }
        return c0384h.m829isMaxVisibleO0kMr_c(hVar, j2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void launchAnimation() {
        InterfaceC0381e interfaceC0381eRequireBringIntoViewSpec = requireBringIntoViewSpec();
        if (this.isAnimationRunning) {
            AbstractC1403e.throwIllegalStateException("launchAnimation called when previous animation was running");
        }
        AbstractC1476z.s(getCoroutineScope(), null, EnumC1475y.f3408e, new b(new l0(requireBringIntoViewSpec().getScrollAnimationSpec()), interfaceC0381eRequireBringIntoViewSpec, null), 1);
    }

    /* JADX INFO: renamed from: relocationOffset-BMxPBkI, reason: not valid java name */
    private final long m831relocationOffsetBMxPBkI(J.h hVar, long j2) {
        long jM5251toSizeozmzZPI = e0.t.m5251toSizeozmzZPI(j2);
        int i2 = AbstractC0385i.$EnumSwitchMapping$0[this.orientation.ordinal()];
        if (i2 != 1) {
            if (i2 != 2) {
                throw new H0.c();
            }
            return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(requireBringIntoViewSpec().calculateScrollDistance(hVar.getLeft(), hVar.getRight() - hVar.getLeft(), Float.intBitsToFloat((int) (jM5251toSizeozmzZPI >> 32))))) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L));
        }
        float fCalculateScrollDistance = requireBringIntoViewSpec().calculateScrollDistance(hVar.getTop(), hVar.getBottom() - hVar.getTop(), Float.intBitsToFloat((int) (jM5251toSizeozmzZPI & 4294967295L)));
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(0.0f)) << 32) | (((long) Float.floatToRawIntBits(fCalculateScrollDistance)) & 4294967295L));
    }

    private final InterfaceC0381e requireBringIntoViewSpec() {
        InterfaceC0381e interfaceC0381e = this.bringIntoViewSpec;
        return interfaceC0381e == null ? (InterfaceC0381e) AbstractC1003m.currentValueOf(this, AbstractC0383g.getLocalBringIntoViewSpec()) : interfaceC0381e;
    }

    @Override // androidx.compose.foundation.relocation.g
    public Object bringChildIntoView(h1.a aVar, Y0.c cVar) {
        J.h hVar = (J.h) aVar.invoke();
        U0.n nVar = U0.n.f1521a;
        if (hVar != null && !m830isMaxVisibleO0kMr_c$default(this, hVar, 0L, 1, null)) {
            C1459h c1459h = new C1459h(1, j1.a.H(cVar));
            c1459h.s();
            if (this.bringIntoViewRequests.enqueue(new a(aVar, c1459h)) && !this.isAnimationRunning) {
                launchAnimation();
            }
            Object objR = c1459h.r();
            if (objR == Z0.a.f1616b) {
                return objR;
            }
        }
        return nVar;
    }

    @Override // androidx.compose.foundation.relocation.g
    public J.h calculateRectForParent(J.h hVar) {
        if (e0.s.m5237equalsimpl0(this.viewportSize, e0.s.Companion.m5244getZeroYbymL2g())) {
            AbstractC1403e.throwIllegalStateException("Expected BringIntoViewRequester to not be used before parents are placed.");
        }
        return m828computeDestinationO0kMr_c(hVar, this.viewportSize);
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    /* JADX INFO: renamed from: getViewportSize-YbymL2g$foundation_release, reason: not valid java name */
    public final long m832getViewportSizeYbymL2g$foundation_release() {
        return this.viewportSize;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    public final void onFocusBoundsChanged(androidx.compose.ui.layout.J j2) {
        J.h focusedChildBounds;
        this.focusedChild = j2;
        if (this.childWasMaxVisibleBeforeViewportShrunk && (focusedChildBounds = getFocusedChildBounds()) != null && !m829isMaxVisibleO0kMr_c(focusedChildBounds, this.viewportSize)) {
            this.trackingFocusedChild = true;
            launchAnimation();
        }
        this.childWasMaxVisibleBeforeViewportShrunk = false;
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.L
    public /* bridge */ /* synthetic */ void onPlaced(androidx.compose.ui.layout.J j2) {
        super.onPlaced(j2);
    }

    @Override // androidx.compose.ui.node.L
    /* JADX INFO: renamed from: onRemeasured-ozmzZPI, reason: not valid java name */
    public void mo833onRemeasuredozmzZPI(long j2) {
        J.h focusedChildBounds;
        long j3 = this.viewportSize;
        this.viewportSize = j2;
        if (m826compareToTemP2vQ(j2, j3) >= 0 || this.isAnimationRunning || this.trackingFocusedChild || (focusedChildBounds = getFocusedChildBounds()) == null || !m829isMaxVisibleO0kMr_c(focusedChildBounds, j3)) {
            return;
        }
        this.childWasMaxVisibleBeforeViewportShrunk = true;
    }

    public final void update(I i2, boolean z2, InterfaceC0381e interfaceC0381e) {
        this.orientation = i2;
        this.reverseDirection = z2;
        this.bringIntoViewSpec = interfaceC0381e;
    }
}
