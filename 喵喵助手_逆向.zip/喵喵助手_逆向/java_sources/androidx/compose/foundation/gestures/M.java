package androidx.compose.foundation.gestures;

import androidx.compose.ui.input.pointer.C0918p;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public interface M {
    /* JADX INFO: renamed from: calculateMouseWheelScroll-8xgXZGE, reason: not valid java name */
    long mo793calculateMouseWheelScroll8xgXZGE(InterfaceC1307d interfaceC1307d, C0918p c0918p, long j2);

    default boolean isPreciseWheelScroll(C0918p c0918p) {
        return false;
    }

    default boolean isSmoothScrollingEnabled() {
        return true;
    }
}
