package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public final class W implements androidx.compose.ui.B {
    @Override // androidx.compose.ui.B, Y0.h
    public <R> R fold(R r2, h1.e eVar) {
        return (R) androidx.compose.ui.z.fold(this, r2, eVar);
    }

    @Override // androidx.compose.ui.B, Y0.h
    public <E extends Y0.f> E get(Y0.g gVar) {
        return (E) androidx.compose.ui.z.get(this, gVar);
    }

    @Override // androidx.compose.ui.B, Y0.f
    public /* bridge */ /* synthetic */ Y0.g getKey() {
        return super.getKey();
    }

    @Override // androidx.compose.ui.B
    public float getScaleFactor() {
        return 1.0f;
    }

    @Override // androidx.compose.ui.B, Y0.h
    public Y0.h minusKey(Y0.g gVar) {
        return androidx.compose.ui.z.minusKey(this, gVar);
    }

    @Override // androidx.compose.ui.B, Y0.h
    public Y0.h plus(Y0.h hVar) {
        return androidx.compose.ui.z.plus(this, hVar);
    }
}
