package androidx.compose.foundation.gestures;

import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class ScrollableElement extends AbstractC1000k0 {
    private final InterfaceC0381e bringIntoViewSpec;
    private final boolean enabled;
    private final InterfaceC0400y flingBehavior;
    private final androidx.compose.foundation.interaction.n interactionSource;
    private final I orientation;
    private final androidx.compose.foundation.i0 overscrollEffect;
    private final boolean reverseDirection;
    private final c0 state;

    public ScrollableElement(c0 c0Var, I i2, androidx.compose.foundation.i0 i0Var, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e) {
        this.state = c0Var;
        this.orientation = i2;
        this.overscrollEffect = i0Var;
        this.enabled = z2;
        this.reverseDirection = z3;
        this.flingBehavior = interfaceC0400y;
        this.interactionSource = nVar;
        this.bringIntoViewSpec = interfaceC0381e;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ScrollableElement)) {
            return false;
        }
        ScrollableElement scrollableElement = (ScrollableElement) obj;
        return kotlin.jvm.internal.o.a(this.state, scrollableElement.state) && this.orientation == scrollableElement.orientation && kotlin.jvm.internal.o.a(this.overscrollEffect, scrollableElement.overscrollEffect) && this.enabled == scrollableElement.enabled && this.reverseDirection == scrollableElement.reverseDirection && kotlin.jvm.internal.o.a(this.flingBehavior, scrollableElement.flingBehavior) && kotlin.jvm.internal.o.a(this.interactionSource, scrollableElement.interactionSource) && kotlin.jvm.internal.o.a(this.bringIntoViewSpec, scrollableElement.bringIntoViewSpec);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final InterfaceC0381e getBringIntoViewSpec() {
        return this.bringIntoViewSpec;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final InterfaceC0400y getFlingBehavior() {
        return this.flingBehavior;
    }

    public final androidx.compose.foundation.interaction.n getInteractionSource() {
        return this.interactionSource;
    }

    public final I getOrientation() {
        return this.orientation;
    }

    public final androidx.compose.foundation.i0 getOverscrollEffect() {
        return this.overscrollEffect;
    }

    public final boolean getReverseDirection() {
        return this.reverseDirection;
    }

    public final c0 getState() {
        return this.state;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        int iHashCode = (this.orientation.hashCode() + (this.state.hashCode() * 31)) * 31;
        androidx.compose.foundation.i0 i0Var = this.overscrollEffect;
        int iC = D0.d.c(D0.d.c((iHashCode + (i0Var != null ? i0Var.hashCode() : 0)) * 31, 31, this.enabled), 31, this.reverseDirection);
        InterfaceC0400y interfaceC0400y = this.flingBehavior;
        int iHashCode2 = (iC + (interfaceC0400y != null ? interfaceC0400y.hashCode() : 0)) * 31;
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        int iHashCode3 = (iHashCode2 + (nVar != null ? nVar.hashCode() : 0)) * 31;
        InterfaceC0381e interfaceC0381e = this.bringIntoViewSpec;
        return iHashCode3 + (interfaceC0381e != null ? interfaceC0381e.hashCode() : 0);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("scrollable");
        c1065l1.getProperties().set("orientation", this.orientation);
        c1065l1.getProperties().set("state", this.state);
        c1065l1.getProperties().set("overscrollEffect", this.overscrollEffect);
        D0.d.l(this.reverseDirection, D0.d.l(this.enabled, c1065l1.getProperties(), "enabled", c1065l1), "reverseDirection", c1065l1).set("flingBehavior", this.flingBehavior);
        c1065l1.getProperties().set("interactionSource", this.interactionSource);
        c1065l1.getProperties().set("bringIntoViewSpec", this.bringIntoViewSpec);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public b0 create() {
        return new b0(this.state, this.overscrollEffect, this.flingBehavior, this.orientation, this.enabled, this.reverseDirection, this.interactionSource, this.bringIntoViewSpec);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(b0 b0Var) {
        b0Var.update(this.state, this.orientation, this.overscrollEffect, this.enabled, this.reverseDirection, this.flingBehavior, this.interactionSource, this.bringIntoViewSpec);
    }
}
