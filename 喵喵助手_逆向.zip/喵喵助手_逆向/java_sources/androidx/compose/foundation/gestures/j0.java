package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.D0;

/* JADX INFO: loaded from: classes.dex */
public abstract class j0 {
    private static final h1.c NoOnReport = new D0(20);

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n NoOnReport$lambda$0(float f2) {
        return U0.n.f1521a;
    }
}
