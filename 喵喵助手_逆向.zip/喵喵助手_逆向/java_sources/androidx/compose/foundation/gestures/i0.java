package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public interface i0 extends InterfaceC0400y {
    static /* synthetic */ Object performFling$suspendImpl(i0 i0Var, Q q2, float f2, Y0.c cVar) {
        return i0Var.performFling(q2, f2, j0.NoOnReport, cVar);
    }

    @Override // androidx.compose.foundation.gestures.InterfaceC0400y
    default Object performFling(Q q2, float f2, Y0.c cVar) {
        return performFling$suspendImpl(this, q2, f2, cVar);
    }

    Object performFling(Q q2, float f2, h1.c cVar, Y0.c cVar2);
}
