package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.ui.input.pointer.InterfaceC0905c;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {

    public static final class a extends a1.i implements h1.e {
        private /* synthetic */ Object L$0;
        int label;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            a aVar = new a(cVar);
            aVar.L$0 = obj;
            return aVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((a) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC0905c interfaceC0905c = (InterfaceC0905c) this.L$0;
                this.label = 1;
                if (A.awaitAllPointersUp$default(interfaceC0905c, null, this, 1, null) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    public static final class b extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return A.awaitAllPointersUp(null, null, this);
        }
    }

    public static final class c extends a1.i implements h1.e {
        final /* synthetic */ h1.e $block;
        final /* synthetic */ Y0.h $currentContext;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(Y0.h hVar, h1.e eVar, Y0.c cVar) {
            super(cVar);
            this.$currentContext = hVar;
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            c cVar2 = new c(this.$currentContext, this.$block, cVar);
            cVar2.L$0 = obj;
            return cVar2;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0905c interfaceC0905c, Y0.c cVar) {
            return ((c) create(interfaceC0905c, cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:27:0x005a A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:32:0x0067  */
        /* JADX WARN: Removed duplicated region for block: B:35:0x0072  */
        /* JADX WARN: Removed duplicated region for block: B:36:0x0073  */
        /* JADX WARN: Removed duplicated region for block: B:38:0x0042 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Type inference failed for: r1v0, types: [int] */
        /* JADX WARN: Type inference failed for: r1v1 */
        /* JADX WARN: Type inference failed for: r1v10 */
        /* JADX WARN: Type inference failed for: r1v11 */
        /* JADX WARN: Type inference failed for: r1v18 */
        /* JADX WARN: Type inference failed for: r1v19 */
        /* JADX WARN: Type inference failed for: r1v2, types: [androidx.compose.ui.input.pointer.c, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r1v20 */
        /* JADX WARN: Type inference failed for: r1v21 */
        /* JADX WARN: Type inference failed for: r1v22 */
        /* JADX WARN: Type inference failed for: r1v3, types: [androidx.compose.ui.input.pointer.c, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r1v7 */
        /* JADX WARN: Type inference failed for: r1v8, types: [h1.e] */
        /* JADX WARN: Type inference failed for: r9v12 */
        /* JADX WARN: Type inference failed for: r9v5, types: [java.lang.Object] */
        /* JADX WARN: Type inference failed for: r9v8 */
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x0058 -> B:12:0x0027). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x006f -> B:12:0x0027). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                r8 = this;
                Z0.a r0 = Z0.a.f1616b
                int r1 = r8.label
                r2 = 3
                r3 = 2
                r4 = 0
                r5 = 1
                if (r1 == 0) goto L33
                if (r1 == r5) goto L2b
                if (r1 == r3) goto L20
                if (r1 != r2) goto L18
                java.lang.Object r1 = r8.L$0
                androidx.compose.ui.input.pointer.c r1 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r1
                a.AbstractC0292a.H(r9)
                goto L27
            L18:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r0)
                throw r9
            L20:
                java.lang.Object r1 = r8.L$0
                androidx.compose.ui.input.pointer.c r1 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r1
                a.AbstractC0292a.H(r9)     // Catch: java.util.concurrent.CancellationException -> L29
            L27:
                r9 = r1
                goto L3a
            L29:
                r9 = move-exception
                goto L5f
            L2b:
                java.lang.Object r1 = r8.L$0
                androidx.compose.ui.input.pointer.c r1 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r1
                a.AbstractC0292a.H(r9)     // Catch: java.util.concurrent.CancellationException -> L29
                goto L50
            L33:
                a.AbstractC0292a.H(r9)
                java.lang.Object r9 = r8.L$0
                androidx.compose.ui.input.pointer.c r9 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r9
            L3a:
                Y0.h r1 = r8.$currentContext
                boolean r1 = r1.AbstractC1476z.o(r1)
                if (r1 == 0) goto L73
                h1.e r1 = r8.$block     // Catch: java.util.concurrent.CancellationException -> L5b
                r8.L$0 = r9     // Catch: java.util.concurrent.CancellationException -> L5b
                r8.label = r5     // Catch: java.util.concurrent.CancellationException -> L5b
                java.lang.Object r1 = r1.invoke(r9, r8)     // Catch: java.util.concurrent.CancellationException -> L5b
                if (r1 != r0) goto L4f
                return r0
            L4f:
                r1 = r9
            L50:
                r8.L$0 = r1     // Catch: java.util.concurrent.CancellationException -> L29
                r8.label = r3     // Catch: java.util.concurrent.CancellationException -> L29
                java.lang.Object r9 = androidx.compose.foundation.gestures.A.awaitAllPointersUp$default(r1, r4, r8, r5, r4)     // Catch: java.util.concurrent.CancellationException -> L29
                if (r9 != r0) goto L27
                return r0
            L5b:
                r1 = move-exception
                r7 = r1
                r1 = r9
                r9 = r7
            L5f:
                Y0.h r6 = r8.$currentContext
                boolean r6 = r1.AbstractC1476z.o(r6)
                if (r6 == 0) goto L72
                r8.L$0 = r1
                r8.label = r2
                java.lang.Object r9 = androidx.compose.foundation.gestures.A.awaitAllPointersUp$default(r1, r4, r8, r5, r4)
                if (r9 != r0) goto L27
                return r0
            L72:
                throw r9
            L73:
                U0.n r9 = U0.n.f1521a
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.A.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public static final class d extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return A.forEachGesture(null, null, this);
        }
    }

    public static final boolean allPointersUp(InterfaceC0905c interfaceC0905c) {
        List<androidx.compose.ui.input.pointer.C> changes = interfaceC0905c.getCurrentEvent().getChanges();
        int size = changes.size();
        boolean z2 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            if (changes.get(i2).getPressed()) {
                z2 = true;
                break;
            }
            i2++;
        }
        return !z2;
    }

    public static final Object awaitAllPointersUp(androidx.compose.ui.input.pointer.L l2, Y0.c cVar) {
        Object objAwaitPointerEventScope = l2.awaitPointerEventScope(new a(null), cVar);
        return objAwaitPointerEventScope == Z0.a.f1616b ? objAwaitPointerEventScope : U0.n.f1521a;
    }

    public static /* synthetic */ Object awaitAllPointersUp$default(InterfaceC0905c interfaceC0905c, androidx.compose.ui.input.pointer.r rVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            rVar = androidx.compose.ui.input.pointer.r.Final;
        }
        return awaitAllPointersUp(interfaceC0905c, rVar, cVar);
    }

    public static final Object awaitEachGesture(androidx.compose.ui.input.pointer.L l2, h1.e eVar, Y0.c cVar) {
        Object objAwaitPointerEventScope = l2.awaitPointerEventScope(new c(cVar.getContext(), eVar, null), cVar);
        return objAwaitPointerEventScope == Z0.a.f1616b ? objAwaitPointerEventScope : U0.n.f1521a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0091 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0072 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r10v10 */
    /* JADX WARN: Type inference failed for: r10v6, types: [Y0.h, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r10v8 */
    /* JADX WARN: Type inference failed for: r2v0, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v19 */
    /* JADX WARN: Type inference failed for: r2v2, types: [androidx.compose.ui.input.pointer.L, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v20 */
    /* JADX WARN: Type inference failed for: r2v3, types: [androidx.compose.ui.input.pointer.L, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r8v0, types: [androidx.compose.ui.input.pointer.L] */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v17 */
    /* JADX WARN: Type inference failed for: r8v18 */
    /* JADX WARN: Type inference failed for: r8v19 */
    /* JADX WARN: Type inference failed for: r8v2, types: [Y0.h, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v20 */
    /* JADX WARN: Type inference failed for: r8v21 */
    /* JADX WARN: Type inference failed for: r8v22 */
    /* JADX WARN: Type inference failed for: r8v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v6 */
    /* JADX WARN: Type inference failed for: r8v8 */
    /* JADX WARN: Type inference failed for: r8v9 */
    /* JADX WARN: Type inference failed for: r9v0, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v13 */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v17 */
    /* JADX WARN: Type inference failed for: r9v18 */
    /* JADX WARN: Type inference failed for: r9v19 */
    /* JADX WARN: Type inference failed for: r9v2, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v20 */
    /* JADX WARN: Type inference failed for: r9v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v4, types: [h1.e, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x008f -> B:18:0x0050). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:39:0x00a9 -> B:18:0x0050). Please report as a decompilation issue!!! */
    @U0.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object forEachGesture(androidx.compose.ui.input.pointer.L r8, h1.e r9, Y0.c r10) {
        /*
            boolean r0 = r10 instanceof androidx.compose.foundation.gestures.A.d
            if (r0 == 0) goto L13
            r0 = r10
            androidx.compose.foundation.gestures.A$d r0 = (androidx.compose.foundation.gestures.A.d) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.A$d r0 = new androidx.compose.foundation.gestures.A$d
            r0.<init>(r10)
        L18:
            java.lang.Object r10 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 3
            r4 = 2
            r5 = 1
            if (r2 == 0) goto L65
            if (r2 == r5) goto L55
            if (r2 == r4) goto L41
            if (r2 != r3) goto L39
            java.lang.Object r8 = r0.L$2
            Y0.h r8 = (Y0.h) r8
            java.lang.Object r9 = r0.L$1
            h1.e r9 = (h1.e) r9
            java.lang.Object r2 = r0.L$0
            androidx.compose.ui.input.pointer.L r2 = (androidx.compose.ui.input.pointer.L) r2
            a.AbstractC0292a.H(r10)
            goto L50
        L39:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L41:
            java.lang.Object r8 = r0.L$2
            Y0.h r8 = (Y0.h) r8
            java.lang.Object r9 = r0.L$1
            h1.e r9 = (h1.e) r9
            java.lang.Object r2 = r0.L$0
            androidx.compose.ui.input.pointer.L r2 = (androidx.compose.ui.input.pointer.L) r2
            a.AbstractC0292a.H(r10)     // Catch: java.util.concurrent.CancellationException -> L53
        L50:
            r10 = r8
            r8 = r2
            goto L6c
        L53:
            r10 = move-exception
            goto L97
        L55:
            java.lang.Object r8 = r0.L$2
            Y0.h r8 = (Y0.h) r8
            java.lang.Object r9 = r0.L$1
            h1.e r9 = (h1.e) r9
            java.lang.Object r2 = r0.L$0
            androidx.compose.ui.input.pointer.L r2 = (androidx.compose.ui.input.pointer.L) r2
            a.AbstractC0292a.H(r10)     // Catch: java.util.concurrent.CancellationException -> L53
            goto L83
        L65:
            a.AbstractC0292a.H(r10)
            Y0.h r10 = r0.getContext()
        L6c:
            boolean r2 = r1.AbstractC1476z.o(r10)
            if (r2 == 0) goto Lad
            r0.L$0 = r8     // Catch: java.util.concurrent.CancellationException -> L92
            r0.L$1 = r9     // Catch: java.util.concurrent.CancellationException -> L92
            r0.L$2 = r10     // Catch: java.util.concurrent.CancellationException -> L92
            r0.label = r5     // Catch: java.util.concurrent.CancellationException -> L92
            java.lang.Object r2 = r9.invoke(r8, r0)     // Catch: java.util.concurrent.CancellationException -> L92
            if (r2 != r1) goto L81
            return r1
        L81:
            r2 = r8
            r8 = r10
        L83:
            r0.L$0 = r2     // Catch: java.util.concurrent.CancellationException -> L53
            r0.L$1 = r9     // Catch: java.util.concurrent.CancellationException -> L53
            r0.L$2 = r8     // Catch: java.util.concurrent.CancellationException -> L53
            r0.label = r4     // Catch: java.util.concurrent.CancellationException -> L53
            java.lang.Object r10 = awaitAllPointersUp(r2, r0)     // Catch: java.util.concurrent.CancellationException -> L53
            if (r10 != r1) goto L50
            return r1
        L92:
            r2 = move-exception
            r7 = r2
            r2 = r8
            r8 = r10
            r10 = r7
        L97:
            boolean r6 = r1.AbstractC1476z.o(r8)
            if (r6 == 0) goto Lac
            r0.L$0 = r2
            r0.L$1 = r9
            r0.L$2 = r8
            r0.label = r3
            java.lang.Object r10 = awaitAllPointersUp(r2, r0)
            if (r10 != r1) goto L50
            return r1
        Lac:
            throw r10
        Lad:
            U0.n r8 = U0.n.f1521a
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.A.forEachGesture(androidx.compose.ui.input.pointer.L, h1.e, Y0.c):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0041, code lost:
    
        if (allPointersUp(r7) == false) goto L16;
     */
    /* JADX WARN: Removed duplicated region for block: B:21:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x004d -> B:19:0x0050). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object awaitAllPointersUp(androidx.compose.ui.input.pointer.InterfaceC0905c r7, androidx.compose.ui.input.pointer.r r8, Y0.c r9) {
        /*
            boolean r0 = r9 instanceof androidx.compose.foundation.gestures.A.b
            if (r0 == 0) goto L13
            r0 = r9
            androidx.compose.foundation.gestures.A$b r0 = (androidx.compose.foundation.gestures.A.b) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.A$b r0 = new androidx.compose.foundation.gestures.A$b
            r0.<init>(r9)
        L18:
            java.lang.Object r9 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L3a
            if (r2 != r3) goto L32
            java.lang.Object r7 = r0.L$1
            androidx.compose.ui.input.pointer.r r7 = (androidx.compose.ui.input.pointer.r) r7
            java.lang.Object r8 = r0.L$0
            androidx.compose.ui.input.pointer.c r8 = (androidx.compose.ui.input.pointer.InterfaceC0905c) r8
            a.AbstractC0292a.H(r9)
            r6 = r8
            r8 = r7
            r7 = r6
            goto L50
        L32:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L3a:
            a.AbstractC0292a.H(r9)
            boolean r9 = allPointersUp(r7)
            if (r9 != 0) goto L6d
        L43:
            r0.L$0 = r7
            r0.L$1 = r8
            r0.label = r3
            java.lang.Object r9 = r7.awaitPointerEvent(r8, r0)
            if (r9 != r1) goto L50
            return r1
        L50:
            androidx.compose.ui.input.pointer.p r9 = (androidx.compose.ui.input.pointer.C0918p) r9
            java.util.List r9 = r9.getChanges()
            int r2 = r9.size()
            r4 = 0
        L5b:
            if (r4 >= r2) goto L6d
            java.lang.Object r5 = r9.get(r4)
            androidx.compose.ui.input.pointer.C r5 = (androidx.compose.ui.input.pointer.C) r5
            boolean r5 = r5.getPressed()
            if (r5 == 0) goto L6a
            goto L43
        L6a:
            int r4 = r4 + 1
            goto L5b
        L6d:
            U0.n r7 = U0.n.f1521a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.A.awaitAllPointersUp(androidx.compose.ui.input.pointer.c, androidx.compose.ui.input.pointer.r, Y0.c):java.lang.Object");
    }
}
