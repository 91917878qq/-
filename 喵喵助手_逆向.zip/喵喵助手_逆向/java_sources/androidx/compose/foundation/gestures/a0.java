package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public final class a0 implements androidx.compose.ui.input.nestedscroll.a {
    public static final int $stable = 8;
    private boolean enabled;
    private final P scrollingLogic;

    public static final class a extends a1.c {
        long J$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return a0.this.mo801onPostFlingRZ2iAVY(0L, 0L, this);
        }
    }

    public a0(P p2, boolean z2) {
        this.scrollingLogic = p2;
        this.enabled = z2;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final P getScrollingLogic() {
        return this.scrollingLogic;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // androidx.compose.ui.input.nestedscroll.a
    /* JADX INFO: renamed from: onPostFling-RZ2iAVY, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object mo801onPostFlingRZ2iAVY(long r3, long r5, Y0.c r7) {
        /*
            r2 = this;
            boolean r3 = r7 instanceof androidx.compose.foundation.gestures.a0.a
            if (r3 == 0) goto L13
            r3 = r7
            androidx.compose.foundation.gestures.a0$a r3 = (androidx.compose.foundation.gestures.a0.a) r3
            int r4 = r3.label
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r4 & r0
            if (r1 == 0) goto L13
            int r4 = r4 - r0
            r3.label = r4
            goto L18
        L13:
            androidx.compose.foundation.gestures.a0$a r3 = new androidx.compose.foundation.gestures.a0$a
            r3.<init>(r7)
        L18:
            java.lang.Object r4 = r3.result
            Z0.a r7 = Z0.a.f1616b
            int r0 = r3.label
            r1 = 1
            if (r0 == 0) goto L31
            if (r0 != r1) goto L29
            long r5 = r3.J$0
            a.AbstractC0292a.H(r4)
            goto L54
        L29:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            r3.<init>(r4)
            throw r3
        L31:
            a.AbstractC0292a.H(r4)
            boolean r4 = r2.enabled
            if (r4 == 0) goto L5f
            androidx.compose.foundation.gestures.P r4 = r2.scrollingLogic
            boolean r4 = r4.isFlinging()
            if (r4 == 0) goto L47
            e0.z$a r3 = e0.z.Companion
            long r3 = r3.m5317getZero9UxMQ8M()
            goto L5a
        L47:
            androidx.compose.foundation.gestures.P r4 = r2.scrollingLogic
            r3.J$0 = r5
            r3.label = r1
            java.lang.Object r4 = r4.mo797doFlingAnimationQWom1Mo(r5, r3)
            if (r4 != r7) goto L54
            return r7
        L54:
            e0.z r4 = (e0.z) r4
            long r3 = r4.m5315unboximpl()
        L5a:
            long r3 = e0.z.m5309minusAH228Gc(r5, r3)
            goto L65
        L5f:
            e0.z$a r3 = e0.z.Companion
            long r3 = r3.m5317getZero9UxMQ8M()
        L65:
            e0.z r3 = e0.z.m5297boximpl(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.a0.mo801onPostFlingRZ2iAVY(long, long, Y0.c):java.lang.Object");
    }

    @Override // androidx.compose.ui.input.nestedscroll.a
    /* JADX INFO: renamed from: onPostScroll-DzOQY0M, reason: not valid java name */
    public long mo802onPostScrollDzOQY0M(long j2, long j3, int i2) {
        return this.enabled ? this.scrollingLogic.mo798performRawScrollMKHz9U(j3) : J.f.Companion.m66getZeroF1C5BW0();
    }

    @Override // androidx.compose.ui.input.nestedscroll.a
    /* JADX INFO: renamed from: onPreFling-QWom1Mo, reason: not valid java name */
    public /* bridge */ /* synthetic */ Object mo803onPreFlingQWom1Mo(long j2, Y0.c cVar) {
        return super.mo803onPreFlingQWom1Mo(j2, cVar);
    }

    @Override // androidx.compose.ui.input.nestedscroll.a
    /* JADX INFO: renamed from: onPreScroll-OzD1aCk, reason: not valid java name */
    public /* bridge */ /* synthetic */ long mo804onPreScrollOzD1aCk(long j2, int i2) {
        return super.mo804onPreScrollOzD1aCk(j2, i2);
    }

    public final void setEnabled(boolean z2) {
        this.enabled = z2;
    }
}
