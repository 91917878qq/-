package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public interface P {
    /* JADX INFO: renamed from: doFlingAnimation-QWom1Mo, reason: not valid java name */
    Object mo797doFlingAnimationQWom1Mo(long j2, Y0.c cVar);

    boolean isFlinging();

    /* JADX INFO: renamed from: performRawScroll-MK-Hz9U, reason: not valid java name */
    long mo798performRawScrollMKHz9U(long j2);
}
