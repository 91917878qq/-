package androidx.compose.foundation.gestures;

import O0.C0228r0;
import a.AbstractC0292a;
import androidx.compose.animation.core.AbstractC0333s0;
import androidx.compose.animation.core.D0;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public abstract class Z {
    private static final float DefaultScrollMotionDurationScaleFactor = 1.0f;
    private static final h1.c CanDragCalculation = new D0(19);
    private static final Q NoOpScrollScope = new X();
    private static final androidx.compose.ui.B DefaultScrollMotionDurationScale = new W();
    private static final InterfaceC1307d UnityDensity = new Y();

    public static final class a extends a1.c {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return Z.m800semanticsScrollByd4ec7I(null, 0L, this);
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ long $offset;
        final /* synthetic */ kotlin.jvm.internal.B $previousValue;
        final /* synthetic */ e0 $this_semanticsScrollBy;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(e0 e0Var, long j2, kotlin.jvm.internal.B b2, Y0.c cVar) {
            super(2, cVar);
            this.$this_semanticsScrollBy = e0Var;
            this.$offset = j2;
            this.$previousValue = b2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.B b2, e0 e0Var, G g2, float f2, float f3) {
            b2.f3115b += e0Var.reverseIfNeeded(e0Var.m821toFloatk4lQ0M(g2.mo766scrollByOzD1aCk(e0Var.m822toOffsettuRUvjQ(e0Var.reverseIfNeeded(f2 - b2.f3115b)), androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI())));
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = new b(this.$this_semanticsScrollBy, this.$offset, this.$previousValue, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // h1.e
        public final Object invoke(G g2, Y0.c cVar) {
            return ((b) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                G g2 = (G) this.L$0;
                float fM821toFloatk4lQ0M = this.$this_semanticsScrollBy.m821toFloatk4lQ0M(this.$offset);
                C0228r0 c0228r0 = new C0228r0(this.$previousValue, this.$this_semanticsScrollBy, g2, 4);
                this.label = 1;
                if (AbstractC0333s0.animate$default(0.0f, fM821toFloatk4lQ0M, 0.0f, null, c0228r0, this, 12, null) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean CanDragCalculation$lambda$0(androidx.compose.ui.input.pointer.C c2) {
        return !androidx.compose.ui.input.pointer.Q.m3711equalsimpl0(c2.m3662getTypeT8wyACA(), androidx.compose.ui.input.pointer.Q.Companion.m3716getMouseT8wyACA());
    }

    public static final h1.c getCanDragCalculation() {
        return CanDragCalculation;
    }

    public static final androidx.compose.ui.B getDefaultScrollMotionDurationScale() {
        return DefaultScrollMotionDurationScale;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean getShouldBeTriggeredByMouseWheel(InterfaceC0400y interfaceC0400y) {
        return !(interfaceC0400y instanceof U);
    }

    public static final InterfaceC1307d getUnityDensity() {
        return UnityDensity;
    }

    public static final androidx.compose.ui.x scrollable(androidx.compose.ui.x xVar, c0 c0Var, I i2, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar) {
        return scrollable$default(xVar, c0Var, i2, null, z2, z3, interfaceC0400y, nVar, null, 128, null);
    }

    public static /* synthetic */ androidx.compose.ui.x scrollable$default(androidx.compose.ui.x xVar, c0 c0Var, I i2, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            z2 = true;
        }
        boolean z4 = z2;
        if ((i3 & 8) != 0) {
            z3 = false;
        }
        return scrollable(xVar, c0Var, i2, z4, z3, (i3 & 16) != 0 ? null : interfaceC0400y, (i3 & 32) != 0 ? null : nVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX INFO: renamed from: semanticsScrollBy-d-4ec7I, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object m800semanticsScrollByd4ec7I(androidx.compose.foundation.gestures.e0 r11, long r12, Y0.c r14) {
        /*
            boolean r0 = r14 instanceof androidx.compose.foundation.gestures.Z.a
            if (r0 == 0) goto L13
            r0 = r14
            androidx.compose.foundation.gestures.Z$a r0 = (androidx.compose.foundation.gestures.Z.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.Z$a r0 = new androidx.compose.foundation.gestures.Z$a
            r0.<init>(r14)
        L18:
            java.lang.Object r14 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L39
            if (r2 != r3) goto L31
            java.lang.Object r11 = r0.L$1
            kotlin.jvm.internal.B r11 = (kotlin.jvm.internal.B) r11
            java.lang.Object r12 = r0.L$0
            androidx.compose.foundation.gestures.e0 r12 = (androidx.compose.foundation.gestures.e0) r12
            a.AbstractC0292a.H(r14)
            r14 = r11
            r11 = r12
            goto L5a
        L31:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r12)
            throw r11
        L39:
            a.AbstractC0292a.H(r14)
            kotlin.jvm.internal.B r14 = new kotlin.jvm.internal.B
            r14.<init>()
            androidx.compose.foundation.c0 r2 = androidx.compose.foundation.EnumC0368c0.Default
            androidx.compose.foundation.gestures.Z$b r10 = new androidx.compose.foundation.gestures.Z$b
            r9 = 0
            r4 = r10
            r5 = r11
            r6 = r12
            r8 = r14
            r4.<init>(r5, r6, r8, r9)
            r0.L$0 = r11
            r0.L$1 = r14
            r0.label = r3
            java.lang.Object r12 = r11.scroll(r2, r10, r0)
            if (r12 != r1) goto L5a
            return r1
        L5a:
            float r12 = r14.f3115b
            long r11 = r11.m822toOffsettuRUvjQ(r12)
            J.f r11 = J.f.m39boximpl(r11)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.Z.m800semanticsScrollByd4ec7I(androidx.compose.foundation.gestures.e0, long, Y0.c):java.lang.Object");
    }

    public static final androidx.compose.ui.x scrollable(androidx.compose.ui.x xVar, c0 c0Var, I i2, androidx.compose.foundation.i0 i0Var, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e) {
        return xVar.then(new ScrollableElement(c0Var, i2, i0Var, z2, z3, interfaceC0400y, nVar, interfaceC0381e));
    }

    public static /* synthetic */ androidx.compose.ui.x scrollable$default(androidx.compose.ui.x xVar, c0 c0Var, I i2, androidx.compose.foundation.i0 i0Var, boolean z2, boolean z3, InterfaceC0400y interfaceC0400y, androidx.compose.foundation.interaction.n nVar, InterfaceC0381e interfaceC0381e, int i3, Object obj) {
        return scrollable(xVar, c0Var, i2, i0Var, (i3 & 8) != 0 ? true : z2, (i3 & 16) != 0 ? false : z3, (i3 & 32) != 0 ? null : interfaceC0400y, (i3 & 64) != 0 ? null : nVar, (i3 & 128) != 0 ? null : interfaceC0381e);
    }
}
