package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.InterfaceC0313i;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0381e {
    public static final C0380d Companion = C0380d.$$INSTANCE;

    @U0.a
    static /* synthetic */ void getScrollAnimationSpec$annotations() {
    }

    default float calculateScrollDistance(float f2, float f3, float f4) {
        return Companion.defaultCalculateScrollDistance$foundation_release(f2, f3, f4);
    }

    @U0.a
    default InterfaceC0313i getScrollAnimationSpec() {
        return Companion.getDefaultScrollAnimationSpec$foundation_release();
    }
}
