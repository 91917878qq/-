package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public final class X implements Q {
    @Override // androidx.compose.foundation.gestures.Q
    public float scrollBy(float f2) {
        return f2;
    }
}
