package androidx.compose.foundation.gestures;

import Q0.o0;
import a.AbstractC0292a;
import androidx.compose.animation.core.C0321m;
import androidx.compose.animation.core.E0;
import androidx.compose.animation.core.F0;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.runtime.AbstractC0801u0;
import kotlin.jvm.internal.AbstractC1378g;
import kotlin.jvm.internal.C1379h;
import o.AbstractC1403e;

/* JADX INFO: loaded from: classes.dex */
public final class l0 {

    @Deprecated
    public static final float VisibilityThreshold = 0.01f;
    private boolean isRunning;
    private long lastFrameTime = Long.MIN_VALUE;
    private C0321m lastVelocity = ZeroVector;
    private float value;
    private final F0 vectorizedSpec;
    private static final a Companion = new a(null);
    public static final int $stable = 8;
    private static final C0321m ZeroVector = new C0321m(0.0f);

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final C0321m getZeroVector() {
            return l0.ZeroVector;
        }

        public final boolean isZeroish(float f2) {
            return Math.abs(f2) < 0.01f;
        }

        private a() {
        }
    }

    public static final class b extends a1.c {
        float F$0;
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return l0.this.animateToZero(null, null, this);
        }
    }

    public l0(InterfaceC0313i interfaceC0313i) {
        this.vectorizedSpec = interfaceC0313i.vectorize(E0.getVectorConverter(C1379h.f3125a));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateToZero$lambda$1(l0 l0Var, float f2, h1.c cVar, long j2) {
        if (l0Var.lastFrameTime == Long.MIN_VALUE) {
            l0Var.lastFrameTime = j2;
        }
        C0321m c0321m = new C0321m(l0Var.value);
        long durationNanos = f2 == 0.0f ? l0Var.vectorizedSpec.getDurationNanos(new C0321m(l0Var.value), ZeroVector, l0Var.lastVelocity) : j1.a.U((j2 - l0Var.lastFrameTime) / f2);
        F0 f02 = l0Var.vectorizedSpec;
        C0321m c0321m2 = ZeroVector;
        float value = ((C0321m) f02.getValueFromNanos(durationNanos, c0321m, c0321m2, l0Var.lastVelocity)).getValue();
        l0Var.lastVelocity = (C0321m) l0Var.vectorizedSpec.getVelocityFromNanos(durationNanos, c0321m, c0321m2, l0Var.lastVelocity);
        l0Var.lastFrameTime = j2;
        float f3 = l0Var.value - value;
        l0Var.value = value;
        cVar.invoke(Float.valueOf(f3));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateToZero$lambda$2(l0 l0Var, h1.c cVar, long j2) {
        float f2 = l0Var.value;
        l0Var.value = 0.0f;
        cVar.invoke(Float.valueOf(f2));
        return U0.n.f1521a;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0075 A[Catch: all -> 0x0033, PHI: r12 r13 r14
  0x0075: PHI (r12v4 float) = (r12v2 float), (r12v5 float) binds: [B:29:0x006f, B:36:0x0098] A[DONT_GENERATE, DONT_INLINE]
  0x0075: PHI (r13v6 h1.c) = (r13v2 h1.c), (r13v7 h1.c) binds: [B:29:0x006f, B:36:0x0098] A[DONT_GENERATE, DONT_INLINE]
  0x0075: PHI (r14v16 h1.a) = (r14v8 h1.a), (r14v17 h1.a) binds: [B:29:0x006f, B:36:0x0098] A[DONT_GENERATE, DONT_INLINE], TRY_ENTER, TryCatch #0 {all -> 0x0033, blocks: (B:13:0x002e, B:43:0x00bb, B:20:0x0048, B:35:0x0093, B:30:0x0075, B:32:0x007f, B:37:0x009a, B:40:0x00a6), top: B:48:0x0024 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x007f A[Catch: all -> 0x0033, TryCatch #0 {all -> 0x0033, blocks: (B:13:0x002e, B:43:0x00bb, B:20:0x0048, B:35:0x0093, B:30:0x0075, B:32:0x007f, B:37:0x009a, B:40:0x00a6), top: B:48:0x0024 }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00a6 A[Catch: all -> 0x0033, TryCatch #0 {all -> 0x0033, blocks: (B:13:0x002e, B:43:0x00bb, B:20:0x0048, B:35:0x0093, B:30:0x0075, B:32:0x007f, B:37:0x009a, B:40:0x00a6), top: B:48:0x0024 }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x0090 -> B:35:0x0093). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object animateToZero(h1.c cVar, h1.a aVar, Y0.c cVar2) {
        b bVar;
        h1.c cVar3;
        float f2;
        h1.a aVar2;
        h1.a aVar3;
        if (cVar2 instanceof b) {
            bVar = (b) cVar2;
            int i2 = bVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                bVar.label = i2 - Integer.MIN_VALUE;
            } else {
                bVar = new b(cVar2);
            }
        }
        Object obj = bVar.result;
        Z0.a aVar4 = Z0.a.f1616b;
        int i3 = bVar.label;
        try {
            if (i3 != 0) {
                if (i3 != 1) {
                    if (i3 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    aVar3 = (h1.a) bVar.L$0;
                    AbstractC0292a.H(obj);
                    aVar3.invoke();
                    this.lastFrameTime = Long.MIN_VALUE;
                    this.lastVelocity = ZeroVector;
                    this.isRunning = false;
                    return U0.n.f1521a;
                }
                f2 = bVar.F$0;
                h1.a aVar5 = (h1.a) bVar.L$1;
                h1.c cVar4 = (h1.c) bVar.L$0;
                AbstractC0292a.H(obj);
                aVar2 = aVar5;
                cVar3 = cVar4;
                aVar2.invoke();
                if (f2 != 0.0f) {
                    if (!Companion.isZeroish(this.value)) {
                        o0 o0Var = new o0(this, f2, cVar3);
                        bVar.L$0 = cVar3;
                        bVar.L$1 = aVar2;
                        bVar.F$0 = f2;
                        bVar.label = 1;
                        if (AbstractC0801u0.withFrameNanos(o0Var, bVar) == aVar4) {
                            return aVar4;
                        }
                        aVar2.invoke();
                        if (f2 != 0.0f) {
                        }
                    }
                }
                aVar3 = aVar2;
                if (Math.abs(this.value) != 0.0f) {
                    this.lastFrameTime = Long.MIN_VALUE;
                    this.lastVelocity = ZeroVector;
                    this.isRunning = false;
                    return U0.n.f1521a;
                }
                M0.m mVar = new M0.m(18, this, cVar3);
                bVar.L$0 = aVar3;
                bVar.L$1 = null;
                bVar.label = 2;
                if (AbstractC0801u0.withFrameNanos(mVar, bVar) == aVar4) {
                    return aVar4;
                }
                aVar3.invoke();
                this.lastFrameTime = Long.MIN_VALUE;
                this.lastVelocity = ZeroVector;
                this.isRunning = false;
                return U0.n.f1521a;
            }
            AbstractC0292a.H(obj);
            if (this.isRunning) {
                AbstractC1403e.throwIllegalStateException("animateToZero called while previous animation is running");
            }
            androidx.compose.ui.B b2 = (androidx.compose.ui.B) bVar.getContext().get(androidx.compose.ui.B.Key);
            float scaleFactor = b2 != null ? b2.getScaleFactor() : 1.0f;
            this.isRunning = true;
            cVar3 = cVar;
            f2 = scaleFactor;
            aVar2 = aVar;
            if (!Companion.isZeroish(this.value)) {
            }
            aVar3 = aVar2;
            if (Math.abs(this.value) != 0.0f) {
            }
        } catch (Throwable th) {
            this.lastFrameTime = Long.MIN_VALUE;
            this.lastVelocity = ZeroVector;
            this.isRunning = false;
            throw th;
        }
    }

    public final float getValue() {
        return this.value;
    }

    public final void setValue(float f2) {
        this.value = f2;
    }
}
