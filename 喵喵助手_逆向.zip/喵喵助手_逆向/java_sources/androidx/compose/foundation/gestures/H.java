package androidx.compose.foundation.gestures;

/* JADX INFO: loaded from: classes.dex */
public interface H {
    /* JADX INFO: renamed from: dispatchScrollDeltaInfo-k-4lQ0M, reason: not valid java name */
    void mo768dispatchScrollDeltaInfok4lQ0M(long j2);
}
