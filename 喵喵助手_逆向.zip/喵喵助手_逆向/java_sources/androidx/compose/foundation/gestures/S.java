package androidx.compose.foundation.gestures;

import androidx.compose.foundation.EnumC0368c0;

/* JADX INFO: loaded from: classes.dex */
public interface S {
    static /* synthetic */ Object scroll$default(S s2, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: scroll");
        }
        if ((i2 & 1) != 0) {
            EnumC0368c0 enumC0368c02 = EnumC0368c0.Default;
        }
        return s2.a();
    }

    Object a();
}
