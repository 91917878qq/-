package androidx.compose.foundation.gestures;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;

/* JADX INFO: loaded from: classes.dex */
public abstract class d0 {
    public static final c0 ScrollableState(h1.c cVar) {
        return new C0388l(cVar);
    }

    public static final c0 rememberScrollableState(h1.c cVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-180460798, i2, -1, "androidx.compose.foundation.gestures.rememberScrollableState (ScrollableState.kt:159)");
        }
        d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(cVar, interfaceC0768p, i2 & 14);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = ScrollableState(new Q0.c0(d2VarRememberUpdatedState, 4));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        c0 c0Var = (c0) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return c0Var;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float rememberScrollableState$lambda$1$lambda$0(d2 d2Var, float f2) {
        return ((Number) ((h1.c) d2Var.getValue()).invoke(Float.valueOf(f2))).floatValue();
    }
}
