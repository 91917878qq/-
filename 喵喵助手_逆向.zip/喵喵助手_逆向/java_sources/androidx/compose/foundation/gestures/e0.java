package androidx.compose.foundation.gestures;

import O0.C0218m;
import a.AbstractC0292a;
import androidx.compose.foundation.EnumC0368c0;
import e0.AbstractC1303A;

/* JADX INFO: loaded from: classes.dex */
public final class e0 implements P {
    public static final int $stable = 8;
    private InterfaceC0400y flingBehavior;
    private boolean isFlinging;
    private final h1.a isScrollableNodeAttached;
    private androidx.compose.ui.input.nestedscroll.b nestedScrollDispatcher;
    private H onScrollChangedDispatcher;
    private I orientation;
    private androidx.compose.foundation.i0 overscrollEffect;
    private boolean reverseDirection;
    private c0 scrollableState;
    private int latestScrollSource = androidx.compose.ui.input.nestedscroll.f.Companion.m3636getUserInputWNlRxjI();
    private Q outerStateScope = Z.NoOpScrollScope;
    private final c nestedScrollScope = new c();
    private final h1.c performScrollForOverscroll = new C0218m(this, 10);

    public static final class a extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return e0.this.mo797doFlingAnimationQWom1Mo(0L, this);
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ long $available;
        final /* synthetic */ kotlin.jvm.internal.D $result;
        long J$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        int label;

        public static final class a implements Q {
            final /* synthetic */ G $nestedScrollScope;
            final /* synthetic */ e0 this$0;

            public a(e0 e0Var, G g2) {
                this.this$0 = e0Var;
                this.$nestedScrollScope = g2;
            }

            @Override // androidx.compose.foundation.gestures.Q
            public float scrollBy(float f2) {
                boolean zShouldCancelFling = androidx.compose.foundation.A.isFlingContinuationAtBoundsEnabled ? !((Boolean) this.this$0.isScrollableNodeAttached.invoke()).booleanValue() : this.this$0.shouldCancelFling(f2);
                if (Math.abs(f2) != 0.0f && zShouldCancelFling) {
                    throw new C0401z();
                }
                e0 e0Var = this.this$0;
                return e0Var.reverseIfNeeded(e0Var.m821toFloatk4lQ0M(this.$nestedScrollScope.mo767scrollByWithOverscrollOzD1aCk(e0Var.m819reverseIfNeededMKHz9U(e0Var.m822toOffsettuRUvjQ(f2)), androidx.compose.ui.input.nestedscroll.f.Companion.m3635getSideEffectWNlRxjI())));
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(kotlin.jvm.internal.D d2, long j2, Y0.c cVar) {
            super(2, cVar);
            this.$result = d2;
            this.$available = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = e0.this.new b(this.$result, this.$available, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // h1.e
        public final Object invoke(G g2, Y0.c cVar) {
            return ((b) create(g2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            e0 e0Var;
            kotlin.jvm.internal.D d2;
            e0 e0Var2;
            long j2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                a aVar2 = new a(e0.this, (G) this.L$0);
                e0Var = e0.this;
                kotlin.jvm.internal.D d3 = this.$result;
                long j3 = this.$available;
                InterfaceC0400y interfaceC0400y = e0Var.flingBehavior;
                long j4 = d3.f3117b;
                float fReverseIfNeeded = e0Var.reverseIfNeeded(e0Var.m816toFloatTH1AsA0(j3));
                this.L$0 = e0Var;
                this.L$1 = e0Var;
                this.L$2 = d3;
                this.J$0 = j4;
                this.label = 1;
                Object objPerformFling = interfaceC0400y.performFling(aVar2, fReverseIfNeeded, this);
                if (objPerformFling == aVar) {
                    return aVar;
                }
                d2 = d3;
                obj = objPerformFling;
                e0Var2 = e0Var;
                j2 = j4;
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                j2 = this.J$0;
                d2 = (kotlin.jvm.internal.D) this.L$2;
                e0Var = (e0) this.L$1;
                e0Var2 = (e0) this.L$0;
                AbstractC0292a.H(obj);
            }
            d2.f3117b = e0Var.m817updateQWom1Mo(j2, e0Var2.reverseIfNeeded(((Number) obj).floatValue()));
            return U0.n.f1521a;
        }
    }

    public static final class c implements G {
        public c() {
        }

        @Override // androidx.compose.foundation.gestures.G
        /* JADX INFO: renamed from: scrollBy-OzD1aCk */
        public long mo766scrollByOzD1aCk(long j2, int i2) {
            return e0.this.m814performScroll3eAAhYA(e0.this.outerStateScope, j2, i2);
        }

        @Override // androidx.compose.foundation.gestures.G
        /* JADX INFO: renamed from: scrollByWithOverscroll-OzD1aCk */
        public long mo767scrollByWithOverscrollOzD1aCk(long j2, int i2) {
            e0.this.latestScrollSource = i2;
            androidx.compose.foundation.i0 i0Var = e0.this.overscrollEffect;
            if (i0Var != null && e0.this.getShouldDispatchOverscroll()) {
                return i0Var.mo695applyToScrollRhakbz0(j2, e0.this.latestScrollSource, e0.this.performScrollForOverscroll);
            }
            return e0.this.m814performScroll3eAAhYA(e0.this.outerStateScope, j2, i2);
        }
    }

    public static final class d extends a1.j implements h1.e {
        /* synthetic */ long J$0;
        long J$1;
        int label;

        public d(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            d dVar = e0.this.new d(cVar);
            dVar.J$0 = ((e0.z) obj).m5315unboximpl();
            return dVar;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return m824invokesFctU(((e0.z) obj).m5315unboximpl(), (Y0.c) obj2);
        }

        /* JADX INFO: renamed from: invoke-sF-c-tU, reason: not valid java name */
        public final Object m824invokesFctU(long j2, Y0.c cVar) {
            return ((d) create(e0.z.m5297boximpl(j2), cVar)).invokeSuspend(U0.n.f1521a);
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0085 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:23:0x0086  */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r14) {
            /*
                r13 = this;
                Z0.a r6 = Z0.a.f1616b
                int r0 = r13.label
                r1 = 3
                r2 = 2
                r3 = 1
                if (r0 == 0) goto L33
                if (r0 == r3) goto L2c
                if (r0 == r2) goto L22
                if (r0 != r1) goto L1a
                long r0 = r13.J$1
                long r2 = r13.J$0
                a.AbstractC0292a.H(r14)
                r9 = r0
                r0 = r14
                goto L87
            L1a:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L22:
                long r2 = r13.J$1
                long r4 = r13.J$0
                a.AbstractC0292a.H(r14)
                r0 = r14
                r7 = r4
                goto L66
            L2c:
                long r3 = r13.J$0
                a.AbstractC0292a.H(r14)
                r0 = r14
                goto L4a
            L33:
                a.AbstractC0292a.H(r14)
                long r4 = r13.J$0
                androidx.compose.foundation.gestures.e0 r0 = androidx.compose.foundation.gestures.e0.this
                androidx.compose.ui.input.nestedscroll.b r0 = androidx.compose.foundation.gestures.e0.access$getNestedScrollDispatcher$p(r0)
                r13.J$0 = r4
                r13.label = r3
                java.lang.Object r0 = r0.m3619dispatchPreFlingQWom1Mo(r4, r13)
                if (r0 != r6) goto L49
                return r6
            L49:
                r3 = r4
            L4a:
                e0.z r0 = (e0.z) r0
                long r7 = r0.m5315unboximpl()
                long r7 = e0.z.m5309minusAH228Gc(r3, r7)
                androidx.compose.foundation.gestures.e0 r0 = androidx.compose.foundation.gestures.e0.this
                r13.J$0 = r3
                r13.J$1 = r7
                r13.label = r2
                java.lang.Object r0 = r0.mo797doFlingAnimationQWom1Mo(r7, r13)
                if (r0 != r6) goto L63
                return r6
            L63:
                r11 = r3
                r2 = r7
                r7 = r11
            L66:
                e0.z r0 = (e0.z) r0
                long r9 = r0.m5315unboximpl()
                androidx.compose.foundation.gestures.e0 r0 = androidx.compose.foundation.gestures.e0.this
                androidx.compose.ui.input.nestedscroll.b r0 = androidx.compose.foundation.gestures.e0.access$getNestedScrollDispatcher$p(r0)
                long r2 = e0.z.m5309minusAH228Gc(r2, r9)
                r13.J$0 = r7
                r13.J$1 = r9
                r13.label = r1
                r1 = r2
                r3 = r9
                r5 = r13
                java.lang.Object r0 = r0.m3617dispatchPostFlingRZ2iAVY(r1, r3, r5)
                if (r0 != r6) goto L86
                return r6
            L86:
                r2 = r7
            L87:
                e0.z r0 = (e0.z) r0
                long r0 = r0.m5315unboximpl()
                long r0 = e0.z.m5309minusAH228Gc(r9, r0)
                long r0 = e0.z.m5309minusAH228Gc(r2, r0)
                e0.z r0 = e0.z.m5297boximpl(r0)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.e0.d.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public static final class e extends a1.j implements h1.e {
        final /* synthetic */ h1.e $block;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(h1.e eVar, Y0.c cVar) {
            super(2, cVar);
            this.$block = eVar;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            e eVar = e0.this.new e(this.$block, cVar);
            eVar.L$0 = obj;
            return eVar;
        }

        @Override // h1.e
        public final Object invoke(Q q2, Y0.c cVar) {
            return ((e) create(q2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                e0.this.outerStateScope = (Q) this.L$0;
                h1.e eVar = this.$block;
                c cVar = e0.this.nestedScrollScope;
                this.label = 1;
                if (eVar.invoke(cVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    public e0(c0 c0Var, androidx.compose.foundation.i0 i0Var, InterfaceC0400y interfaceC0400y, I i2, boolean z2, androidx.compose.ui.input.nestedscroll.b bVar, H h2, h1.a aVar) {
        this.scrollableState = c0Var;
        this.overscrollEffect = i0Var;
        this.flingBehavior = interfaceC0400y;
        this.orientation = i2;
        this.reverseDirection = z2;
        this.nestedScrollDispatcher = bVar;
        this.onScrollChangedDispatcher = h2;
        this.isScrollableNodeAttached = aVar;
    }

    /* JADX INFO: renamed from: dispatchRawDelta-MK-Hz9U, reason: not valid java name */
    private final long m813dispatchRawDeltaMKHz9U(long j2) {
        return m822toOffsettuRUvjQ(reverseIfNeeded(this.scrollableState.dispatchRawDelta(reverseIfNeeded(m821toFloatk4lQ0M(j2)))));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean getShouldDispatchOverscroll() {
        return this.scrollableState.getCanScrollForward() || this.scrollableState.getCanScrollBackward();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: performScroll-3eAAhYA, reason: not valid java name */
    public final long m814performScroll3eAAhYA(Q q2, long j2, int i2) {
        long jM3620dispatchPreScrollOzD1aCk = this.nestedScrollDispatcher.m3620dispatchPreScrollOzD1aCk(j2, i2);
        long jM54minusMKHz9U = J.f.m54minusMKHz9U(j2, jM3620dispatchPreScrollOzD1aCk);
        long jM819reverseIfNeededMKHz9U = m819reverseIfNeededMKHz9U(m822toOffsettuRUvjQ(q2.scrollBy(m821toFloatk4lQ0M(m819reverseIfNeededMKHz9U(m820singleAxisOffsetMKHz9U(jM54minusMKHz9U))))));
        if (androidx.compose.foundation.A.isOnScrollChangedCallbackEnabled) {
            this.onScrollChangedDispatcher.mo768dispatchScrollDeltaInfok4lQ0M(jM819reverseIfNeededMKHz9U);
        }
        return J.f.m55plusMKHz9U(J.f.m55plusMKHz9U(jM3620dispatchPreScrollOzD1aCk, jM819reverseIfNeededMKHz9U), this.nestedScrollDispatcher.m3618dispatchPostScrollDzOQY0M(jM819reverseIfNeededMKHz9U, J.f.m54minusMKHz9U(jM54minusMKHz9U, jM819reverseIfNeededMKHz9U), i2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.f performScrollForOverscroll$lambda$1(e0 e0Var, J.f fVar) {
        return J.f.m39boximpl(e0Var.m814performScroll3eAAhYA(e0Var.outerStateScope, fVar.m60unboximpl(), e0Var.latestScrollSource));
    }

    public static /* synthetic */ Object scroll$default(e0 e0Var, EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return e0Var.scroll(enumC0368c0, eVar, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean shouldCancelFling(float f2) {
        return (f2 > 0.0f && !this.scrollableState.getCanScrollForward()) || (f2 < 0.0f && !this.scrollableState.getCanScrollBackward()) || !((Boolean) this.isScrollableNodeAttached.invoke()).booleanValue();
    }

    /* JADX INFO: renamed from: singleAxisVelocity-AH228Gc, reason: not valid java name */
    private final long m815singleAxisVelocityAH228Gc(long j2) {
        return this.orientation == I.Horizontal ? e0.z.m5302copyOhffZ5M$default(j2, 0.0f, 0.0f, 1, null) : e0.z.m5302copyOhffZ5M$default(j2, 0.0f, 0.0f, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: toFloat-TH1AsA0, reason: not valid java name */
    public final float m816toFloatTH1AsA0(long j2) {
        return this.orientation == I.Horizontal ? e0.z.m5306getXimpl(j2) : e0.z.m5307getYimpl(j2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: update-QWom1Mo, reason: not valid java name */
    public final long m817updateQWom1Mo(long j2, float f2) {
        return this.orientation == I.Horizontal ? e0.z.m5302copyOhffZ5M$default(j2, f2, 0.0f, 2, null) : e0.z.m5302copyOhffZ5M$default(j2, 0.0f, f2, 1, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // androidx.compose.foundation.gestures.P
    /* JADX INFO: renamed from: doFlingAnimation-QWom1Mo */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object mo797doFlingAnimationQWom1Mo(long r13, Y0.c r15) {
        /*
            r12 = this;
            boolean r0 = r15 instanceof androidx.compose.foundation.gestures.e0.a
            if (r0 == 0) goto L13
            r0 = r15
            androidx.compose.foundation.gestures.e0$a r0 = (androidx.compose.foundation.gestures.e0.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.e0$a r0 = new androidx.compose.foundation.gestures.e0$a
            r0.<init>(r15)
        L18:
            java.lang.Object r15 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L36
            if (r2 != r4) goto L2e
            java.lang.Object r13 = r0.L$0
            kotlin.jvm.internal.D r13 = (kotlin.jvm.internal.D) r13
            a.AbstractC0292a.H(r15)     // Catch: java.lang.Throwable -> L2c
            goto L5a
        L2c:
            r13 = move-exception
            goto L63
        L2e:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r14 = "call to 'resume' before 'invoke' with coroutine"
            r13.<init>(r14)
            throw r13
        L36:
            a.AbstractC0292a.H(r15)
            kotlin.jvm.internal.D r15 = new kotlin.jvm.internal.D
            r15.<init>()
            r15.f3117b = r13
            r12.isFlinging = r4
            androidx.compose.foundation.c0 r2 = androidx.compose.foundation.EnumC0368c0.Default     // Catch: java.lang.Throwable -> L2c
            androidx.compose.foundation.gestures.e0$b r11 = new androidx.compose.foundation.gestures.e0$b     // Catch: java.lang.Throwable -> L2c
            r10 = 0
            r5 = r11
            r6 = r12
            r7 = r15
            r8 = r13
            r5.<init>(r7, r8, r10)     // Catch: java.lang.Throwable -> L2c
            r0.L$0 = r15     // Catch: java.lang.Throwable -> L2c
            r0.label = r4     // Catch: java.lang.Throwable -> L2c
            java.lang.Object r13 = r12.scroll(r2, r11, r0)     // Catch: java.lang.Throwable -> L2c
            if (r13 != r1) goto L59
            return r1
        L59:
            r13 = r15
        L5a:
            r12.isFlinging = r3
            long r13 = r13.f3117b
            e0.z r13 = e0.z.m5297boximpl(r13)
            return r13
        L63:
            r12.isFlinging = r3
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.e0.mo797doFlingAnimationQWom1Mo(long, Y0.c):java.lang.Object");
    }

    public final c0 getScrollableState() {
        return this.scrollableState;
    }

    @Override // androidx.compose.foundation.gestures.P
    public boolean isFlinging() {
        return this.isFlinging;
    }

    public final boolean isVertical() {
        return this.orientation == I.Vertical;
    }

    /* JADX INFO: renamed from: onScrollStopped-BMRW4eQ, reason: not valid java name */
    public final Object m818onScrollStoppedBMRW4eQ(long j2, boolean z2, Y0.c cVar) {
        U0.n nVar = U0.n.f1521a;
        if (z2 && !Z.getShouldBeTriggeredByMouseWheel(this.flingBehavior)) {
            return nVar;
        }
        long jM815singleAxisVelocityAH228Gc = m815singleAxisVelocityAH228Gc(j2);
        d dVar = new d(null);
        androidx.compose.foundation.i0 i0Var = this.overscrollEffect;
        if (i0Var == null || !getShouldDispatchOverscroll()) {
            Object objInvoke = dVar.invoke(e0.z.m5297boximpl(jM815singleAxisVelocityAH228Gc), cVar);
            return objInvoke == Z0.a.f1616b ? objInvoke : nVar;
        }
        Object objMo694applyToFlingBMRW4eQ = i0Var.mo694applyToFlingBMRW4eQ(jM815singleAxisVelocityAH228Gc, dVar, cVar);
        return objMo694applyToFlingBMRW4eQ == Z0.a.f1616b ? objMo694applyToFlingBMRW4eQ : nVar;
    }

    @Override // androidx.compose.foundation.gestures.P
    /* JADX INFO: renamed from: performRawScroll-MK-Hz9U */
    public long mo798performRawScrollMKHz9U(long j2) {
        return this.scrollableState.isScrollInProgress() ? J.f.Companion.m66getZeroF1C5BW0() : m813dispatchRawDeltaMKHz9U(j2);
    }

    public final float reverseIfNeeded(float f2) {
        return this.reverseDirection ? f2 * (-1) : f2;
    }

    /* JADX INFO: renamed from: reverseIfNeeded-MK-Hz9U, reason: not valid java name */
    public final long m819reverseIfNeededMKHz9U(long j2) {
        return this.reverseDirection ? J.f.m57timestuRUvjQ(j2, -1.0f) : j2;
    }

    public final Object scroll(EnumC0368c0 enumC0368c0, h1.e eVar, Y0.c cVar) {
        Object objScroll = this.scrollableState.scroll(enumC0368c0, new e(eVar, null), cVar);
        return objScroll == Z0.a.f1616b ? objScroll : U0.n.f1521a;
    }

    public final void setScrollableState(c0 c0Var) {
        this.scrollableState = c0Var;
    }

    public final boolean shouldScrollImmediately() {
        if (!this.scrollableState.isScrollInProgress()) {
            androidx.compose.foundation.i0 i0Var = this.overscrollEffect;
            if (!(i0Var != null ? i0Var.isInProgress() : false)) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: renamed from: singleAxisOffset-MK-Hz9U, reason: not valid java name */
    public final long m820singleAxisOffsetMKHz9U(long j2) {
        return this.orientation == I.Horizontal ? J.f.m44copydBAh8RU$default(j2, 0.0f, 0.0f, 1, null) : J.f.m44copydBAh8RU$default(j2, 0.0f, 0.0f, 2, null);
    }

    /* JADX INFO: renamed from: toFloat-k-4lQ0M, reason: not valid java name */
    public final float m821toFloatk4lQ0M(long j2) {
        return Float.intBitsToFloat((int) (this.orientation == I.Horizontal ? j2 >> 32 : j2 & 4294967295L));
    }

    /* JADX INFO: renamed from: toOffset-tuRUvjQ, reason: not valid java name */
    public final long m822toOffsettuRUvjQ(float f2) {
        if (f2 == 0.0f) {
            return J.f.Companion.m66getZeroF1C5BW0();
        }
        if (this.orientation == I.Horizontal) {
            return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(f2)) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L));
        }
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(0.0f)) << 32) | (((long) Float.floatToRawIntBits(f2)) & 4294967295L));
    }

    /* JADX INFO: renamed from: toVelocity-adjELrA, reason: not valid java name */
    public final long m823toVelocityadjELrA(float f2) {
        return f2 == 0.0f ? e0.z.Companion.m5317getZero9UxMQ8M() : this.orientation == I.Horizontal ? AbstractC1303A.Velocity(f2, 0.0f) : AbstractC1303A.Velocity(0.0f, f2);
    }

    public final boolean update(c0 c0Var, I i2, androidx.compose.foundation.i0 i0Var, boolean z2, InterfaceC0400y interfaceC0400y, androidx.compose.ui.input.nestedscroll.b bVar) {
        boolean z3;
        boolean z4 = true;
        if (kotlin.jvm.internal.o.a(this.scrollableState, c0Var)) {
            z3 = false;
        } else {
            this.scrollableState = c0Var;
            z3 = true;
        }
        this.overscrollEffect = i0Var;
        if (this.orientation != i2) {
            this.orientation = i2;
            z3 = true;
        }
        if (this.reverseDirection != z2) {
            this.reverseDirection = z2;
        } else {
            z4 = z3;
        }
        this.flingBehavior = interfaceC0400y;
        this.nestedScrollDispatcher = bVar;
        return z4;
    }
}
