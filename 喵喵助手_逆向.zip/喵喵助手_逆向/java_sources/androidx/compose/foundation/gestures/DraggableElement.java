package androidx.compose.foundation.gestures;

import androidx.compose.animation.core.D0;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class DraggableElement extends AbstractC1000k0 {
    public static final int $stable = 0;
    private final boolean enabled;
    private final androidx.compose.foundation.interaction.n interactionSource;
    private final h1.f onDragStarted;
    private final h1.f onDragStopped;
    private final I orientation;
    private final boolean reverseDirection;
    private final boolean startDragImmediately;
    private final InterfaceC0399x state;
    public static final a Companion = new a(null);
    private static final h1.c CanDrag = new D0(17);

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final h1.c getCanDrag() {
            return DraggableElement.CanDrag;
        }

        private a() {
        }
    }

    public DraggableElement(InterfaceC0399x interfaceC0399x, I i2, boolean z2, androidx.compose.foundation.interaction.n nVar, boolean z3, h1.f fVar, h1.f fVar2, boolean z4) {
        this.state = interfaceC0399x;
        this.orientation = i2;
        this.enabled = z2;
        this.interactionSource = nVar;
        this.startDragImmediately = z3;
        this.onDragStarted = fVar;
        this.onDragStopped = fVar2;
        this.reverseDirection = z4;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean CanDrag$lambda$0(androidx.compose.ui.input.pointer.C c2) {
        return true;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || DraggableElement.class != obj.getClass()) {
            return false;
        }
        DraggableElement draggableElement = (DraggableElement) obj;
        return kotlin.jvm.internal.o.a(this.state, draggableElement.state) && this.orientation == draggableElement.orientation && this.enabled == draggableElement.enabled && kotlin.jvm.internal.o.a(this.interactionSource, draggableElement.interactionSource) && this.startDragImmediately == draggableElement.startDragImmediately && kotlin.jvm.internal.o.a(this.onDragStarted, draggableElement.onDragStarted) && kotlin.jvm.internal.o.a(this.onDragStopped, draggableElement.onDragStopped) && this.reverseDirection == draggableElement.reverseDirection;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        int iC = D0.d.c((this.orientation.hashCode() + (this.state.hashCode() * 31)) * 31, 31, this.enabled);
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        return Boolean.hashCode(this.reverseDirection) + ((this.onDragStopped.hashCode() + ((this.onDragStarted.hashCode() + D0.d.c((iC + (nVar != null ? nVar.hashCode() : 0)) * 31, 31, this.startDragImmediately)) * 31)) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("draggable");
        c1065l1.getProperties().set("orientation", this.orientation);
        D0.d.l(this.reverseDirection, D0.d.l(this.enabled, c1065l1.getProperties(), "enabled", c1065l1), "reverseDirection", c1065l1).set("interactionSource", this.interactionSource);
        D0.d.l(this.startDragImmediately, c1065l1.getProperties(), "startDragImmediately", c1065l1).set("onDragStarted", this.onDragStarted);
        c1065l1.getProperties().set("onDragStopped", this.onDragStopped);
        c1065l1.getProperties().set("state", this.state);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public C0398w create() {
        return new C0398w(this.state, CanDrag, this.orientation, this.enabled, this.interactionSource, this.startDragImmediately, this.onDragStarted, this.onDragStopped, this.reverseDirection);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(C0398w c0398w) {
        c0398w.update(this.state, CanDrag, this.orientation, this.enabled, this.interactionSource, this.startDragImmediately, this.onDragStarted, this.onDragStopped, this.reverseDirection);
    }
}
