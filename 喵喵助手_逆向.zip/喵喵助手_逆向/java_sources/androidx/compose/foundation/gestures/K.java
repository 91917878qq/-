package androidx.compose.foundation.gestures;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class K implements J, InterfaceC1307d {
    public static final int $stable = 0;
    private final /* synthetic */ InterfaceC1307d $$delegate_0;
    private boolean isCanceled;
    private boolean isReleased;
    private final z1.a mutex = new z1.d(false);

    public static final class a extends a1.c {
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return K.this.awaitRelease(this);
        }
    }

    public static final class b extends a1.c {
        int label;
        /* synthetic */ Object result;

        public b(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return K.this.reset(this);
        }
    }

    public static final class c extends a1.c {
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return K.this.tryAwaitRelease(this);
        }
    }

    public K(InterfaceC1307d interfaceC1307d) {
        this.$$delegate_0 = interfaceC1307d;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // androidx.compose.foundation.gestures.J
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object awaitRelease(Y0.c r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof androidx.compose.foundation.gestures.K.a
            if (r0 == 0) goto L13
            r0 = r5
            androidx.compose.foundation.gestures.K$a r0 = (androidx.compose.foundation.gestures.K.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.K$a r0 = new androidx.compose.foundation.gestures.K$a
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 != r3) goto L27
            a.AbstractC0292a.H(r5)
            goto L3b
        L27:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L2f:
            a.AbstractC0292a.H(r5)
            r0.label = r3
            java.lang.Object r5 = r4.tryAwaitRelease(r0)
            if (r5 != r1) goto L3b
            return r1
        L3b:
            java.lang.Boolean r5 = (java.lang.Boolean) r5
            boolean r5 = r5.booleanValue()
            if (r5 == 0) goto L46
            U0.n r5 = U0.n.f1521a
            return r5
        L46:
            androidx.compose.foundation.gestures.B r5 = new androidx.compose.foundation.gestures.B
            java.lang.String r0 = "The press gesture was canceled."
            r5.<init>(r0)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.K.awaitRelease(Y0.c):java.lang.Object");
    }

    public final void cancel() {
        this.isCanceled = true;
        if (((z1.d) this.mutex).c()) {
            ((z1.d) this.mutex).f(null);
        }
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    public float getDensity() {
        return this.$$delegate_0.getDensity();
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d, e0.m
    public float getFontScale() {
        return this.$$delegate_0.getFontScale();
    }

    public final void release() {
        this.isReleased = true;
        if (((z1.d) this.mutex).c()) {
            ((z1.d) this.mutex).f(null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object reset(Y0.c r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof androidx.compose.foundation.gestures.K.b
            if (r0 == 0) goto L13
            r0 = r5
            androidx.compose.foundation.gestures.K$b r0 = (androidx.compose.foundation.gestures.K.b) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.K$b r0 = new androidx.compose.foundation.gestures.K$b
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 != r3) goto L27
            a.AbstractC0292a.H(r5)
            goto L3d
        L27:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L2f:
            a.AbstractC0292a.H(r5)
            z1.a r5 = r4.mutex
            r0.label = r3
            java.lang.Object r5 = z1.e.b(r5, r0)
            if (r5 != r1) goto L3d
            return r1
        L3d:
            r5 = 0
            r4.isReleased = r5
            r4.isCanceled = r5
            U0.n r5 = U0.n.f1521a
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.K.reset(Y0.c):java.lang.Object");
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx--R2X_6o */
    public int mo781roundToPxR2X_6o(long j2) {
        return this.$$delegate_0.mo781roundToPxR2X_6o(j2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx-0680j_4 */
    public int mo782roundToPx0680j_4(float f2) {
        return this.$$delegate_0.mo782roundToPx0680j_4(f2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toDp-GaN1DYA */
    public float mo783toDpGaN1DYA(long j2) {
        return this.$$delegate_0.mo783toDpGaN1DYA(j2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM */
    public float mo784toDpu2uoSUM(float f2) {
        return this.$$delegate_0.mo784toDpu2uoSUM(f2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDpSize-k-rfVVM */
    public long mo786toDpSizekrfVVM(long j2) {
        return this.$$delegate_0.mo786toDpSizekrfVVM(j2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx--R2X_6o */
    public float mo787toPxR2X_6o(long j2) {
        return this.$$delegate_0.mo787toPxR2X_6o(j2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx-0680j_4 */
    public float mo788toPx0680j_4(float f2) {
        return this.$$delegate_0.mo788toPx0680j_4(f2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    public J.h toRect(e0.k kVar) {
        return this.$$delegate_0.toRect(kVar);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSize-XkaWNTQ */
    public long mo789toSizeXkaWNTQ(long j2) {
        return this.$$delegate_0.mo789toSizeXkaWNTQ(j2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toSp-0xMU5do */
    public long mo790toSp0xMU5do(float f2) {
        return this.$$delegate_0.mo790toSp0xMU5do(f2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4 */
    public long mo791toSpkPz2Gy4(float f2) {
        return this.$$delegate_0.mo791toSpkPz2Gy4(f2);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // androidx.compose.foundation.gestures.J
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object tryAwaitRelease(Y0.c r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof androidx.compose.foundation.gestures.K.c
            if (r0 == 0) goto L13
            r0 = r5
            androidx.compose.foundation.gestures.K$c r0 = (androidx.compose.foundation.gestures.K.c) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            androidx.compose.foundation.gestures.K$c r0 = new androidx.compose.foundation.gestures.K$c
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.result
            Z0.a r1 = Z0.a.f1616b
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 != r3) goto L27
            a.AbstractC0292a.H(r5)
            goto L45
        L27:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L2f:
            a.AbstractC0292a.H(r5)
            boolean r5 = r4.isReleased
            if (r5 != 0) goto L4a
            boolean r5 = r4.isCanceled
            if (r5 != 0) goto L4a
            z1.a r5 = r4.mutex
            r0.label = r3
            java.lang.Object r5 = z1.e.b(r5, r0)
            if (r5 != r1) goto L45
            return r1
        L45:
            z1.a r5 = r4.mutex
            z1.e.c(r5)
        L4a:
            boolean r5 = r4.isReleased
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.K.tryAwaitRelease(Y0.c):java.lang.Object");
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM */
    public float mo785toDpu2uoSUM(int i2) {
        return this.$$delegate_0.mo785toDpu2uoSUM(i2);
    }

    @Override // androidx.compose.foundation.gestures.J, e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4 */
    public long mo792toSpkPz2Gy4(int i2) {
        return this.$$delegate_0.mo792toSpkPz2Gy4(i2);
    }
}
