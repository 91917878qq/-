package androidx.compose.foundation.gestures;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class Y implements InterfaceC1307d {
    @Override // e0.InterfaceC1307d
    public float getDensity() {
        return 1.0f;
    }

    @Override // e0.InterfaceC1307d, e0.m
    public float getFontScale() {
        return 1.0f;
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx--R2X_6o */
    public /* bridge */ /* synthetic */ int mo781roundToPxR2X_6o(long j2) {
        return super.mo781roundToPxR2X_6o(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: roundToPx-0680j_4 */
    public /* bridge */ /* synthetic */ int mo782roundToPx0680j_4(float f2) {
        return super.mo782roundToPx0680j_4(f2);
    }

    @Override // e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toDp-GaN1DYA */
    public /* bridge */ /* synthetic */ float mo783toDpGaN1DYA(long j2) {
        return super.mo783toDpGaN1DYA(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM */
    public /* bridge */ /* synthetic */ float mo784toDpu2uoSUM(float f2) {
        return super.mo784toDpu2uoSUM(f2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDpSize-k-rfVVM */
    public /* bridge */ /* synthetic */ long mo786toDpSizekrfVVM(long j2) {
        return super.mo786toDpSizekrfVVM(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx--R2X_6o */
    public /* bridge */ /* synthetic */ float mo787toPxR2X_6o(long j2) {
        return super.mo787toPxR2X_6o(j2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toPx-0680j_4 */
    public /* bridge */ /* synthetic */ float mo788toPx0680j_4(float f2) {
        return super.mo788toPx0680j_4(f2);
    }

    @Override // e0.InterfaceC1307d
    public /* bridge */ /* synthetic */ J.h toRect(e0.k kVar) {
        return super.toRect(kVar);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSize-XkaWNTQ */
    public /* bridge */ /* synthetic */ long mo789toSizeXkaWNTQ(long j2) {
        return super.mo789toSizeXkaWNTQ(j2);
    }

    @Override // e0.InterfaceC1307d, e0.m
    /* JADX INFO: renamed from: toSp-0xMU5do */
    public /* bridge */ /* synthetic */ long mo790toSp0xMU5do(float f2) {
        return super.mo790toSp0xMU5do(f2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4 */
    public /* bridge */ /* synthetic */ long mo791toSpkPz2Gy4(float f2) {
        return super.mo791toSpkPz2Gy4(f2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toDp-u2uoSUM */
    public /* bridge */ /* synthetic */ float mo785toDpu2uoSUM(int i2) {
        return super.mo785toDpu2uoSUM(i2);
    }

    @Override // e0.InterfaceC1307d
    /* JADX INFO: renamed from: toSp-kPz2Gy4 */
    public /* bridge */ /* synthetic */ long mo792toSpkPz2Gy4(int i2) {
        return super.mo792toSpkPz2Gy4(i2);
    }
}
