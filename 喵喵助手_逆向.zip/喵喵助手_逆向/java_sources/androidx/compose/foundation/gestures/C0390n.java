package androidx.compose.foundation.gestures;

import androidx.compose.foundation.text.input.internal.C0;
import androidx.compose.foundation.text.selection.e0;
import androidx.compose.foundation.text.selection.t0;
import e0.InterfaceC1307d;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0390n implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1737b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h1.a f1738c;

    public /* synthetic */ C0390n(h1.a aVar, int i2) {
        this.f1737b = i2;
        this.f1738c = aVar;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1737b) {
            case 0:
                return AbstractC0391o.detectDragGestures$lambda$5(this.f1738c, (androidx.compose.ui.input.pointer.C) obj);
            case 1:
                return Boolean.valueOf(C0.textFieldDragAndDropNode$lambda$1(this.f1738c, (androidx.compose.ui.draganddrop.b) obj));
            case 2:
                return e0.a.invoke$lambda$9$lambda$8$lambda$5(this.f1738c, (InterfaceC1307d) obj);
            default:
                return t0.e.invoke$lambda$9$lambda$8$lambda$5(this.f1738c, (InterfaceC1307d) obj);
        }
    }
}
