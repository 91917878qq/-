package androidx.compose.foundation.gestures;

import J.f;
import O0.C0198c;
import a.AbstractC0292a;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.AbstractC0333s0;
import androidx.compose.animation.core.B0;
import androidx.compose.animation.core.E0;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.foundation.EnumC0368c0;

/* JADX INFO: loaded from: classes.dex */
public abstract class N {

    public static final class a extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return N.animateScrollBy(null, 0.0f, null, this);
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ InterfaceC0313i $animationSpec;
        final /* synthetic */ kotlin.jvm.internal.B $previousValue;
        final /* synthetic */ float $value;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(float f2, InterfaceC0313i interfaceC0313i, kotlin.jvm.internal.B b2, Y0.c cVar) {
            super(2, cVar);
            this.$value = f2;
            this.$animationSpec = interfaceC0313i;
            this.$previousValue = b2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.B b2, Q q2, float f2, float f3) {
            float f4 = b2.f3115b;
            b2.f3115b = q2.scrollBy(f2 - f4) + f4;
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = new b(this.$value, this.$animationSpec, this.$previousValue, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // h1.e
        public final Object invoke(Q q2, Y0.c cVar) {
            return ((b) create(q2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                Q q2 = (Q) this.L$0;
                float f2 = this.$value;
                InterfaceC0313i interfaceC0313i = this.$animationSpec;
                C0198c c0198c = new C0198c(7, this.$previousValue, q2);
                this.label = 1;
                if (AbstractC0333s0.animate$default(0.0f, f2, 0.0f, interfaceC0313i, c0198c, this, 4, null) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    public static final class c extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public c(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return N.m794animateScrollByubNVwUQ(null, 0L, null, this);
        }
    }

    public static final class d extends a1.j implements h1.e {
        final /* synthetic */ InterfaceC0313i $animationSpec;
        final /* synthetic */ kotlin.jvm.internal.D $previousValue;
        final /* synthetic */ long $value;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(long j2, InterfaceC0313i interfaceC0313i, kotlin.jvm.internal.D d2, Y0.c cVar) {
            super(2, cVar);
            this.$value = j2;
            this.$animationSpec = interfaceC0313i;
            this.$previousValue = d2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.D d2, L l2, J.f fVar, J.f fVar2) {
            long j2 = d2.f3117b;
            J.f.m54minusMKHz9U(fVar.m60unboximpl(), d2.f3117b);
            d2.f3117b = J.f.m55plusMKHz9U(j2, l2.a());
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            d dVar = new d(this.$value, this.$animationSpec, this.$previousValue, cVar);
            dVar.L$0 = obj;
            return dVar;
        }

        public final Object invoke(L l2, Y0.c cVar) {
            return ((d) create(l2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                if (this.L$0 != null) {
                    throw new ClassCastException();
                }
                f.a aVar2 = J.f.Companion;
                B0 vectorConverter = E0.getVectorConverter(aVar2);
                J.f fVarM39boximpl = J.f.m39boximpl(aVar2.m66getZeroF1C5BW0());
                J.f fVarM39boximpl2 = J.f.m39boximpl(this.$value);
                InterfaceC0313i interfaceC0313i = this.$animationSpec;
                O o2 = new O(this.$previousValue, 0);
                this.label = 1;
                if (AbstractC0333s0.animate(vectorConverter, fVarM39boximpl, fVarM39boximpl2, (8 & 8) != 0 ? null : null, (8 & 16) != 0 ? AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null) : interfaceC0313i, o2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public /* synthetic */ Object invoke(Object obj, Object obj2) {
            if (obj == null) {
                return invoke((L) null, (Y0.c) obj2);
            }
            throw new ClassCastException();
        }
    }

    public static final class e extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public e(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return N.scrollBy(null, 0.0f, this);
        }
    }

    public static final class f extends a1.j implements h1.e {
        final /* synthetic */ kotlin.jvm.internal.B $consumed;
        final /* synthetic */ float $value;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(kotlin.jvm.internal.B b2, float f2, Y0.c cVar) {
            super(2, cVar);
            this.$consumed = b2;
            this.$value = f2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            f fVar = new f(this.$consumed, this.$value, cVar);
            fVar.L$0 = obj;
            return fVar;
        }

        @Override // h1.e
        public final Object invoke(Q q2, Y0.c cVar) {
            return ((f) create(q2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            Q q2 = (Q) this.L$0;
            this.$consumed.f3115b = q2.scrollBy(this.$value);
            return U0.n.f1521a;
        }
    }

    public static final class g extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public g(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return N.m796scrollByd4ec7I(null, 0L, this);
        }
    }

    public static final class h extends a1.j implements h1.e {
        final /* synthetic */ kotlin.jvm.internal.D $consumed;
        final /* synthetic */ long $value;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(kotlin.jvm.internal.D d2, long j2, Y0.c cVar) {
            super(2, cVar);
            this.$consumed = d2;
            this.$value = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            h hVar = new h(this.$consumed, this.$value, cVar);
            hVar.L$0 = obj;
            return hVar;
        }

        public final Object invoke(L l2, Y0.c cVar) {
            return ((h) create(l2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            this.L$0.getClass();
            throw new ClassCastException();
        }

        @Override // h1.e
        public /* synthetic */ Object invoke(Object obj, Object obj2) {
            if (obj == null) {
                return invoke((L) null, (Y0.c) obj2);
            }
            throw new ClassCastException();
        }
    }

    public static final class i extends a1.j implements h1.e {
        int label;

        public i(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new i(cVar);
        }

        @Override // h1.e
        public final Object invoke(Q q2, Y0.c cVar) {
            return ((i) create(q2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            return U0.n.f1521a;
        }
    }

    public static final class j extends a1.j implements h1.e {
        int label;

        public j(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new j(cVar);
        }

        public final Object invoke(L l2, Y0.c cVar) {
            return ((j) create(l2, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            return U0.n.f1521a;
        }

        @Override // h1.e
        public /* synthetic */ Object invoke(Object obj, Object obj2) {
            if (obj == null) {
                return invoke((L) null, (Y0.c) obj2);
            }
            throw new ClassCastException();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object animateScrollBy(androidx.compose.foundation.gestures.c0 r7, float r8, androidx.compose.animation.core.InterfaceC0313i r9, Y0.c r10) {
        /*
            boolean r0 = r10 instanceof androidx.compose.foundation.gestures.N.a
            if (r0 == 0) goto L14
            r0 = r10
            androidx.compose.foundation.gestures.N$a r0 = (androidx.compose.foundation.gestures.N.a) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.label = r1
        L12:
            r4 = r0
            goto L1a
        L14:
            androidx.compose.foundation.gestures.N$a r0 = new androidx.compose.foundation.gestures.N$a
            r0.<init>(r10)
            goto L12
        L1a:
            java.lang.Object r10 = r4.result
            Z0.a r0 = Z0.a.f1616b
            int r1 = r4.label
            r2 = 1
            if (r1 == 0) goto L35
            if (r1 != r2) goto L2d
            java.lang.Object r7 = r4.L$0
            kotlin.jvm.internal.B r7 = (kotlin.jvm.internal.B) r7
            a.AbstractC0292a.H(r10)
            goto L53
        L2d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L35:
            a.AbstractC0292a.H(r10)
            kotlin.jvm.internal.B r10 = new kotlin.jvm.internal.B
            r10.<init>()
            androidx.compose.foundation.gestures.N$b r3 = new androidx.compose.foundation.gestures.N$b
            r1 = 0
            r3.<init>(r8, r9, r10, r1)
            r4.L$0 = r10
            r4.label = r2
            r2 = 0
            r5 = 1
            r6 = 0
            r1 = r7
            java.lang.Object r7 = androidx.compose.foundation.gestures.c0.scroll$default(r1, r2, r3, r4, r5, r6)
            if (r7 != r0) goto L52
            return r0
        L52:
            r7 = r10
        L53:
            float r7 = r7.f3115b
            java.lang.Float r8 = new java.lang.Float
            r8.<init>(r7)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.N.animateScrollBy(androidx.compose.foundation.gestures.c0, float, androidx.compose.animation.core.i, Y0.c):java.lang.Object");
    }

    public static /* synthetic */ Object animateScrollBy$default(c0 c0Var, float f2, InterfaceC0313i interfaceC0313i, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            interfaceC0313i = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
        }
        return animateScrollBy(c0Var, f2, interfaceC0313i, cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0014  */
    /* JADX INFO: renamed from: animateScrollBy-ubNVwUQ, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object m794animateScrollByubNVwUQ(androidx.compose.foundation.gestures.S r11, long r12, androidx.compose.animation.core.InterfaceC0313i r14, Y0.c r15) {
        /*
            boolean r0 = r15 instanceof androidx.compose.foundation.gestures.N.c
            if (r0 == 0) goto L14
            r0 = r15
            androidx.compose.foundation.gestures.N$c r0 = (androidx.compose.foundation.gestures.N.c) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.label = r1
        L12:
            r4 = r0
            goto L1a
        L14:
            androidx.compose.foundation.gestures.N$c r0 = new androidx.compose.foundation.gestures.N$c
            r0.<init>(r15)
            goto L12
        L1a:
            java.lang.Object r15 = r4.result
            Z0.a r0 = Z0.a.f1616b
            int r1 = r4.label
            r2 = 1
            if (r1 == 0) goto L35
            if (r1 != r2) goto L2d
            java.lang.Object r11 = r4.L$0
            kotlin.jvm.internal.D r11 = (kotlin.jvm.internal.D) r11
            a.AbstractC0292a.H(r15)
            goto L5f
        L2d:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r12)
            throw r11
        L35:
            a.AbstractC0292a.H(r15)
            kotlin.jvm.internal.D r15 = new kotlin.jvm.internal.D
            r15.<init>()
            J.f$a r1 = J.f.Companion
            long r5 = r1.m66getZeroF1C5BW0()
            r15.f3117b = r5
            androidx.compose.foundation.gestures.N$d r3 = new androidx.compose.foundation.gestures.N$d
            r10 = 0
            r5 = r3
            r6 = r12
            r8 = r14
            r9 = r15
            r5.<init>(r6, r8, r9, r10)
            r4.L$0 = r15
            r4.label = r2
            r2 = 0
            r5 = 1
            r6 = 0
            r1 = r11
            java.lang.Object r11 = androidx.compose.foundation.gestures.S.scroll$default(r1, r2, r3, r4, r5, r6)
            if (r11 != r0) goto L5e
            return r0
        L5e:
            r11 = r15
        L5f:
            long r11 = r11.f3117b
            J.f r11 = J.f.m39boximpl(r11)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.N.m794animateScrollByubNVwUQ(androidx.compose.foundation.gestures.S, long, androidx.compose.animation.core.i, Y0.c):java.lang.Object");
    }

    /* JADX INFO: renamed from: animateScrollBy-ubNVwUQ$default, reason: not valid java name */
    public static /* synthetic */ Object m795animateScrollByubNVwUQ$default(S s2, long j2, InterfaceC0313i interfaceC0313i, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            interfaceC0313i = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
        }
        return m794animateScrollByubNVwUQ(s2, j2, interfaceC0313i, cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object scrollBy(androidx.compose.foundation.gestures.c0 r7, float r8, Y0.c r9) {
        /*
            boolean r0 = r9 instanceof androidx.compose.foundation.gestures.N.e
            if (r0 == 0) goto L14
            r0 = r9
            androidx.compose.foundation.gestures.N$e r0 = (androidx.compose.foundation.gestures.N.e) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.label = r1
        L12:
            r4 = r0
            goto L1a
        L14:
            androidx.compose.foundation.gestures.N$e r0 = new androidx.compose.foundation.gestures.N$e
            r0.<init>(r9)
            goto L12
        L1a:
            java.lang.Object r9 = r4.result
            Z0.a r0 = Z0.a.f1616b
            int r1 = r4.label
            r2 = 1
            if (r1 == 0) goto L35
            if (r1 != r2) goto L2d
            java.lang.Object r7 = r4.L$0
            kotlin.jvm.internal.B r7 = (kotlin.jvm.internal.B) r7
            a.AbstractC0292a.H(r9)
            goto L53
        L2d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L35:
            a.AbstractC0292a.H(r9)
            kotlin.jvm.internal.B r9 = new kotlin.jvm.internal.B
            r9.<init>()
            androidx.compose.foundation.gestures.N$f r3 = new androidx.compose.foundation.gestures.N$f
            r1 = 0
            r3.<init>(r9, r8, r1)
            r4.L$0 = r9
            r4.label = r2
            r2 = 0
            r5 = 1
            r6 = 0
            r1 = r7
            java.lang.Object r7 = androidx.compose.foundation.gestures.c0.scroll$default(r1, r2, r3, r4, r5, r6)
            if (r7 != r0) goto L52
            return r0
        L52:
            r7 = r9
        L53:
            float r7 = r7.f3115b
            java.lang.Float r8 = new java.lang.Float
            r8.<init>(r7)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.N.scrollBy(androidx.compose.foundation.gestures.c0, float, Y0.c):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0014  */
    /* JADX INFO: renamed from: scrollBy-d-4ec7I, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object m796scrollByd4ec7I(androidx.compose.foundation.gestures.S r7, long r8, Y0.c r10) {
        /*
            boolean r0 = r10 instanceof androidx.compose.foundation.gestures.N.g
            if (r0 == 0) goto L14
            r0 = r10
            androidx.compose.foundation.gestures.N$g r0 = (androidx.compose.foundation.gestures.N.g) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.label = r1
        L12:
            r4 = r0
            goto L1a
        L14:
            androidx.compose.foundation.gestures.N$g r0 = new androidx.compose.foundation.gestures.N$g
            r0.<init>(r10)
            goto L12
        L1a:
            java.lang.Object r10 = r4.result
            Z0.a r0 = Z0.a.f1616b
            int r1 = r4.label
            r2 = 1
            if (r1 == 0) goto L35
            if (r1 != r2) goto L2d
            java.lang.Object r7 = r4.L$0
            kotlin.jvm.internal.D r7 = (kotlin.jvm.internal.D) r7
            a.AbstractC0292a.H(r10)
            goto L5b
        L2d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L35:
            a.AbstractC0292a.H(r10)
            kotlin.jvm.internal.D r10 = new kotlin.jvm.internal.D
            r10.<init>()
            J.f$a r1 = J.f.Companion
            long r5 = r1.m66getZeroF1C5BW0()
            r10.f3117b = r5
            androidx.compose.foundation.gestures.N$h r3 = new androidx.compose.foundation.gestures.N$h
            r1 = 0
            r3.<init>(r10, r8, r1)
            r4.L$0 = r10
            r4.label = r2
            r2 = 0
            r5 = 1
            r6 = 0
            r1 = r7
            java.lang.Object r7 = androidx.compose.foundation.gestures.S.scroll$default(r1, r2, r3, r4, r5, r6)
            if (r7 != r0) goto L5a
            return r0
        L5a:
            r7 = r10
        L5b:
            long r7 = r7.f3117b
            J.f r7 = J.f.m39boximpl(r7)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.N.m796scrollByd4ec7I(androidx.compose.foundation.gestures.S, long, Y0.c):java.lang.Object");
    }

    public static final Object stopScroll(c0 c0Var, EnumC0368c0 enumC0368c0, Y0.c cVar) {
        Object objScroll = c0Var.scroll(enumC0368c0, new i(null), cVar);
        return objScroll == Z0.a.f1616b ? objScroll : U0.n.f1521a;
    }

    public static /* synthetic */ Object stopScroll$default(c0 c0Var, EnumC0368c0 enumC0368c0, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return stopScroll(c0Var, enumC0368c0, cVar);
    }

    public static final Object stopScroll(S s2, EnumC0368c0 enumC0368c0, Y0.c cVar) {
        new j(null);
        Object objA = s2.a();
        return objA == Z0.a.f1616b ? objA : U0.n.f1521a;
    }

    public static /* synthetic */ Object stopScroll$default(S s2, EnumC0368c0 enumC0368c0, Y0.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            enumC0368c0 = EnumC0368c0.Default;
        }
        return stopScroll(s2, enumC0368c0, cVar);
    }
}
