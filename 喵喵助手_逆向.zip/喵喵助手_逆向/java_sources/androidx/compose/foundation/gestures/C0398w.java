package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.foundation.EnumC0368c0;
import androidx.compose.foundation.gestures.AbstractC0389m;
import r1.AbstractC1476z;
import r1.EnumC1475y;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0398w extends r {
    public static final int $stable = 8;
    private h1.f onDragStarted;
    private h1.f onDragStopped;
    private I orientation;
    private boolean reverseDirection;
    private boolean startDragImmediately;
    private InterfaceC0399x state;

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.w$a */
    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ h1.e $forEachDelta;
        private /* synthetic */ Object L$0;
        int label;
        final /* synthetic */ C0398w this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(h1.e eVar, C0398w c0398w, Y0.c cVar) {
            super(2, cVar);
            this.$forEachDelta = eVar;
            this.this$0 = c0398w;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(InterfaceC0394s interfaceC0394s, C0398w c0398w, AbstractC0389m.b bVar) {
            interfaceC0394s.dragBy(AbstractC0397v.m877toFloat3MmeM6k(c0398w.m883reverseIfNeededMKHz9U(bVar.m838getDeltaF1C5BW0()), c0398w.orientation));
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            a aVar = new a(this.$forEachDelta, this.this$0, cVar);
            aVar.L$0 = obj;
            return aVar;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0394s interfaceC0394s, Y0.c cVar) {
            return ((a) create(interfaceC0394s, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC0394s interfaceC0394s = (InterfaceC0394s) this.L$0;
                h1.e eVar = this.$forEachDelta;
                M0.m mVar = new M0.m(16, interfaceC0394s, this.this$0);
                this.label = 1;
                if (eVar.invoke(mVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.w$b */
    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ long $startedPosition;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$startedPosition = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = C0398w.this.new b(this.$startedPosition, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                h1.f fVar = C0398w.this.onDragStarted;
                J.f fVarM39boximpl = J.f.m39boximpl(this.$startedPosition);
                this.label = 1;
                if (fVar.invoke(interfaceC1474x, fVarM39boximpl, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.w$c */
    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ long $velocity;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(long j2, Y0.c cVar) {
            super(2, cVar);
            this.$velocity = j2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            c cVar2 = C0398w.this.new c(this.$velocity, cVar);
            cVar2.L$0 = obj;
            return cVar2;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                h1.f fVar = C0398w.this.onDragStopped;
                Float f2 = new Float(AbstractC0397v.m878toFloatsFctU(C0398w.this.m882reverseIfNeededAH228Gc(this.$velocity), C0398w.this.orientation));
                this.label = 1;
                if (fVar.invoke(interfaceC1474x, f2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public C0398w(InterfaceC0399x interfaceC0399x, h1.c cVar, I i2, boolean z2, androidx.compose.foundation.interaction.n nVar, boolean z3, h1.f fVar, h1.f fVar2, boolean z4) {
        super(cVar, z2, nVar, i2);
        this.state = interfaceC0399x;
        this.orientation = i2;
        this.startDragImmediately = z3;
        this.onDragStarted = fVar;
        this.onDragStopped = fVar2;
        this.reverseDirection = z4;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: reverseIfNeeded-AH228Gc, reason: not valid java name */
    public final long m882reverseIfNeededAH228Gc(long j2) {
        return e0.z.m5312timesadjELrA(j2, this.reverseDirection ? -1.0f : 1.0f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: reverseIfNeeded-MK-Hz9U, reason: not valid java name */
    public final long m883reverseIfNeededMKHz9U(long j2) {
        return J.f.m57timestuRUvjQ(j2, this.reverseDirection ? -1.0f : 1.0f);
    }

    @Override // androidx.compose.foundation.gestures.r
    public Object drag(h1.e eVar, Y0.c cVar) {
        Object objDrag = this.state.drag(EnumC0368c0.UserInput, new a(eVar, this, null), cVar);
        return objDrag == Z0.a.f1616b ? objDrag : U0.n.f1521a;
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    /* JADX INFO: renamed from: getTouchBoundsExpansion-RZrCHBk */
    public /* bridge */ /* synthetic */ long mo697getTouchBoundsExpansionRZrCHBk() {
        return super.mo697getTouchBoundsExpansionRZrCHBk();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean interceptOutOfBoundsChildEvents() {
        return super.interceptOutOfBoundsChildEvents();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.foundation.gestures.r
    /* JADX INFO: renamed from: onDragStarted-k-4lQ0M */
    public void mo806onDragStartedk4lQ0M(long j2) {
        if (!isAttached() || kotlin.jvm.internal.o.a(this.onDragStarted, AbstractC0397v.NoOpOnDragStarted)) {
            return;
        }
        AbstractC1476z.s(getCoroutineScope(), null, EnumC1475y.f3408e, new b(j2, null), 1);
    }

    @Override // androidx.compose.foundation.gestures.r
    /* JADX INFO: renamed from: onDragStopped-TH1AsA0 */
    public void mo807onDragStoppedTH1AsA0(long j2) {
        if (!isAttached() || kotlin.jvm.internal.o.a(this.onDragStopped, AbstractC0397v.NoOpOnDragStopped)) {
            return;
        }
        AbstractC1476z.s(getCoroutineScope(), null, EnumC1475y.f3408e, new c(j2, null), 1);
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ void onViewConfigurationChange() {
        super.onViewConfigurationChange();
    }

    @Override // androidx.compose.foundation.gestures.r, androidx.compose.ui.node.N0
    public /* bridge */ /* synthetic */ boolean sharePointerInputWithSiblings() {
        return super.sharePointerInputWithSiblings();
    }

    @Override // androidx.compose.foundation.gestures.r
    public boolean startDragImmediately() {
        return this.startDragImmediately;
    }

    public final void update(InterfaceC0399x interfaceC0399x, h1.c cVar, I i2, boolean z2, androidx.compose.foundation.interaction.n nVar, boolean z3, h1.f fVar, h1.f fVar2, boolean z4) {
        boolean z5;
        boolean z6;
        h1.f fVar3;
        if (kotlin.jvm.internal.o.a(this.state, interfaceC0399x)) {
            z5 = false;
        } else {
            this.state = interfaceC0399x;
            z5 = true;
        }
        if (this.orientation != i2) {
            this.orientation = i2;
            z5 = true;
        }
        if (this.reverseDirection != z4) {
            this.reverseDirection = z4;
            fVar3 = fVar;
            z6 = true;
        } else {
            z6 = z5;
            fVar3 = fVar;
        }
        this.onDragStarted = fVar3;
        this.onDragStopped = fVar2;
        this.startDragImmediately = z3;
        update(cVar, z2, nVar, i2, z6);
    }
}
