package androidx.compose.foundation.gestures;

import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;
import e0.AbstractC1303A;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0397v {
    private static final h1.f NoOpOnDragStarted = new C0395t(null);
    private static final h1.f NoOpOnDragStopped = new C0396u(null);

    public static final InterfaceC0399x DraggableState(h1.c cVar) {
        return new C0386j(cVar);
    }

    public static final androidx.compose.ui.x draggable(androidx.compose.ui.x xVar, InterfaceC0399x interfaceC0399x, I i2, boolean z2, androidx.compose.foundation.interaction.n nVar, boolean z3, h1.f fVar, h1.f fVar2, boolean z4) {
        return xVar.then(new DraggableElement(interfaceC0399x, i2, z2, nVar, z3, fVar, fVar2, z4));
    }

    public static final InterfaceC0399x rememberDraggableState(h1.c cVar, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-183245213, i2, -1, "androidx.compose.foundation.gestures.rememberDraggableState (Draggable.kt:130)");
        }
        d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(cVar, interfaceC0768p, i2 & 14);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = DraggableState(new Q0.c0(d2VarRememberUpdatedState, 3));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        InterfaceC0399x interfaceC0399x = (InterfaceC0399x) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return interfaceC0399x;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n rememberDraggableState$lambda$1$lambda$0(d2 d2Var, float f2) {
        ((h1.c) d2Var.getValue()).invoke(Float.valueOf(f2));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: toFloat-3MmeM6k, reason: not valid java name */
    public static final float m877toFloat3MmeM6k(long j2, I i2) {
        return Float.intBitsToFloat((int) (i2 == I.Vertical ? j2 & 4294967295L : j2 >> 32));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: toFloat-sF-c-tU, reason: not valid java name */
    public static final float m878toFloatsFctU(long j2, I i2) {
        return i2 == I.Vertical ? e0.z.m5307getYimpl(j2) : e0.z.m5306getXimpl(j2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: toValidVelocity-TH1AsA0, reason: not valid java name */
    public static final long m879toValidVelocityTH1AsA0(long j2) {
        return AbstractC1303A.Velocity(Float.isNaN(e0.z.m5306getXimpl(j2)) ? 0.0f : e0.z.m5306getXimpl(j2), Float.isNaN(e0.z.m5307getYimpl(j2)) ? 0.0f : e0.z.m5307getYimpl(j2));
    }
}
