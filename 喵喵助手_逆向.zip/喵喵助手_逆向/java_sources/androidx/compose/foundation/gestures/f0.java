package androidx.compose.foundation.gestures;

import a.AbstractC0292a;

/* JADX INFO: loaded from: classes.dex */
public final class f0 extends a1.j implements h1.f {
    int label;

    public f0(Y0.c cVar) {
        super(3, cVar);
    }

    @Override // h1.f
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
        return m825invoked4ec7I((J) obj, ((J.f) obj2).m60unboximpl(), (Y0.c) obj3);
    }

    /* JADX INFO: renamed from: invoke-d-4ec7I, reason: not valid java name */
    public final Object m825invoked4ec7I(J j2, long j3, Y0.c cVar) {
        return new f0(cVar).invokeSuspend(U0.n.f1521a);
    }

    @Override // a1.a
    public final Object invokeSuspend(Object obj) {
        Z0.a aVar = Z0.a.f1616b;
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        AbstractC0292a.H(obj);
        return U0.n.f1521a;
    }
}
