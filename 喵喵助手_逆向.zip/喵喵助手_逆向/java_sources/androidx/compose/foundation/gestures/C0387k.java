package androidx.compose.foundation.gestures;

import a.AbstractC0292a;
import androidx.compose.animation.core.AbstractC0319l;
import androidx.compose.animation.core.AbstractC0333s0;
import androidx.compose.animation.core.C0311h;
import androidx.compose.animation.core.C0317k;
import androidx.compose.animation.core.InterfaceC0341y;
import e0.InterfaceC1307d;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.foundation.gestures.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0387k implements U {
    public static final int $stable = 0;
    private InterfaceC0341y flingDecay;
    private int lastAnimationCycleCount;
    private final androidx.compose.ui.B motionDurationScale;

    /* JADX INFO: renamed from: androidx.compose.foundation.gestures.k$a */
    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ float $initialVelocity;
        final /* synthetic */ Q $this_performFling;
        Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ C0387k this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(float f2, C0387k c0387k, Q q2, Y0.c cVar) {
            super(2, cVar);
            this.$initialVelocity = f2;
            this.this$0 = c0387k;
            this.$this_performFling = q2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(kotlin.jvm.internal.B b2, Q q2, kotlin.jvm.internal.B b3, C0387k c0387k, C0311h c0311h) {
            float fFloatValue = ((Number) c0311h.getValue()).floatValue() - b2.f3115b;
            float fScrollBy = q2.scrollBy(fFloatValue);
            b2.f3115b = ((Number) c0311h.getValue()).floatValue();
            b3.f3115b = ((Number) c0311h.getVelocity()).floatValue();
            if (Math.abs(fFloatValue - fScrollBy) > 0.5f) {
                c0311h.cancelAnimation();
            }
            c0387k.setLastAnimationCycleCount(c0387k.getLastAnimationCycleCount() + 1);
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new a(this.$initialVelocity, this.this$0, this.$this_performFling, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            float f2;
            C0317k c0317k;
            C0317k c0317k2;
            kotlin.jvm.internal.B b2;
            InterfaceC0341y interfaceC0341y;
            M0.q qVar;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                if (Math.abs(this.$initialVelocity) > 1.0f) {
                    kotlin.jvm.internal.B b3 = new kotlin.jvm.internal.B();
                    float f3 = this.$initialVelocity;
                    b3.f3115b = f3;
                    kotlin.jvm.internal.B b4 = new kotlin.jvm.internal.B();
                    C0317k c0317kAnimationState$default = AbstractC0319l.AnimationState$default(0.0f, f3, 0L, 0L, false, 28, null);
                    try {
                        interfaceC0341y = this.this$0.flingDecay;
                        qVar = new M0.q(b4, this.$this_performFling, b3, this.this$0, 6);
                        this.L$0 = b3;
                        this.L$1 = c0317kAnimationState$default;
                        this.label = 1;
                        c0317k = c0317kAnimationState$default;
                    } catch (CancellationException unused) {
                        c0317k = c0317kAnimationState$default;
                    }
                    try {
                    } catch (CancellationException unused2) {
                        c0317k2 = c0317k;
                        b2 = b3;
                        b2.f3115b = ((Number) c0317k2.getVelocity()).floatValue();
                    }
                    if (AbstractC0333s0.animateDecay$default(c0317kAnimationState$default, interfaceC0341y, false, qVar, this, 2, null) == aVar) {
                        return aVar;
                    }
                    b2 = b3;
                    f2 = b2.f3115b;
                } else {
                    f2 = this.$initialVelocity;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                c0317k2 = (C0317k) this.L$1;
                b2 = (kotlin.jvm.internal.B) this.L$0;
                try {
                    AbstractC0292a.H(obj);
                } catch (CancellationException unused3) {
                    b2.f3115b = ((Number) c0317k2.getVelocity()).floatValue();
                }
                f2 = b2.f3115b;
            }
            return new Float(f2);
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public C0387k(InterfaceC0341y interfaceC0341y, androidx.compose.ui.B b2) {
        this.flingDecay = interfaceC0341y;
        this.motionDurationScale = b2;
    }

    public final int getLastAnimationCycleCount() {
        return this.lastAnimationCycleCount;
    }

    @Override // androidx.compose.foundation.gestures.U, androidx.compose.foundation.gestures.InterfaceC0400y
    public Object performFling(Q q2, float f2, Y0.c cVar) {
        this.lastAnimationCycleCount = 0;
        return AbstractC1476z.A(this.motionDurationScale, new a(f2, this, q2, null), cVar);
    }

    public final void setLastAnimationCycleCount(int i2) {
        this.lastAnimationCycleCount = i2;
    }

    @Override // androidx.compose.foundation.gestures.U
    public void updateDensity(InterfaceC1307d interfaceC1307d) {
        this.flingDecay = androidx.compose.animation.Q.splineBasedDecay(interfaceC1307d);
    }

    public /* synthetic */ C0387k(InterfaceC0341y interfaceC0341y, androidx.compose.ui.B b2, int i2, AbstractC1378g abstractC1378g) {
        this(interfaceC0341y, (i2 & 2) != 0 ? Z.getDefaultScrollMotionDurationScale() : b2);
    }
}
