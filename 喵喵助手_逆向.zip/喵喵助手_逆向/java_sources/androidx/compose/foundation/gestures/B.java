package androidx.compose.foundation.gestures;

import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class B extends CancellationException {
    public static final int $stable = 8;

    /* JADX WARN: Multi-variable type inference failed */
    public B() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    public B(String str) {
        super(str);
    }

    public /* synthetic */ B(String str, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? null : str);
    }
}
