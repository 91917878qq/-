package androidx.compose.foundation;

import a.AbstractC0292a;
import androidx.compose.ui.layout.AbstractC0972w0;
import androidx.compose.ui.layout.InterfaceC0966t0;
import androidx.compose.ui.layout.InterfaceC0968u0;
import androidx.compose.ui.node.AbstractC1003m;
import androidx.compose.ui.node.InterfaceC1001l;
import androidx.compose.ui.node.InterfaceC1029z0;
import androidx.compose.ui.node.S0;
import androidx.compose.ui.node.T0;
import androidx.compose.ui.node.a1;
import androidx.compose.ui.node.b1;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.C1449a0;
import r1.InterfaceC1451b0;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class J extends androidx.compose.ui.node.r implements S0, androidx.compose.ui.node.C, InterfaceC1001l, InterfaceC1029z0, a1 {
    private final androidx.compose.ui.focus.L focusTargetNode;
    private androidx.compose.foundation.interaction.e focusedInteraction;
    private androidx.compose.ui.layout.J globalLayoutCoordinates;
    private androidx.compose.foundation.interaction.n interactionSource;
    private final h1.c onFocusChange;
    private InterfaceC0966t0 pinnedHandle;
    private final boolean shouldAutoInvalidate;
    private static final a TraverseKey = new a(null);
    public static final int $stable = 8;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        private a() {
        }
    }

    public /* synthetic */ class b extends kotlin.jvm.internal.l implements h1.a {
        public b(Object obj) {
            super(0, obj, J.class, "requestFocus", "requestFocus()Z", 0);
        }

        @Override // h1.a
        public final Boolean invoke() {
            return Boolean.valueOf(((J) this.receiver).requestFocus());
        }
    }

    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ r1.I $handler;
        final /* synthetic */ androidx.compose.foundation.interaction.k $interaction;
        final /* synthetic */ androidx.compose.foundation.interaction.n $this_emitWithFallback;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.k kVar, r1.I i2, Y0.c cVar) {
            super(2, cVar);
            this.$this_emitWithFallback = nVar;
            this.$interaction = kVar;
            this.$handler = i2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new c(this.$this_emitWithFallback, this.$interaction, this.$handler, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                androidx.compose.foundation.interaction.n nVar = this.$this_emitWithFallback;
                androidx.compose.foundation.interaction.k kVar = this.$interaction;
                this.label = 1;
                if (nVar.emit(kVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            r1.I i3 = this.$handler;
            if (i3 != null) {
                i3.dispose();
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((c) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public /* synthetic */ class d extends kotlin.jvm.internal.l implements h1.e {
        public d(Object obj) {
            super(2, obj, J.class, "onFocusStateChange", "onFocusStateChange(Landroidx/compose/ui/focus/FocusState;Landroidx/compose/ui/focus/FocusState;)V", 0);
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((androidx.compose.ui.focus.I) obj, (androidx.compose.ui.focus.I) obj2);
            return U0.n.f1521a;
        }

        public final void invoke(androidx.compose.ui.focus.I i2, androidx.compose.ui.focus.I i3) {
            ((J) this.receiver).onFocusStateChange(i2, i3);
        }
    }

    public static final class e extends a1.j implements h1.e {
        int label;

        public e(Y0.c cVar) {
            super(2, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return J.this.new e(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                J j2 = J.this;
                this.label = 1;
                if (androidx.compose.ui.relocation.b.bringIntoView$default(j2, null, this, 1, null) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((e) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public /* synthetic */ J(androidx.compose.foundation.interaction.n nVar, int i2, h1.c cVar, AbstractC1378g abstractC1378g) {
        this(nVar, i2, cVar);
    }

    private final void disposeInteractionSource() {
        androidx.compose.foundation.interaction.e eVar;
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null && (eVar = this.focusedInteraction) != null) {
            nVar.tryEmit(new androidx.compose.foundation.interaction.f(eVar));
        }
        this.focusedInteraction = null;
    }

    private final void emitInteraction(boolean z2) {
        androidx.compose.foundation.interaction.n nVar = this.interactionSource;
        if (nVar != null) {
            if (!z2) {
                androidx.compose.foundation.interaction.e eVar = this.focusedInteraction;
                if (eVar != null) {
                    emitWithFallback(nVar, new androidx.compose.foundation.interaction.f(eVar));
                    this.focusedInteraction = null;
                    return;
                }
                return;
            }
            androidx.compose.foundation.interaction.e eVar2 = this.focusedInteraction;
            if (eVar2 != null) {
                emitWithFallback(nVar, new androidx.compose.foundation.interaction.f(eVar2));
                this.focusedInteraction = null;
            }
            androidx.compose.foundation.interaction.e eVar3 = new androidx.compose.foundation.interaction.e();
            emitWithFallback(nVar, eVar3);
            this.focusedInteraction = eVar3;
        }
    }

    private final void emitWithFallback(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.k kVar) {
        if (!isAttached()) {
            nVar.tryEmit(kVar);
        } else {
            InterfaceC1451b0 interfaceC1451b0 = (InterfaceC1451b0) getCoroutineScope().getCoroutineContext().get(C1449a0.f3342b);
            AbstractC1476z.s(getCoroutineScope(), null, null, new c(nVar, kVar, interfaceC1451b0 != null ? interfaceC1451b0.c(new M0.m(13, nVar, kVar)) : null, null), 3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n emitWithFallback$lambda$6(androidx.compose.foundation.interaction.n nVar, androidx.compose.foundation.interaction.k kVar, Throwable th) {
        nVar.tryEmit(kVar);
        return U0.n.f1521a;
    }

    private final K getFocusedBoundsObserver() {
        if (!isAttached()) {
            return null;
        }
        a1 a1VarFindNearestAncestor = b1.findNearestAncestor(this, K.TraverseKey);
        if (a1VarFindNearestAncestor instanceof K) {
            return (K) a1VarFindNearestAncestor;
        }
        return null;
    }

    private final void notifyObserverWhenAttached() {
        K focusedBoundsObserver;
        androidx.compose.ui.layout.J j2 = this.globalLayoutCoordinates;
        if (j2 != null) {
            kotlin.jvm.internal.o.b(j2);
            if (!j2.isAttached() || (focusedBoundsObserver = getFocusedBoundsObserver()) == null) {
                return;
            }
            focusedBoundsObserver.onFocusBoundsChanged(this.globalLayoutCoordinates);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onFocusStateChange(androidx.compose.ui.focus.I i2, androidx.compose.ui.focus.I i3) {
        boolean zIsFocused;
        if (isAttached() && (zIsFocused = i3.isFocused()) != i2.isFocused()) {
            h1.c cVar = this.onFocusChange;
            if (cVar != null) {
                cVar.invoke(Boolean.valueOf(zIsFocused));
            }
            if (zIsFocused) {
                AbstractC1476z.s(getCoroutineScope(), null, null, new e(null), 3);
                InterfaceC0968u0 interfaceC0968u0RetrievePinnableContainer = retrievePinnableContainer();
                this.pinnedHandle = interfaceC0968u0RetrievePinnableContainer != null ? interfaceC0968u0RetrievePinnableContainer.pin() : null;
                notifyObserverWhenAttached();
            } else {
                InterfaceC0966t0 interfaceC0966t0 = this.pinnedHandle;
                if (interfaceC0966t0 != null) {
                    interfaceC0966t0.release();
                }
                this.pinnedHandle = null;
                K focusedBoundsObserver = getFocusedBoundsObserver();
                if (focusedBoundsObserver != null) {
                    focusedBoundsObserver.onFocusBoundsChanged(null);
                }
            }
            T0.invalidateSemantics(this);
            emitInteraction(zIsFocused);
        }
    }

    private final InterfaceC0968u0 retrievePinnableContainer() {
        kotlin.jvm.internal.E e2 = new kotlin.jvm.internal.E();
        androidx.compose.ui.node.A0.observeReads(this, new I.g(3, e2, this));
        return (InterfaceC0968u0) e2.f3118b;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n retrievePinnableContainer$lambda$0(kotlin.jvm.internal.E e2, J j2) {
        e2.f3118b = AbstractC1003m.currentValueOf(j2, AbstractC0972w0.getLocalPinnableContainer());
        return U0.n.f1521a;
    }

    @Override // androidx.compose.ui.node.S0
    public void applySemantics(androidx.compose.ui.semantics.E e2) {
        androidx.compose.ui.semantics.C.setFocused(e2, this.focusTargetNode.getFocusState().isFocused());
        androidx.compose.ui.semantics.C.requestFocus$default(e2, null, new b(this), 1, null);
    }

    public final androidx.compose.ui.focus.I getFocusState() {
        return this.focusTargetNode.getFocusState();
    }

    @Override // androidx.compose.ui.w
    public boolean getShouldAutoInvalidate() {
        return this.shouldAutoInvalidate;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldClearDescendantSemantics() {
        return super.getShouldClearDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean getShouldMergeDescendantSemantics() {
        return super.getShouldMergeDescendantSemantics();
    }

    @Override // androidx.compose.ui.node.a1
    public Object getTraverseKey() {
        return TraverseKey;
    }

    @Override // androidx.compose.ui.node.S0
    public /* bridge */ /* synthetic */ boolean isImportantForBounds() {
        return super.isImportantForBounds();
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.node.C
    public void onGloballyPositioned(androidx.compose.ui.layout.J j2) {
        this.globalLayoutCoordinates = j2;
        if (this.focusTargetNode.getFocusState().isFocused()) {
            if (j2.isAttached()) {
                notifyObserverWhenAttached();
                return;
            }
            K focusedBoundsObserver = getFocusedBoundsObserver();
            if (focusedBoundsObserver != null) {
                focusedBoundsObserver.onFocusBoundsChanged(null);
            }
        }
    }

    @Override // androidx.compose.ui.node.r, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.node.InterfaceC1029z0
    public void onObservedReadsChanged() {
        InterfaceC0968u0 interfaceC0968u0RetrievePinnableContainer = retrievePinnableContainer();
        if (this.focusTargetNode.getFocusState().isFocused()) {
            InterfaceC0966t0 interfaceC0966t0 = this.pinnedHandle;
            if (interfaceC0966t0 != null) {
                interfaceC0966t0.release();
            }
            this.pinnedHandle = interfaceC0968u0RetrievePinnableContainer != null ? interfaceC0968u0RetrievePinnableContainer.pin() : null;
        }
    }

    @Override // androidx.compose.ui.w
    public void onReset() {
        InterfaceC0966t0 interfaceC0966t0 = this.pinnedHandle;
        if (interfaceC0966t0 != null) {
            interfaceC0966t0.release();
        }
        this.pinnedHandle = null;
    }

    public final boolean requestFocus() {
        return androidx.compose.ui.focus.L.m2735requestFocus3ESFkO8$default(this.focusTargetNode, 0, 1, null);
    }

    public final void update(androidx.compose.foundation.interaction.n nVar) {
        if (kotlin.jvm.internal.o.a(this.interactionSource, nVar)) {
            return;
        }
        disposeInteractionSource();
        this.interactionSource = nVar;
    }

    public /* synthetic */ J(androidx.compose.foundation.interaction.n nVar, int i2, h1.c cVar, int i3, AbstractC1378g abstractC1378g) {
        this(nVar, (i3 & 2) != 0 ? androidx.compose.ui.focus.V.Companion.m2762getAlwaysLCbbffg() : i2, (i3 & 4) != 0 ? null : cVar, null);
    }

    private J(androidx.compose.foundation.interaction.n nVar, int i2, h1.c cVar) {
        this.interactionSource = nVar;
        this.onFocusChange = cVar;
        this.focusTargetNode = (androidx.compose.ui.focus.L) delegate(androidx.compose.ui.focus.M.m2739FocusTargetModifierNodePYyLHbc(i2, new d(this)));
    }
}
