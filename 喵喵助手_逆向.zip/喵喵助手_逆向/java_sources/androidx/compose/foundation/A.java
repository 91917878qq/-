package androidx.compose.foundation;

/* JADX INFO: loaded from: classes.dex */
public final class A {
    public static boolean isPausableCompositionInPrefetchEnabled;
    public static final A INSTANCE = new A();
    public static boolean DragGesturePickUpEnabled = true;
    public static boolean isDetectTapGesturesImmediateCoroutineDispatchEnabled = true;
    public static boolean isNewContextMenuEnabled = true;
    public static boolean isSmartSelectionEnabled = true;
    public static boolean isAutomaticNestedPrefetchEnabled = true;
    public static boolean isNonComposedClickableEnabled = true;
    public static boolean isOnScrollChangedCallbackEnabled = true;
    public static boolean isAdjustPointerInputChangeOffsetForVelocityTrackerEnabled = true;
    public static boolean isFlingContinuationAtBoundsEnabled = true;
    public static boolean isNonSuspendingPointerInputInClickableEnabled = true;
    public static boolean isTextFieldDpadNavigationEnabled = true;
    public static final int $stable = 8;

    private A() {
    }

    public static /* synthetic */ void getDragGesturePickUpEnabled$annotations() {
    }

    public static /* synthetic */ void isAdjustPointerInputChangeOffsetForVelocityTrackerEnabled$annotations() {
    }

    public static /* synthetic */ void isAutomaticNestedPrefetchEnabled$annotations() {
    }

    public static /* synthetic */ void isDetectTapGesturesImmediateCoroutineDispatchEnabled$annotations() {
    }

    public static /* synthetic */ void isFlingContinuationAtBoundsEnabled$annotations() {
    }

    public static /* synthetic */ void isNewContextMenuEnabled$annotations() {
    }

    public static /* synthetic */ void isNonComposedClickableEnabled$annotations() {
    }

    public static /* synthetic */ void isNonSuspendingPointerInputInClickableEnabled$annotations() {
    }

    public static /* synthetic */ void isOnScrollChangedCallbackEnabled$annotations() {
    }

    public static /* synthetic */ void isPausableCompositionInPrefetchEnabled$annotations() {
    }

    public static /* synthetic */ void isSmartSelectionEnabled$annotations() {
    }

    public static /* synthetic */ void isTextFieldDpadNavigationEnabled$annotations() {
    }
}
