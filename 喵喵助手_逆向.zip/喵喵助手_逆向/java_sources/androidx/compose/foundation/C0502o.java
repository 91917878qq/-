package androidx.compose.foundation;

import e0.C1311h;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.foundation.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0502o {
    public static final int $stable = 0;
    private final androidx.compose.ui.graphics.P brush;
    private final float width;

    public /* synthetic */ C0502o(float f2, androidx.compose.ui.graphics.P p2, AbstractC1378g abstractC1378g) {
        this(f2, p2);
    }

    /* JADX INFO: renamed from: copy-D5KLDUw$default, reason: not valid java name */
    public static /* synthetic */ C0502o m1118copyD5KLDUw$default(C0502o c0502o, float f2, androidx.compose.ui.graphics.P p2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = c0502o.width;
        }
        if ((i2 & 2) != 0) {
            p2 = c0502o.brush;
        }
        return c0502o.m1119copyD5KLDUw(f2, p2);
    }

    /* JADX INFO: renamed from: copy-D5KLDUw, reason: not valid java name */
    public final C0502o m1119copyD5KLDUw(float f2, androidx.compose.ui.graphics.P p2) {
        return new C0502o(f2, p2, null);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0502o)) {
            return false;
        }
        C0502o c0502o = (C0502o) obj;
        return C1311h.m5081equalsimpl0(this.width, c0502o.width) && kotlin.jvm.internal.o.a(this.brush, c0502o.brush);
    }

    public final androidx.compose.ui.graphics.P getBrush() {
        return this.brush;
    }

    /* JADX INFO: renamed from: getWidth-D9Ej5fM, reason: not valid java name */
    public final float m1120getWidthD9Ej5fM() {
        return this.width;
    }

    public int hashCode() {
        return this.brush.hashCode() + (C1311h.m5082hashCodeimpl(this.width) * 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("BorderStroke(width=");
        D0.d.u(this.width, sb, ", brush=");
        sb.append(this.brush);
        sb.append(')');
        return sb.toString();
    }

    private C0502o(float f2, androidx.compose.ui.graphics.P p2) {
        this.width = f2;
        this.brush = p2;
    }
}
