package androidx.compose.foundation;

import e0.C1305b;
import o.AbstractC1403e;

/* JADX INFO: renamed from: androidx.compose.foundation.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0521s {
    /* JADX INFO: renamed from: checkScrollableContainerConstraints-K40F9xA, reason: not valid java name */
    public static final void m1142checkScrollableContainerConstraintsK40F9xA(long j2, androidx.compose.foundation.gestures.I i2) {
        if (i2 == androidx.compose.foundation.gestures.I.Vertical) {
            if (C1305b.m5040getMaxHeightimpl(j2) != Integer.MAX_VALUE) {
                return;
            }
            AbstractC1403e.throwIllegalStateException("Vertically scrollable component was measured with an infinity maximum height constraints, which is disallowed. One of the common reasons is nesting layouts like LazyColumn and Column(Modifier.verticalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyColumn scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        } else {
            if (C1305b.m5041getMaxWidthimpl(j2) != Integer.MAX_VALUE) {
                return;
            }
            AbstractC1403e.throwIllegalStateException("Horizontally scrollable component was measured with an infinity maximum width constraints, which is disallowed. One of the common reasons is nesting layouts like LazyRow and Row(Modifier.horizontalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyRow scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        }
    }
}
