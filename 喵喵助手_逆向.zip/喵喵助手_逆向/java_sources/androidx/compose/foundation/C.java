package androidx.compose.foundation;

import android.content.res.Configuration;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;

/* JADX INFO: loaded from: classes.dex */
public abstract class C {
    public static final boolean _isSystemInDarkTheme(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-882615028, i2, -1, "androidx.compose.foundation._isSystemInDarkTheme (DarkTheme.android.kt:45)");
        }
        boolean z2 = (((Configuration) interfaceC0768p.consume(AndroidCompositionLocals_androidKt.getLocalConfiguration())).uiMode & 48) == 32;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return z2;
    }
}
