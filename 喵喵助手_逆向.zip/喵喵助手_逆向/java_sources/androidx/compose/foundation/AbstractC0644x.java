package androidx.compose.foundation;

import e0.C1311h;

/* JADX INFO: renamed from: androidx.compose.foundation.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0644x {
    private static final float MaxSupportedElevation = C1311h.m5076constructorimpl(30);

    public static final androidx.compose.ui.x clipScrollableContainer(androidx.compose.ui.x xVar, androidx.compose.foundation.gestures.I i2) {
        return xVar.then(i2 == androidx.compose.foundation.gestures.I.Vertical ? androidx.compose.ui.draw.h.clip(androidx.compose.ui.x.Companion, G0.INSTANCE) : androidx.compose.ui.draw.h.clip(androidx.compose.ui.x.Companion, N.INSTANCE));
    }

    public static final float getMaxSupportedElevation() {
        return MaxSupportedElevation;
    }
}
