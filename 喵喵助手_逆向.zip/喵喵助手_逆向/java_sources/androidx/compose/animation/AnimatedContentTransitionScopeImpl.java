package androidx.compose.animation;

import androidx.compose.animation.C;
import androidx.compose.animation.C0345f;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.E0;
import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.w0;
import androidx.compose.animation.core.y0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import androidx.compose.ui.layout.InterfaceC0962r0;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;
import e0.InterfaceC1307d;
import j.d0;

/* JADX INFO: loaded from: classes.dex */
public final class AnimatedContentTransitionScopeImpl implements InterfaceC0346g {
    public static final int $stable = 8;
    private d2 animatedSize;
    private InterfaceC0849g contentAlignment;
    private e0.u layoutDirection;
    private final B0 measuredSize$delegate = V1.mutableStateOf$default(e0.s.m5231boximpl(e0.s.Companion.m5244getZeroYbymL2g()), null, 2, null);
    private final j.S targetSizeMap;
    private final v0 transition;

    public static final class SizeModifierElement<S> extends AbstractC1000k0 {
        private final AnimatedContentTransitionScopeImpl scope;
        private final androidx.compose.animation.core.v0.a sizeAnimation;
        private final d2 sizeTransform;

        public SizeModifierElement(androidx.compose.animation.core.v0.a aVar, d2 d2Var, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            this.sizeAnimation = aVar;
            this.sizeTransform = d2Var;
            this.scope = animatedContentTransitionScopeImpl;
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
            return super.all(cVar);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
            return super.any(cVar);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0
        public boolean equals(Object obj) {
            if (obj instanceof SizeModifierElement) {
                SizeModifierElement sizeModifierElement = (SizeModifierElement) obj;
                if (kotlin.jvm.internal.o.a(sizeModifierElement.sizeAnimation, this.sizeAnimation) && kotlin.jvm.internal.o.a(sizeModifierElement.sizeTransform, this.sizeTransform)) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
            return super.foldIn(obj, eVar);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
            return super.foldOut(obj, eVar);
        }

        public final AnimatedContentTransitionScopeImpl getScope() {
            return this.scope;
        }

        public final androidx.compose.animation.core.v0.a getSizeAnimation() {
            return this.sizeAnimation;
        }

        public final d2 getSizeTransform() {
            return this.sizeTransform;
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0
        public int hashCode() {
            int iHashCode = this.scope.hashCode() * 31;
            androidx.compose.animation.core.v0.a aVar = this.sizeAnimation;
            return this.sizeTransform.hashCode() + ((iHashCode + (aVar != null ? aVar.hashCode() : 0)) * 31);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0
        public void inspectableProperties(C1065l1 c1065l1) {
            c1065l1.setName("sizeTransform");
            c1065l1.getProperties().set("sizeAnimation", this.sizeAnimation);
            c1065l1.getProperties().set("sizeTransform", this.sizeTransform);
            c1065l1.getProperties().set("scope", this.scope);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
            return super.then(xVar);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0
        public b create() {
            return new b(this.sizeAnimation, this.sizeTransform, this.scope);
        }

        @Override // androidx.compose.ui.node.AbstractC1000k0
        public void update(b bVar) {
            bVar.setSizeAnimation(this.sizeAnimation);
            bVar.setSizeTransform(this.sizeTransform);
            bVar.setScope(this.scope);
        }
    }

    public static final class a implements InterfaceC0962r0 {
        public static final int $stable = 0;
        private final B0 isTarget$delegate;

        public a(boolean z2) {
            this.isTarget$delegate = V1.mutableStateOf$default(Boolean.valueOf(z2), null, 2, null);
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
            return super.all(cVar);
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
            return super.any(cVar);
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
            return super.foldIn(obj, eVar);
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
            return super.foldOut(obj, eVar);
        }

        public final boolean isTarget() {
            return ((Boolean) this.isTarget$delegate.getValue()).booleanValue();
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0
        public Object modifyParentData(InterfaceC1307d interfaceC1307d, Object obj) {
            return this;
        }

        public final void setTarget(boolean z2) {
            this.isTarget$delegate.setValue(Boolean.valueOf(z2));
        }

        @Override // androidx.compose.ui.layout.InterfaceC0962r0, androidx.compose.ui.v, androidx.compose.ui.x
        public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
            return super.then(xVar);
        }
    }

    public static final class b extends I {
        private long lastSize = AbstractC0295b.UnspecifiedSize;
        private AnimatedContentTransitionScopeImpl scope;
        private androidx.compose.animation.core.v0.a sizeAnimation;
        private d2 sizeTransform;

        public static final class a extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ long $measuredSize;
            final /* synthetic */ AbstractC0974x0 $placeable;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(AbstractC0974x0 abstractC0974x0, long j2) {
                super(1);
                this.$placeable = abstractC0974x0;
                this.$measuredSize = j2;
            }

            @Override // h1.c
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                invoke((AbstractC0974x0.a) obj);
                return U0.n.f1521a;
            }

            public final void invoke(AbstractC0974x0.a aVar) {
                AbstractC0974x0.a.m3923place70tqf50$default(aVar, this.$placeable, b.this.getScope().getContentAlignment().mo2803alignKFBX0sM(e0.s.m5234constructorimpl((((long) this.$placeable.getWidth()) << 32) | (((long) this.$placeable.getHeight()) & 4294967295L)), this.$measuredSize, e0.u.Ltr), 0.0f, 2, null);
            }
        }

        /* JADX INFO: renamed from: androidx.compose.animation.AnimatedContentTransitionScopeImpl$b$b, reason: collision with other inner class name */
        public static final class C0008b extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ long $currentSize;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0008b(long j2) {
                super(1);
                this.$currentSize = j2;
            }

            @Override // h1.c
            public final androidx.compose.animation.core.F invoke(w0 w0Var) {
                long jM5243unboximpl;
                androidx.compose.animation.core.F fMo576createAnimationSpecTemP2vQ;
                if (kotlin.jvm.internal.o.a(w0Var.getInitialState(), b.this.getScope().getInitialState())) {
                    jM5243unboximpl = b.this.m558lastContinuousSizeOrDefaultmzRDjE0(this.$currentSize);
                } else {
                    d2 d2Var = (d2) b.this.getScope().getTargetSizeMap$animation().d(w0Var.getInitialState());
                    jM5243unboximpl = d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g();
                }
                d2 d2Var2 = (d2) b.this.getScope().getTargetSizeMap$animation().d(w0Var.getTargetState());
                long jM5243unboximpl2 = d2Var2 != null ? ((e0.s) d2Var2.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g();
                N n2 = (N) b.this.getSizeTransform().getValue();
                return (n2 == null || (fMo576createAnimationSpecTemP2vQ = n2.mo576createAnimationSpecTemP2vQ(jM5243unboximpl, jM5243unboximpl2)) == null) ? AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null) : fMo576createAnimationSpecTemP2vQ;
            }
        }

        public static final class c extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ long $currentSize;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(long j2) {
                super(1);
                this.$currentSize = j2;
            }

            @Override // h1.c
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                return e0.s.m5231boximpl(m560invokeYEO4UFw(obj));
            }

            /* JADX INFO: renamed from: invoke-YEO4UFw, reason: not valid java name */
            public final long m560invokeYEO4UFw(Object obj) {
                if (kotlin.jvm.internal.o.a(obj, b.this.getScope().getInitialState())) {
                    return b.this.m558lastContinuousSizeOrDefaultmzRDjE0(this.$currentSize);
                }
                d2 d2Var = (d2) b.this.getScope().getTargetSizeMap$animation().d(obj);
                return d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g();
            }
        }

        public b(androidx.compose.animation.core.v0.a aVar, d2 d2Var, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            this.sizeAnimation = aVar;
            this.sizeTransform = d2Var;
            this.scope = animatedContentTransitionScopeImpl;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: lastContinuousSizeOrDefault-mzRDjE0, reason: not valid java name */
        public final long m558lastContinuousSizeOrDefaultmzRDjE0(long j2) {
            return e0.s.m5237equalsimpl0(this.lastSize, AbstractC0295b.UnspecifiedSize) ? j2 : this.lastSize;
        }

        public final AnimatedContentTransitionScopeImpl getScope() {
            return this.scope;
        }

        public final androidx.compose.animation.core.v0.a getSizeAnimation() {
            return this.sizeAnimation;
        }

        public final d2 getSizeTransform() {
            return this.sizeTransform;
        }

        @Override // androidx.compose.animation.I, androidx.compose.ui.node.M
        /* JADX INFO: renamed from: measure-3p2s80s, reason: not valid java name */
        public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
            long jM5243unboximpl;
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
            if (interfaceC0937e0.isLookingAhead()) {
                jM5243unboximpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
            } else if (this.sizeAnimation == null) {
                jM5243unboximpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
                this.lastSize = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
            } else {
                long jM5234constructorimpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
                androidx.compose.animation.core.v0.a aVar = this.sizeAnimation;
                kotlin.jvm.internal.o.b(aVar);
                d2 d2VarAnimate = aVar.animate(new C0008b(jM5234constructorimpl), new c(jM5234constructorimpl));
                this.scope.setAnimatedSize$animation(d2VarAnimate);
                jM5243unboximpl = ((e0.s) d2VarAnimate.getValue()).m5243unboximpl();
                this.lastSize = ((e0.s) d2VarAnimate.getValue()).m5243unboximpl();
            }
            return InterfaceC0937e0.layout$default(interfaceC0937e0, (int) (jM5243unboximpl >> 32), (int) (jM5243unboximpl & 4294967295L), null, new a(abstractC0974x0Mo3865measureBRTryo0, jM5243unboximpl), 4, null);
        }

        @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onDensityChange() {
            super.onDensityChange();
        }

        @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
        public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
            super.onLayoutDirectionChange();
        }

        @Override // androidx.compose.ui.w
        public void onReset() {
            super.onReset();
            this.lastSize = AbstractC0295b.UnspecifiedSize;
        }

        public final void setScope(AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            this.scope = animatedContentTransitionScopeImpl;
        }

        public final void setSizeAnimation(androidx.compose.animation.core.v0.a aVar) {
            this.sizeAnimation = aVar;
        }

        public final void setSizeTransform(d2 d2Var) {
            this.sizeTransform = d2Var;
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffset;
        final /* synthetic */ AnimatedContentTransitionScopeImpl this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(h1.c cVar, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            super(1);
            this.$initialOffset = cVar;
            this.this$0 = animatedContentTransitionScopeImpl;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            long j2 = i2;
            return (Integer) this.$initialOffset.invoke(Integer.valueOf(((int) (this.this$0.m550getCurrentSizeYbymL2g() >> 32)) - e0.o.m5196getXimpl(this.this$0.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), this.this$0.m550getCurrentSizeYbymL2g()))));
        }
    }

    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffset;
        final /* synthetic */ AnimatedContentTransitionScopeImpl this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(h1.c cVar, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            super(1);
            this.$initialOffset = cVar;
            this.this$0 = animatedContentTransitionScopeImpl;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            long j2 = i2;
            return (Integer) this.$initialOffset.invoke(Integer.valueOf((-e0.o.m5196getXimpl(this.this$0.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), this.this$0.m550getCurrentSizeYbymL2g()))) - i2));
        }
    }

    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffset;
        final /* synthetic */ AnimatedContentTransitionScopeImpl this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(h1.c cVar, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            super(1);
            this.$initialOffset = cVar;
            this.this$0 = animatedContentTransitionScopeImpl;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            long j2 = i2;
            return (Integer) this.$initialOffset.invoke(Integer.valueOf(((int) (this.this$0.m550getCurrentSizeYbymL2g() & 4294967295L)) - e0.o.m5197getYimpl(this.this$0.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((4294967295L & j2) | (j2 << 32)), this.this$0.m550getCurrentSizeYbymL2g()))));
        }
    }

    public static final class f extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffset;
        final /* synthetic */ AnimatedContentTransitionScopeImpl this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(h1.c cVar, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
            super(1);
            this.$initialOffset = cVar;
            this.this$0 = animatedContentTransitionScopeImpl;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            long j2 = i2;
            return (Integer) this.$initialOffset.invoke(Integer.valueOf((-e0.o.m5197getYimpl(this.this$0.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), this.this$0.m550getCurrentSizeYbymL2g()))) - i2));
        }
    }

    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffset;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(h1.c cVar) {
            super(1);
            this.$targetOffset = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            d2 d2Var = (d2) AnimatedContentTransitionScopeImpl.this.getTargetSizeMap$animation().d(AnimatedContentTransitionScopeImpl.this.getTransition$animation().getTargetState());
            long j2 = i2;
            return (Integer) this.$targetOffset.invoke(Integer.valueOf((-e0.o.m5196getXimpl(AnimatedContentTransitionScopeImpl.this.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g()))) - i2));
        }
    }

    public static final class h extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffset;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(h1.c cVar) {
            super(1);
            this.$targetOffset = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            d2 d2Var = (d2) AnimatedContentTransitionScopeImpl.this.getTargetSizeMap$animation().d(AnimatedContentTransitionScopeImpl.this.getTransition$animation().getTargetState());
            long jM5243unboximpl = d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g();
            long j2 = i2;
            return (Integer) this.$targetOffset.invoke(Integer.valueOf((-e0.o.m5196getXimpl(AnimatedContentTransitionScopeImpl.this.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), jM5243unboximpl))) + ((int) (jM5243unboximpl >> 32))));
        }
    }

    public static final class i extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffset;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(h1.c cVar) {
            super(1);
            this.$targetOffset = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            d2 d2Var = (d2) AnimatedContentTransitionScopeImpl.this.getTargetSizeMap$animation().d(AnimatedContentTransitionScopeImpl.this.getTransition$animation().getTargetState());
            long j2 = i2;
            return (Integer) this.$targetOffset.invoke(Integer.valueOf((-e0.o.m5197getYimpl(AnimatedContentTransitionScopeImpl.this.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g()))) - i2));
        }
    }

    public static final class j extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffset;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(h1.c cVar) {
            super(1);
            this.$targetOffset = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }

        public final Integer invoke(int i2) {
            d2 d2Var = (d2) AnimatedContentTransitionScopeImpl.this.getTargetSizeMap$animation().d(AnimatedContentTransitionScopeImpl.this.getTransition$animation().getTargetState());
            long jM5243unboximpl = d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : e0.s.Companion.m5244getZeroYbymL2g();
            long j2 = i2;
            return (Integer) this.$targetOffset.invoke(Integer.valueOf((-e0.o.m5197getYimpl(AnimatedContentTransitionScopeImpl.this.m549calculateOffsetemnUabE(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32)), jM5243unboximpl))) + ((int) (jM5243unboximpl & 4294967295L))));
        }
    }

    public AnimatedContentTransitionScopeImpl(v0 v0Var, InterfaceC0849g interfaceC0849g, e0.u uVar) {
        this.transition = v0Var;
        this.contentAlignment = interfaceC0849g;
        this.layoutDirection = uVar;
        long[] jArr = d0.f2979a;
        this.targetSizeMap = new j.S();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: calculateOffset-emnUabE, reason: not valid java name */
    public final long m549calculateOffsetemnUabE(long j2, long j3) {
        return getContentAlignment().mo2803alignKFBX0sM(j2, j3, e0.u.Ltr);
    }

    private static final boolean createSizeAnimationModifier$lambda$2(B0 b02) {
        return ((Boolean) b02.getValue()).booleanValue();
    }

    private static final void createSizeAnimationModifier$lambda$3(B0 b02, boolean z2) {
        b02.setValue(Boolean.valueOf(z2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: getCurrentSize-YbymL2g, reason: not valid java name */
    public final long m550getCurrentSizeYbymL2g() {
        d2 d2Var = this.animatedSize;
        return d2Var != null ? ((e0.s) d2Var.getValue()).m5243unboximpl() : m553getMeasuredSizeYbymL2g$animation();
    }

    /* JADX INFO: renamed from: isLeft-gWo6LJ4, reason: not valid java name */
    private final boolean m551isLeftgWo6LJ4(int i2) {
        C0345f.a aVar = C0345f.Companion;
        return C0345f.m646equalsimpl0(i2, aVar.m652getLeftDKzdypw()) || (C0345f.m646equalsimpl0(i2, aVar.m654getStartDKzdypw()) && this.layoutDirection == e0.u.Ltr) || (C0345f.m646equalsimpl0(i2, aVar.m651getEndDKzdypw()) && this.layoutDirection == e0.u.Rtl);
    }

    /* JADX INFO: renamed from: isRight-gWo6LJ4, reason: not valid java name */
    private final boolean m552isRightgWo6LJ4(int i2) {
        C0345f.a aVar = C0345f.Companion;
        return C0345f.m646equalsimpl0(i2, aVar.m653getRightDKzdypw()) || (C0345f.m646equalsimpl0(i2, aVar.m654getStartDKzdypw()) && this.layoutDirection == e0.u.Rtl) || (C0345f.m646equalsimpl0(i2, aVar.m651getEndDKzdypw()) && this.layoutDirection == e0.u.Ltr);
    }

    public final androidx.compose.ui.x createSizeAnimationModifier$animation(C0355p c0355p, InterfaceC0768p interfaceC0768p, int i2) {
        androidx.compose.ui.x xVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(93755870, i2, -1, "androidx.compose.animation.AnimatedContentTransitionScopeImpl.createSizeAnimationModifier (AnimatedContent.kt:557)");
        }
        boolean zChanged = interfaceC0768p.changed(this);
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        v0.a aVarCreateDeferredAnimation = null;
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        B0 b02 = (B0) objRememberedValue;
        d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(c0355p.getSizeTransform(), interfaceC0768p, 0);
        if (kotlin.jvm.internal.o.a(this.transition.getCurrentState(), this.transition.getTargetState())) {
            createSizeAnimationModifier$lambda$3(b02, false);
        } else if (d2VarRememberUpdatedState.getValue() != null) {
            createSizeAnimationModifier$lambda$3(b02, true);
        }
        if (createSizeAnimationModifier$lambda$2(b02)) {
            interfaceC0768p.startReplaceGroup(1353180665);
            aVarCreateDeferredAnimation = y0.createDeferredAnimation(this.transition, E0.getVectorConverter(e0.s.Companion), null, interfaceC0768p, 0, 2);
            boolean zChanged2 = interfaceC0768p.changed(aVarCreateDeferredAnimation);
            Object objRememberedValue2 = interfaceC0768p.rememberedValue();
            if (zChanged2 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                N n2 = (N) d2VarRememberUpdatedState.getValue();
                objRememberedValue2 = (n2 == null || n2.getClip()) ? androidx.compose.ui.draw.h.clipToBounds(androidx.compose.ui.x.Companion) : androidx.compose.ui.x.Companion;
                interfaceC0768p.updateRememberedValue(objRememberedValue2);
            }
            xVar = (androidx.compose.ui.x) objRememberedValue2;
            interfaceC0768p.endReplaceGroup();
        } else {
            interfaceC0768p.startReplaceGroup(1353446707);
            interfaceC0768p.endReplaceGroup();
            this.animatedSize = null;
            xVar = androidx.compose.ui.x.Companion;
        }
        androidx.compose.ui.x xVarThen = xVar.then(new SizeModifierElement(aVarCreateDeferredAnimation, d2VarRememberUpdatedState, this));
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return xVarThen;
    }

    public final d2 getAnimatedSize$animation() {
        return this.animatedSize;
    }

    @Override // androidx.compose.animation.InterfaceC0346g
    public InterfaceC0849g getContentAlignment() {
        return this.contentAlignment;
    }

    @Override // androidx.compose.animation.InterfaceC0346g, androidx.compose.animation.core.w0
    public Object getInitialState() {
        return this.transition.getSegment().getInitialState();
    }

    @Override // androidx.compose.animation.InterfaceC0346g
    public /* bridge */ /* synthetic */ C getKeepUntilTransitionsFinished(C.a aVar) {
        return super.getKeepUntilTransitionsFinished(aVar);
    }

    public final e0.u getLayoutDirection$animation() {
        return this.layoutDirection;
    }

    /* JADX INFO: renamed from: getMeasuredSize-YbymL2g$animation, reason: not valid java name */
    public final long m553getMeasuredSizeYbymL2g$animation() {
        return ((e0.s) this.measuredSize$delegate.getValue()).m5243unboximpl();
    }

    public final j.S getTargetSizeMap$animation() {
        return this.targetSizeMap;
    }

    @Override // androidx.compose.animation.InterfaceC0346g, androidx.compose.animation.core.w0
    public Object getTargetState() {
        return this.transition.getSegment().getTargetState();
    }

    public final v0 getTransition$animation() {
        return this.transition;
    }

    @Override // androidx.compose.animation.InterfaceC0346g, androidx.compose.animation.core.w0
    public /* bridge */ /* synthetic */ boolean isTransitioningTo(Object obj, Object obj2) {
        return super.isTransitioningTo(obj, obj2);
    }

    public final void setAnimatedSize$animation(d2 d2Var) {
        this.animatedSize = d2Var;
    }

    public void setContentAlignment(InterfaceC0849g interfaceC0849g) {
        this.contentAlignment = interfaceC0849g;
    }

    public final void setLayoutDirection$animation(e0.u uVar) {
        this.layoutDirection = uVar;
    }

    /* JADX INFO: renamed from: setMeasuredSize-ozmzZPI$animation, reason: not valid java name */
    public final void m554setMeasuredSizeozmzZPI$animation(long j2) {
        this.measuredSize$delegate.setValue(e0.s.m5231boximpl(j2));
    }

    @Override // androidx.compose.animation.InterfaceC0346g
    /* JADX INFO: renamed from: slideIntoContainer-mOhB8PU, reason: not valid java name */
    public A mo555slideIntoContainermOhB8PU(int i2, androidx.compose.animation.core.F f2, h1.c cVar) {
        if (m551isLeftgWo6LJ4(i2)) {
            return AbstractC0359u.slideInHorizontally(f2, new c(cVar, this));
        }
        if (m552isRightgWo6LJ4(i2)) {
            return AbstractC0359u.slideInHorizontally(f2, new d(cVar, this));
        }
        C0345f.a aVar = C0345f.Companion;
        return C0345f.m646equalsimpl0(i2, aVar.m655getUpDKzdypw()) ? AbstractC0359u.slideInVertically(f2, new e(cVar, this)) : C0345f.m646equalsimpl0(i2, aVar.m650getDownDKzdypw()) ? AbstractC0359u.slideInVertically(f2, new f(cVar, this)) : A.Companion.getNone();
    }

    @Override // androidx.compose.animation.InterfaceC0346g
    /* JADX INFO: renamed from: slideOutOfContainer-mOhB8PU, reason: not valid java name */
    public C mo556slideOutOfContainermOhB8PU(int i2, androidx.compose.animation.core.F f2, h1.c cVar) {
        if (m551isLeftgWo6LJ4(i2)) {
            return AbstractC0359u.slideOutHorizontally(f2, new g(cVar));
        }
        if (m552isRightgWo6LJ4(i2)) {
            return AbstractC0359u.slideOutHorizontally(f2, new h(cVar));
        }
        C0345f.a aVar = C0345f.Companion;
        return C0345f.m646equalsimpl0(i2, aVar.m655getUpDKzdypw()) ? AbstractC0359u.slideOutVertically(f2, new i(cVar)) : C0345f.m646equalsimpl0(i2, aVar.m650getDownDKzdypw()) ? AbstractC0359u.slideOutVertically(f2, new j(cVar)) : C.Companion.getNone();
    }

    @Override // androidx.compose.animation.InterfaceC0346g
    public C0355p using(C0355p c0355p, N n2) {
        c0355p.setSizeTransform$animation(n2);
        return c0355p;
    }
}
