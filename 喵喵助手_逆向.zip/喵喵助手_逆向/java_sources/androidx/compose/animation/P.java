package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public final class P {
    public static final int $stable = 0;
    private final androidx.compose.animation.core.F animationSpec;
    private final h1.c slideOffset;

    public P(h1.c cVar, androidx.compose.animation.core.F f2) {
        this.slideOffset = cVar;
        this.animationSpec = f2;
    }

    public static /* synthetic */ P copy$default(P p2, h1.c cVar, androidx.compose.animation.core.F f2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            cVar = p2.slideOffset;
        }
        if ((i2 & 2) != 0) {
            f2 = p2.animationSpec;
        }
        return p2.copy(cVar, f2);
    }

    public final h1.c component1() {
        return this.slideOffset;
    }

    public final androidx.compose.animation.core.F component2() {
        return this.animationSpec;
    }

    public final P copy(h1.c cVar, androidx.compose.animation.core.F f2) {
        return new P(cVar, f2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof P)) {
            return false;
        }
        P p2 = (P) obj;
        return kotlin.jvm.internal.o.a(this.slideOffset, p2.slideOffset) && kotlin.jvm.internal.o.a(this.animationSpec, p2.animationSpec);
    }

    public final androidx.compose.animation.core.F getAnimationSpec() {
        return this.animationSpec;
    }

    public final h1.c getSlideOffset() {
        return this.slideOffset;
    }

    public int hashCode() {
        return this.animationSpec.hashCode() + (this.slideOffset.hashCode() * 31);
    }

    public String toString() {
        return "Slide(slideOffset=" + this.slideOffset + ", animationSpec=" + this.animationSpec + ')';
    }
}
