package androidx.compose.animation.core;

import androidx.compose.foundation.AbstractC0371e;
import androidx.compose.foundation.AbstractC0406k;
import androidx.compose.foundation.C0364a0;
import androidx.compose.foundation.S;
import androidx.compose.foundation.gestures.AbstractC0383g;
import androidx.compose.foundation.gestures.AbstractC0391o;
import androidx.compose.foundation.gestures.DraggableElement;
import androidx.compose.foundation.gestures.E;
import androidx.compose.foundation.layout.C0428k;
import androidx.compose.foundation.layout.C0436o;
import androidx.compose.foundation.lazy.O;
import androidx.compose.foundation.pager.C0505b;
import androidx.compose.ui.graphics.C0877n0;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.platform.C1083s;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class D0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1634b;

    public /* synthetic */ D0(int i2) {
        this.f1634b = i2;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1634b) {
            case 0:
                return E0.IntSizeToVector$lambda$14((e0.s) obj);
            case 1:
                return E0.IntSizeToVector$lambda$15((C0323n) obj);
            case 2:
                return E0.RectToVector$lambda$16((J.h) obj);
            case 3:
                return E0.RectToVector$lambda$17((C0327p) obj);
            case 4:
                return Float.valueOf(((C0321m) obj).getValue());
            case 5:
                return AbstractC0406k.drawContentWithoutBorder$lambda$0((androidx.compose.ui.graphics.drawscope.c) obj);
            case 6:
                return S.a.measure_3p2s80s$lambda$0((AbstractC0974x0.a) obj);
            case 7:
                return C0364a0.a.invokeSuspend$lambda$0(((Long) obj).longValue());
            case 8:
                return AbstractC0371e.defaultOverscrollFactory((androidx.compose.runtime.B) obj);
            case 9:
                return androidx.compose.foundation.s0.progressSemantics$lambda$1((androidx.compose.ui.semantics.E) obj);
            case 10:
                return androidx.compose.foundation.C0.Saver$lambda$5(((Integer) obj).intValue());
            case 11:
                return AbstractC0383g.LocalBringIntoViewSpec$lambda$0((androidx.compose.runtime.B) obj);
            case androidx.compose.ui.graphics.B0.TranslateX /* 12 */:
                return AbstractC0391o.detectHorizontalDragGestures$lambda$25((J.f) obj);
            case androidx.compose.ui.graphics.B0.TranslateY /* 13 */:
                return AbstractC0391o.detectDragGesturesAfterLongPress$lambda$11((J.f) obj);
            case androidx.compose.ui.graphics.B0.TranslateZ /* 14 */:
                return AbstractC0391o.detectDragGestures$lambda$1((J.f) obj);
            case 15:
                return AbstractC0391o.detectVerticalDragGestures$lambda$18((J.f) obj);
            case C0877n0.Size /* 16 */:
                return AbstractC0391o.detectDragGestures$lambda$8((androidx.compose.ui.input.pointer.C) obj);
            case 17:
                return Boolean.valueOf(DraggableElement.CanDrag$lambda$0((androidx.compose.ui.input.pointer.C) obj));
            case 18:
                return E.b.a.invokeSuspend$lambda$0(((Long) obj).longValue());
            case 19:
                return Boolean.valueOf(androidx.compose.foundation.gestures.Z.CanDragCalculation$lambda$0((androidx.compose.ui.input.pointer.C) obj));
            case C1083s.AccessibilitySliderStepsCount /* 20 */:
                return androidx.compose.foundation.gestures.j0.NoOnReport$lambda$0(((Float) obj).floatValue());
            case 21:
                return C0428k.measure_3p2s80s$lambda$0((AbstractC0974x0.a) obj);
            case 22:
                return C0436o.measure_3p2s80s$lambda$0((AbstractC0974x0.a) obj);
            case 23:
                return androidx.compose.foundation.layout.A0.measure_3p2s80s$lambda$1$lambda$0((AbstractC0974x0.a) obj);
            case 24:
                return androidx.compose.foundation.lazy.A.measureLazyList_LCrQqZ4$lambda$2((AbstractC0974x0.a) obj);
            case 25:
                return androidx.compose.foundation.lazy.J.items$lambda$0(((Integer) obj).intValue());
            case 26:
                return androidx.compose.foundation.lazy.O.Saver$lambda$9((List) obj);
            case 27:
                return O.a.saver$lambda$3(null, (List) obj);
            case 28:
                return C0505b.Saver$lambda$2((List) obj);
            default:
                return androidx.compose.foundation.pager.y.measurePager_BiYVr7A$lambda$3((AbstractC0974x0.a) obj);
        }
    }
}
