package androidx.compose.animation.core;

import androidx.compose.animation.core.N;
import androidx.compose.animation.core.N.a;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.d2;
import kotlin.jvm.internal.C1379h;

/* JADX INFO: loaded from: classes.dex */
public abstract class O {

    public static final class a implements androidx.compose.runtime.V {
        final /* synthetic */ N $this_animateValue$inlined;
        final /* synthetic */ N.a $transitionAnimation$inlined;

        public a(N n2, N.a aVar) {
            this.$this_animateValue$inlined = n2;
            this.$transitionAnimation$inlined = aVar;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$this_animateValue$inlined.removeAnimation$animation_core(this.$transitionAnimation$inlined);
        }
    }

    public static final d2 animateFloat(N n2, float f2, float f3, M m2, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        String str2 = (i3 & 8) != 0 ? "FloatAnimation" : str;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-644770905, i2, -1, "androidx.compose.animation.core.animateFloat (InfiniteTransition.kt:296)");
        }
        int i4 = i2 << 3;
        d2 d2VarAnimateValue = animateValue(n2, Float.valueOf(f2), Float.valueOf(f3), E0.getVectorConverter(C1379h.f3125a), m2, str2, interfaceC0768p, (i2 & 1022) | (57344 & i4) | (i4 & 458752), 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValue;
    }

    public static final <T, V extends AbstractC0329q> d2 animateValue(N n2, T t2, T t3, B0 b02, M m2, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 16) != 0) {
            str = "ValueAnimation";
        }
        String str2 = str;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1062847727, i2, -1, "androidx.compose.animation.core.animateValue (InfiniteTransition.kt:245)");
        }
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        C0765o c0765o = InterfaceC0768p.Companion;
        if (objRememberedValue == c0765o.getEmpty()) {
            objRememberedValue = n2.new a(t2, t3, b02, m2, str2);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        N.a aVar = (N.a) objRememberedValue;
        boolean z2 = true;
        boolean z3 = ((((i2 & 112) ^ 48) > 32 && interfaceC0768p.changedInstance(t2)) || (i2 & 48) == 32) | ((((i2 & 896) ^ 384) > 256 && interfaceC0768p.changedInstance(t3)) || (i2 & 384) == 256);
        if ((((57344 & i2) ^ 24576) <= 16384 || !interfaceC0768p.changedInstance(m2)) && (i2 & 24576) != 16384) {
            z2 = false;
        }
        boolean z4 = z3 | z2;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == c0765o.getEmpty()) {
            objRememberedValue2 = new O0.r(t2, aVar, t3, m2, 6);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.Z.SideEffect((h1.a) objRememberedValue2, interfaceC0768p, 0);
        boolean zChangedInstance = interfaceC0768p.changedInstance(n2);
        Object objRememberedValue3 = interfaceC0768p.rememberedValue();
        if (zChangedInstance || objRememberedValue3 == c0765o.getEmpty()) {
            objRememberedValue3 = new M0.m(5, n2, aVar);
            interfaceC0768p.updateRememberedValue(objRememberedValue3);
        }
        androidx.compose.runtime.Z.DisposableEffect(aVar, (h1.c) objRememberedValue3, interfaceC0768p, 6);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateValue$lambda$3$lambda$2(Object obj, N.a aVar, Object obj2, M m2) {
        if (!kotlin.jvm.internal.o.a(obj, aVar.getInitialValue$animation_core()) || !kotlin.jvm.internal.o.a(obj2, aVar.getTargetValue$animation_core())) {
            aVar.updateValues$animation_core(obj, obj2, m2);
        }
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V animateValue$lambda$6$lambda$5(N n2, N.a aVar, androidx.compose.runtime.W w2) {
        n2.addAnimation$animation_core(aVar);
        return new a(n2, aVar);
    }

    public static final N rememberInfiniteTransition(String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 1) != 0) {
            str = "InfiniteTransition";
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1013651573, i2, -1, "androidx.compose.animation.core.rememberInfiniteTransition (InfiniteTransition.kt:44)");
        }
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = new N(str);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        N n2 = (N) objRememberedValue;
        n2.run$animation_core(interfaceC0768p, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return n2;
    }

    @U0.a
    public static final /* synthetic */ d2 animateFloat(N n2, float f2, float f3, M m2, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(469472752, i2, -1, "androidx.compose.animation.core.animateFloat (InfiniteTransition.kt:336)");
        }
        d2 d2VarAnimateFloat = animateFloat(n2, f2, f3, m2, "FloatAnimation", interfaceC0768p, (i2 & 14) | 24576 | (i2 & 112) | (i2 & 896) | (i2 & 7168), 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateFloat;
    }

    @U0.a
    public static final /* synthetic */ N rememberInfiniteTransition(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-840193660, i2, -1, "androidx.compose.animation.core.rememberInfiniteTransition (InfiniteTransition.kt:303)");
        }
        N nRememberInfiniteTransition = rememberInfiniteTransition("InfiniteTransition", interfaceC0768p, 6, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return nRememberInfiniteTransition;
    }

    @U0.a
    public static final /* synthetic */ d2 animateValue(N n2, Object obj, Object obj2, B0 b02, M m2, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1695411770, i2, -1, "androidx.compose.animation.core.animateValue (InfiniteTransition.kt:317)");
        }
        int i3 = (i2 >> 3) & 8;
        d2 d2VarAnimateValue = animateValue(n2, obj, obj2, b02, m2, "ValueAnimation", interfaceC0768p, (i2 & 14) | 196608 | (i3 << 3) | (i2 & 112) | (i3 << 6) | (i2 & 896) | (i2 & 7168) | (i2 & 57344), 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValue;
    }
}
