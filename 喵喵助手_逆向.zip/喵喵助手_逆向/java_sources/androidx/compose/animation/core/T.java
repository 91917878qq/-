package androidx.compose.animation.core;

import androidx.compose.animation.core.Q;
import j.C1331B;
import j.C1332C;

/* JADX INFO: loaded from: classes.dex */
public final class T implements B {
    public static final int $stable = 0;
    private final a config;
    private float periodicBias;

    public static final class a extends S {
        public static final int $stable = 8;

        public a() {
            super(null);
        }

        @Override // androidx.compose.animation.core.S
        public Q.a createEntityFor$animation_core(Object obj) {
            return new Q.a(obj, null, 0, 6, null);
        }
    }

    public T(a aVar) {
        this.config = aVar;
        this.periodicBias = Float.NaN;
    }

    public final a getConfig() {
        return this.config;
    }

    public T(a aVar, float f2) {
        this(aVar);
        this.periodicBias = f2;
    }

    @Override // androidx.compose.animation.core.B, androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> I0 vectorize(B0 b02) {
        int[] iArr;
        Object[] objArr;
        int[] iArr2;
        Object[] objArr2;
        int i2;
        C1332C keyframes$animation_core = this.config.getKeyframes$animation_core();
        C1331B c1331b = new C1331B(keyframes$animation_core.f3042e + 2);
        C1332C c1332c = new C1332C(keyframes$animation_core.f3042e);
        int[] iArr3 = keyframes$animation_core.f3039b;
        Object[] objArr3 = keyframes$animation_core.f3040c;
        long[] jArr = keyframes$animation_core.f3038a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i3 = 0;
            while (true) {
                long j2 = jArr[i3];
                if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i4 = 8;
                    int i5 = 8 - ((~(i3 - length)) >>> 31);
                    int i6 = 0;
                    while (i6 < i5) {
                        if ((255 & j2) < 128) {
                            int i7 = (i3 << 3) + i6;
                            int i8 = iArr3[i7];
                            Q.a aVar = (Q.a) objArr3[i7];
                            c1331b.d(i8);
                            iArr2 = iArr3;
                            objArr2 = objArr3;
                            c1332c.i(i8, new U0.g(b02.getConvertToVector().invoke(aVar.getValue$animation_core()), aVar.getEasing$animation_core()));
                            i2 = 8;
                        } else {
                            iArr2 = iArr3;
                            objArr2 = objArr3;
                            i2 = i4;
                        }
                        j2 >>= i2;
                        i6++;
                        i4 = i2;
                        iArr3 = iArr2;
                        objArr3 = objArr2;
                    }
                    iArr = iArr3;
                    objArr = objArr3;
                    if (i5 != i4) {
                        break;
                    }
                } else {
                    iArr = iArr3;
                    objArr = objArr3;
                }
                if (i3 == length) {
                    break;
                }
                i3++;
                iArr3 = iArr;
                objArr3 = objArr;
            }
        }
        if (!keyframes$animation_core.a(0)) {
            c1331b.c();
        }
        if (!keyframes$animation_core.a(this.config.getDurationMillis())) {
            c1331b.d(this.config.getDurationMillis());
        }
        c1331b.h();
        return new P0(c1331b, c1332c, this.config.getDurationMillis(), this.config.getDelayMillis(), this.periodicBias);
    }
}
