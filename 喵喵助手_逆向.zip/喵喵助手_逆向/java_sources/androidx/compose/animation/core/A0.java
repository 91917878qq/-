package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class A0 implements B {
    public static final int $stable = 0;
    private final int delay;
    private final int durationMillis;
    private final C easing;

    public A0() {
        this(0, 0, null, 7, null);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof A0)) {
            return false;
        }
        A0 a02 = (A0) obj;
        return a02.durationMillis == this.durationMillis && a02.delay == this.delay && kotlin.jvm.internal.o.a(a02.easing, this.easing);
    }

    public final int getDelay() {
        return this.delay;
    }

    public final int getDurationMillis() {
        return this.durationMillis;
    }

    public final C getEasing() {
        return this.easing;
    }

    public int hashCode() {
        return ((this.easing.hashCode() + (this.durationMillis * 31)) * 31) + this.delay;
    }

    public A0(int i2, int i3, C c2) {
        this.durationMillis = i2;
        this.delay = i3;
        this.easing = c2;
    }

    @Override // androidx.compose.animation.core.B, androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> T0 vectorize(B0 b02) {
        return new T0(this.durationMillis, this.delay, this.easing);
    }

    public /* synthetic */ A0(int i2, int i3, C c2, int i4, AbstractC1378g abstractC1378g) {
        this((i4 & 1) != 0 ? 300 : i2, (i4 & 2) != 0 ? 0 : i3, (i4 & 4) != 0 ? E.getFastOutSlowInEasing() : c2);
    }
}
