package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0313i {
    <V extends AbstractC0329q> F0 vectorize(B0 b02);
}
