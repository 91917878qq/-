package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0303d {
    long getDurationNanos();

    Object getTargetValue();

    B0 getTypeConverter();

    Object getValueFromNanos(long j2);

    AbstractC0329q getVelocityVectorFromNanos(long j2);

    default boolean isFinishedFromNanos(long j2) {
        return j2 >= getDurationNanos();
    }

    boolean isInfinite();
}
