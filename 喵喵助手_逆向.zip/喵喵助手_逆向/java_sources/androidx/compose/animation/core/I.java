package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class I implements H {
    public static final int $stable = 0;
    private final float absVelocityThreshold;
    private final float friction;

    /* JADX WARN: Illegal instructions before constructor call */
    public I() {
        float f2 = 0.0f;
        this(f2, f2, 3, null);
    }

    @Override // androidx.compose.animation.core.H
    public float getAbsVelocityThreshold() {
        return this.absVelocityThreshold;
    }

    @Override // androidx.compose.animation.core.H
    public long getDurationNanos(float f2, float f3) {
        return ((long) ((((float) Math.log(getAbsVelocityThreshold() / Math.abs(f3))) * 1000.0f) / this.friction)) * AbstractC0307f.MillisToNanos;
    }

    @Override // androidx.compose.animation.core.H
    public float getTargetValue(float f2, float f3) {
        if (Math.abs(f3) <= getAbsVelocityThreshold()) {
            return f2;
        }
        double dLog = Math.log(Math.abs(getAbsVelocityThreshold() / f3));
        float f4 = this.friction;
        return ((f3 / f4) * ((float) Math.exp((((double) f4) * ((dLog / ((double) f4)) * ((double) 1000))) / ((double) 1000.0f)))) + (f2 - (f3 / f4));
    }

    @Override // androidx.compose.animation.core.H
    public float getValueFromNanos(long j2, float f2, float f3) {
        long j3 = j2 / AbstractC0307f.MillisToNanos;
        float f4 = this.friction;
        return ((f3 / f4) * ((float) Math.exp((f4 * j3) / 1000.0f))) + (f2 - (f3 / f4));
    }

    @Override // androidx.compose.animation.core.H
    public float getVelocityFromNanos(long j2, float f2, float f3) {
        return f3 * ((float) Math.exp(((j2 / AbstractC0307f.MillisToNanos) / 1000.0f) * this.friction));
    }

    public I(float f2, float f3) {
        this.absVelocityThreshold = Math.max(1.0E-7f, Math.abs(f3));
        this.friction = Math.max(1.0E-4f, f2) * (-4.2f);
    }

    public /* synthetic */ I(float f2, float f3, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? 1.0f : f2, (i2 & 2) != 0 ? 0.1f : f3);
    }
}
