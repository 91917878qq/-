package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0340x implements InterfaceC0303d {
    public static final int $stable = 0;
    private final H0 animationSpec;
    private final long durationNanos;
    private final AbstractC0329q endVelocity;
    private final Object initialValue;
    private final AbstractC0329q initialValueVector;
    private final AbstractC0329q initialVelocityVector;
    private final boolean isInfinite;
    private final Object targetValue;
    private final B0 typeConverter;

    public C0340x(H0 h02, B0 b02, Object obj, AbstractC0329q abstractC0329q) {
        this.animationSpec = h02;
        this.typeConverter = b02;
        this.initialValue = obj;
        AbstractC0329q abstractC0329q2 = (AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj);
        this.initialValueVector = abstractC0329q2;
        this.initialVelocityVector = r.copy(abstractC0329q);
        this.targetValue = getTypeConverter().getConvertFromVector().invoke(h02.getTargetValue(abstractC0329q2, abstractC0329q));
        this.durationNanos = h02.getDurationNanos(abstractC0329q2, abstractC0329q);
        AbstractC0329q abstractC0329qCopy = r.copy(h02.getVelocityFromNanos(getDurationNanos(), abstractC0329q2, abstractC0329q));
        this.endVelocity = abstractC0329qCopy;
        int size$animation_core = abstractC0329qCopy.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q3 = this.endVelocity;
            abstractC0329q3.set$animation_core(i2, j1.a.n(abstractC0329q3.get$animation_core(i2), -this.animationSpec.getAbsVelocityThreshold(), this.animationSpec.getAbsVelocityThreshold()));
        }
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public long getDurationNanos() {
        return this.durationNanos;
    }

    public final Object getInitialValue() {
        return this.initialValue;
    }

    public final AbstractC0329q getInitialVelocityVector() {
        return this.initialVelocityVector;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public Object getTargetValue() {
        return this.targetValue;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public B0 getTypeConverter() {
        return this.typeConverter;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public Object getValueFromNanos(long j2) {
        return !isFinishedFromNanos(j2) ? getTypeConverter().getConvertFromVector().invoke(this.animationSpec.getValueFromNanos(j2, this.initialValueVector, this.initialVelocityVector)) : getTargetValue();
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public AbstractC0329q getVelocityVectorFromNanos(long j2) {
        return !isFinishedFromNanos(j2) ? this.animationSpec.getVelocityFromNanos(j2, this.initialValueVector, this.initialVelocityVector) : this.endVelocity;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public /* bridge */ /* synthetic */ boolean isFinishedFromNanos(long j2) {
        return super.isFinishedFromNanos(j2);
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public boolean isInfinite() {
        return this.isInfinite;
    }

    public C0340x(InterfaceC0341y interfaceC0341y, B0 b02, Object obj, AbstractC0329q abstractC0329q) {
        this(interfaceC0341y.vectorize(b02), b02, obj, abstractC0329q);
    }

    public C0340x(InterfaceC0341y interfaceC0341y, B0 b02, Object obj, Object obj2) {
        this(interfaceC0341y.vectorize(b02), b02, obj, (AbstractC0329q) b02.getConvertToVector().invoke(obj2));
    }
}
