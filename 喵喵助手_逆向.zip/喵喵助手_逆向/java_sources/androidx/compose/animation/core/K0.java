package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final class K0 implements J0 {
    public static final int $stable = 8;
    private final InterfaceC0332s anims;
    private AbstractC0329q endVelocityVector;
    private AbstractC0329q valueVector;
    private AbstractC0329q velocityVector;

    public static final class a implements InterfaceC0332s {
        final /* synthetic */ G $anim;

        public a(G g2) {
            this.$anim = g2;
        }

        @Override // androidx.compose.animation.core.InterfaceC0332s
        public G get(int i2) {
            return this.$anim;
        }
    }

    public K0(InterfaceC0332s interfaceC0332s) {
        this.anims = interfaceC0332s;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        int size$animation_core = abstractC0329q.getSize$animation_core();
        long jMax = 0;
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            jMax = Math.max(jMax, this.anims.get(i2).getDurationNanos(abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2), abstractC0329q3.get$animation_core(i2)));
        }
        return jMax;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        if (this.endVelocityVector == null) {
            this.endVelocityVector = r.newInstance(abstractC0329q3);
        }
        AbstractC0329q abstractC0329q4 = this.endVelocityVector;
        if (abstractC0329q4 == null) {
            kotlin.jvm.internal.o.k("endVelocityVector");
            throw null;
        }
        int size$animation_core = abstractC0329q4.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q5 = this.endVelocityVector;
            if (abstractC0329q5 == null) {
                kotlin.jvm.internal.o.k("endVelocityVector");
                throw null;
            }
            abstractC0329q5.set$animation_core(i2, this.anims.get(i2).getEndVelocity(abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2), abstractC0329q3.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q6 = this.endVelocityVector;
        if (abstractC0329q6 != null) {
            return abstractC0329q6;
        }
        kotlin.jvm.internal.o.k("endVelocityVector");
        throw null;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        if (this.valueVector == null) {
            this.valueVector = r.newInstance(abstractC0329q);
        }
        AbstractC0329q abstractC0329q4 = this.valueVector;
        if (abstractC0329q4 == null) {
            kotlin.jvm.internal.o.k("valueVector");
            throw null;
        }
        int size$animation_core = abstractC0329q4.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q5 = this.valueVector;
            if (abstractC0329q5 == null) {
                kotlin.jvm.internal.o.k("valueVector");
                throw null;
            }
            abstractC0329q5.set$animation_core(i2, this.anims.get(i2).getValueFromNanos(j2, abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2), abstractC0329q3.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q6 = this.valueVector;
        if (abstractC0329q6 != null) {
            return abstractC0329q6;
        }
        kotlin.jvm.internal.o.k("valueVector");
        throw null;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        if (this.velocityVector == null) {
            this.velocityVector = r.newInstance(abstractC0329q3);
        }
        AbstractC0329q abstractC0329q4 = this.velocityVector;
        if (abstractC0329q4 == null) {
            kotlin.jvm.internal.o.k("velocityVector");
            throw null;
        }
        int size$animation_core = abstractC0329q4.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q5 = this.velocityVector;
            if (abstractC0329q5 == null) {
                kotlin.jvm.internal.o.k("velocityVector");
                throw null;
            }
            abstractC0329q5.set$animation_core(i2, this.anims.get(i2).getVelocityFromNanos(j2, abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2), abstractC0329q3.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q6 = this.velocityVector;
        if (abstractC0329q6 != null) {
            return abstractC0329q6;
        }
        kotlin.jvm.internal.o.k("velocityVector");
        throw null;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }

    public K0(G g2) {
        this(new a(g2));
    }
}
