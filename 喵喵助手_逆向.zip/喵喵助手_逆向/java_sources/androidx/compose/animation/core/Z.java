package androidx.compose.animation.core;

import l.AbstractC1380a;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends AbstractC1380a {
    public static final int $stable = 8;

    public Z() {
        super("Mutation interrupted");
    }
}
