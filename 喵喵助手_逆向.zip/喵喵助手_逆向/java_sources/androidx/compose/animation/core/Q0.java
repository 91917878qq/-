package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class Q0 implements J0 {
    public static final int $stable = 8;
    private final I0 animation;
    private final long durationNanos;
    private final long initialOffsetNanos;
    private final int iterations;
    private final EnumC0302c0 repeatMode;

    public /* synthetic */ Q0(int i2, I0 i02, EnumC0302c0 enumC0302c0, long j2, AbstractC1378g abstractC1378g) {
        this(i2, i02, enumC0302c0, j2);
    }

    private final long repetitionPlayTimeNanos(long j2) {
        long j3 = this.initialOffsetNanos;
        if (j2 + j3 <= 0) {
            return 0L;
        }
        long j4 = j2 + j3;
        long jMin = Math.min(j4 / this.durationNanos, ((long) this.iterations) - 1);
        return (this.repeatMode == EnumC0302c0.Restart || jMin % ((long) 2) == 0) ? j4 - (jMin * this.durationNanos) : ((jMin + 1) * this.durationNanos) - j4;
    }

    private final AbstractC0329q repetitionStartVelocity(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        long j3 = this.initialOffsetNanos;
        long j4 = j2 + j3;
        long j5 = this.durationNanos;
        return j4 > j5 ? getVelocityFromNanos(j5 - j3, abstractC0329q, abstractC0329q2, abstractC0329q3) : abstractC0329q2;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return (((long) this.iterations) * this.durationNanos) - this.initialOffsetNanos;
    }

    public final long getDurationNanos$animation_core() {
        return this.durationNanos;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.animation.getValueFromNanos(repetitionPlayTimeNanos(j2), abstractC0329q, abstractC0329q2, repetitionStartVelocity(j2, abstractC0329q, abstractC0329q3, abstractC0329q2));
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.animation.getVelocityFromNanos(repetitionPlayTimeNanos(j2), abstractC0329q, abstractC0329q2, repetitionStartVelocity(j2, abstractC0329q, abstractC0329q3, abstractC0329q2));
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }

    private Q0(int i2, I0 i02, EnumC0302c0 enumC0302c0, long j2) {
        this.iterations = i2;
        this.animation = i02;
        this.repeatMode = enumC0302c0;
        if (i2 < 1) {
            throw new IllegalArgumentException("Iterations count can't be less than 1");
        }
        this.durationNanos = ((long) (i02.getDurationMillis() + i02.getDelayMillis())) * AbstractC0307f.MillisToNanos;
        this.initialOffsetNanos = j2 * AbstractC0307f.MillisToNanos;
    }

    public /* synthetic */ Q0(int i2, I0 i02, EnumC0302c0 enumC0302c0, long j2, int i3, AbstractC1378g abstractC1378g) {
        this(i2, i02, (i3 & 4) != 0 ? EnumC0302c0.Restart : enumC0302c0, (i3 & 8) != 0 ? C0322m0.m616constructorimpl$default(0, 0, 2, null) : j2, (AbstractC1378g) null);
    }

    public /* synthetic */ Q0(int i2, I0 i02, EnumC0302c0 enumC0302c0, int i3, AbstractC1378g abstractC1378g) {
        this(i2, i02, (i3 & 4) != 0 ? EnumC0302c0.Restart : enumC0302c0);
    }

    @U0.a
    public /* synthetic */ Q0(int i2, I0 i02, EnumC0302c0 enumC0302c0) {
        this(i2, i02, enumC0302c0, C0322m0.m616constructorimpl$default(0, 0, 2, null), (AbstractC1378g) null);
    }
}
