package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0321m extends AbstractC0329q {
    public static final int $stable = 8;
    private final int size;
    private float value;

    public C0321m(float f2) {
        super(null);
        this.value = f2;
        this.size = 1;
    }

    public boolean equals(Object obj) {
        return (obj instanceof C0321m) && ((C0321m) obj).value == this.value;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public float get$animation_core(int i2) {
        if (i2 == 0) {
            return this.value;
        }
        return 0.0f;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public int getSize$animation_core() {
        return this.size;
    }

    public final float getValue() {
        return this.value;
    }

    public int hashCode() {
        return Float.hashCode(this.value);
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void reset$animation_core() {
        this.value = 0.0f;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void set$animation_core(int i2, float f2) {
        if (i2 == 0) {
            this.value = f2;
        }
    }

    public final void setValue$animation_core(float f2) {
        this.value = f2;
    }

    public String toString() {
        return "AnimationVector1D: value = " + this.value;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public C0321m newVector$animation_core() {
        return new C0321m(0.0f);
    }
}
