package androidx.compose.animation.core;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class Y {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ Y[] $VALUES;
    public static final Y Default = new Y("Default", 0);
    public static final Y UserInput = new Y("UserInput", 1);
    public static final Y PreventUserInput = new Y("PreventUserInput", 2);

    private static final /* synthetic */ Y[] $values() {
        return new Y[]{Default, UserInput, PreventUserInput};
    }

    static {
        Y[] yArr$values = $values();
        $VALUES = yArr$values;
        $ENTRIES = AbstractC0292a.q(yArr$values);
    }

    private Y(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static Y valueOf(String str) {
        return (Y) Enum.valueOf(Y.class, str);
    }

    public static Y[] values() {
        return (Y[]) $VALUES.clone();
    }
}
