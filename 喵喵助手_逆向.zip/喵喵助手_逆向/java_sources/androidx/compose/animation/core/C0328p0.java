package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.p0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0328p0 implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1647b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0317k f1648c;

    public /* synthetic */ C0328p0(int i2, C0317k c0317k) {
        this.f1647b = i2;
        this.f1648c = c0317k;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1647b) {
            case 0:
                return AbstractC0333s0.animate$lambda$9(this.f1648c);
            default:
                return AbstractC0333s0.animate$lambda$8$lambda$6(this.f1648c);
        }
    }
}
