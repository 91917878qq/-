package androidx.compose.animation.core;

import androidx.compose.foundation.gestures.AbstractC0391o;
import androidx.compose.foundation.lazy.C0458k;

/* JADX INFO: renamed from: androidx.compose.animation.core.r0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0331r0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1654b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h1.e f1655c;

    public /* synthetic */ C0331r0(int i2, h1.e eVar) {
        this.f1654b = i2;
        this.f1655c = eVar;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1654b) {
            case 0:
                return AbstractC0333s0.animateDecay$lambda$0(this.f1655c, (C0311h) obj);
            case 1:
                return AbstractC0391o.n.invokeSuspend$lambda$0(this.f1655c, (androidx.compose.ui.input.pointer.C) obj);
            case 2:
                return AbstractC0391o.C0031o.invokeSuspend$lambda$1(this.f1655c, (androidx.compose.ui.input.pointer.C) obj);
            case 3:
                return AbstractC0391o.p.invokeSuspend$lambda$1(this.f1655c, (androidx.compose.ui.input.pointer.C) obj);
            default:
                return C0458k.schedulePrefetch$lambda$0(this.f1655c, (androidx.compose.foundation.lazy.E) obj);
        }
    }
}
