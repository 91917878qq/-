package androidx.compose.animation.core;

import j.AbstractC1353k;
import j.AbstractC1355m;

/* JADX INFO: loaded from: classes.dex */
public final class P0 implements I0 {
    public static final int $stable = 8;
    private final int delayMillis;
    private final int durationMillis;
    private final AbstractC1355m keyframes;
    private AbstractC0329q lastInitialValue;
    private AbstractC0329q lastTargetValue;
    private U monoSpline;
    private final float periodicBias;
    private float[] times;
    private final AbstractC1353k timestamps;
    private AbstractC0329q valueVector;
    private float[][] values;
    private AbstractC0329q velocityVector;

    public P0(AbstractC1353k abstractC1353k, AbstractC1355m abstractC1355m, int i2, int i3, float f2) {
        this.timestamps = abstractC1353k;
        this.keyframes = abstractC1355m;
        this.durationMillis = i2;
        this.delayMillis = i3;
        this.periodicBias = f2;
    }

    private final int findEntryForTimeMillis(int i2) {
        int iA = AbstractC1353k.a(this.timestamps, i2);
        return iA < -1 ? -(iA + 2) : iA;
    }

    private final float getEasedTimeFromIndex(int i2, int i3) {
        float fTransform;
        AbstractC1353k abstractC1353k = this.timestamps;
        if (i2 >= abstractC1353k.f3020b - 1) {
            fTransform = i3;
        } else {
            int iB = abstractC1353k.b(i2);
            int iB2 = this.timestamps.b(i2 + 1);
            if (i3 == iB) {
                fTransform = iB;
            } else {
                float f2 = iB2 - iB;
                fTransform = (getEasing(i2).transform((i3 - iB) / f2) * f2) + iB;
            }
        }
        return fTransform / 1000;
    }

    private final C getEasing(int i2) {
        C c2;
        U0.g gVar = (U0.g) this.keyframes.b(this.timestamps.b(i2));
        return (gVar == null || (c2 = (C) gVar.f1512c) == null) ? E.getLinearEasing() : c2;
    }

    private final void init(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        float[] fArr;
        if (this.valueVector == null) {
            this.valueVector = r.newInstance(abstractC0329q);
            this.velocityVector = r.newInstance(abstractC0329q3);
            int i2 = this.timestamps.f3020b;
            float[] fArr2 = new float[i2];
            for (int i3 = 0; i3 < i2; i3++) {
                fArr2[i3] = this.timestamps.b(i3) / 1000;
            }
            this.times = fArr2;
        }
        if (this.monoSpline != null && kotlin.jvm.internal.o.a(this.lastInitialValue, abstractC0329q) && kotlin.jvm.internal.o.a(this.lastTargetValue, abstractC0329q2)) {
            return;
        }
        boolean zA = kotlin.jvm.internal.o.a(this.lastInitialValue, abstractC0329q);
        boolean zA2 = kotlin.jvm.internal.o.a(this.lastTargetValue, abstractC0329q2);
        this.lastInitialValue = abstractC0329q;
        this.lastTargetValue = abstractC0329q2;
        int size$animation_core = abstractC0329q.getSize$animation_core();
        float[][] fArr3 = this.values;
        if (fArr3 == null) {
            int i4 = this.timestamps.f3020b;
            fArr3 = new float[i4][];
            for (int i5 = 0; i5 < i4; i5++) {
                int iB = this.timestamps.b(i5);
                U0.g gVar = (U0.g) this.keyframes.b(iB);
                if (iB == 0 && gVar == null) {
                    fArr = new float[size$animation_core];
                    for (int i6 = 0; i6 < size$animation_core; i6++) {
                        fArr[i6] = abstractC0329q.get$animation_core(i6);
                    }
                } else if (iB == getDurationMillis() && gVar == null) {
                    fArr = new float[size$animation_core];
                    for (int i7 = 0; i7 < size$animation_core; i7++) {
                        fArr[i7] = abstractC0329q2.get$animation_core(i7);
                    }
                } else {
                    kotlin.jvm.internal.o.b(gVar);
                    AbstractC0329q abstractC0329q4 = (AbstractC0329q) gVar.f1511b;
                    float[] fArr4 = new float[size$animation_core];
                    for (int i8 = 0; i8 < size$animation_core; i8++) {
                        fArr4[i8] = abstractC0329q4.get$animation_core(i8);
                    }
                    fArr = fArr4;
                }
                fArr3[i5] = fArr;
            }
            this.values = fArr3;
        } else {
            if (!zA && !this.keyframes.a(0)) {
                int iA = AbstractC1353k.a(this.timestamps, 0);
                float[] fArr5 = new float[size$animation_core];
                for (int i9 = 0; i9 < size$animation_core; i9++) {
                    fArr5[i9] = abstractC0329q.get$animation_core(i9);
                }
                fArr3[iA] = fArr5;
            }
            if (!zA2 && !this.keyframes.a(getDurationMillis())) {
                int iA2 = AbstractC1353k.a(this.timestamps, getDurationMillis());
                float[] fArr6 = new float[size$animation_core];
                for (int i10 = 0; i10 < size$animation_core; i10++) {
                    fArr6[i10] = abstractC0329q2.get$animation_core(i10);
                }
                fArr3[iA2] = fArr6;
            }
        }
        float[] fArr7 = this.times;
        if (fArr7 == null) {
            kotlin.jvm.internal.o.k("times");
            throw null;
        }
        this.monoSpline = new U(fArr7, fArr3, this.periodicBias);
    }

    @Override // androidx.compose.animation.core.I0
    public int getDelayMillis() {
        return this.delayMillis;
    }

    @Override // androidx.compose.animation.core.I0
    public int getDurationMillis() {
        return this.durationMillis;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        int iClampPlayTime = (int) G0.clampPlayTime(this, j2 / AbstractC0307f.MillisToNanos);
        U0.g gVar = (U0.g) this.keyframes.b(iClampPlayTime);
        if (gVar != null) {
            return (AbstractC0329q) gVar.f1511b;
        }
        if (iClampPlayTime >= getDurationMillis()) {
            return abstractC0329q2;
        }
        if (iClampPlayTime <= 0) {
            return abstractC0329q;
        }
        init(abstractC0329q, abstractC0329q2, abstractC0329q3);
        int iFindEntryForTimeMillis = findEntryForTimeMillis(iClampPlayTime);
        AbstractC0329q abstractC0329q4 = this.valueVector;
        kotlin.jvm.internal.o.b(abstractC0329q4);
        U u2 = this.monoSpline;
        kotlin.jvm.internal.o.b(u2);
        u2.getPos(getEasedTimeFromIndex(iFindEntryForTimeMillis, iClampPlayTime), abstractC0329q4, iFindEntryForTimeMillis);
        return abstractC0329q4;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        int iClampPlayTime = (int) G0.clampPlayTime(this, j2 / AbstractC0307f.MillisToNanos);
        init(abstractC0329q, abstractC0329q2, abstractC0329q3);
        int iFindEntryForTimeMillis = findEntryForTimeMillis(iClampPlayTime);
        AbstractC0329q abstractC0329q4 = this.velocityVector;
        kotlin.jvm.internal.o.b(abstractC0329q4);
        U u2 = this.monoSpline;
        kotlin.jvm.internal.o.b(u2);
        u2.getSlope(getEasedTimeFromIndex(iFindEntryForTimeMillis, iClampPlayTime), abstractC0329q4, iFindEntryForTimeMillis);
        return abstractC0329q4;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }
}
