package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface w0 {
    Object getInitialState();

    Object getTargetState();

    default boolean isTransitioningTo(Object obj, Object obj2) {
        return kotlin.jvm.internal.o.a(obj, getInitialState()) && kotlin.jvm.internal.o.a(obj2, getTargetState());
    }
}
