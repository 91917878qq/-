package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class K implements G {
    public static final int $stable = 0;
    private final int delay;
    private final long delayNanos;
    private final int duration;
    private final long durationNanos;
    private final C easing;

    public K() {
        this(0, 0, null, 7, null);
    }

    private final long clampPlayTimeNanos(long j2) {
        long j3 = j2 - this.delayNanos;
        long j4 = this.durationNanos;
        if (j3 < 0) {
            j3 = 0;
        }
        return j3 > j4 ? j4 : j3;
    }

    public final int getDelay() {
        return this.delay;
    }

    public final int getDuration() {
        return this.duration;
    }

    @Override // androidx.compose.animation.core.G
    public long getDurationNanos(float f2, float f3, float f4) {
        return this.delayNanos + this.durationNanos;
    }

    @Override // androidx.compose.animation.core.G
    public /* bridge */ /* synthetic */ float getEndVelocity(float f2, float f3, float f4) {
        return super.getEndVelocity(f2, f3, f4);
    }

    @Override // androidx.compose.animation.core.G
    public float getValueFromNanos(long j2, float f2, float f3, float f4) {
        long j3 = j2 - this.delayNanos;
        long j4 = this.durationNanos;
        if (j3 < 0) {
            j3 = 0;
        }
        if (j3 > j4) {
            j3 = j4;
        }
        float fTransform = this.easing.transform(this.duration == 0 ? 1.0f : j3 / j4);
        return (f3 * fTransform) + ((1 - fTransform) * f2);
    }

    @Override // androidx.compose.animation.core.G
    public float getVelocityFromNanos(long j2, float f2, float f3, float f4) {
        long j3 = j2 - this.delayNanos;
        long j4 = this.durationNanos;
        if (j3 < 0) {
            j3 = 0;
        }
        long j5 = j3 > j4 ? j4 : j3;
        if (j5 == 0) {
            return f4;
        }
        return (getValueFromNanos(j5, f2, f3, f4) - getValueFromNanos(j5 - AbstractC0307f.MillisToNanos, f2, f3, f4)) * 1000.0f;
    }

    @Override // androidx.compose.animation.core.G, androidx.compose.animation.core.InterfaceC0313i
    public /* bridge */ /* synthetic */ F0 vectorize(B0 b02) {
        return super.vectorize(b02);
    }

    public K(int i2, int i3, C c2) {
        this.duration = i2;
        this.delay = i3;
        this.easing = c2;
        this.durationNanos = ((long) i2) * AbstractC0307f.MillisToNanos;
        this.delayNanos = ((long) i3) * AbstractC0307f.MillisToNanos;
    }

    @Override // androidx.compose.animation.core.G, androidx.compose.animation.core.InterfaceC0313i
    public /* bridge */ /* synthetic */ K0 vectorize(B0 b02) {
        return super.vectorize(b02);
    }

    public /* synthetic */ K(int i2, int i3, C c2, int i4, AbstractC1378g abstractC1378g) {
        this((i4 & 1) != 0 ? 300 : i2, (i4 & 2) != 0 ? 0 : i3, (i4 & 4) != 0 ? E.getFastOutSlowInEasing() : c2);
    }
}
