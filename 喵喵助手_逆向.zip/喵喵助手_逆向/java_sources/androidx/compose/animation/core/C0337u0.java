package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.u0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0337u0 implements h1.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1657b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ v0 f1658c;

    public /* synthetic */ C0337u0(v0 v0Var, int i2) {
        this.f1657b = i2;
        this.f1658c = v0Var;
    }

    @Override // h1.a
    public final Object invoke() {
        switch (this.f1657b) {
            case 0:
                return Boolean.valueOf(v0.animateTo$lambda$13$lambda$12(this.f1658c));
            default:
                return Long.valueOf(this.f1658c.calculateTotalDurationNanos());
        }
    }
}
