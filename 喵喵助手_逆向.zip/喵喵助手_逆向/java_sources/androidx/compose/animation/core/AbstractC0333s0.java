package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.runtime.AbstractC0801u0;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.C1379h;

/* JADX INFO: renamed from: androidx.compose.animation.core.s0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0333s0 {

    /* JADX INFO: renamed from: androidx.compose.animation.core.s0$a */
    public static final class a extends a1.c {
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;
        /* synthetic */ Object result;

        public a(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return AbstractC0333s0.animate(null, null, 0L, null, this);
        }
    }

    public static final Object animate(float f2, float f3, float f4, InterfaceC0313i interfaceC0313i, h1.e eVar, Y0.c cVar) {
        Object objAnimate = animate(E0.getVectorConverter(C1379h.f3125a), new Float(f2), new Float(f3), new Float(f4), interfaceC0313i, eVar, cVar);
        return objAnimate == Z0.a.f1616b ? objAnimate : U0.n.f1521a;
    }

    public static /* synthetic */ Object animate$default(float f2, float f3, float f4, InterfaceC0313i interfaceC0313i, h1.e eVar, Y0.c cVar, int i2, Object obj) {
        float f5 = (i2 & 4) != 0 ? 0.0f : f4;
        if ((i2 & 8) != 0) {
            interfaceC0313i = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
        }
        return animate(f2, f3, f5, interfaceC0313i, eVar, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$11(kotlin.jvm.internal.E e2, float f2, InterfaceC0303d interfaceC0303d, C0317k c0317k, h1.c cVar, long j2) {
        Object obj = e2.f3118b;
        kotlin.jvm.internal.o.b(obj);
        doAnimationFrameWithScale((C0311h) obj, j2, f2, interfaceC0303d, c0317k, cVar);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$2(h1.e eVar, B0 b02, C0311h c0311h) {
        eVar.invoke(c0311h.getValue(), b02.getConvertFromVector().invoke(c0311h.getVelocityVector()));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$5(C0311h c0311h) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$8(kotlin.jvm.internal.E e2, Object obj, InterfaceC0303d interfaceC0303d, AbstractC0329q abstractC0329q, C0317k c0317k, float f2, h1.c cVar, long j2) {
        C0311h c0311h = new C0311h(obj, interfaceC0303d.getTypeConverter(), abstractC0329q, j2, interfaceC0303d.getTargetValue(), j2, true, new C0328p0(1, c0317k));
        doAnimationFrameWithScale(c0311h, j2, f2, interfaceC0303d, c0317k, cVar);
        e2.f3118b = c0311h;
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$8$lambda$6(C0317k c0317k) {
        c0317k.setRunning$animation_core(false);
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animate$lambda$9(C0317k c0317k) {
        c0317k.setRunning$animation_core(false);
        return U0.n.f1521a;
    }

    public static final Object animateDecay(float f2, float f3, H h2, h1.e eVar, Y0.c cVar) {
        Object objAnimate$default = animate$default(AbstractC0319l.AnimationState$default(f2, f3, 0L, 0L, false, 28, null), AbstractC0307f.DecayAnimation(h2, f2, f3), 0L, new C0331r0(0, eVar), cVar, 2, null);
        return objAnimate$default == Z0.a.f1616b ? objAnimate$default : U0.n.f1521a;
    }

    public static /* synthetic */ Object animateDecay$default(C0317k c0317k, InterfaceC0341y interfaceC0341y, boolean z2, h1.c cVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        if ((i2 & 4) != 0) {
            cVar = new O0.L0(12);
        }
        return animateDecay(c0317k, interfaceC0341y, z2, cVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateDecay$lambda$0(h1.e eVar, C0311h c0311h) {
        eVar.invoke(c0311h.getValue(), Float.valueOf(((C0321m) c0311h.getVelocityVector()).getValue()));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateDecay$lambda$4(C0311h c0311h) {
        return U0.n.f1521a;
    }

    public static final <T, V extends AbstractC0329q> Object animateTo(C0317k c0317k, T t2, InterfaceC0313i interfaceC0313i, boolean z2, h1.c cVar, Y0.c cVar2) {
        Object objAnimate = animate(c0317k, new C0335t0(interfaceC0313i, c0317k.getTypeConverter(), c0317k.getValue(), t2, c0317k.getVelocityVector()), z2 ? c0317k.getLastFrameTimeNanos() : Long.MIN_VALUE, cVar, cVar2);
        return objAnimate == Z0.a.f1616b ? objAnimate : U0.n.f1521a;
    }

    public static /* synthetic */ Object animateTo$default(C0317k c0317k, Object obj, InterfaceC0313i interfaceC0313i, boolean z2, h1.c cVar, Y0.c cVar2, int i2, Object obj2) {
        if ((i2 & 2) != 0) {
            interfaceC0313i = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i2 & 4) != 0) {
            z2 = false;
        }
        boolean z3 = z2;
        if ((i2 & 8) != 0) {
            cVar = new O0.L0(14);
        }
        return animateTo(c0317k, obj, interfaceC0313i2, z3, cVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateTo$lambda$3(C0311h c0311h) {
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <R, T, V extends AbstractC0329q> Object callWithFrameNanos(InterfaceC0303d interfaceC0303d, h1.c cVar, Y0.c cVar2) {
        return interfaceC0303d.isInfinite() ? L.withInfiniteAnimationFrameNanos(cVar, cVar2) : AbstractC0801u0.withFrameNanos(new O0.S(1, cVar), cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object callWithFrameNanos$lambda$12(h1.c cVar, long j2) {
        return cVar.invoke(Long.valueOf(j2));
    }

    private static final <T, V extends AbstractC0329q> void doAnimationFrame(C0311h c0311h, long j2, long j3, InterfaceC0303d interfaceC0303d, C0317k c0317k, h1.c cVar) {
        c0311h.setLastFrameTimeNanos$animation_core(j2);
        c0311h.setValue$animation_core(interfaceC0303d.getValueFromNanos(j3));
        c0311h.setVelocityVector$animation_core(interfaceC0303d.getVelocityVectorFromNanos(j3));
        if (interfaceC0303d.isFinishedFromNanos(j3)) {
            c0311h.setFinishedTimeNanos$animation_core(c0311h.getLastFrameTimeNanos());
            c0311h.setRunning$animation_core(false);
        }
        updateState(c0311h, c0317k);
        cVar.invoke(c0311h);
    }

    private static final <T, V extends AbstractC0329q> void doAnimationFrameWithScale(C0311h c0311h, long j2, float f2, InterfaceC0303d interfaceC0303d, C0317k c0317k, h1.c cVar) {
        doAnimationFrame(c0311h, j2, f2 == 0.0f ? interfaceC0303d.getDurationNanos() : (long) ((j2 - c0311h.getStartTimeNanos()) / f2), interfaceC0303d, c0317k, cVar);
    }

    public static final float getDurationScale(Y0.h hVar) {
        androidx.compose.ui.B b2 = (androidx.compose.ui.B) hVar.get(androidx.compose.ui.B.Key);
        float scaleFactor = b2 != null ? b2.getScaleFactor() : 1.0f;
        if (!(scaleFactor >= 0.0f)) {
            AbstractC0300b0.throwIllegalStateException("negative scale factor");
        }
        return scaleFactor;
    }

    public static final <T, V extends AbstractC0329q> void updateState(C0311h c0311h, C0317k c0317k) {
        c0317k.setValue$animation_core(c0311h.getValue());
        r.copyFrom(c0317k.getVelocityVector(), c0311h.getVelocityVector());
        c0317k.setFinishedTimeNanos$animation_core(c0311h.getFinishedTimeNanos());
        c0317k.setLastFrameTimeNanos$animation_core(c0311h.getLastFrameTimeNanos());
        c0317k.setRunning$animation_core(c0311h.isRunning());
    }

    public static final <T, V extends AbstractC0329q> Object animateDecay(C0317k c0317k, InterfaceC0341y interfaceC0341y, boolean z2, h1.c cVar, Y0.c cVar2) {
        Object objAnimate = animate(c0317k, new C0340x(interfaceC0341y, c0317k.getTypeConverter(), c0317k.getValue(), c0317k.getVelocityVector()), z2 ? c0317k.getLastFrameTimeNanos() : Long.MIN_VALUE, cVar, cVar2);
        return objAnimate == Z0.a.f1616b ? objAnimate : U0.n.f1521a;
    }

    public static final <T, V extends AbstractC0329q> Object animate(B0 b02, T t2, T t3, T t4, InterfaceC0313i interfaceC0313i, h1.e eVar, Y0.c cVar) {
        AbstractC0329q abstractC0329qNewInstance;
        if (t4 == null || (abstractC0329qNewInstance = (AbstractC0329q) b02.getConvertToVector().invoke(t4)) == null) {
            abstractC0329qNewInstance = r.newInstance((AbstractC0329q) b02.getConvertToVector().invoke(t2));
        }
        Object objAnimate$default = animate$default(new C0317k(b02, t2, abstractC0329qNewInstance, 0L, 0L, false, 56, null), new C0335t0(interfaceC0313i, b02, t2, t3, abstractC0329qNewInstance), 0L, new M0.m(6, eVar, b02), cVar, 2, null);
        return objAnimate$default == Z0.a.f1616b ? objAnimate$default : U0.n.f1521a;
    }

    public static /* synthetic */ Object animate$default(C0317k c0317k, InterfaceC0303d interfaceC0303d, long j2, h1.c cVar, Y0.c cVar2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            j2 = Long.MIN_VALUE;
        }
        long j3 = j2;
        if ((i2 & 4) != 0) {
            cVar = new O0.L0(13);
        }
        return animate(c0317k, interfaceC0303d, j3, cVar, cVar2);
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final <T, V extends AbstractC0329q> Object animate(final C0317k c0317k, final InterfaceC0303d interfaceC0303d, long j2, final h1.c cVar, Y0.c cVar2) {
        a aVar;
        kotlin.jvm.internal.E e2;
        h1.c cVar3;
        C0317k c0317k2;
        C0311h c0311h;
        C0311h c0311h2;
        h1.c cVar4;
        C0317k c0317k3 = c0317k;
        InterfaceC0303d interfaceC0303d2 = interfaceC0303d;
        if (cVar2 instanceof a) {
            aVar = (a) cVar2;
            int i2 = aVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                aVar.label = i2 - Integer.MIN_VALUE;
            } else {
                aVar = new a(cVar2);
            }
        }
        a aVar2 = aVar;
        Object obj = aVar2.result;
        Z0.a aVar3 = Z0.a.f1616b;
        int i3 = aVar2.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            final Object valueFromNanos = interfaceC0303d2.getValueFromNanos(0L);
            final AbstractC0329q velocityVectorFromNanos = interfaceC0303d2.getVelocityVectorFromNanos(0L);
            final kotlin.jvm.internal.E e3 = new kotlin.jvm.internal.E();
            try {
                if (j2 == Long.MIN_VALUE) {
                    final float durationScale = getDurationScale(aVar2.getContext());
                    h1.c cVar5 = new h1.c() { // from class: androidx.compose.animation.core.o0
                        @Override // h1.c
                        public final Object invoke(Object obj2) {
                            long jLongValue = ((Long) obj2).longValue();
                            return AbstractC0333s0.animate$lambda$8(e3, valueFromNanos, interfaceC0303d, velocityVectorFromNanos, c0317k, durationScale, cVar, jLongValue);
                        }
                    };
                    aVar2.L$0 = c0317k3;
                    aVar2.L$1 = interfaceC0303d2;
                    cVar3 = cVar;
                    aVar2.L$2 = cVar3;
                    aVar2.L$3 = e3;
                    aVar2.label = 1;
                    if (callWithFrameNanos(interfaceC0303d2, cVar5, aVar2) == aVar3) {
                        return aVar3;
                    }
                } else {
                    cVar3 = cVar;
                    try {
                        C0311h c0311h3 = new C0311h(valueFromNanos, interfaceC0303d.getTypeConverter(), velocityVectorFromNanos, j2, interfaceC0303d.getTargetValue(), j2, true, new C0328p0(0, c0317k3));
                        e3 = e3;
                        doAnimationFrameWithScale(c0311h3, j2, getDurationScale(aVar2.getContext()), interfaceC0303d, c0317k, cVar);
                        e3.f3118b = c0311h3;
                    } catch (CancellationException e4) {
                        e = e4;
                        e3 = e3;
                        e2 = e3;
                        c0311h = (C0311h) e2.f3118b;
                        if (c0311h != null) {
                            c0311h.setRunning$animation_core(false);
                        }
                        c0311h2 = (C0311h) e2.f3118b;
                        if (c0311h2 != null && c0311h2.getLastFrameTimeNanos() == c0317k3.getLastFrameTimeNanos()) {
                            c0317k3.setRunning$animation_core(false);
                        }
                        throw e;
                    }
                }
                c0317k2 = c0317k3;
                e2 = e3;
            } catch (CancellationException e5) {
                e = e5;
            }
        } else {
            if (i3 != 1 && i3 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            e2 = (kotlin.jvm.internal.E) aVar2.L$3;
            h1.c cVar6 = (h1.c) aVar2.L$2;
            InterfaceC0303d interfaceC0303d3 = (InterfaceC0303d) aVar2.L$1;
            c0317k2 = (C0317k) aVar2.L$0;
            try {
                AbstractC0292a.H(obj);
                cVar3 = cVar6;
                interfaceC0303d2 = interfaceC0303d3;
            } catch (CancellationException e6) {
                e = e6;
                c0317k3 = c0317k2;
                c0311h = (C0311h) e2.f3118b;
                if (c0311h != null) {
                }
                c0311h2 = (C0311h) e2.f3118b;
                if (c0311h2 != null) {
                    c0317k3.setRunning$animation_core(false);
                }
                throw e;
            }
        }
        do {
            Object obj2 = e2.f3118b;
            kotlin.jvm.internal.o.b(obj2);
            if (((C0311h) obj2).isRunning()) {
                final float durationScale2 = getDurationScale(aVar2.getContext());
                final kotlin.jvm.internal.E e7 = e2;
                final InterfaceC0303d interfaceC0303d4 = interfaceC0303d2;
                final C0317k c0317k4 = c0317k2;
                final h1.c cVar7 = cVar3;
                cVar4 = new h1.c() { // from class: androidx.compose.animation.core.q0
                    @Override // h1.c
                    public final Object invoke(Object obj3) {
                        long jLongValue = ((Long) obj3).longValue();
                        return AbstractC0333s0.animate$lambda$11(e7, durationScale2, interfaceC0303d4, c0317k4, cVar7, jLongValue);
                    }
                };
                aVar2.L$0 = c0317k2;
                aVar2.L$1 = interfaceC0303d2;
                aVar2.L$2 = cVar3;
                aVar2.L$3 = e2;
                aVar2.label = 2;
            } else {
                return U0.n.f1521a;
            }
        } while (callWithFrameNanos(interfaceC0303d2, cVar4, aVar2) != aVar3);
        return aVar3;
    }
}
