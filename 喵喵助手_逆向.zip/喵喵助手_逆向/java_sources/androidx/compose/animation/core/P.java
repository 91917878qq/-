package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class P {
    public static final int $stable = 8;
    private C easing;
    private final Object value;

    public /* synthetic */ P(Object obj, C c2, AbstractC1378g abstractC1378g) {
        this(obj, c2);
    }

    public final C getEasing$animation_core() {
        return this.easing;
    }

    public final Object getValue$animation_core() {
        return this.value;
    }

    public final void setEasing$animation_core(C c2) {
        this.easing = c2;
    }

    public final <V extends AbstractC0329q> U0.g toPair$animation_core(h1.c cVar) {
        return new U0.g(cVar.invoke(this.value), this.easing);
    }

    private P(Object obj, C c2) {
        this.value = obj;
        this.easing = c2;
    }
}
