package androidx.compose.animation.core;

import j.AbstractC1356n;
import j.C1332C;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class S {
    public static final int $stable = 8;
    private int delayMillis;
    private int durationMillis;
    private final C1332C keyframes;

    public /* synthetic */ S(AbstractC1378g abstractC1378g) {
        this();
    }

    public P at(Object obj, int i2) {
        P pCreateEntityFor$animation_core = createEntityFor$animation_core(obj);
        this.keyframes.i(i2, pCreateEntityFor$animation_core);
        return pCreateEntityFor$animation_core;
    }

    public P atFraction(Object obj, float f2) {
        return at(obj, Math.round(this.durationMillis * f2));
    }

    public abstract P createEntityFor$animation_core(Object obj);

    public final int getDelayMillis() {
        return this.delayMillis;
    }

    public final int getDurationMillis() {
        return this.durationMillis;
    }

    public final C1332C getKeyframes$animation_core() {
        return this.keyframes;
    }

    public final void setDelayMillis(int i2) {
        this.delayMillis = i2;
    }

    public final void setDurationMillis(int i2) {
        this.durationMillis = i2;
    }

    public final P using(P p2, C c2) {
        p2.setEasing$animation_core(c2);
        return p2;
    }

    private S() {
        this.durationMillis = 300;
        C1332C c1332c = AbstractC1356n.f3046a;
        this.keyframes = new C1332C();
    }
}
