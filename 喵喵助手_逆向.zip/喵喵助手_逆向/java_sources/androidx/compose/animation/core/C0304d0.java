package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.d0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0304d0 implements F {
    public static final int $stable = 0;
    private final B animation;
    private final long initialStartOffset;
    private final int iterations;
    private final EnumC0302c0 repeatMode;

    public /* synthetic */ C0304d0(int i2, B b2, EnumC0302c0 enumC0302c0, long j2, AbstractC1378g abstractC1378g) {
        this(i2, b2, enumC0302c0, j2);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0304d0)) {
            return false;
        }
        C0304d0 c0304d0 = (C0304d0) obj;
        return c0304d0.iterations == this.iterations && kotlin.jvm.internal.o.a(c0304d0.animation, this.animation) && c0304d0.repeatMode == this.repeatMode && C0322m0.m618equalsimpl0(c0304d0.initialStartOffset, this.initialStartOffset);
    }

    public final B getAnimation() {
        return this.animation;
    }

    /* JADX INFO: renamed from: getInitialStartOffset-Rmkjzm4, reason: not valid java name */
    public final long m607getInitialStartOffsetRmkjzm4() {
        return this.initialStartOffset;
    }

    public final int getIterations() {
        return this.iterations;
    }

    public final EnumC0302c0 getRepeatMode() {
        return this.repeatMode;
    }

    public int hashCode() {
        return C0322m0.m621hashCodeimpl(this.initialStartOffset) + ((this.repeatMode.hashCode() + ((this.animation.hashCode() + (this.iterations * 31)) * 31)) * 31);
    }

    private C0304d0(int i2, B b2, EnumC0302c0 enumC0302c0, long j2) {
        this.iterations = i2;
        this.animation = b2;
        this.repeatMode = enumC0302c0;
        this.initialStartOffset = j2;
    }

    @Override // androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> J0 vectorize(B0 b02) {
        return new Q0(this.iterations, this.animation.vectorize(b02), this.repeatMode, this.initialStartOffset, (AbstractC1378g) null);
    }

    public /* synthetic */ C0304d0(int i2, B b2, EnumC0302c0 enumC0302c0, long j2, int i3, AbstractC1378g abstractC1378g) {
        this(i2, b2, (i3 & 4) != 0 ? EnumC0302c0.Restart : enumC0302c0, (i3 & 8) != 0 ? C0322m0.m616constructorimpl$default(0, 0, 2, null) : j2, (AbstractC1378g) null);
    }

    public /* synthetic */ C0304d0(int i2, B b2, EnumC0302c0 enumC0302c0, int i3, AbstractC1378g abstractC1378g) {
        this(i2, b2, (i3 & 4) != 0 ? EnumC0302c0.Restart : enumC0302c0);
    }

    @U0.a
    public /* synthetic */ C0304d0(int i2, B b2, EnumC0302c0 enumC0302c0) {
        this(i2, b2, enumC0302c0, C0322m0.m616constructorimpl$default(0, 0, 2, null), (AbstractC1378g) null);
    }
}
