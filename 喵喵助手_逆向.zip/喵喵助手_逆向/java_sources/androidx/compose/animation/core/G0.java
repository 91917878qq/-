package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public abstract class G0 {
    private static final int[] EmptyIntArray = new int[0];
    private static final float[] EmptyFloatArray = new float[0];
    private static final C0336u EmptyArcSpline = new C0336u(new int[2], new float[2], new float[][]{new float[2], new float[2]});

    public static final class a implements InterfaceC0332s {
        private final J[] anims;

        /* JADX WARN: Incorrect types in method signature: (TV;FF)V */
        public a(AbstractC0329q abstractC0329q, float f2, float f3) {
            int size$animation_core = abstractC0329q.getSize$animation_core();
            J[] jArr = new J[size$animation_core];
            for (int i2 = 0; i2 < size$animation_core; i2++) {
                jArr[i2] = new J(f2, f3, abstractC0329q.get$animation_core(i2));
            }
            this.anims = jArr;
        }

        @Override // androidx.compose.animation.core.InterfaceC0332s
        public J get(int i2) {
            return this.anims[i2];
        }
    }

    public static final class b implements InterfaceC0332s {
        private final J anim;

        public b(float f2, float f3) {
            this.anim = new J(f2, f3, 0.0f, 4, null);
        }

        @Override // androidx.compose.animation.core.InterfaceC0332s
        public J get(int i2) {
            return this.anim;
        }
    }

    public static final long clampPlayTime(I0 i02, long j2) {
        long delayMillis = j2 - ((long) i02.getDelayMillis());
        long durationMillis = i02.getDurationMillis();
        if (delayMillis < 0) {
            delayMillis = 0;
        }
        return delayMillis > durationMillis ? durationMillis : delayMillis;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <V extends AbstractC0329q> InterfaceC0332s createSpringAnimations(V v2, float f2, float f3) {
        return v2 != null ? new a(v2, f2, f3) : new b(f2, f3);
    }

    public static final <V extends AbstractC0329q> long getDurationMillis(F0 f02, V v2, V v3, V v4) {
        return f02.getDurationNanos(v2, v3, v4) / AbstractC0307f.MillisToNanos;
    }

    public static final <V extends AbstractC0329q> V getValueFromMillis(F0 f02, long j2, V v2, V v3, V v4) {
        return (V) f02.getValueFromNanos(j2 * AbstractC0307f.MillisToNanos, v2, v3, v4);
    }
}
