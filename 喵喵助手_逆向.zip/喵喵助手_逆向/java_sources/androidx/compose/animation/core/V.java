package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public abstract class V {
    private static final boolean MonoSplineIsExtrapolate = true;

    public static final float hermiteDifferential(float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = f3 * f3;
        float f9 = 2;
        return (((((f6 + f7) * 3) * f8) + (f6 - (((f9 * f6) + f7) * (f9 * f3)))) * f2) - ((f4 - f5) * ((f3 - f8) * 6));
    }

    public static final float hermiteInterpolate(float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = f3 * f3;
        float f9 = f8 * f3;
        float f10 = 2;
        return ((((f9 - f8) * (f2 * f7)) + (((f3 - (f10 * f8)) + f9) * (f6 * f2))) + f4) - ((f4 - f5) * ((3 * f8) - (f10 * f9)));
    }
}
