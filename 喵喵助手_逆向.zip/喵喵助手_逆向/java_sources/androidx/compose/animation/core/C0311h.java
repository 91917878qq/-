package androidx.compose.animation.core;

import androidx.compose.runtime.V1;

/* JADX INFO: renamed from: androidx.compose.animation.core.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0311h {
    public static final int $stable = 8;
    private long finishedTimeNanos = Long.MIN_VALUE;
    private final androidx.compose.runtime.B0 isRunning$delegate;
    private long lastFrameTimeNanos;
    private final h1.a onCancel;
    private final long startTimeNanos;
    private final Object targetValue;
    private final B0 typeConverter;
    private final androidx.compose.runtime.B0 value$delegate;
    private AbstractC0329q velocityVector;

    public C0311h(Object obj, B0 b02, AbstractC0329q abstractC0329q, long j2, Object obj2, long j3, boolean z2, h1.a aVar) {
        this.typeConverter = b02;
        this.targetValue = obj2;
        this.startTimeNanos = j3;
        this.onCancel = aVar;
        this.value$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.velocityVector = r.copy(abstractC0329q);
        this.lastFrameTimeNanos = j2;
        this.isRunning$delegate = V1.mutableStateOf$default(Boolean.valueOf(z2), null, 2, null);
    }

    public final void cancelAnimation() {
        setRunning$animation_core(false);
        this.onCancel.invoke();
    }

    public final long getFinishedTimeNanos() {
        return this.finishedTimeNanos;
    }

    public final long getLastFrameTimeNanos() {
        return this.lastFrameTimeNanos;
    }

    public final long getStartTimeNanos() {
        return this.startTimeNanos;
    }

    public final Object getTargetValue() {
        return this.targetValue;
    }

    public final B0 getTypeConverter() {
        return this.typeConverter;
    }

    public final Object getValue() {
        return this.value$delegate.getValue();
    }

    public final Object getVelocity() {
        return this.typeConverter.getConvertFromVector().invoke(this.velocityVector);
    }

    public final AbstractC0329q getVelocityVector() {
        return this.velocityVector;
    }

    public final boolean isRunning() {
        return ((Boolean) this.isRunning$delegate.getValue()).booleanValue();
    }

    public final void setFinishedTimeNanos$animation_core(long j2) {
        this.finishedTimeNanos = j2;
    }

    public final void setLastFrameTimeNanos$animation_core(long j2) {
        this.lastFrameTimeNanos = j2;
    }

    public final void setRunning$animation_core(boolean z2) {
        this.isRunning$delegate.setValue(Boolean.valueOf(z2));
    }

    public final void setValue$animation_core(Object obj) {
        this.value$delegate.setValue(obj);
    }

    public final void setVelocityVector$animation_core(AbstractC0329q abstractC0329q) {
        this.velocityVector = abstractC0329q;
    }

    public final C0317k toAnimationState() {
        return new C0317k(this.typeConverter, getValue(), this.velocityVector, this.lastFrameTimeNanos, this.finishedTimeNanos, isRunning());
    }
}
