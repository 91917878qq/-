package androidx.compose.animation.core;

import androidx.compose.runtime.AbstractC0801u0;
import androidx.compose.ui.platform.InterfaceC1038c1;

/* JADX INFO: loaded from: classes.dex */
public abstract class L {

    public static final class a implements h1.c {
        final /* synthetic */ h1.c $onFrame;

        public a(h1.c cVar) {
            this.$onFrame = cVar;
        }

        /* JADX WARN: Type inference failed for: r4v3, types: [R, java.lang.Object] */
        public final R invoke(long j2) {
            return this.$onFrame.invoke(Long.valueOf(j2 / AbstractC0307f.MillisToNanos));
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).longValue());
        }
    }

    public static final <R> Object withInfiniteAnimationFrameMillis(h1.c cVar, Y0.c cVar2) {
        return withInfiniteAnimationFrameNanos(new a(cVar), cVar2);
    }

    public static final <R> Object withInfiniteAnimationFrameNanos(h1.c cVar, Y0.c cVar2) {
        if (cVar2.getContext().get(InterfaceC1038c1.Key) == null) {
            return AbstractC0801u0.withFrameNanos(cVar, cVar2);
        }
        throw new ClassCastException();
    }
}
