package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.j0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0316j0 implements F {
    public static final int $stable = 0;
    private final float dampingRatio;
    private final float stiffness;
    private final Object visibilityThreshold;

    public C0316j0() {
        this(0.0f, 0.0f, null, 7, null);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0316j0)) {
            return false;
        }
        C0316j0 c0316j0 = (C0316j0) obj;
        return c0316j0.dampingRatio == this.dampingRatio && c0316j0.stiffness == this.stiffness && kotlin.jvm.internal.o.a(c0316j0.visibilityThreshold, this.visibilityThreshold);
    }

    public final float getDampingRatio() {
        return this.dampingRatio;
    }

    public final float getStiffness() {
        return this.stiffness;
    }

    public final Object getVisibilityThreshold() {
        return this.visibilityThreshold;
    }

    public int hashCode() {
        Object obj = this.visibilityThreshold;
        return Float.hashCode(this.stiffness) + D0.d.a(this.dampingRatio, (obj != null ? obj.hashCode() : 0) * 31, 31);
    }

    public C0316j0(float f2, float f3, Object obj) {
        this.dampingRatio = f2;
        this.stiffness = f3;
        this.visibilityThreshold = obj;
    }

    @Override // androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> S0 vectorize(B0 b02) {
        return new S0(this.dampingRatio, this.stiffness, AbstractC0315j.convert(b02, this.visibilityThreshold));
    }

    public /* synthetic */ C0316j0(float f2, float f3, Object obj, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? 1.0f : f2, (i2 & 2) != 0 ? 1500.0f : f3, (i2 & 4) != 0 ? null : obj);
    }
}
