package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final class U {
    public static final int $stable = 8;
    private final float[] slopeTemp;
    private final float[][] tangents;
    private final float[] timePoints;
    private final float[][] values;

    public U(float[] fArr, float[][] fArr2, float f2) {
        int i2;
        int length = fArr.length;
        int i3 = 0;
        int length2 = fArr2[0].length;
        this.slopeTemp = new float[length2];
        int i4 = length - 1;
        float[][] fArrMakeFloatArray = makeFloatArray(i4, length2);
        float[][] fArrMakeFloatArray2 = makeFloatArray(length, length2);
        for (int i5 = 0; i5 < length2; i5++) {
            int i6 = 0;
            while (i6 < i4) {
                int i7 = i6 + 1;
                float f3 = fArr[i7] - fArr[i6];
                float[] fArr3 = fArrMakeFloatArray[i6];
                float f4 = (fArr2[i7][i5] - fArr2[i6][i5]) / f3;
                fArr3[i5] = f4;
                if (i6 == 0) {
                    fArrMakeFloatArray2[i6][i5] = f4;
                } else {
                    fArrMakeFloatArray2[i6][i5] = (fArrMakeFloatArray[i6 - 1][i5] + f4) * 0.5f;
                }
                i6 = i7;
            }
            fArrMakeFloatArray2[i4][i5] = fArrMakeFloatArray[length - 2][i5];
        }
        if (!Float.isNaN(f2)) {
            for (int i8 = 0; i8 < length2; i8++) {
                float[] fArr4 = fArrMakeFloatArray[length - 2];
                float f5 = (1 - f2) * fArr4[i8];
                float[] fArr5 = fArrMakeFloatArray[0];
                float f6 = (fArr5[i8] * f2) + f5;
                fArr5[i8] = f6;
                fArr4[i8] = f6;
                fArrMakeFloatArray2[i4][i8] = f6;
                fArrMakeFloatArray2[0][i8] = f6;
            }
        }
        int i9 = 0;
        while (i9 < i4) {
            int i10 = i3;
            while (i10 < length2) {
                float f7 = fArrMakeFloatArray[i9][i10];
                if (f7 == 0.0f) {
                    fArrMakeFloatArray2[i9][i10] = 0.0f;
                    fArrMakeFloatArray2[i9 + 1][i10] = 0.0f;
                    i2 = length2;
                } else {
                    float f8 = fArrMakeFloatArray2[i9][i10] / f7;
                    int i11 = i9 + 1;
                    float f9 = fArrMakeFloatArray2[i11][i10] / f7;
                    i2 = length2;
                    float fHypot = (float) Math.hypot(f8, f9);
                    if (fHypot > 9.0d) {
                        float f10 = 3.0f / fHypot;
                        float[] fArr6 = fArrMakeFloatArray2[i9];
                        float[] fArr7 = fArrMakeFloatArray[i9];
                        fArr6[i10] = f8 * f10 * fArr7[i10];
                        fArrMakeFloatArray2[i11][i10] = f10 * f9 * fArr7[i10];
                    }
                }
                i10++;
                length2 = i2;
            }
            i9++;
            i3 = 0;
        }
        this.timePoints = fArr;
        this.values = fArr2;
        this.tangents = fArrMakeFloatArray2;
    }

    public static /* synthetic */ void getPos$default(U u2, float f2, AbstractC0329q abstractC0329q, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        u2.getPos(f2, abstractC0329q, i2);
    }

    private final void getSlope(float f2, float[] fArr) {
        int length = this.values[0].length;
        float[] fArr2 = this.timePoints;
        int length2 = fArr2.length;
        float f3 = fArr2[0];
        int i2 = length2 - 1;
        float f4 = fArr2[i2];
        if (f2 < f3) {
            f2 = f3;
        }
        if (f2 <= f4) {
            f4 = f2;
        }
        if (fArr.length < length) {
            return;
        }
        int i3 = 0;
        while (i3 < i2) {
            float[] fArr3 = this.timePoints;
            int i4 = i3 + 1;
            float f5 = fArr3[i4];
            if (f4 <= f5) {
                float f6 = fArr3[i3];
                float f7 = f5 - f6;
                float f8 = (f4 - f6) / f7;
                for (int i5 = 0; i5 < length; i5++) {
                    float[][] fArr4 = this.values;
                    float f9 = fArr4[i3][i5];
                    float f10 = fArr4[i4][i5];
                    float[][] fArr5 = this.tangents;
                    fArr[i5] = V.hermiteDifferential(f7, f8, f9, f10, fArr5[i3][i5], fArr5[i4][i5]) / f7;
                }
                return;
            }
            i3 = i4;
        }
    }

    public static /* synthetic */ void getSlope$default(U u2, float f2, AbstractC0329q abstractC0329q, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        u2.getSlope(f2, abstractC0329q, i2);
    }

    private final float[][] makeFloatArray(int i2, int i3) {
        float[][] fArr = new float[i2][];
        for (int i4 = 0; i4 < i2; i4++) {
            fArr[i4] = new float[i3];
        }
        return fArr;
    }

    public final float getPos(float f2, int i2) {
        int i3;
        float[][] fArr = this.values;
        float[][] fArr2 = this.tangents;
        float[] fArr3 = this.timePoints;
        int length = fArr3.length;
        int i4 = 0;
        if (f2 <= fArr3[0]) {
            i3 = 0;
        } else {
            i3 = length - 1;
            if (f2 < fArr3[i3]) {
                i3 = -1;
            }
        }
        if (i3 != -1) {
            float f3 = fArr[i3][i2];
            float f4 = fArr3[i3];
            return ((f2 - f4) * getSlope(f4, i2)) + f3;
        }
        int i5 = length - 1;
        while (i4 < i5) {
            float[] fArr4 = this.timePoints;
            float f5 = fArr4[i4];
            if (f2 == f5) {
                return fArr[i4][i2];
            }
            int i6 = i4 + 1;
            float f6 = fArr4[i6];
            if (f2 < f6) {
                float f7 = f6 - f5;
                return V.hermiteInterpolate(f7, (f2 - f5) / f7, fArr[i4][i2], fArr[i6][i2], fArr2[i4][i2], fArr2[i6][i2]);
            }
            i4 = i6;
        }
        return 0.0f;
    }

    public final void getSlope(float f2, AbstractC0329q abstractC0329q, int i2) {
        int i3;
        float[] fArr = this.timePoints;
        float[][] fArr2 = this.values;
        float[][] fArr3 = this.tangents;
        int length = fArr.length;
        int i4 = 0;
        int length2 = fArr2[0].length;
        if (f2 <= fArr[0]) {
            i3 = 0;
        } else {
            i3 = length - 1;
            if (f2 < fArr[i3]) {
                i3 = -1;
            }
        }
        if (i3 != -1) {
            float[] fArr4 = fArr3[i3];
            if (fArr4.length < length2) {
                return;
            }
            while (i4 < length2) {
                abstractC0329q.set$animation_core(i4, fArr4[i4]);
                i4++;
            }
            return;
        }
        int i5 = length - 1;
        int i6 = i2;
        while (i6 < i5) {
            int i7 = i6 + 1;
            float f3 = fArr[i7];
            if (f2 <= f3) {
                float f4 = fArr[i6];
                float f5 = f3 - f4;
                float f6 = (f2 - f4) / f5;
                while (i4 < length2) {
                    abstractC0329q.set$animation_core(i4, V.hermiteDifferential(f5, f6, fArr2[i6][i4], fArr2[i7][i4], fArr3[i6][i4], fArr3[i7][i4]) / f5);
                    i4++;
                }
                return;
            }
            i6 = i7;
        }
    }

    public final void getPos(float f2, AbstractC0329q abstractC0329q, int i2) {
        int i3;
        float[] fArr = this.timePoints;
        int length = fArr.length;
        int i4 = 0;
        int length2 = this.values[0].length;
        if (f2 <= fArr[0]) {
            i3 = 0;
        } else {
            i3 = length - 1;
            if (f2 < fArr[i3]) {
                i3 = -1;
            }
        }
        if (i3 != -1) {
            getSlope(fArr[i3], this.slopeTemp);
            while (i4 < length2) {
                abstractC0329q.set$animation_core(i4, ((f2 - this.timePoints[i3]) * this.slopeTemp[i4]) + this.values[i3][i4]);
                i4++;
            }
            return;
        }
        int i5 = length - 1;
        int i6 = i2;
        while (i6 < i5) {
            float[] fArr2 = this.timePoints;
            float f3 = fArr2[i6];
            if (f2 == f3) {
                while (i4 < length2) {
                    abstractC0329q.set$animation_core(i4, this.values[i6][i4]);
                    i4++;
                }
                return;
            }
            int i7 = i6 + 1;
            float f4 = fArr2[i7];
            if (f2 < f4) {
                float f5 = f4 - f3;
                float f6 = (f2 - f3) / f5;
                while (i4 < length2) {
                    float[][] fArr3 = this.values;
                    float f7 = fArr3[i6][i4];
                    float f8 = fArr3[i7][i4];
                    float[][] fArr4 = this.tangents;
                    abstractC0329q.set$animation_core(i4, V.hermiteInterpolate(f5, f6, f7, f8, fArr4[i6][i4], fArr4[i7][i4]));
                    i4++;
                }
                return;
            }
            i6 = i7;
        }
    }

    private final float getSlope(float f2, int i2) {
        float[] fArr = this.timePoints;
        float[][] fArr2 = this.values;
        float[][] fArr3 = this.tangents;
        int length = fArr.length;
        int i3 = 0;
        float f3 = fArr[0];
        int i4 = length - 1;
        float f4 = fArr[i4];
        if (f2 < f3) {
            f2 = f3;
        }
        if (f2 <= f4) {
            f4 = f2;
        }
        while (i3 < i4) {
            int i5 = i3 + 1;
            float f5 = fArr[i5];
            if (f4 <= f5) {
                float f6 = fArr2[i3][i2];
                float f7 = fArr2[i5][i2];
                float f8 = fArr3[i3][i2];
                float f9 = fArr3[i5][i2];
                float f10 = fArr[i3];
                float f11 = f5 - f10;
                return V.hermiteDifferential(f11, (f4 - f10) / f11, f6, f7, f8, f9) / f11;
            }
            i3 = i5;
        }
        return 0.0f;
    }
}
