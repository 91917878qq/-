package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface G extends InterfaceC0313i {
    long getDurationNanos(float f2, float f3, float f4);

    default float getEndVelocity(float f2, float f3, float f4) {
        return getVelocityFromNanos(getDurationNanos(f2, f3, f4), f2, f3, f4);
    }

    float getValueFromNanos(long j2, float f2, float f3, float f4);

    float getVelocityFromNanos(long j2, float f2, float f3, float f4);

    @Override // androidx.compose.animation.core.InterfaceC0313i
    default <V extends AbstractC0329q> K0 vectorize(B0 b02) {
        return new K0(this);
    }
}
