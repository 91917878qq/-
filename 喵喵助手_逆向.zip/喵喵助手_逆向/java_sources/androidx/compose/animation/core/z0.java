package androidx.compose.animation.core;

import androidx.compose.runtime.V1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class z0 {
    public static final int $stable = 0;
    private final androidx.compose.runtime.B0 isRunning$delegate;

    public /* synthetic */ z0(AbstractC1378g abstractC1378g) {
        this();
    }

    public abstract Object getCurrentState();

    public abstract Object getTargetState();

    public final boolean isRunning$animation_core() {
        return ((Boolean) this.isRunning$delegate.getValue()).booleanValue();
    }

    public abstract void setCurrentState$animation_core(Object obj);

    public final void setRunning$animation_core(boolean z2) {
        this.isRunning$delegate.setValue(Boolean.valueOf(z2));
    }

    public abstract void setTargetState$animation_core(Object obj);

    public abstract void transitionConfigured$animation_core(v0 v0Var);

    public abstract void transitionRemoved$animation_core();

    private z0() {
        this.isRunning$delegate = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
    }
}
