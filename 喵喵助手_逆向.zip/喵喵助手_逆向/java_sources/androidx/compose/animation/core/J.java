package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class J implements G {
    public static final int $stable = 8;
    private final float dampingRatio;
    private final C0314i0 spring;
    private final float stiffness;
    private final float visibilityThreshold;

    public J() {
        this(0.0f, 0.0f, 0.0f, 7, null);
    }

    public final float getDampingRatio() {
        return this.dampingRatio;
    }

    @Override // androidx.compose.animation.core.G
    public long getDurationNanos(float f2, float f3, float f4) {
        float stiffness = this.spring.getStiffness();
        float dampingRatio = this.spring.getDampingRatio();
        float f5 = f2 - f3;
        float f6 = this.visibilityThreshold;
        return AbstractC0312h0.estimateAnimationDurationMillis(stiffness, dampingRatio, f4 / f6, f5 / f6, 1.0f) * AbstractC0307f.MillisToNanos;
    }

    @Override // androidx.compose.animation.core.G
    public float getEndVelocity(float f2, float f3, float f4) {
        return 0.0f;
    }

    public final float getStiffness() {
        return this.stiffness;
    }

    @Override // androidx.compose.animation.core.G
    public float getValueFromNanos(long j2, float f2, float f3, float f4) {
        long j3 = j2 / AbstractC0307f.MillisToNanos;
        this.spring.setFinalPosition(f3);
        return Float.intBitsToFloat((int) (this.spring.m608updateValuesIJZedt4$animation_core(f2, f4, j3) >> 32));
    }

    @Override // androidx.compose.animation.core.G
    public float getVelocityFromNanos(long j2, float f2, float f3, float f4) {
        long j3 = j2 / AbstractC0307f.MillisToNanos;
        this.spring.setFinalPosition(f3);
        return Float.intBitsToFloat((int) (this.spring.m608updateValuesIJZedt4$animation_core(f2, f4, j3) & 4294967295L));
    }

    @Override // androidx.compose.animation.core.G, androidx.compose.animation.core.InterfaceC0313i
    public /* bridge */ /* synthetic */ F0 vectorize(B0 b02) {
        return super.vectorize(b02);
    }

    public J(float f2, float f3, float f4) {
        this.dampingRatio = f2;
        this.stiffness = f3;
        this.visibilityThreshold = f4;
        C0314i0 c0314i0 = new C0314i0(1.0f);
        c0314i0.setDampingRatio(f2);
        c0314i0.setStiffness(f3);
        this.spring = c0314i0;
    }

    @Override // androidx.compose.animation.core.G, androidx.compose.animation.core.InterfaceC0313i
    public /* bridge */ /* synthetic */ K0 vectorize(B0 b02) {
        return super.vectorize(b02);
    }

    public /* synthetic */ J(float f2, float f3, float f4, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? 1.0f : f2, (i2 & 2) != 0 ? 1500.0f : f3, (i2 & 4) != 0 ? 0.01f : f4);
    }
}
