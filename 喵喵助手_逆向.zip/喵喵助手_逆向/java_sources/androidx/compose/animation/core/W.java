package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final class W {
    private final long packedValue;

    private /* synthetic */ W(long j2) {
        this.packedValue = j2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ W m588boximpl(long j2) {
        return new W(j2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    public static long m589constructorimpl(long j2) {
        return j2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m590equalsimpl(long j2, Object obj) {
        return (obj instanceof W) && j2 == ((W) obj).m596unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m591equalsimpl0(long j2, long j3) {
        return j2 == j3;
    }

    /* JADX INFO: renamed from: getValue-impl, reason: not valid java name */
    public static final float m592getValueimpl(long j2) {
        return Float.intBitsToFloat((int) (j2 >> 32));
    }

    /* JADX INFO: renamed from: getVelocity-impl, reason: not valid java name */
    public static final float m593getVelocityimpl(long j2) {
        return Float.intBitsToFloat((int) (j2 & 4294967295L));
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m594hashCodeimpl(long j2) {
        return Long.hashCode(j2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m595toStringimpl(long j2) {
        return "Motion(packedValue=" + j2 + ')';
    }

    public boolean equals(Object obj) {
        return m590equalsimpl(this.packedValue, obj);
    }

    public final long getPackedValue() {
        return this.packedValue;
    }

    public int hashCode() {
        return m594hashCodeimpl(this.packedValue);
    }

    public String toString() {
        return m595toStringimpl(this.packedValue);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ long m596unboximpl() {
        return this.packedValue;
    }
}
