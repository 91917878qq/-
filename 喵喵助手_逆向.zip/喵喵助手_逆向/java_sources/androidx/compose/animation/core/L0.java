package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final class L0 implements H0 {
    private final float absVelocityThreshold;
    private final H floatDecaySpec;
    private AbstractC0329q targetVector;
    private AbstractC0329q valueVector;
    private AbstractC0329q velocityVector;

    public L0(H h2) {
        this.floatDecaySpec = h2;
        this.absVelocityThreshold = h2.getAbsVelocityThreshold();
    }

    @Override // androidx.compose.animation.core.H0
    public float getAbsVelocityThreshold() {
        return this.absVelocityThreshold;
    }

    @Override // androidx.compose.animation.core.H0
    public long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2) {
        if (this.velocityVector == null) {
            this.velocityVector = r.newInstance(abstractC0329q);
        }
        AbstractC0329q abstractC0329q3 = this.velocityVector;
        if (abstractC0329q3 == null) {
            kotlin.jvm.internal.o.k("velocityVector");
            throw null;
        }
        int size$animation_core = abstractC0329q3.getSize$animation_core();
        long jMax = 0;
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            jMax = Math.max(jMax, this.floatDecaySpec.getDurationNanos(abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2)));
        }
        return jMax;
    }

    public final H getFloatDecaySpec() {
        return this.floatDecaySpec;
    }

    @Override // androidx.compose.animation.core.H0
    public AbstractC0329q getTargetValue(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2) {
        if (this.targetVector == null) {
            this.targetVector = r.newInstance(abstractC0329q);
        }
        AbstractC0329q abstractC0329q3 = this.targetVector;
        if (abstractC0329q3 == null) {
            kotlin.jvm.internal.o.k("targetVector");
            throw null;
        }
        int size$animation_core = abstractC0329q3.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q4 = this.targetVector;
            if (abstractC0329q4 == null) {
                kotlin.jvm.internal.o.k("targetVector");
                throw null;
            }
            abstractC0329q4.set$animation_core(i2, this.floatDecaySpec.getTargetValue(abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q5 = this.targetVector;
        if (abstractC0329q5 != null) {
            return abstractC0329q5;
        }
        kotlin.jvm.internal.o.k("targetVector");
        throw null;
    }

    @Override // androidx.compose.animation.core.H0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2) {
        if (this.valueVector == null) {
            this.valueVector = r.newInstance(abstractC0329q);
        }
        AbstractC0329q abstractC0329q3 = this.valueVector;
        if (abstractC0329q3 == null) {
            kotlin.jvm.internal.o.k("valueVector");
            throw null;
        }
        int size$animation_core = abstractC0329q3.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q4 = this.valueVector;
            if (abstractC0329q4 == null) {
                kotlin.jvm.internal.o.k("valueVector");
                throw null;
            }
            abstractC0329q4.set$animation_core(i2, this.floatDecaySpec.getValueFromNanos(j2, abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q5 = this.valueVector;
        if (abstractC0329q5 != null) {
            return abstractC0329q5;
        }
        kotlin.jvm.internal.o.k("valueVector");
        throw null;
    }

    @Override // androidx.compose.animation.core.H0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2) {
        if (this.velocityVector == null) {
            this.velocityVector = r.newInstance(abstractC0329q);
        }
        AbstractC0329q abstractC0329q3 = this.velocityVector;
        if (abstractC0329q3 == null) {
            kotlin.jvm.internal.o.k("velocityVector");
            throw null;
        }
        int size$animation_core = abstractC0329q3.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            AbstractC0329q abstractC0329q4 = this.velocityVector;
            if (abstractC0329q4 == null) {
                kotlin.jvm.internal.o.k("velocityVector");
                throw null;
            }
            abstractC0329q4.set$animation_core(i2, this.floatDecaySpec.getVelocityFromNanos(j2, abstractC0329q.get$animation_core(i2), abstractC0329q2.get$animation_core(i2)));
        }
        AbstractC0329q abstractC0329q5 = this.velocityVector;
        if (abstractC0329q5 != null) {
            return abstractC0329q5;
        }
        kotlin.jvm.internal.o.k("velocityVector");
        throw null;
    }
}
