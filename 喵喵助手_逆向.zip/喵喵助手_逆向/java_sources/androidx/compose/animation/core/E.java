package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public abstract class E {
    private static final float OneUlpAt1 = 1.1920929E-7f;
    private static final C FastOutSlowInEasing = new C0339w(0.4f, 0.0f, 0.2f, 1.0f);
    private static final C LinearOutSlowInEasing = new C0339w(0.0f, 0.0f, 0.2f, 1.0f);
    private static final C FastOutLinearInEasing = new C0339w(0.4f, 0.0f, 1.0f, 1.0f);
    private static final C LinearEasing = new R0.j(8);

    /* JADX INFO: Access modifiers changed from: private */
    public static final float LinearEasing$lambda$0(float f2) {
        return f2;
    }

    public static final C getFastOutLinearInEasing() {
        return FastOutLinearInEasing;
    }

    public static final C getFastOutSlowInEasing() {
        return FastOutSlowInEasing;
    }

    public static final C getLinearEasing() {
        return LinearEasing;
    }

    public static final C getLinearOutSlowInEasing() {
        return LinearOutSlowInEasing;
    }
}
