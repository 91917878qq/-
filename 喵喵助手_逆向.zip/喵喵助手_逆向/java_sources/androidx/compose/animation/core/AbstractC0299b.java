package androidx.compose.animation.core;

import kotlin.jvm.internal.C1379h;

/* JADX INFO: renamed from: androidx.compose.animation.core.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0299b {
    private static final C0321m positiveInfinityBounds1D = r.AnimationVector(Float.POSITIVE_INFINITY);
    private static final C0323n positiveInfinityBounds2D = r.AnimationVector(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
    private static final C0325o positiveInfinityBounds3D = r.AnimationVector(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
    private static final C0327p positiveInfinityBounds4D = r.AnimationVector(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
    private static final C0321m negativeInfinityBounds1D = r.AnimationVector(Float.NEGATIVE_INFINITY);
    private static final C0323n negativeInfinityBounds2D = r.AnimationVector(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
    private static final C0325o negativeInfinityBounds3D = r.AnimationVector(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
    private static final C0327p negativeInfinityBounds4D = r.AnimationVector(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);

    public static final C0297a Animatable(float f2, float f3) {
        return new C0297a(Float.valueOf(f2), E0.getVectorConverter(C1379h.f3125a), Float.valueOf(f3), null, 8, null);
    }

    public static /* synthetic */ C0297a Animatable$default(float f2, float f3, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            f3 = 0.01f;
        }
        return Animatable(f2, f3);
    }
}
