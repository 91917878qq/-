package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0329q {
    public static final int $stable = 0;

    public /* synthetic */ AbstractC0329q(AbstractC1378g abstractC1378g) {
        this();
    }

    public abstract float get$animation_core(int i2);

    public abstract int getSize$animation_core();

    public abstract AbstractC0329q newVector$animation_core();

    public abstract void reset$animation_core();

    public abstract void set$animation_core(int i2, float f2);

    private AbstractC0329q() {
    }
}
