package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0342z implements InterfaceC0341y {
    private final H floatDecaySpec;

    public C0342z(H h2) {
        this.floatDecaySpec = h2;
    }

    @Override // androidx.compose.animation.core.InterfaceC0341y
    public <V extends AbstractC0329q> H0 vectorize(B0 b02) {
        return new L0(this.floatDecaySpec);
    }
}
