package androidx.compose.animation.core;

import J.f;
import J.h;
import J.l;
import e0.C1311h;
import e0.j;
import e0.o;
import e0.s;
import kotlin.jvm.internal.C1379h;

/* JADX INFO: loaded from: classes.dex */
public abstract class E0 {
    private static final B0 FloatToVector = TwoWayConverter(new O0.L0(17), new D0(4));
    private static final B0 IntToVector = TwoWayConverter(new O0.L0(18), new O0.L0(19));
    private static final B0 DpToVector = TwoWayConverter(new O0.L0(20), new O0.L0(21));
    private static final B0 DpOffsetToVector = TwoWayConverter(new O0.L0(22), new O0.L0(23));
    private static final B0 SizeToVector = TwoWayConverter(new O0.L0(24), new O0.L0(25));
    private static final B0 OffsetToVector = TwoWayConverter(new O0.L0(26), new O0.L0(27));
    private static final B0 IntOffsetToVector = TwoWayConverter(new O0.L0(28), new O0.L0(29));
    private static final B0 IntSizeToVector = TwoWayConverter(new D0(0), new D0(1));
    private static final B0 RectToVector = TwoWayConverter(new D0(2), new D0(3));

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0323n DpOffsetToVector$lambda$6(e0.j jVar) {
        return new C0323n(e0.j.m5137getXD9Ej5fM(jVar.m5145unboximpl()), e0.j.m5139getYD9Ej5fM(jVar.m5145unboximpl()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final e0.j DpOffsetToVector$lambda$7(C0323n c0323n) {
        float fM5076constructorimpl = C1311h.m5076constructorimpl(c0323n.getV1());
        float fM5076constructorimpl2 = C1311h.m5076constructorimpl(c0323n.getV2());
        return e0.j.m5131boximpl(e0.j.m5132constructorimpl((((long) Float.floatToRawIntBits(fM5076constructorimpl)) << 32) | (((long) Float.floatToRawIntBits(fM5076constructorimpl2)) & 4294967295L)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0321m DpToVector$lambda$4(C1311h c1311h) {
        return new C0321m(c1311h.m5090unboximpl());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C1311h DpToVector$lambda$5(C0321m c0321m) {
        return C1311h.m5074boximpl(C1311h.m5076constructorimpl(c0321m.getValue()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0321m FloatToVector$lambda$0(float f2) {
        return new C0321m(f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0323n IntOffsetToVector$lambda$12(e0.o oVar) {
        return new C0323n(e0.o.m5196getXimpl(oVar.m5205unboximpl()), e0.o.m5197getYimpl(oVar.m5205unboximpl()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final e0.o IntOffsetToVector$lambda$13(C0323n c0323n) {
        return e0.o.m5187boximpl(e0.o.m5190constructorimpl((((long) Math.round(c0323n.getV1())) << 32) | (((long) Math.round(c0323n.getV2())) & 4294967295L)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0323n IntSizeToVector$lambda$14(e0.s sVar) {
        return new C0323n((int) (sVar.m5243unboximpl() >> 32), (int) (sVar.m5243unboximpl() & 4294967295L));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final e0.s IntSizeToVector$lambda$15(C0323n c0323n) {
        int iRound = Math.round(c0323n.getV1());
        if (iRound < 0) {
            iRound = 0;
        }
        int iRound2 = Math.round(c0323n.getV2());
        return e0.s.m5231boximpl(e0.s.m5234constructorimpl((((long) (iRound2 >= 0 ? iRound2 : 0)) & 4294967295L) | (((long) iRound) << 32)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0321m IntToVector$lambda$2(int i2) {
        return new C0321m(i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int IntToVector$lambda$3(C0321m c0321m) {
        return (int) c0321m.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0323n OffsetToVector$lambda$10(J.f fVar) {
        return new C0323n(Float.intBitsToFloat((int) (fVar.m60unboximpl() >> 32)), Float.intBitsToFloat((int) (fVar.m60unboximpl() & 4294967295L)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.f OffsetToVector$lambda$11(C0323n c0323n) {
        float v12 = c0323n.getV1();
        float v2 = c0323n.getV2();
        return J.f.m39boximpl(J.f.m42constructorimpl((((long) Float.floatToRawIntBits(v12)) << 32) | (((long) Float.floatToRawIntBits(v2)) & 4294967295L)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0327p RectToVector$lambda$16(J.h hVar) {
        return new C0327p(hVar.getLeft(), hVar.getTop(), hVar.getRight(), hVar.getBottom());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.h RectToVector$lambda$17(C0327p c0327p) {
        return new J.h(c0327p.getV1(), c0327p.getV2(), c0327p.getV3(), c0327p.getV4());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final C0323n SizeToVector$lambda$8(J.l lVar) {
        return new C0323n(Float.intBitsToFloat((int) (lVar.m124unboximpl() >> 32)), Float.intBitsToFloat((int) (lVar.m124unboximpl() & 4294967295L)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final J.l SizeToVector$lambda$9(C0323n c0323n) {
        float v12 = c0323n.getV1();
        float v2 = c0323n.getV2();
        return J.l.m107boximpl(J.l.m110constructorimpl((((long) Float.floatToRawIntBits(v12)) << 32) | (((long) Float.floatToRawIntBits(v2)) & 4294967295L)));
    }

    public static final <T, V extends AbstractC0329q> B0 TwoWayConverter(h1.c cVar, h1.c cVar2) {
        return new C0(cVar, cVar2);
    }

    public static final B0 getVectorConverter(C1379h c1379h) {
        return FloatToVector;
    }

    public static final float lerp(float f2, float f3, float f4) {
        return (f3 * f4) + ((1 - f4) * f2);
    }

    public static final B0 getVectorConverter(kotlin.jvm.internal.m mVar) {
        return IntToVector;
    }

    public static final B0 getVectorConverter(h.a aVar) {
        return RectToVector;
    }

    public static final B0 getVectorConverter(C1311h.a aVar) {
        return DpToVector;
    }

    public static final B0 getVectorConverter(j.a aVar) {
        return DpOffsetToVector;
    }

    public static final B0 getVectorConverter(l.a aVar) {
        return SizeToVector;
    }

    public static final B0 getVectorConverter(f.a aVar) {
        return OffsetToVector;
    }

    public static final B0 getVectorConverter(o.a aVar) {
        return IntOffsetToVector;
    }

    public static final B0 getVectorConverter(s.a aVar) {
        return IntSizeToVector;
    }
}
