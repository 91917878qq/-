package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.runtime.AbstractC0801u0;
import androidx.compose.runtime.InterfaceC0813y0;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.W0;
import j.C1342M;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.AbstractC1378g;
import kotlin.jvm.internal.C1379h;
import r1.AbstractC1476z;
import r1.C1459h;
import r1.InterfaceC1458g;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.animation.core.f0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0308f0 extends z0 {
    private final h1.c animateOneFrameLambda;
    private Object composedTargetState;
    private InterfaceC1458g compositionContinuation;
    private final z1.a compositionContinuationMutex;
    private b currentAnimation;
    private final androidx.compose.runtime.B0 currentState$delegate;
    private float durationScale;
    private final h1.c firstFrameLambda;
    private final InterfaceC0813y0 fraction$delegate;
    private final C1342M initialValueAnimations;
    private long lastFrameTimeNanos;
    private final C0298a0 mutatorMutex;
    private final h1.a recalculateTotalDurationNanos;
    private final androidx.compose.runtime.B0 targetState$delegate;
    private long totalDurationNanos;
    private v0 transition;
    private static final a Companion = new a(null);
    public static final int $stable = 8;
    private static final C0321m ZeroVelocity = new C0321m(0.0f);
    private static final C0321m Target1 = new C0321m(1.0f);

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$a */
    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final C0321m getTarget1() {
            return C0308f0.Target1;
        }

        public final C0321m getZeroVelocity() {
            return C0308f0.ZeroVelocity;
        }

        private a() {
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$b */
    public static final class b {
        public static final int $stable = 8;
        private F0 animationSpec;
        private long animationSpecDuration;
        private long durationNanos;
        private C0321m initialVelocity;
        private boolean isComplete;
        private long progressNanos;
        private C0321m start = new C0321m(0.0f);
        private float value;

        public final F0 getAnimationSpec() {
            return this.animationSpec;
        }

        public final long getAnimationSpecDuration() {
            return this.animationSpecDuration;
        }

        public final long getDurationNanos() {
            return this.durationNanos;
        }

        public final C0321m getInitialVelocity() {
            return this.initialVelocity;
        }

        public final long getProgressNanos() {
            return this.progressNanos;
        }

        public final C0321m getStart() {
            return this.start;
        }

        public final float getValue() {
            return this.value;
        }

        public final boolean isComplete() {
            return this.isComplete;
        }

        public final void setAnimationSpec(F0 f02) {
            this.animationSpec = f02;
        }

        public final void setAnimationSpecDuration(long j2) {
            this.animationSpecDuration = j2;
        }

        public final void setComplete(boolean z2) {
            this.isComplete = z2;
        }

        public final void setDurationNanos(long j2) {
            this.durationNanos = j2;
        }

        public final void setInitialVelocity(C0321m c0321m) {
            this.initialVelocity = c0321m;
        }

        public final void setProgressNanos(long j2) {
            this.progressNanos = j2;
        }

        public final void setStart(C0321m c0321m) {
            this.start = c0321m;
        }

        public final void setValue(float f2) {
            this.value = f2;
        }

        public String toString() {
            return "progress nanos: " + this.progressNanos + ", animationSpec: " + this.animationSpec + ", isComplete: " + this.isComplete + ", value: " + this.value + ", start: " + this.start + ", initialVelocity: " + this.initialVelocity + ", durationNanos: " + this.durationNanos + ", animationSpecDuration: " + this.animationSpecDuration;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$c */
    public static final class c extends a1.j implements h1.c {
        final /* synthetic */ F $animationSpec;
        final /* synthetic */ Object $targetState;
        final /* synthetic */ v0 $transition;
        int label;
        final /* synthetic */ C0308f0 this$0;

        /* JADX INFO: renamed from: androidx.compose.animation.core.f0$c$a */
        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ F $animationSpec;
            final /* synthetic */ Object $targetState;
            final /* synthetic */ v0 $transition;
            Object L$0;
            Object L$1;
            int label;
            final /* synthetic */ C0308f0 this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(C0308f0 c0308f0, Object obj, v0 v0Var, F f2, Y0.c cVar) {
                super(2, cVar);
                this.this$0 = c0308f0;
                this.$targetState = obj;
                this.$transition = v0Var;
                this.$animationSpec = f2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                return new a(this.this$0, this.$targetState, this.$transition, this.$animationSpec, cVar);
            }

            /* JADX WARN: Removed duplicated region for block: B:31:0x00b9 A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:34:0x00c8  */
            /* JADX WARN: Removed duplicated region for block: B:75:0x01e9 A[RETURN] */
            @Override // a1.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final Object invokeSuspend(Object obj) {
                C0308f0 c0308f0;
                z1.a aVar;
                C0308f0 c0308f02;
                C0321m zeroVelocity;
                C0308f0 c0308f03;
                Z0.a aVar2 = Z0.a.f1616b;
                int i2 = this.label;
                try {
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        Object targetState = this.this$0.getTargetState();
                        if (!kotlin.jvm.internal.o.a(this.$targetState, targetState)) {
                            this.this$0.moveAnimationToInitialState();
                            this.this$0.setFraction(0.0f);
                            this.$transition.updateTarget$animation_core(this.$targetState);
                            this.$transition.setPlayTimeNanos(0L);
                            this.this$0.setCurrentState$animation_core(targetState);
                            this.this$0.setTargetState$animation_core(this.$targetState);
                        }
                        z1.a compositionContinuationMutex$animation_core = this.this$0.getCompositionContinuationMutex$animation_core();
                        C0308f0 c0308f04 = this.this$0;
                        this.L$0 = compositionContinuationMutex$animation_core;
                        this.L$1 = c0308f04;
                        this.label = 1;
                        z1.d dVar = (z1.d) compositionContinuationMutex$animation_core;
                        if (dVar.d(null, this) == aVar2) {
                            return aVar2;
                        }
                        c0308f0 = c0308f04;
                        aVar = dVar;
                    } else {
                        if (i2 != 1) {
                            if (i2 == 2) {
                                AbstractC0292a.H(obj);
                                c0308f02 = this.this$0;
                                this.label = 3;
                                if (c0308f02.waitForCompositionAfterTargetStateChange(this) == aVar2) {
                                    return aVar2;
                                }
                                if (!kotlin.jvm.internal.o.a(this.this$0.getCurrentState(), this.$targetState)) {
                                }
                                return U0.n.f1521a;
                            }
                            if (i2 != 3) {
                                if (i2 != 4) {
                                    if (i2 != 5) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    AbstractC0292a.H(obj);
                                    this.this$0.setFraction(0.0f);
                                    return U0.n.f1521a;
                                }
                                AbstractC0292a.H(obj);
                                this.this$0.setCurrentState$animation_core(this.$targetState);
                                c0308f03 = this.this$0;
                                this.label = 5;
                                if (c0308f03.waitForComposition(this) == aVar2) {
                                    return aVar2;
                                }
                                this.this$0.setFraction(0.0f);
                                return U0.n.f1521a;
                            }
                            AbstractC0292a.H(obj);
                            if (!kotlin.jvm.internal.o.a(this.this$0.getCurrentState(), this.$targetState)) {
                                if (this.this$0.getFraction() < 1.0f) {
                                    b bVar = this.this$0.currentAnimation;
                                    F f2 = this.$animationSpec;
                                    J0 j0Vectorize = f2 != null ? f2.vectorize(E0.getVectorConverter(C1379h.f3125a)) : null;
                                    if (bVar == null || !kotlin.jvm.internal.o.a(j0Vectorize, bVar.getAnimationSpec())) {
                                        F0 animationSpec = bVar != null ? bVar.getAnimationSpec() : null;
                                        if (animationSpec != null) {
                                            long progressNanos = bVar.getProgressNanos();
                                            C0321m start = bVar.getStart();
                                            C0321m target1 = C0308f0.Companion.getTarget1();
                                            C0321m initialVelocity = bVar.getInitialVelocity();
                                            if (initialVelocity == null) {
                                                initialVelocity = C0308f0.Companion.getZeroVelocity();
                                            }
                                            zeroVelocity = (C0321m) animationSpec.getVelocityFromNanos(progressNanos, start, target1, initialVelocity);
                                        } else if (bVar == null || bVar.getProgressNanos() == 0) {
                                            zeroVelocity = C0308f0.Companion.getZeroVelocity();
                                        } else {
                                            long durationNanos = bVar.getDurationNanos();
                                            if (durationNanos == Long.MIN_VALUE) {
                                                durationNanos = this.this$0.getTotalDurationNanos$animation_core();
                                            }
                                            float f3 = durationNanos / 1.0E9f;
                                            zeroVelocity = f3 <= 0.0f ? C0308f0.Companion.getZeroVelocity() : new C0321m(1.0f / f3);
                                        }
                                        if (bVar == null) {
                                            bVar = new b();
                                        }
                                        bVar.setAnimationSpec(j0Vectorize);
                                        bVar.setComplete(false);
                                        bVar.setValue(this.this$0.getFraction());
                                        bVar.getStart().set$animation_core(0, this.this$0.getFraction());
                                        bVar.setDurationNanos(this.this$0.getTotalDurationNanos$animation_core());
                                        bVar.setProgressNanos(0L);
                                        bVar.setInitialVelocity(zeroVelocity);
                                        bVar.setAnimationSpecDuration(j0Vectorize != null ? j0Vectorize.getDurationNanos(bVar.getStart(), C0308f0.Companion.getTarget1(), zeroVelocity) : j1.a.U((1.0d - ((double) this.this$0.getFraction())) * this.this$0.getTotalDurationNanos$animation_core()));
                                        this.this$0.currentAnimation = bVar;
                                    }
                                }
                                C0308f0 c0308f05 = this.this$0;
                                this.L$0 = null;
                                this.L$1 = null;
                                this.label = 4;
                                if (c0308f05.runAnimations(this) == aVar2) {
                                    return aVar2;
                                }
                                this.this$0.setCurrentState$animation_core(this.$targetState);
                                c0308f03 = this.this$0;
                                this.label = 5;
                                if (c0308f03.waitForComposition(this) == aVar2) {
                                }
                                this.this$0.setFraction(0.0f);
                            }
                            return U0.n.f1521a;
                        }
                        c0308f0 = (C0308f0) this.L$1;
                        z1.a aVar3 = (z1.a) this.L$0;
                        AbstractC0292a.H(obj);
                        aVar = aVar3;
                    }
                    Object composedTargetState$animation_core = c0308f0.getComposedTargetState$animation_core();
                    ((z1.d) aVar).f(null);
                    if (!kotlin.jvm.internal.o.a(this.$targetState, composedTargetState$animation_core)) {
                        C0308f0 c0308f06 = this.this$0;
                        this.L$0 = null;
                        this.L$1 = null;
                        this.label = 2;
                        if (c0308f06.doOneFrame(this) == aVar2) {
                            return aVar2;
                        }
                        c0308f02 = this.this$0;
                        this.label = 3;
                        if (c0308f02.waitForCompositionAfterTargetStateChange(this) == aVar2) {
                        }
                    }
                    if (!kotlin.jvm.internal.o.a(this.this$0.getCurrentState(), this.$targetState)) {
                    }
                    return U0.n.f1521a;
                } catch (Throwable th) {
                    ((z1.d) aVar).f(null);
                    throw th;
                }
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(v0 v0Var, C0308f0 c0308f0, Object obj, F f2, Y0.c cVar) {
            super(1, cVar);
            this.$transition = v0Var;
            this.this$0 = c0308f0;
            this.$targetState = obj;
            this.$animationSpec = f2;
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return new c(this.$transition, this.this$0, this.$targetState, this.$animationSpec, cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((c) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                a aVar2 = new a(this.this$0, this.$targetState, this.$transition, this.$animationSpec, null);
                this.label = 1;
                if (AbstractC1476z.e(aVar2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            this.$transition.onTransitionEnd$animation_core();
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$d */
    public static final class d extends a1.c {
        int label;
        /* synthetic */ Object result;

        public d(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return C0308f0.this.runAnimations(this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$e */
    public static final class e extends a1.j implements h1.c {
        final /* synthetic */ float $fraction;
        final /* synthetic */ Object $oldTargetState;
        final /* synthetic */ Object $targetState;
        final /* synthetic */ v0 $transition;
        int label;
        final /* synthetic */ C0308f0 this$0;

        /* JADX INFO: renamed from: androidx.compose.animation.core.f0$e$a */
        public static final class a extends a1.j implements h1.e {
            final /* synthetic */ float $fraction;
            final /* synthetic */ Object $oldTargetState;
            final /* synthetic */ Object $targetState;
            final /* synthetic */ v0 $transition;
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ C0308f0 this$0;

            /* JADX INFO: renamed from: androidx.compose.animation.core.f0$e$a$a, reason: collision with other inner class name */
            public static final class C0016a extends a1.j implements h1.e {
                int label;
                final /* synthetic */ C0308f0 this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0016a(C0308f0 c0308f0, Y0.c cVar) {
                    super(2, cVar);
                    this.this$0 = c0308f0;
                }

                @Override // a1.a
                public final Y0.c create(Object obj, Y0.c cVar) {
                    return new C0016a(this.this$0, cVar);
                }

                @Override // a1.a
                public final Object invokeSuspend(Object obj) {
                    Z0.a aVar = Z0.a.f1616b;
                    int i2 = this.label;
                    if (i2 == 0) {
                        AbstractC0292a.H(obj);
                        C0308f0 c0308f0 = this.this$0;
                        this.label = 1;
                        if (c0308f0.runAnimations(this) == aVar) {
                            return aVar;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0292a.H(obj);
                    }
                    return U0.n.f1521a;
                }

                @Override // h1.e
                public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                    return ((C0016a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(Object obj, Object obj2, C0308f0 c0308f0, v0 v0Var, float f2, Y0.c cVar) {
                super(2, cVar);
                this.$targetState = obj;
                this.$oldTargetState = obj2;
                this.this$0 = c0308f0;
                this.$transition = v0Var;
                this.$fraction = f2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(this.$targetState, this.$oldTargetState, this.this$0, this.$transition, this.$fraction, cVar);
                aVar.L$0 = obj;
                return aVar;
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                U0.n nVar = U0.n.f1521a;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    InterfaceC1474x interfaceC1474x = (InterfaceC1474x) this.L$0;
                    if (kotlin.jvm.internal.o.a(this.$targetState, this.$oldTargetState)) {
                        this.this$0.currentAnimation = null;
                        if (kotlin.jvm.internal.o.a(this.this$0.getCurrentState(), this.$targetState)) {
                            return nVar;
                        }
                    } else {
                        this.this$0.moveAnimationToInitialState();
                    }
                    if (!kotlin.jvm.internal.o.a(this.$targetState, this.$oldTargetState)) {
                        this.$transition.updateTarget$animation_core(this.$targetState);
                        this.$transition.setPlayTimeNanos(0L);
                        this.this$0.setTargetState$animation_core(this.$targetState);
                        this.$transition.resetAnimationFraction$animation_core(this.$fraction);
                    }
                    this.this$0.setFraction(this.$fraction);
                    if (this.this$0.initialValueAnimations.e()) {
                        AbstractC1476z.s(interfaceC1474x, null, null, new C0016a(this.this$0, null), 3);
                    } else {
                        this.this$0.lastFrameTimeNanos = Long.MIN_VALUE;
                    }
                    C0308f0 c0308f0 = this.this$0;
                    this.label = 1;
                    if (c0308f0.waitForCompositionAfterTargetStateChange(this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0292a.H(obj);
                }
                this.this$0.seekToFraction();
                return nVar;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(Object obj, Object obj2, C0308f0 c0308f0, v0 v0Var, float f2, Y0.c cVar) {
            super(1, cVar);
            this.$targetState = obj;
            this.$oldTargetState = obj2;
            this.this$0 = c0308f0;
            this.$transition = v0Var;
            this.$fraction = f2;
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return new e(this.$targetState, this.$oldTargetState, this.this$0, this.$transition, this.$fraction, cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((e) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                a aVar2 = new a(this.$targetState, this.$oldTargetState, this.this$0, this.$transition, this.$fraction, null);
                this.label = 1;
                if (AbstractC1476z.e(aVar2, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$f */
    public static final class f extends a1.j implements h1.c {
        final /* synthetic */ Object $targetState;
        final /* synthetic */ v0 $transition;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(Object obj, v0 v0Var, Y0.c cVar) {
            super(1, cVar);
            this.$targetState = obj;
            this.$transition = v0Var;
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return C0308f0.this.new f(this.$targetState, this.$transition, cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((f) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                C0308f0.this.endAllAnimations();
                C0308f0.this.lastFrameTimeNanos = Long.MIN_VALUE;
                C0308f0.this.setFraction(0.0f);
                Object obj2 = this.$targetState;
                float f2 = kotlin.jvm.internal.o.a(obj2, C0308f0.this.getCurrentState()) ? -4.0f : kotlin.jvm.internal.o.a(obj2, C0308f0.this.getTargetState()) ? -5.0f : -3.0f;
                this.$transition.updateTarget$animation_core(this.$targetState);
                this.$transition.setPlayTimeNanos(0L);
                C0308f0.this.setTargetState$animation_core(this.$targetState);
                C0308f0.this.setFraction(0.0f);
                C0308f0.this.setCurrentState$animation_core(this.$targetState);
                this.$transition.resetAnimationFraction$animation_core(f2);
                if (f2 == -3.0f) {
                    C0308f0 c0308f0 = C0308f0.this;
                    this.label = 1;
                    if (c0308f0.waitForCompositionAfterTargetStateChange(this) == aVar) {
                        return aVar;
                    }
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            this.$transition.onTransitionEnd$animation_core();
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$g */
    public static final class g extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public g(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return C0308f0.this.waitForComposition(this);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.f0$h */
    public static final class h extends a1.c {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        public h(Y0.c cVar) {
            super(cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return C0308f0.this.waitForCompositionAfterTargetStateChange(this);
        }
    }

    public C0308f0(Object obj) {
        super(null);
        this.targetState$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.currentState$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.composedTargetState = obj;
        this.recalculateTotalDurationNanos = new E0.f(this, 6);
        this.fraction$delegate = W0.mutableFloatStateOf(0.0f);
        this.compositionContinuationMutex = z1.e.a();
        this.mutatorMutex = new C0298a0();
        this.lastFrameTimeNanos = Long.MIN_VALUE;
        this.initialValueAnimations = new C1342M();
        final int i2 = 0;
        this.firstFrameLambda = new h1.c(this) { // from class: androidx.compose.animation.core.e0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ C0308f0 f1636c;

            {
                this.f1636c = this;
            }

            @Override // h1.c
            public final Object invoke(Object obj2) {
                Long l2 = (Long) obj2;
                switch (i2) {
                    case 0:
                        return C0308f0.firstFrameLambda$lambda$1(this.f1636c, l2.longValue());
                    default:
                        return C0308f0.animateOneFrameLambda$lambda$4(this.f1636c, l2.longValue());
                }
            }
        };
        final int i3 = 1;
        this.animateOneFrameLambda = new h1.c(this) { // from class: androidx.compose.animation.core.e0

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public final /* synthetic */ C0308f0 f1636c;

            {
                this.f1636c = this;
            }

            @Override // h1.c
            public final Object invoke(Object obj2) {
                Long l2 = (Long) obj2;
                switch (i3) {
                    case 0:
                        return C0308f0.firstFrameLambda$lambda$1(this.f1636c, l2.longValue());
                    default:
                        return C0308f0.animateOneFrameLambda$lambda$4(this.f1636c, l2.longValue());
                }
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object animateOneFrame(Y0.c cVar) {
        float durationScale = AbstractC0333s0.getDurationScale(cVar.getContext());
        U0.n nVar = U0.n.f1521a;
        if (durationScale <= 0.0f) {
            endAllAnimations();
            return nVar;
        }
        this.durationScale = durationScale;
        Object objWithFrameNanos = AbstractC0801u0.withFrameNanos(this.animateOneFrameLambda, cVar);
        return objWithFrameNanos == Z0.a.f1616b ? objWithFrameNanos : nVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateOneFrameLambda$lambda$4(C0308f0 c0308f0, long j2) {
        long j3 = j2 - c0308f0.lastFrameTimeNanos;
        c0308f0.lastFrameTimeNanos = j2;
        long jU = j1.a.U(j3 / ((double) c0308f0.durationScale));
        if (c0308f0.initialValueAnimations.e()) {
            C1342M c1342m = c0308f0.initialValueAnimations;
            Object[] objArr = c1342m.f2958a;
            int i2 = c1342m.f2959b;
            int i3 = 0;
            for (int i4 = 0; i4 < i2; i4++) {
                b bVar = (b) objArr[i4];
                c0308f0.recalculateAnimationValue(bVar, jU);
                bVar.setComplete(true);
            }
            v0 v0Var = c0308f0.transition;
            if (v0Var != null) {
                v0Var.updateInitialValues$animation_core();
            }
            C1342M c1342m2 = c0308f0.initialValueAnimations;
            int i5 = c1342m2.f2959b;
            Object[] objArr2 = c1342m2.f2958a;
            m1.e eVarH0 = j1.a.h0(0, i5);
            int i6 = eVarH0.f3189b;
            int i7 = eVarH0.f3190c;
            if (i6 <= i7) {
                while (true) {
                    objArr2[i6 - i3] = objArr2[i6];
                    if (((b) objArr2[i6]).isComplete()) {
                        i3++;
                    }
                    if (i6 == i7) {
                        break;
                    }
                    i6++;
                }
            }
            V0.r.W(objArr2, i5 - i3, i5);
            c1342m2.f2959b -= i3;
        }
        b bVar2 = c0308f0.currentAnimation;
        if (bVar2 != null) {
            bVar2.setDurationNanos(c0308f0.totalDurationNanos);
            c0308f0.recalculateAnimationValue(bVar2, jU);
            c0308f0.setFraction(bVar2.getValue());
            if (bVar2.getValue() == 1.0f) {
                c0308f0.currentAnimation = null;
            }
            c0308f0.seekToFraction();
        }
        return U0.n.f1521a;
    }

    public static /* synthetic */ Object animateTo$default(C0308f0 c0308f0, Object obj, F f2, Y0.c cVar, int i2, Object obj2) {
        if ((i2 & 1) != 0) {
            obj = c0308f0.getTargetState();
        }
        if ((i2 & 2) != 0) {
            f2 = null;
        }
        return c0308f0.animateTo(obj, f2, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object doOneFrame(Y0.c cVar) {
        long j2 = this.lastFrameTimeNanos;
        U0.n nVar = U0.n.f1521a;
        if (j2 == Long.MIN_VALUE) {
            Object objWithFrameNanos = AbstractC0801u0.withFrameNanos(this.firstFrameLambda, cVar);
            return objWithFrameNanos == Z0.a.f1616b ? objWithFrameNanos : nVar;
        }
        Object objAnimateOneFrame = animateOneFrame(cVar);
        return objAnimateOneFrame == Z0.a.f1616b ? objAnimateOneFrame : nVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void endAllAnimations() {
        v0 v0Var = this.transition;
        if (v0Var != null) {
            v0Var.clearInitialAnimations$animation_core();
        }
        this.initialValueAnimations.i();
        if (this.currentAnimation != null) {
            this.currentAnimation = null;
            setFraction(1.0f);
            seekToFraction();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n firstFrameLambda$lambda$1(C0308f0 c0308f0, long j2) {
        c0308f0.lastFrameTimeNanos = j2;
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void moveAnimationToInitialState() {
        v0 v0Var = this.transition;
        if (v0Var == null) {
            return;
        }
        b bVar = this.currentAnimation;
        if (bVar == null) {
            if (this.totalDurationNanos <= 0 || getFraction() == 1.0f || kotlin.jvm.internal.o.a(getCurrentState(), getTargetState())) {
                bVar = null;
            } else {
                bVar = new b();
                bVar.setValue(getFraction());
                long j2 = this.totalDurationNanos;
                bVar.setDurationNanos(j2);
                bVar.setAnimationSpecDuration(j1.a.U((1.0d - ((double) getFraction())) * j2));
                bVar.getStart().set$animation_core(0, getFraction());
            }
        }
        if (bVar != null) {
            bVar.setDurationNanos(this.totalDurationNanos);
            this.initialValueAnimations.g(bVar);
            v0Var.setInitialAnimations$animation_core(bVar);
        }
        this.currentAnimation = null;
    }

    private final void recalculateAnimationValue(b bVar, long j2) {
        long progressNanos = bVar.getProgressNanos() + j2;
        bVar.setProgressNanos(progressNanos);
        long animationSpecDuration = bVar.getAnimationSpecDuration();
        if (progressNanos >= animationSpecDuration) {
            bVar.setValue(1.0f);
            return;
        }
        F0 animationSpec = bVar.getAnimationSpec();
        if (animationSpec == null) {
            float f2 = progressNanos / animationSpecDuration;
            bVar.setValue((f2 * 1.0f) + ((1 - f2) * bVar.getStart().get$animation_core(0)));
            return;
        }
        C0321m start = bVar.getStart();
        C0321m c0321m = Target1;
        C0321m initialVelocity = bVar.getInitialVelocity();
        if (initialVelocity == null) {
            initialVelocity = ZeroVelocity;
        }
        bVar.setValue(j1.a.n(((C0321m) animationSpec.getValueFromNanos(progressNanos, start, c0321m, initialVelocity)).get$animation_core(0), 0.0f, 1.0f));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n recalculateTotalDurationNanos$lambda$0(C0308f0 c0308f0) {
        v0 v0Var = c0308f0.transition;
        c0308f0.totalDurationNanos = v0Var != null ? v0Var.getTotalDurationNanos() : 0L;
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object runAnimations(Y0.c cVar) {
        d dVar;
        if (cVar instanceof d) {
            dVar = (d) cVar;
            int i2 = dVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                dVar.label = i2 - Integer.MIN_VALUE;
            } else {
                dVar = new d(cVar);
            }
        }
        Object obj = dVar.result;
        Object obj2 = Z0.a.f1616b;
        int i3 = dVar.label;
        U0.n nVar = U0.n.f1521a;
        if (i3 == 0) {
            AbstractC0292a.H(obj);
            if (this.initialValueAnimations.d() && this.currentAnimation == null) {
                return nVar;
            }
            if (AbstractC0333s0.getDurationScale(dVar.getContext()) == 0.0f) {
                endAllAnimations();
                this.lastFrameTimeNanos = Long.MIN_VALUE;
                return nVar;
            }
            if (this.lastFrameTimeNanos == Long.MIN_VALUE) {
                h1.c cVar2 = this.firstFrameLambda;
                dVar.label = 1;
                if (AbstractC0801u0.withFrameNanos(cVar2, dVar) == obj2) {
                    return obj2;
                }
            }
        } else {
            if (i3 != 1 && i3 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
        }
        do {
            if (!this.initialValueAnimations.e() && this.currentAnimation == null) {
                this.lastFrameTimeNanos = Long.MIN_VALUE;
                return nVar;
            }
            dVar.label = 2;
        } while (animateOneFrame(dVar) != obj2);
        return obj2;
    }

    public static /* synthetic */ Object seekTo$default(C0308f0 c0308f0, float f2, Object obj, Y0.c cVar, int i2, Object obj2) {
        if ((i2 & 2) != 0) {
            obj = c0308f0.getTargetState();
        }
        return c0308f0.seekTo(f2, obj, cVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void seekToFraction() {
        v0 v0Var = this.transition;
        if (v0Var == null) {
            return;
        }
        v0Var.seekAnimations$animation_core(j1.a.U(((double) getFraction()) * v0Var.getTotalDurationNanos()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setFraction(float f2) {
        this.fraction$delegate.setFloatValue(f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object waitForComposition(Y0.c cVar) {
        g gVar;
        Object targetState;
        Object obj;
        if (cVar instanceof g) {
            gVar = (g) cVar;
            int i2 = gVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                gVar.label = i2 - Integer.MIN_VALUE;
            } else {
                gVar = new g(cVar);
            }
        }
        Object obj2 = gVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = gVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj2);
            targetState = getTargetState();
            z1.a aVar2 = this.compositionContinuationMutex;
            gVar.L$0 = targetState;
            gVar.label = 1;
            if (((z1.d) aVar2).d(null, gVar) == aVar) {
                return aVar;
            }
        } else {
            if (i3 != 1) {
                if (i3 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                obj = gVar.L$0;
                AbstractC0292a.H(obj2);
                if (!kotlin.jvm.internal.o.a(obj2, obj)) {
                    return U0.n.f1521a;
                }
                this.lastFrameTimeNanos = Long.MIN_VALUE;
                throw new CancellationException("targetState while waiting for composition");
            }
            Object obj3 = gVar.L$0;
            AbstractC0292a.H(obj2);
            targetState = obj3;
        }
        gVar.L$0 = targetState;
        gVar.label = 2;
        C1459h c1459h = new C1459h(1, j1.a.H(gVar));
        c1459h.s();
        setCompositionContinuation$animation_core(c1459h);
        ((z1.d) getCompositionContinuationMutex$animation_core()).f(null);
        Object objR = c1459h.r();
        if (objR == aVar) {
            return aVar;
        }
        obj = targetState;
        obj2 = objR;
        if (!kotlin.jvm.internal.o.a(obj2, obj)) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:30:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object waitForCompositionAfterTargetStateChange(Y0.c cVar) {
        h hVar;
        Object targetState;
        Object obj;
        if (cVar instanceof h) {
            hVar = (h) cVar;
            int i2 = hVar.label;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                hVar.label = i2 - Integer.MIN_VALUE;
            } else {
                hVar = new h(cVar);
            }
        }
        Object obj2 = hVar.result;
        Z0.a aVar = Z0.a.f1616b;
        int i3 = hVar.label;
        if (i3 == 0) {
            AbstractC0292a.H(obj2);
            targetState = getTargetState();
            z1.a aVar2 = this.compositionContinuationMutex;
            hVar.L$0 = targetState;
            hVar.label = 1;
            if (((z1.d) aVar2).d(null, hVar) == aVar) {
                return aVar;
            }
        } else {
            if (i3 != 1) {
                if (i3 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                obj = hVar.L$0;
                AbstractC0292a.H(obj2);
                if (!kotlin.jvm.internal.o.a(obj2, obj)) {
                    this.lastFrameTimeNanos = Long.MIN_VALUE;
                    throw new CancellationException("snapTo() was canceled because state was changed to " + obj2 + " instead of " + obj);
                }
                return U0.n.f1521a;
            }
            Object obj3 = hVar.L$0;
            AbstractC0292a.H(obj2);
            targetState = obj3;
        }
        if (kotlin.jvm.internal.o.a(targetState, this.composedTargetState)) {
            ((z1.d) this.compositionContinuationMutex).f(null);
            return U0.n.f1521a;
        }
        hVar.L$0 = targetState;
        hVar.label = 2;
        C1459h c1459h = new C1459h(1, j1.a.H(hVar));
        c1459h.s();
        setCompositionContinuation$animation_core(c1459h);
        ((z1.d) getCompositionContinuationMutex$animation_core()).f(null);
        Object objR = c1459h.r();
        if (objR == aVar) {
            return aVar;
        }
        obj = targetState;
        obj2 = objR;
        if (!kotlin.jvm.internal.o.a(obj2, obj)) {
        }
        return U0.n.f1521a;
    }

    public final Object animateTo(Object obj, F f2, Y0.c cVar) {
        Object objMutate$default;
        v0 v0Var = this.transition;
        U0.n nVar = U0.n.f1521a;
        return (v0Var != null && (objMutate$default = C0298a0.mutate$default(this.mutatorMutex, null, new c(v0Var, this, obj, f2, null), cVar, 1, null)) == Z0.a.f1616b) ? objMutate$default : nVar;
    }

    public final Object getComposedTargetState$animation_core() {
        return this.composedTargetState;
    }

    public final InterfaceC1458g getCompositionContinuation$animation_core() {
        return this.compositionContinuation;
    }

    public final z1.a getCompositionContinuationMutex$animation_core() {
        return this.compositionContinuationMutex;
    }

    @Override // androidx.compose.animation.core.z0
    public Object getCurrentState() {
        return this.currentState$delegate.getValue();
    }

    public final float getFraction() {
        return this.fraction$delegate.getFloatValue();
    }

    @Override // androidx.compose.animation.core.z0
    public Object getTargetState() {
        return this.targetState$delegate.getValue();
    }

    public final long getTotalDurationNanos$animation_core() {
        return this.totalDurationNanos;
    }

    public final void observeTotalDuration$animation_core() {
        y0.getSeekableStateObserver().observeReads(this, y0.SeekableTransitionStateTotalDurationChanged, this.recalculateTotalDurationNanos);
    }

    public final void onTotalDurationChanged$animation_core() {
        long j2 = this.totalDurationNanos;
        observeTotalDuration$animation_core();
        long j3 = this.totalDurationNanos;
        if (j2 != j3) {
            b bVar = this.currentAnimation;
            if (bVar == null) {
                if (j3 != 0) {
                    seekToFraction();
                    return;
                }
                return;
            }
            long progressNanos = bVar.getProgressNanos();
            long j4 = this.totalDurationNanos;
            if (progressNanos > j4) {
                endAllAnimations();
                return;
            }
            bVar.setDurationNanos(j4);
            if (bVar.getAnimationSpec() == null) {
                bVar.setAnimationSpecDuration(j1.a.U((1.0d - ((double) bVar.getStart().get$animation_core(0))) * this.totalDurationNanos));
            }
        }
    }

    public final Object seekTo(float f2, Object obj, Y0.c cVar) {
        boolean z2 = false;
        if (0.0f <= f2 && f2 <= 1.0f) {
            z2 = true;
        }
        if (!z2) {
            AbstractC0300b0.throwIllegalArgumentException("Expecting fraction between 0 and 1. Got " + f2);
        }
        v0 v0Var = this.transition;
        U0.n nVar = U0.n.f1521a;
        if (v0Var == null) {
            return nVar;
        }
        Object objMutate$default = C0298a0.mutate$default(this.mutatorMutex, null, new e(obj, getTargetState(), this, v0Var, f2, null), cVar, 1, null);
        return objMutate$default == Z0.a.f1616b ? objMutate$default : nVar;
    }

    public final void setComposedTargetState$animation_core(Object obj) {
        this.composedTargetState = obj;
    }

    public final void setCompositionContinuation$animation_core(InterfaceC1458g interfaceC1458g) {
        this.compositionContinuation = interfaceC1458g;
    }

    @Override // androidx.compose.animation.core.z0
    public void setCurrentState$animation_core(Object obj) {
        this.currentState$delegate.setValue(obj);
    }

    @Override // androidx.compose.animation.core.z0
    public void setTargetState$animation_core(Object obj) {
        this.targetState$delegate.setValue(obj);
    }

    public final void setTotalDurationNanos$animation_core(long j2) {
        this.totalDurationNanos = j2;
    }

    public final Object snapTo(Object obj, Y0.c cVar) {
        Object objMutate$default;
        v0 v0Var = this.transition;
        U0.n nVar = U0.n.f1521a;
        return v0Var == null ? nVar : (!(kotlin.jvm.internal.o.a(getCurrentState(), obj) && kotlin.jvm.internal.o.a(getTargetState(), obj)) && (objMutate$default = C0298a0.mutate$default(this.mutatorMutex, null, new f(obj, v0Var, null), cVar, 1, null)) == Z0.a.f1616b) ? objMutate$default : nVar;
    }

    @Override // androidx.compose.animation.core.z0
    public void transitionConfigured$animation_core(v0 v0Var) {
        v0 v0Var2 = this.transition;
        if (!(v0Var2 == null || kotlin.jvm.internal.o.a(v0Var, v0Var2))) {
            AbstractC0300b0.throwIllegalStateException("An instance of SeekableTransitionState has been used in different Transitions. Previous instance: " + this.transition + ", new instance: " + v0Var);
        }
        this.transition = v0Var;
    }

    @Override // androidx.compose.animation.core.z0
    public void transitionRemoved$animation_core() {
        this.transition = null;
        y0.getSeekableStateObserver().clear(this);
    }
}
