package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface H0 {
    float getAbsVelocityThreshold();

    long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2);

    AbstractC0329q getTargetValue(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2);

    AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2);

    AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2);
}
