package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0325o extends AbstractC0329q {
    public static final int $stable = 8;
    private final int size;

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    private float f1638v1;
    private float v2;
    private float v3;

    public C0325o(float f2, float f3, float f4) {
        super(null);
        this.f1638v1 = f2;
        this.v2 = f3;
        this.v3 = f4;
        this.size = 3;
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0325o) {
            C0325o c0325o = (C0325o) obj;
            if (c0325o.f1638v1 == this.f1638v1 && c0325o.v2 == this.v2 && c0325o.v3 == this.v3) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public float get$animation_core(int i2) {
        if (i2 == 0) {
            return this.f1638v1;
        }
        if (i2 == 1) {
            return this.v2;
        }
        if (i2 != 2) {
            return 0.0f;
        }
        return this.v3;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public int getSize$animation_core() {
        return this.size;
    }

    public final float getV1() {
        return this.f1638v1;
    }

    public final float getV2() {
        return this.v2;
    }

    public final float getV3() {
        return this.v3;
    }

    public int hashCode() {
        return Float.hashCode(this.v3) + D0.d.a(this.v2, Float.hashCode(this.f1638v1) * 31, 31);
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void reset$animation_core() {
        this.f1638v1 = 0.0f;
        this.v2 = 0.0f;
        this.v3 = 0.0f;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void set$animation_core(int i2, float f2) {
        if (i2 == 0) {
            this.f1638v1 = f2;
        } else if (i2 == 1) {
            this.v2 = f2;
        } else {
            if (i2 != 2) {
                return;
            }
            this.v3 = f2;
        }
    }

    public final void setV1$animation_core(float f2) {
        this.f1638v1 = f2;
    }

    public final void setV2$animation_core(float f2) {
        this.v2 = f2;
    }

    public final void setV3$animation_core(float f2) {
        this.v3 = f2;
    }

    public String toString() {
        return "AnimationVector3D: v1 = " + this.f1638v1 + ", v2 = " + this.v2 + ", v3 = " + this.v3;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public C0325o newVector$animation_core() {
        return new C0325o(0.0f, 0.0f, 0.0f);
    }
}
