package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class M implements InterfaceC0313i {
    public static final int $stable = 8;
    private final B animation;
    private final long initialStartOffset;
    private final EnumC0302c0 repeatMode;

    public /* synthetic */ M(B b2, EnumC0302c0 enumC0302c0, long j2, AbstractC1378g abstractC1378g) {
        this(b2, enumC0302c0, j2);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof M)) {
            return false;
        }
        M m2 = (M) obj;
        return kotlin.jvm.internal.o.a(m2.animation, this.animation) && m2.repeatMode == this.repeatMode && C0322m0.m618equalsimpl0(m2.initialStartOffset, this.initialStartOffset);
    }

    public final B getAnimation() {
        return this.animation;
    }

    /* JADX INFO: renamed from: getInitialStartOffset-Rmkjzm4, reason: not valid java name */
    public final long m580getInitialStartOffsetRmkjzm4() {
        return this.initialStartOffset;
    }

    public final EnumC0302c0 getRepeatMode() {
        return this.repeatMode;
    }

    public int hashCode() {
        return C0322m0.m621hashCodeimpl(this.initialStartOffset) + ((this.repeatMode.hashCode() + (this.animation.hashCode() * 31)) * 31);
    }

    @Override // androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> F0 vectorize(B0 b02) {
        return new M0(this.animation.vectorize(b02), this.repeatMode, this.initialStartOffset, (AbstractC1378g) null);
    }

    private M(B b2, EnumC0302c0 enumC0302c0, long j2) {
        this.animation = b2;
        this.repeatMode = enumC0302c0;
        this.initialStartOffset = j2;
    }

    public /* synthetic */ M(B b2, EnumC0302c0 enumC0302c0, long j2, int i2, AbstractC1378g abstractC1378g) {
        this(b2, (i2 & 2) != 0 ? EnumC0302c0.Restart : enumC0302c0, (i2 & 4) != 0 ? C0322m0.m616constructorimpl$default(0, 0, 2, null) : j2, (AbstractC1378g) null);
    }

    public /* synthetic */ M(B b2, EnumC0302c0 enumC0302c0, int i2, AbstractC1378g abstractC1378g) {
        this(b2, (i2 & 2) != 0 ? EnumC0302c0.Restart : enumC0302c0);
    }

    @U0.a
    public /* synthetic */ M(B b2, EnumC0302c0 enumC0302c0) {
        this(b2, enumC0302c0, C0322m0.m616constructorimpl$default(0, 0, 2, null), (AbstractC1378g) null);
    }
}
