package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class S0 implements J0 {
    public static final int $stable = 8;
    private final /* synthetic */ K0 $$delegate_0;
    private final float dampingRatio;
    private final float stiffness;

    private S0(float f2, float f3, InterfaceC0332s interfaceC0332s) {
        this.$$delegate_0 = new K0(interfaceC0332s);
        this.dampingRatio = f2;
        this.stiffness = f3;
    }

    public final float getDampingRatio() {
        return this.dampingRatio;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.$$delegate_0.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.$$delegate_0.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    public final float getStiffness() {
        return this.stiffness;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.$$delegate_0.getValueFromNanos(j2, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.$$delegate_0.getVelocityFromNanos(j2, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public boolean isInfinite() {
        return this.$$delegate_0.isInfinite();
    }

    public /* synthetic */ S0(float f2, float f3, AbstractC0329q abstractC0329q, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? 1.0f : f2, (i2 & 2) != 0 ? 1500.0f : f3, (i2 & 4) != 0 ? null : abstractC0329q);
    }

    public S0(float f2, float f3, AbstractC0329q abstractC0329q) {
        this(f2, f3, G0.createSpringAnimations(abstractC0329q, f2, f3));
    }
}
