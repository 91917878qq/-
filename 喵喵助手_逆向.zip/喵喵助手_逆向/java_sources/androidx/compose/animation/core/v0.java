package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.animation.core.C0308f0;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.AbstractC0801u0;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.I1;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.InterfaceC0813y0;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.W0;
import androidx.compose.runtime.d2;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.EnumC1475y;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class v0 {
    public static final int $stable = 0;
    private final androidx.compose.runtime.snapshots.w _animations;
    private final androidx.compose.runtime.A0 _playTimeNanos$delegate;
    private final androidx.compose.runtime.snapshots.w _transitions;
    private final androidx.compose.runtime.B0 isSeeking$delegate;
    private final String label;
    private long lastSeekedTimeNanos;
    private final v0 parentTransition;
    private final androidx.compose.runtime.B0 segment$delegate;
    private final androidx.compose.runtime.A0 startTimeNanos$delegate;
    private final androidx.compose.runtime.B0 targetState$delegate;
    private final d2 totalDurationNanos$delegate;
    private final z0 transitionState;
    private final androidx.compose.runtime.B0 updateChildrenNeeded$delegate;

    public final class a {
        private final androidx.compose.runtime.B0 data$delegate = V1.mutableStateOf$default(null, null, 2, null);
        private final String label;
        private final B0 typeConverter;

        /* JADX INFO: renamed from: androidx.compose.animation.core.v0$a$a, reason: collision with other inner class name */
        public final class C0017a implements d2 {
            private final androidx.compose.animation.core.v0.c animation;
            private h1.c targetValueByState;
            final /* synthetic */ androidx.compose.animation.core.v0.a this$0;
            private h1.c transitionSpec;

            public C0017a(a aVar, androidx.compose.animation.core.v0.c cVar, h1.c cVar2, h1.c cVar3) {
                this.this$0 = aVar;
                this.animation = cVar;
                this.transitionSpec = cVar2;
                this.targetValueByState = cVar3;
            }

            public final androidx.compose.animation.core.v0.c getAnimation() {
                return this.animation;
            }

            public final h1.c getTargetValueByState() {
                return this.targetValueByState;
            }

            public final h1.c getTransitionSpec() {
                return this.transitionSpec;
            }

            @Override // androidx.compose.runtime.d2
            public Object getValue() {
                updateAnimationStates(v0.this.getSegment());
                return this.animation.getValue();
            }

            public final void setTargetValueByState(h1.c cVar) {
                this.targetValueByState = cVar;
            }

            public final void setTransitionSpec(h1.c cVar) {
                this.transitionSpec = cVar;
            }

            public final void updateAnimationStates(w0 w0Var) {
                Object objInvoke = this.targetValueByState.invoke(w0Var.getTargetState());
                if (!v0.this.isSeeking()) {
                    this.animation.updateTargetValue$animation_core(objInvoke, (F) this.transitionSpec.invoke(w0Var));
                } else {
                    this.animation.updateInitialAndTargetValue$animation_core(this.targetValueByState.invoke(w0Var.getInitialState()), objInvoke, (F) this.transitionSpec.invoke(w0Var));
                }
            }
        }

        public a(B0 b02, String str) {
            this.typeConverter = b02;
            this.label = str;
        }

        public final d2 animate(h1.c cVar, h1.c cVar2) {
            C0017a data$animation_core = getData$animation_core();
            if (data$animation_core == null) {
                v0 v0Var = v0.this;
                data$animation_core = new C0017a(this, v0Var.new c(cVar2.invoke(v0Var.getCurrentState()), AbstractC0319l.createZeroVectorFrom(this.typeConverter, cVar2.invoke(v0.this.getCurrentState())), this.typeConverter, this.label), cVar, cVar2);
                v0 v0Var2 = v0.this;
                setData$animation_core(data$animation_core);
                v0Var2.addAnimation$animation_core(data$animation_core.getAnimation());
            }
            v0 v0Var3 = v0.this;
            data$animation_core.setTargetValueByState(cVar2);
            data$animation_core.setTransitionSpec(cVar);
            data$animation_core.updateAnimationStates(v0Var3.getSegment());
            return data$animation_core;
        }

        public final androidx.compose.animation.core.v0.a.a getData$animation_core() {
            return (C0017a) this.data$delegate.getValue();
        }

        public final String getLabel() {
            return this.label;
        }

        public final B0 getTypeConverter() {
            return this.typeConverter;
        }

        public final void setData$animation_core(androidx.compose.animation.core.v0.a.a aVar) {
            this.data$delegate.setValue(aVar);
        }

        public final void setupSeeking$animation_core() {
            C0017a data$animation_core = getData$animation_core();
            if (data$animation_core != null) {
                v0 v0Var = v0.this;
                data$animation_core.getAnimation().updateInitialAndTargetValue$animation_core(data$animation_core.getTargetValueByState().invoke(v0Var.getSegment().getInitialState()), data$animation_core.getTargetValueByState().invoke(v0Var.getSegment().getTargetState()), (F) data$animation_core.getTransitionSpec().invoke(v0Var.getSegment()));
            }
        }
    }

    public static final class b implements w0 {
        private final Object initialState;
        private final Object targetState;

        public b(Object obj, Object obj2) {
            this.initialState = obj;
            this.targetState = obj2;
        }

        public boolean equals(Object obj) {
            if (obj instanceof w0) {
                w0 w0Var = (w0) obj;
                if (kotlin.jvm.internal.o.a(getInitialState(), w0Var.getInitialState()) && kotlin.jvm.internal.o.a(getTargetState(), w0Var.getTargetState())) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.compose.animation.core.w0
        public Object getInitialState() {
            return this.initialState;
        }

        @Override // androidx.compose.animation.core.w0
        public Object getTargetState() {
            return this.targetState;
        }

        public int hashCode() {
            Object initialState = getInitialState();
            int iHashCode = (initialState != null ? initialState.hashCode() : 0) * 31;
            Object targetState = getTargetState();
            return iHashCode + (targetState != null ? targetState.hashCode() : 0);
        }

        @Override // androidx.compose.animation.core.w0
        public /* bridge */ /* synthetic */ boolean isTransitioningTo(Object obj, Object obj2) {
            return super.isTransitioningTo(obj, obj2);
        }
    }

    public final class c implements d2 {
        private final androidx.compose.runtime.B0 animation$delegate;
        private final androidx.compose.runtime.B0 animationSpec$delegate;
        private final C0316j0 defaultSpring;
        private final androidx.compose.runtime.A0 durationNanos$delegate;
        private C0335t0 initialValueAnimation;
        private C0308f0.b initialValueState;
        private final F interruptionSpec;
        private final androidx.compose.runtime.B0 isFinished$delegate;
        private boolean isSeeking;
        private final String label;
        private final InterfaceC0813y0 resetSnapValue$delegate;
        private final androidx.compose.runtime.B0 targetValue$delegate;
        private final B0 typeConverter;
        private boolean useOnlyInitialValue;
        private final androidx.compose.runtime.B0 value$delegate;
        private AbstractC0329q velocityVector;

        public c(Object obj, AbstractC0329q abstractC0329q, B0 b02, String str) {
            Object objInvoke;
            this.typeConverter = b02;
            this.label = str;
            this.targetValue$delegate = V1.mutableStateOf$default(obj, null, 2, null);
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
            this.defaultSpring = c0316j0Spring$default;
            this.animationSpec$delegate = V1.mutableStateOf$default(c0316j0Spring$default, null, 2, null);
            this.animation$delegate = V1.mutableStateOf$default(new C0335t0(getAnimationSpec(), b02, obj, getTargetValue(), abstractC0329q), null, 2, null);
            this.isFinished$delegate = V1.mutableStateOf$default(Boolean.TRUE, null, 2, null);
            this.resetSnapValue$delegate = W0.mutableFloatStateOf(-1.0f);
            this.value$delegate = V1.mutableStateOf$default(obj, null, 2, null);
            this.velocityVector = abstractC0329q;
            this.durationNanos$delegate = I1.mutableLongStateOf(getAnimation().getDurationNanos());
            Float f2 = U0.getVisibilityThresholdMap().get(b02);
            if (f2 != null) {
                float fFloatValue = f2.floatValue();
                AbstractC0329q abstractC0329q2 = (AbstractC0329q) b02.getConvertToVector().invoke(obj);
                int size$animation_core = abstractC0329q2.getSize$animation_core();
                for (int i2 = 0; i2 < size$animation_core; i2++) {
                    abstractC0329q2.set$animation_core(i2, fFloatValue);
                }
                objInvoke = this.typeConverter.getConvertFromVector().invoke(abstractC0329q2);
            } else {
                objInvoke = null;
            }
            this.interruptionSpec = AbstractC0315j.spring$default(0.0f, 0.0f, objInvoke, 3, null);
        }

        private final Object getTargetValue() {
            return this.targetValue$delegate.getValue();
        }

        private final void setAnimation(C0335t0 c0335t0) {
            this.animation$delegate.setValue(c0335t0);
        }

        private final void setAnimationSpec(F f2) {
            this.animationSpec$delegate.setValue(f2);
        }

        private final void setTargetValue(Object obj) {
            this.targetValue$delegate.setValue(obj);
        }

        private final void updateAnimation(Object obj, boolean z2) {
            C0335t0 c0335t0 = this.initialValueAnimation;
            if (kotlin.jvm.internal.o.a(c0335t0 != null ? c0335t0.getTargetValue() : null, getTargetValue())) {
                setAnimation(new C0335t0(this.interruptionSpec, this.typeConverter, obj, obj, r.newInstance(this.velocityVector)));
                this.useOnlyInitialValue = true;
                setDurationNanos$animation_core(getAnimation().getDurationNanos());
                return;
            }
            InterfaceC0313i animationSpec = (!z2 || this.isSeeking || (getAnimationSpec() instanceof C0316j0)) ? getAnimationSpec() : this.interruptionSpec;
            if (v0.this.getPlayTimeNanos() > 0) {
                animationSpec = AbstractC0315j.delayed(animationSpec, v0.this.getPlayTimeNanos());
            }
            setAnimation(new C0335t0(animationSpec, this.typeConverter, obj, getTargetValue(), this.velocityVector));
            setDurationNanos$animation_core(getAnimation().getDurationNanos());
            this.useOnlyInitialValue = false;
            v0.this.onChildAnimationUpdated();
        }

        public static /* synthetic */ void updateAnimation$default(c cVar, Object obj, boolean z2, int i2, Object obj2) {
            if ((i2 & 1) != 0) {
                obj = cVar.getValue();
            }
            if ((i2 & 2) != 0) {
                z2 = false;
            }
            cVar.updateAnimation(obj, z2);
        }

        public final void clearInitialAnimation$animation_core() {
            this.initialValueAnimation = null;
            this.initialValueState = null;
            this.useOnlyInitialValue = false;
        }

        public final C0335t0 getAnimation() {
            return (C0335t0) this.animation$delegate.getValue();
        }

        public final F getAnimationSpec() {
            return (F) this.animationSpec$delegate.getValue();
        }

        public final long getDurationNanos$animation_core() {
            return this.durationNanos$delegate.getLongValue();
        }

        public final C0308f0.b getInitialValueState$animation_core() {
            return this.initialValueState;
        }

        public final String getLabel() {
            return this.label;
        }

        public final float getResetSnapValue$animation_core() {
            return this.resetSnapValue$delegate.getFloatValue();
        }

        public final B0 getTypeConverter() {
            return this.typeConverter;
        }

        @Override // androidx.compose.runtime.d2
        public Object getValue() {
            return this.value$delegate.getValue();
        }

        public final boolean isFinished$animation_core() {
            return ((Boolean) this.isFinished$delegate.getValue()).booleanValue();
        }

        public final void onPlayTimeChanged$animation_core(long j2, boolean z2) {
            if (z2) {
                j2 = getAnimation().getDurationNanos();
            }
            setValue$animation_core(getAnimation().getValueFromNanos(j2));
            this.velocityVector = getAnimation().getVelocityVectorFromNanos(j2);
            if (getAnimation().isFinishedFromNanos(j2)) {
                setFinished$animation_core(true);
            }
        }

        public final void resetAnimation$animation_core() {
            setResetSnapValue$animation_core(-2.0f);
        }

        public final void resetAnimationValue$animation_core(float f2) {
            if (f2 != -4.0f && f2 != -5.0f) {
                setResetSnapValue$animation_core(f2);
                return;
            }
            C0335t0 c0335t0 = this.initialValueAnimation;
            if (c0335t0 != null) {
                getAnimation().setMutableInitialValue$animation_core(c0335t0.getTargetValue());
                this.initialValueState = null;
                this.initialValueAnimation = null;
            }
            Object initialValue = f2 == -4.0f ? getAnimation().getInitialValue() : getAnimation().getTargetValue();
            getAnimation().setMutableInitialValue$animation_core(initialValue);
            getAnimation().setMutableTargetValue$animation_core(initialValue);
            setValue$animation_core(initialValue);
            setDurationNanos$animation_core(getAnimation().getDurationNanos());
        }

        public final void seekTo$animation_core(long j2) {
            if (getResetSnapValue$animation_core() == -1.0f) {
                this.isSeeking = true;
                if (kotlin.jvm.internal.o.a(getAnimation().getTargetValue(), getAnimation().getInitialValue())) {
                    setValue$animation_core(getAnimation().getTargetValue());
                } else {
                    setValue$animation_core(getAnimation().getValueFromNanos(j2));
                    this.velocityVector = getAnimation().getVelocityVectorFromNanos(j2);
                }
            }
        }

        public final void setDurationNanos$animation_core(long j2) {
            this.durationNanos$delegate.setLongValue(j2);
        }

        public final void setFinished$animation_core(boolean z2) {
            this.isFinished$delegate.setValue(Boolean.valueOf(z2));
        }

        public final void setInitialValueAnimation$animation_core(C0308f0.b bVar) {
            if (!kotlin.jvm.internal.o.a(getAnimation().getTargetValue(), getAnimation().getInitialValue())) {
                this.initialValueAnimation = getAnimation();
                this.initialValueState = bVar;
            }
            setAnimation(new C0335t0(this.interruptionSpec, this.typeConverter, getValue(), getValue(), r.newInstance(this.velocityVector)));
            setDurationNanos$animation_core(getAnimation().getDurationNanos());
            this.useOnlyInitialValue = true;
        }

        public final void setInitialValueState$animation_core(C0308f0.b bVar) {
            this.initialValueState = bVar;
        }

        public final void setResetSnapValue$animation_core(float f2) {
            this.resetSnapValue$delegate.setFloatValue(f2);
        }

        public void setValue$animation_core(Object obj) {
            this.value$delegate.setValue(obj);
        }

        public String toString() {
            return "current value: " + getValue() + ", target: " + getTargetValue() + ", spec: " + getAnimationSpec();
        }

        public final void updateInitialAndTargetValue$animation_core(Object obj, Object obj2, F f2) {
            setTargetValue(obj2);
            setAnimationSpec(f2);
            if (kotlin.jvm.internal.o.a(getAnimation().getInitialValue(), obj) && kotlin.jvm.internal.o.a(getAnimation().getTargetValue(), obj2)) {
                return;
            }
            updateAnimation$default(this, obj, false, 2, null);
        }

        public final void updateInitialValue$animation_core() {
            C0335t0 c0335t0;
            C0308f0.b bVar = this.initialValueState;
            if (bVar == null || (c0335t0 = this.initialValueAnimation) == null) {
                return;
            }
            long jU = j1.a.U(bVar.getDurationNanos() * ((double) bVar.getValue()));
            Object valueFromNanos = c0335t0.getValueFromNanos(jU);
            if (this.useOnlyInitialValue) {
                getAnimation().setMutableTargetValue$animation_core(valueFromNanos);
            }
            getAnimation().setMutableInitialValue$animation_core(valueFromNanos);
            setDurationNanos$animation_core(getAnimation().getDurationNanos());
            if (getResetSnapValue$animation_core() == -2.0f || this.useOnlyInitialValue) {
                setValue$animation_core(valueFromNanos);
            } else {
                seekTo$animation_core(v0.this.getPlayTimeNanos());
            }
            if (jU < bVar.getDurationNanos()) {
                bVar.setComplete(false);
            } else {
                this.initialValueState = null;
                this.initialValueAnimation = null;
            }
        }

        public final void updateTargetValue$animation_core(Object obj, F f2) {
            if (this.useOnlyInitialValue) {
                C0335t0 c0335t0 = this.initialValueAnimation;
                if (kotlin.jvm.internal.o.a(obj, c0335t0 != null ? c0335t0.getTargetValue() : null)) {
                    return;
                }
            }
            if (kotlin.jvm.internal.o.a(getTargetValue(), obj) && getResetSnapValue$animation_core() == -1.0f) {
                return;
            }
            setTargetValue(obj);
            setAnimationSpec(f2);
            updateAnimation(getResetSnapValue$animation_core() == -3.0f ? obj : getValue(), !isFinished$animation_core());
            setFinished$animation_core(getResetSnapValue$animation_core() == -3.0f);
            if (getResetSnapValue$animation_core() >= 0.0f) {
                setValue$animation_core(getAnimation().getValueFromNanos((long) (getResetSnapValue$animation_core() * getAnimation().getDurationNanos())));
            } else if (getResetSnapValue$animation_core() == -3.0f) {
                setValue$animation_core(obj);
            }
            this.useOnlyInitialValue = false;
            setResetSnapValue$animation_core(-1.0f);
        }
    }

    public static final class d extends a1.j implements h1.e {
        float F$0;
        private /* synthetic */ Object L$0;
        int label;

        public d(Y0.c cVar) {
            super(2, cVar);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(v0 v0Var, float f2, long j2) {
            if (!v0Var.isSeeking()) {
                v0Var.onFrame$animation_core(j2, f2);
            }
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            d dVar = v0.this.new d(cVar);
            dVar.L$0 = obj;
            return dVar;
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            float durationScale;
            InterfaceC1474x interfaceC1474x;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC1474x interfaceC1474x2 = (InterfaceC1474x) this.L$0;
                durationScale = AbstractC0333s0.getDurationScale(interfaceC1474x2.getCoroutineContext());
                interfaceC1474x = interfaceC1474x2;
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                durationScale = this.F$0;
                interfaceC1474x = (InterfaceC1474x) this.L$0;
                AbstractC0292a.H(obj);
            }
            while (AbstractC1476z.p(interfaceC1474x)) {
                P0.c cVar = new P0.c(v0.this, durationScale, 2);
                this.L$0 = interfaceC1474x;
                this.F$0 = durationScale;
                this.label = 1;
                if (AbstractC0801u0.withFrameNanos(cVar, this) == aVar) {
                    return aVar;
                }
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((d) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class e implements androidx.compose.runtime.V {
        @Override // androidx.compose.runtime.V
        public void dispose() {
        }
    }

    public v0(z0 z0Var, v0 v0Var, String str) {
        this.transitionState = z0Var;
        this.parentTransition = v0Var;
        this.label = str;
        this.targetState$delegate = V1.mutableStateOf$default(getCurrentState(), null, 2, null);
        this.segment$delegate = V1.mutableStateOf$default(new b(getCurrentState(), getCurrentState()), null, 2, null);
        this._playTimeNanos$delegate = I1.mutableLongStateOf(0L);
        this.startTimeNanos$delegate = I1.mutableLongStateOf(Long.MIN_VALUE);
        Boolean bool = Boolean.FALSE;
        this.updateChildrenNeeded$delegate = V1.mutableStateOf$default(bool, null, 2, null);
        this._animations = Q1.mutableStateListOf();
        this._transitions = Q1.mutableStateListOf();
        this.isSeeking$delegate = V1.mutableStateOf$default(bool, null, 2, null);
        this.totalDurationNanos$delegate = Q1.derivedStateOf(new C0337u0(this, 1));
        z0Var.transitionConfigured$animation_core(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean animateTo$lambda$13$lambda$12(v0 v0Var) {
        return !kotlin.jvm.internal.o.a(v0Var.getTargetState(), v0Var.getCurrentState()) || v0Var.isRunning() || v0Var.getUpdateChildrenNeeded();
    }

    private static final boolean animateTo$lambda$14(d2 d2Var) {
        return ((Boolean) d2Var.getValue()).booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V animateTo$lambda$17$lambda$16(InterfaceC1474x interfaceC1474x, v0 v0Var, androidx.compose.runtime.W w2) {
        AbstractC1476z.s(interfaceC1474x, null, EnumC1475y.f3408e, v0Var.new d(null), 1);
        return new e();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateTo$lambda$18(v0 v0Var, Object obj, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        v0Var.animateTo$animation_core(obj, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final long calculateTotalDurationNanos() {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        long jMax = 0;
        for (int i2 = 0; i2 < size; i2++) {
            jMax = Math.max(jMax, ((c) wVar.get(i2)).getDurationNanos$animation_core());
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            jMax = Math.max(jMax, ((v0) wVar2.get(i3)).calculateTotalDurationNanos());
        }
        return jMax;
    }

    public static /* synthetic */ void getHasInitialValueAnimations$annotations() {
    }

    private final boolean getUpdateChildrenNeeded() {
        return ((Boolean) this.updateChildrenNeeded$delegate.getValue()).booleanValue();
    }

    private final long get_playTimeNanos() {
        return this._playTimeNanos$delegate.getLongValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onChildAnimationUpdated() {
        setUpdateChildrenNeeded(true);
        if (isSeeking()) {
            androidx.compose.runtime.snapshots.w wVar = this._animations;
            int size = wVar.size();
            long jMax = 0;
            for (int i2 = 0; i2 < size; i2++) {
                c cVar = (c) wVar.get(i2);
                jMax = Math.max(jMax, cVar.getDurationNanos$animation_core());
                cVar.seekTo$animation_core(this.lastSeekedTimeNanos);
            }
            setUpdateChildrenNeeded(false);
        }
    }

    private final void setSegment(w0 w0Var) {
        this.segment$delegate.setValue(w0Var);
    }

    private final void setUpdateChildrenNeeded(boolean z2) {
        this.updateChildrenNeeded$delegate.setValue(Boolean.valueOf(z2));
    }

    private final void set_playTimeNanos(long j2) {
        this._playTimeNanos$delegate.setLongValue(j2);
    }

    public final boolean addAnimation$animation_core(androidx.compose.animation.core.v0.c cVar) {
        return this._animations.add(cVar);
    }

    public final boolean addTransition$animation_core(v0 v0Var) {
        return this._transitions.add(v0Var);
    }

    public final void animateTo$animation_core(Object obj, InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1493585151);
        if ((i2 & 6) == 0) {
            i3 = ((i2 & 8) == 0 ? interfaceC0768pStartRestartGroup.changed(obj) : interfaceC0768pStartRestartGroup.changedInstance(obj) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(this) ? 32 : 16;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1493585151, i3, -1, "androidx.compose.animation.core.Transition.animateTo (Transition.kt:1180)");
            }
            if (isSeeking()) {
                interfaceC0768pStartRestartGroup.startReplaceGroup(467781377);
                interfaceC0768pStartRestartGroup.endReplaceGroup();
            } else {
                interfaceC0768pStartRestartGroup.startReplaceGroup(466120769);
                updateTarget$animation_core(obj);
                int i4 = i3 & 112;
                boolean z2 = i4 == 32;
                Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = Q1.derivedStateOf(new C0337u0(this, 0));
                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                if (animateTo$lambda$14((d2) objRememberedValue)) {
                    interfaceC0768pStartRestartGroup.startReplaceGroup(466528884);
                    Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                    C0765o c0765o = InterfaceC0768p.Companion;
                    if (objRememberedValue2 == c0765o.getEmpty()) {
                        objRememberedValue2 = androidx.compose.runtime.Z.createCompositionCoroutineScope(Y0.i.f1613b, interfaceC0768pStartRestartGroup);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    }
                    InterfaceC1474x interfaceC1474x = (InterfaceC1474x) objRememberedValue2;
                    boolean zChangedInstance = interfaceC0768pStartRestartGroup.changedInstance(interfaceC1474x) | (i4 == 32);
                    Object objRememberedValue3 = interfaceC0768pStartRestartGroup.rememberedValue();
                    if (zChangedInstance || objRememberedValue3 == c0765o.getEmpty()) {
                        objRememberedValue3 = new M0.m(7, interfaceC1474x, this);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue3);
                    }
                    androidx.compose.runtime.Z.DisposableEffect(interfaceC1474x, this, (h1.c) objRememberedValue3, interfaceC0768pStartRestartGroup, i4);
                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                } else {
                    interfaceC0768pStartRestartGroup.startReplaceGroup(467771457);
                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                }
                interfaceC0768pStartRestartGroup.endReplaceGroup();
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new G.s(this, obj, i2, 8));
        }
    }

    public final void clearInitialAnimations$animation_core() {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).clearInitialAnimation$animation_core();
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((v0) wVar2.get(i3)).clearInitialAnimations$animation_core();
        }
    }

    public final List<androidx.compose.animation.core.v0.c> getAnimations() {
        return this._animations;
    }

    public final Object getCurrentState() {
        return this.transitionState.getCurrentState();
    }

    public final boolean getHasInitialValueAnimations() {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
                int size2 = wVar2.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    if (!((v0) wVar2.get(i3)).getHasInitialValueAnimations()) {
                    }
                }
                return false;
            }
            if (((c) wVar.get(i2)).getInitialValueState$animation_core() != null) {
                break;
            }
            i2++;
        }
        return true;
    }

    public final String getLabel() {
        return this.label;
    }

    public final long getLastSeekedTimeNanos$animation_core() {
        return this.lastSeekedTimeNanos;
    }

    public final v0 getParentTransition() {
        return this.parentTransition;
    }

    public final long getPlayTimeNanos() {
        v0 v0Var = this.parentTransition;
        return v0Var != null ? v0Var.getPlayTimeNanos() : get_playTimeNanos();
    }

    public final w0 getSegment() {
        return (w0) this.segment$delegate.getValue();
    }

    public final long getStartTimeNanos$animation_core() {
        return this.startTimeNanos$delegate.getLongValue();
    }

    public final Object getTargetState() {
        return this.targetState$delegate.getValue();
    }

    public final long getTotalDurationNanos() {
        return ((Number) this.totalDurationNanos$delegate.getValue()).longValue();
    }

    public final List<v0> getTransitions() {
        return this._transitions;
    }

    public final boolean isRunning() {
        return getStartTimeNanos$animation_core() != Long.MIN_VALUE;
    }

    public final boolean isSeeking() {
        return ((Boolean) this.isSeeking$delegate.getValue()).booleanValue();
    }

    public final void onDisposed$animation_core() {
        onTransitionEnd$animation_core();
        this.transitionState.transitionRemoved$animation_core();
    }

    public final void onFrame$animation_core(long j2, float f2) {
        if (getStartTimeNanos$animation_core() == Long.MIN_VALUE) {
            onTransitionStart$animation_core(j2);
        }
        long startTimeNanos$animation_core = j2 - getStartTimeNanos$animation_core();
        if (f2 != 0.0f) {
            startTimeNanos$animation_core = j1.a.U(startTimeNanos$animation_core / ((double) f2));
        }
        setPlayTimeNanos(startTimeNanos$animation_core);
        onFrame$animation_core(startTimeNanos$animation_core, f2 == 0.0f);
    }

    public final void onTransitionEnd$animation_core() {
        setStartTimeNanos$animation_core(Long.MIN_VALUE);
        z0 z0Var = this.transitionState;
        if (z0Var instanceof X) {
            ((X) z0Var).setCurrentState$animation_core(getTargetState());
        }
        setPlayTimeNanos(0L);
        this.transitionState.setRunning$animation_core(false);
        androidx.compose.runtime.snapshots.w wVar = this._transitions;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((v0) wVar.get(i2)).onTransitionEnd$animation_core();
        }
    }

    public final void onTransitionStart$animation_core(long j2) {
        setStartTimeNanos$animation_core(j2);
        this.transitionState.setRunning$animation_core(true);
    }

    public final void removeAnimation$animation_core(androidx.compose.animation.core.v0.c cVar) {
        this._animations.remove(cVar);
    }

    public final boolean removeTransition$animation_core(v0 v0Var) {
        return this._transitions.remove(v0Var);
    }

    public final void resetAnimationFraction$animation_core(float f2) {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).resetAnimationValue$animation_core(f2);
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((v0) wVar2.get(i3)).resetAnimationFraction$animation_core(f2);
        }
    }

    public final void seek(Object obj, Object obj2, long j2) {
        setStartTimeNanos$animation_core(Long.MIN_VALUE);
        this.transitionState.setRunning$animation_core(false);
        if (!isSeeking() || !kotlin.jvm.internal.o.a(getCurrentState(), obj) || !kotlin.jvm.internal.o.a(getTargetState(), obj2)) {
            if (!kotlin.jvm.internal.o.a(getCurrentState(), obj)) {
                z0 z0Var = this.transitionState;
                if (z0Var instanceof X) {
                    ((X) z0Var).setCurrentState$animation_core(obj);
                }
            }
            setTargetState$animation_core(obj2);
            setSeeking$animation_core(true);
            setSegment(new b(obj, obj2));
        }
        androidx.compose.runtime.snapshots.w wVar = this._transitions;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            v0 v0Var = (v0) wVar.get(i2);
            kotlin.jvm.internal.o.c(v0Var, "null cannot be cast to non-null type androidx.compose.animation.core.Transition<kotlin.Any>");
            if (v0Var.isSeeking()) {
                v0Var.seek(v0Var.getCurrentState(), v0Var.getTargetState(), j2);
            }
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._animations;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((c) wVar2.get(i3)).seekTo$animation_core(j2);
        }
        this.lastSeekedTimeNanos = j2;
    }

    public final void seekAnimations$animation_core(long j2) {
        if (getStartTimeNanos$animation_core() == Long.MIN_VALUE) {
            setStartTimeNanos$animation_core(j2);
        }
        setPlayTimeNanos(j2);
        setUpdateChildrenNeeded(false);
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).seekTo$animation_core(j2);
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            v0 v0Var = (v0) wVar2.get(i3);
            if (!kotlin.jvm.internal.o.a(v0Var.getTargetState(), v0Var.getCurrentState())) {
                v0Var.seekAnimations$animation_core(j2);
            }
        }
    }

    public final void setInitialAnimations$animation_core(C0308f0.b bVar) {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).setInitialValueAnimation$animation_core(bVar);
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((v0) wVar2.get(i3)).setInitialAnimations$animation_core(bVar);
        }
    }

    public final void setLastSeekedTimeNanos$animation_core(long j2) {
        this.lastSeekedTimeNanos = j2;
    }

    public final void setPlayTimeNanos(long j2) {
        if (this.parentTransition == null) {
            set_playTimeNanos(j2);
        }
    }

    public final void setSeeking$animation_core(boolean z2) {
        this.isSeeking$delegate.setValue(Boolean.valueOf(z2));
    }

    public final void setStartTimeNanos$animation_core(long j2) {
        this.startTimeNanos$delegate.setLongValue(j2);
    }

    public final void setTargetState$animation_core(Object obj) {
        this.targetState$delegate.setValue(obj);
    }

    public String toString() {
        List<androidx.compose.animation.core.v0.c> animations = getAnimations();
        int size = animations.size();
        String str = "Transition animation values: ";
        for (int i2 = 0; i2 < size; i2++) {
            str = str + animations.get(i2) + ", ";
        }
        return str;
    }

    public final void updateInitialValues$animation_core() {
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).updateInitialValue$animation_core();
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            ((v0) wVar2.get(i3)).updateInitialValues$animation_core();
        }
    }

    public final void updateTarget$animation_core(Object obj) {
        if (kotlin.jvm.internal.o.a(getTargetState(), obj)) {
            return;
        }
        setSegment(new b(getTargetState(), obj));
        if (!kotlin.jvm.internal.o.a(getCurrentState(), getTargetState())) {
            this.transitionState.setCurrentState$animation_core(getTargetState());
        }
        setTargetState$animation_core(obj);
        if (!isRunning()) {
            setUpdateChildrenNeeded(true);
        }
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((c) wVar.get(i2)).resetAnimation$animation_core();
        }
    }

    public final void removeAnimation$animation_core(androidx.compose.animation.core.v0.a aVar) {
        c animation;
        a.C0017a data$animation_core = aVar.getData$animation_core();
        if (data$animation_core == null || (animation = data$animation_core.getAnimation()) == null) {
            return;
        }
        removeAnimation$animation_core((androidx.compose.animation.core.v0.c) animation);
    }

    public final void onFrame$animation_core(long j2, boolean z2) {
        boolean z3 = true;
        if (getStartTimeNanos$animation_core() == Long.MIN_VALUE) {
            onTransitionStart$animation_core(j2);
        } else if (!this.transitionState.isRunning$animation_core()) {
            this.transitionState.setRunning$animation_core(true);
        }
        setUpdateChildrenNeeded(false);
        androidx.compose.runtime.snapshots.w wVar = this._animations;
        int size = wVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            c cVar = (c) wVar.get(i2);
            if (!cVar.isFinished$animation_core()) {
                cVar.onPlayTimeChanged$animation_core(j2, z2);
            }
            if (!cVar.isFinished$animation_core()) {
                z3 = false;
            }
        }
        androidx.compose.runtime.snapshots.w wVar2 = this._transitions;
        int size2 = wVar2.size();
        for (int i3 = 0; i3 < size2; i3++) {
            v0 v0Var = (v0) wVar2.get(i3);
            if (!kotlin.jvm.internal.o.a(v0Var.getTargetState(), v0Var.getCurrentState())) {
                v0Var.onFrame$animation_core(j2, z2);
            }
            if (!kotlin.jvm.internal.o.a(v0Var.getTargetState(), v0Var.getCurrentState())) {
                z3 = false;
            }
        }
        if (z3) {
            onTransitionEnd$animation_core();
        }
    }

    public /* synthetic */ v0(z0 z0Var, v0 v0Var, String str, int i2, AbstractC1378g abstractC1378g) {
        this(z0Var, v0Var, (i2 & 4) != 0 ? null : str);
    }

    public /* synthetic */ v0(z0 z0Var, String str, int i2, AbstractC1378g abstractC1378g) {
        this(z0Var, (i2 & 2) != 0 ? null : str);
    }

    public v0(z0 z0Var, String str) {
        this(z0Var, null, str);
    }

    public v0(Object obj, String str) {
        this(new X(obj), null, str);
    }

    public /* synthetic */ v0(X x2, String str, int i2, AbstractC1378g abstractC1378g) {
        this(x2, (i2 & 2) != 0 ? null : str);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public v0(X x2, String str) {
        this(x2, null, str);
        kotlin.jvm.internal.o.c(x2, "null cannot be cast to non-null type androidx.compose.animation.core.TransitionState<S of androidx.compose.animation.core.Transition>");
    }
}
