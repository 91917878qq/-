package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.t0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0335t0 implements InterfaceC0303d {
    public static final int $stable = 8;
    private long _durationNanos;
    private AbstractC0329q _endVelocity;
    private final F0 animationSpec;
    private AbstractC0329q initialValueVector;
    private final AbstractC0329q initialVelocityVector;
    private Object mutableInitialValue;
    private Object mutableTargetValue;
    private AbstractC0329q targetValueVector;
    private final B0 typeConverter;

    public C0335t0(F0 f02, B0 b02, Object obj, Object obj2, AbstractC0329q abstractC0329q) {
        AbstractC0329q abstractC0329qCopy;
        this.animationSpec = f02;
        this.typeConverter = b02;
        this.mutableTargetValue = obj2;
        this.mutableInitialValue = obj;
        this.initialValueVector = (AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj);
        this.targetValueVector = (AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj2);
        this.initialVelocityVector = (abstractC0329q == null || (abstractC0329qCopy = r.copy(abstractC0329q)) == null) ? r.newInstance((AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj)) : abstractC0329qCopy;
        this._durationNanos = -1L;
    }

    private final AbstractC0329q getEndVelocity() {
        AbstractC0329q abstractC0329q = this._endVelocity;
        if (abstractC0329q != null) {
            return abstractC0329q;
        }
        AbstractC0329q endVelocity = this.animationSpec.getEndVelocity(this.initialValueVector, this.targetValueVector, this.initialVelocityVector);
        this._endVelocity = endVelocity;
        return endVelocity;
    }

    public final F0 getAnimationSpec$animation_core() {
        return this.animationSpec;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public long getDurationNanos() {
        if (this._durationNanos < 0) {
            this._durationNanos = this.animationSpec.getDurationNanos(this.initialValueVector, this.targetValueVector, this.initialVelocityVector);
        }
        return this._durationNanos;
    }

    public final Object getInitialValue() {
        return this.mutableInitialValue;
    }

    public final Object getMutableInitialValue$animation_core() {
        return this.mutableInitialValue;
    }

    public final Object getMutableTargetValue$animation_core() {
        return this.mutableTargetValue;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public Object getTargetValue() {
        return this.mutableTargetValue;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public B0 getTypeConverter() {
        return this.typeConverter;
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public Object getValueFromNanos(long j2) {
        if (isFinishedFromNanos(j2)) {
            return getTargetValue();
        }
        AbstractC0329q valueFromNanos = this.animationSpec.getValueFromNanos(j2, this.initialValueVector, this.targetValueVector, this.initialVelocityVector);
        int size$animation_core = valueFromNanos.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            if (Float.isNaN(valueFromNanos.get$animation_core(i2))) {
                AbstractC0300b0.throwIllegalStateException("AnimationVector cannot contain a NaN. " + valueFromNanos + ". Animation: " + this + ", playTimeNanos: " + j2);
            }
        }
        return getTypeConverter().getConvertFromVector().invoke(valueFromNanos);
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public AbstractC0329q getVelocityVectorFromNanos(long j2) {
        return !isFinishedFromNanos(j2) ? this.animationSpec.getVelocityFromNanos(j2, this.initialValueVector, this.targetValueVector, this.initialVelocityVector) : getEndVelocity();
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public /* bridge */ /* synthetic */ boolean isFinishedFromNanos(long j2) {
        return super.isFinishedFromNanos(j2);
    }

    @Override // androidx.compose.animation.core.InterfaceC0303d
    public boolean isInfinite() {
        return this.animationSpec.isInfinite();
    }

    public final void setMutableInitialValue$animation_core(Object obj) {
        if (kotlin.jvm.internal.o.a(obj, this.mutableInitialValue)) {
            return;
        }
        this.mutableInitialValue = obj;
        this.initialValueVector = (AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj);
        this._endVelocity = null;
        this._durationNanos = -1L;
    }

    public final void setMutableTargetValue$animation_core(Object obj) {
        if (kotlin.jvm.internal.o.a(this.mutableTargetValue, obj)) {
            return;
        }
        this.mutableTargetValue = obj;
        this.targetValueVector = (AbstractC0329q) getTypeConverter().getConvertToVector().invoke(obj);
        this._endVelocity = null;
        this._durationNanos = -1L;
    }

    public String toString() {
        return "TargetBasedAnimation: " + getInitialValue() + " -> " + getTargetValue() + ",initial velocity: " + this.initialVelocityVector + ", duration: " + AbstractC0307f.getDurationMillis(this) + " ms,animationSpec: " + this.animationSpec;
    }

    public /* synthetic */ C0335t0(F0 f02, B0 b02, Object obj, Object obj2, AbstractC0329q abstractC0329q, int i2, AbstractC1378g abstractC1378g) {
        this(f02, b02, obj, obj2, (i2 & 16) != 0 ? null : abstractC0329q);
    }

    public /* synthetic */ C0335t0(InterfaceC0313i interfaceC0313i, B0 b02, Object obj, Object obj2, AbstractC0329q abstractC0329q, int i2, AbstractC1378g abstractC1378g) {
        this(interfaceC0313i, b02, obj, obj2, (i2 & 16) != 0 ? null : abstractC0329q);
    }

    public C0335t0(InterfaceC0313i interfaceC0313i, B0 b02, Object obj, Object obj2, AbstractC0329q abstractC0329q) {
        this(interfaceC0313i.vectorize(b02), b02, obj, obj2, abstractC0329q);
    }
}
