package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import e0.C1311h;
import kotlin.jvm.internal.C1379h;
import r1.InterfaceC1474x;

/* JADX INFO: renamed from: androidx.compose.animation.core.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0301c {
    private static final C0316j0 defaultAnimation = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
    private static final C0316j0 dpDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, C1311h.m5074boximpl(U0.getVisibilityThreshold(C1311h.Companion)), 3, null);
    private static final C0316j0 sizeDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, J.l.m107boximpl(U0.getVisibilityThreshold(J.l.Companion)), 3, null);
    private static final C0316j0 offsetDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, J.f.m39boximpl(U0.getVisibilityThreshold(J.f.Companion)), 3, null);
    private static final C0316j0 rectDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, U0.getVisibilityThreshold(J.h.Companion), 3, null);
    private static final C0316j0 intDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, Integer.valueOf(U0.getVisibilityThreshold(kotlin.jvm.internal.m.f3126a)), 3, null);
    private static final C0316j0 intOffsetDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 3, null);
    private static final C0316j0 intSizeDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 3, null);

    /* JADX INFO: renamed from: androidx.compose.animation.core.c$a */
    public static final class a extends a1.j implements h1.e {
        final /* synthetic */ d2 $animSpec$delegate;
        final /* synthetic */ C0297a $animatable;
        final /* synthetic */ t1.g $channel;
        final /* synthetic */ d2 $listener$delegate;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX INFO: renamed from: androidx.compose.animation.core.c$a$a, reason: collision with other inner class name */
        public static final class C0015a extends a1.j implements h1.e {
            final /* synthetic */ d2 $animSpec$delegate;
            final /* synthetic */ C0297a $animatable;
            final /* synthetic */ d2 $listener$delegate;
            final /* synthetic */ T $newTarget;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0015a(T t2, C0297a c0297a, d2 d2Var, d2 d2Var2, Y0.c cVar) {
                super(2, cVar);
                this.$newTarget = t2;
                this.$animatable = c0297a;
                this.$animSpec$delegate = d2Var;
                this.$listener$delegate = d2Var2;
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                return new C0015a(this.$newTarget, this.$animatable, this.$animSpec$delegate, this.$listener$delegate, cVar);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                int i2 = this.label;
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    if (!kotlin.jvm.internal.o.a(this.$newTarget, this.$animatable.getTargetValue())) {
                        C0297a c0297a = this.$animatable;
                        T t2 = this.$newTarget;
                        InterfaceC0313i interfaceC0313iAnimateValueAsState$lambda$6 = AbstractC0301c.animateValueAsState$lambda$6(this.$animSpec$delegate);
                        this.label = 1;
                        if (C0297a.animateTo$default(c0297a, t2, interfaceC0313iAnimateValueAsState$lambda$6, null, null, this, 12, null) == aVar) {
                            return aVar;
                        }
                    }
                    return U0.n.f1521a;
                }
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
                h1.c cVarAnimateValueAsState$lambda$4 = AbstractC0301c.animateValueAsState$lambda$4(this.$listener$delegate);
                if (cVarAnimateValueAsState$lambda$4 != null) {
                    cVarAnimateValueAsState$lambda$4.invoke(this.$animatable.getValue());
                }
                return U0.n.f1521a;
            }

            @Override // h1.e
            public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
                return ((C0015a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(t1.g gVar, C0297a c0297a, d2 d2Var, d2 d2Var2, Y0.c cVar) {
            super(2, cVar);
            this.$channel = gVar;
            this.$animatable = c0297a;
            this.$animSpec$delegate = d2Var;
            this.$listener$delegate = d2Var2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            a aVar = new a(this.$channel, this.$animatable, this.$animSpec$delegate, this.$listener$delegate, cVar);
            aVar.L$0 = obj;
            return aVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:11:0x0037 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:14:0x0040  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x0068  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0035 -> B:12:0x0038). Please report as a decompilation issue!!! */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r14) throws java.lang.Throwable {
            /*
                r13 = this;
                Z0.a r0 = Z0.a.f1616b
                int r1 = r13.label
                r2 = 1
                if (r1 == 0) goto L1d
                if (r1 != r2) goto L15
                java.lang.Object r1 = r13.L$1
                t1.b r1 = (t1.b) r1
                java.lang.Object r3 = r13.L$0
                r1.x r3 = (r1.InterfaceC1474x) r3
                a.AbstractC0292a.H(r14)
                goto L38
            L15:
                java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r14.<init>(r0)
                throw r14
            L1d:
                a.AbstractC0292a.H(r14)
                java.lang.Object r14 = r13.L$0
                r1.x r14 = (r1.InterfaceC1474x) r14
                t1.g r1 = r13.$channel
                t1.b r1 = r1.iterator()
                r3 = r14
            L2b:
                r13.L$0 = r3
                r13.L$1 = r1
                r13.label = r2
                java.lang.Object r14 = r1.b(r13)
                if (r14 != r0) goto L38
                return r0
            L38:
                java.lang.Boolean r14 = (java.lang.Boolean) r14
                boolean r14 = r14.booleanValue()
                if (r14 == 0) goto L68
                java.lang.Object r14 = r1.c()
                t1.g r4 = r13.$channel
                java.lang.Object r4 = r4.j()
                boolean r5 = r4 instanceof t1.i
                r6 = 0
                if (r5 != 0) goto L50
                goto L51
            L50:
                r4 = r6
            L51:
                if (r4 != 0) goto L55
                r8 = r14
                goto L56
            L55:
                r8 = r4
            L56:
                androidx.compose.animation.core.c$a$a r14 = new androidx.compose.animation.core.c$a$a
                androidx.compose.animation.core.a r9 = r13.$animatable
                androidx.compose.runtime.d2 r10 = r13.$animSpec$delegate
                androidx.compose.runtime.d2 r11 = r13.$listener$delegate
                r12 = 0
                r7 = r14
                r7.<init>(r8, r9, r10, r11, r12)
                r4 = 3
                r1.AbstractC1476z.s(r3, r6, r6, r14, r4)
                goto L2b
            L68:
                U0.n r14 = U0.n.f1521a
                return r14
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.animation.core.AbstractC0301c.a.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((a) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    /* JADX INFO: renamed from: animateDpAsState-AjpBEmI, reason: not valid java name */
    public static final d2 m597animateDpAsStateAjpBEmI(float f2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = dpDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            str = "DpAnimation";
        }
        String str2 = str;
        if ((i3 & 8) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1407150062, i2, -1, "androidx.compose.animation.core.animateDpAsState (AnimateAsState.kt:111)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(C1311h.m5074boximpl(f2), E0.getVectorConverter(C1311h.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    /* JADX INFO: renamed from: animateDpAsState-Kz89ssw, reason: not valid java name */
    public static final /* synthetic */ d2 m598animateDpAsStateKz89ssw(float f2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = dpDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(704104481, i2, -1, "androidx.compose.animation.core.animateDpAsState (AnimateAsState.kt:462)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(C1311h.m5074boximpl(f2), E0.getVectorConverter(C1311h.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    public static final d2 animateFloatAsState(float f2, InterfaceC0313i interfaceC0313i, float f3, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2;
        InterfaceC0313i interfaceC0313i3 = (i3 & 2) != 0 ? defaultAnimation : interfaceC0313i;
        float f4 = (i3 & 4) != 0 ? 0.01f : f3;
        String str2 = (i3 & 8) != 0 ? "FloatAnimation" : str;
        h1.c cVar2 = (i3 & 16) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(668842840, i2, -1, "androidx.compose.animation.core.animateFloatAsState (AnimateAsState.kt:67)");
        }
        if (interfaceC0313i3 == defaultAnimation) {
            interfaceC0768p.startReplaceGroup(1144108831);
            boolean z2 = (((i2 & 896) ^ 384) > 256 && interfaceC0768p.changed(f4)) || (i2 & 384) == 256;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = AbstractC0315j.spring$default(0.0f, 0.0f, Float.valueOf(f4), 3, null);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0313i2 = (C0316j0) objRememberedValue;
            interfaceC0768p.endReplaceGroup();
        } else {
            interfaceC0768p.startReplaceGroup(1144218757);
            interfaceC0768p.endReplaceGroup();
            interfaceC0313i2 = interfaceC0313i3;
        }
        int i4 = i2 << 3;
        d2 d2VarAnimateValueAsState = animateValueAsState(Float.valueOf(f2), E0.getVectorConverter(C1379h.f3125a), interfaceC0313i2, Float.valueOf(f4), str2, cVar2, interfaceC0768p, (i2 & 14) | (i4 & 7168) | (57344 & i4) | (i4 & 458752), 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    public static final d2 animateIntAsState(int i2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i3, int i4) {
        if ((i4 & 2) != 0) {
            interfaceC0313i = intDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i4 & 4) != 0) {
            str = "IntAnimation";
        }
        String str2 = str;
        if ((i4 & 8) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(428074472, i3, -1, "androidx.compose.animation.core.animateIntAsState (AnimateAsState.kt:270)");
        }
        int i5 = i3 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(Integer.valueOf(i2), E0.getVectorConverter(kotlin.jvm.internal.m.f3126a), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i3 & 14) | ((i3 << 3) & 896) | (57344 & i5) | (i5 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    /* JADX INFO: renamed from: animateIntOffsetAsState-8f6pmRE, reason: not valid java name */
    public static final /* synthetic */ d2 m599animateIntOffsetAsState8f6pmRE(long j2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = intOffsetDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1010307371, i2, -1, "androidx.compose.animation.core.animateIntOffsetAsState (AnimateAsState.kt:552)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(e0.o.m5187boximpl(j2), E0.getVectorConverter(e0.o.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    /* JADX INFO: renamed from: animateIntOffsetAsState-HyPO7BM, reason: not valid java name */
    public static final d2 m600animateIntOffsetAsStateHyPO7BM(long j2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2 = (i3 & 2) != 0 ? intOffsetDefaultSpring : interfaceC0313i;
        String str2 = (i3 & 4) != 0 ? "IntOffsetAnimation" : str;
        h1.c cVar2 = (i3 & 8) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-696782904, i2, -1, "androidx.compose.animation.core.animateIntOffsetAsState (AnimateAsState.kt:309)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(e0.o.m5187boximpl(j2), E0.getVectorConverter(e0.o.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    /* JADX INFO: renamed from: animateIntSizeAsState-4goxYXU, reason: not valid java name */
    public static final d2 m601animateIntSizeAsState4goxYXU(long j2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2 = (i3 & 2) != 0 ? intSizeDefaultSpring : interfaceC0313i;
        String str2 = (i3 & 4) != 0 ? "IntSizeAnimation" : str;
        h1.c cVar2 = (i3 & 8) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(582576328, i2, -1, "androidx.compose.animation.core.animateIntSizeAsState (AnimateAsState.kt:347)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(e0.s.m5231boximpl(j2), E0.getVectorConverter(e0.s.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    /* JADX INFO: renamed from: animateIntSizeAsState-zTRF_AQ, reason: not valid java name */
    public static final /* synthetic */ d2 m602animateIntSizeAsStatezTRF_AQ(long j2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = intSizeDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1749239765, i2, -1, "androidx.compose.animation.core.animateIntSizeAsState (AnimateAsState.kt:570)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(e0.s.m5231boximpl(j2), E0.getVectorConverter(e0.s.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    /* JADX INFO: renamed from: animateOffsetAsState-7362WCg, reason: not valid java name */
    public static final d2 m603animateOffsetAsState7362WCg(long j2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2 = (i3 & 2) != 0 ? offsetDefaultSpring : interfaceC0313i;
        String str2 = (i3 & 4) != 0 ? "OffsetAnimation" : str;
        h1.c cVar2 = (i3 & 8) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(357896800, i2, -1, "androidx.compose.animation.core.animateOffsetAsState (AnimateAsState.kt:191)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(J.f.m39boximpl(j2), E0.getVectorConverter(J.f.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    /* JADX INFO: renamed from: animateOffsetAsState-N6fFfp4, reason: not valid java name */
    public static final /* synthetic */ d2 m604animateOffsetAsStateN6fFfp4(long j2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = offsetDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-456513133, i2, -1, "androidx.compose.animation.core.animateOffsetAsState (AnimateAsState.kt:498)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(J.f.m39boximpl(j2), E0.getVectorConverter(J.f.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    public static final d2 animateRectAsState(J.h hVar, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = rectDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            str = "RectAnimation";
        }
        String str2 = str;
        if ((i3 & 8) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(536062978, i2, -1, "androidx.compose.animation.core.animateRectAsState (AnimateAsState.kt:232)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(hVar, E0.getVectorConverter(J.h.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    /* JADX INFO: renamed from: animateSizeAsState-LjSzlW0, reason: not valid java name */
    public static final /* synthetic */ d2 m605animateSizeAsStateLjSzlW0(long j2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = sizeDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(875212471, i2, -1, "androidx.compose.animation.core.animateSizeAsState (AnimateAsState.kt:480)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(J.l.m107boximpl(j2), E0.getVectorConverter(J.l.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    /* JADX INFO: renamed from: animateSizeAsState-YLp_XPw, reason: not valid java name */
    public static final d2 m606animateSizeAsStateYLp_XPw(long j2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2 = (i3 & 2) != 0 ? sizeDefaultSpring : interfaceC0313i;
        String str2 = (i3 & 4) != 0 ? "SizeAnimation" : str;
        h1.c cVar2 = (i3 & 8) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1374633148, i2, -1, "androidx.compose.animation.core.animateSizeAsState (AnimateAsState.kt:152)");
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = animateValueAsState(J.l.m107boximpl(j2), E0.getVectorConverter(J.l.Companion), interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    public static final <T, V extends AbstractC0329q> d2 animateValueAsState(T t2, B0 b02, InterfaceC0313i interfaceC0313i, T t3, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313iSpring;
        if ((i3 & 4) != 0) {
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0313iSpring = (C0316j0) objRememberedValue;
        } else {
            interfaceC0313iSpring = interfaceC0313i;
        }
        T t4 = (i3 & 8) != 0 ? null : t3;
        String str2 = (i3 & 16) != 0 ? "ValueAnimation" : str;
        h1.c cVar2 = (i3 & 32) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1994373980, i2, -1, "androidx.compose.animation.core.animateValueAsState (AnimateAsState.kt:395)");
        }
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        C0765o c0765o = InterfaceC0768p.Companion;
        if (objRememberedValue2 == c0765o.getEmpty()) {
            objRememberedValue2 = V1.mutableStateOf$default(null, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.B0 b03 = (androidx.compose.runtime.B0) objRememberedValue2;
        Object objRememberedValue3 = interfaceC0768p.rememberedValue();
        if (objRememberedValue3 == c0765o.getEmpty()) {
            objRememberedValue3 = new C0297a(t2, b02, t4, str2);
            interfaceC0768p.updateRememberedValue(objRememberedValue3);
        }
        C0297a c0297a = (C0297a) objRememberedValue3;
        d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(cVar2, interfaceC0768p, (i2 >> 15) & 14);
        if (t4 != null && (interfaceC0313iSpring instanceof C0316j0)) {
            C0316j0 c0316j0 = (C0316j0) interfaceC0313iSpring;
            if (!kotlin.jvm.internal.o.a(c0316j0.getVisibilityThreshold(), t4)) {
                interfaceC0313iSpring = AbstractC0315j.spring(c0316j0.getDampingRatio(), c0316j0.getStiffness(), t4);
            }
        }
        d2 d2VarRememberUpdatedState2 = Q1.rememberUpdatedState(interfaceC0313iSpring, interfaceC0768p, 0);
        Object objRememberedValue4 = interfaceC0768p.rememberedValue();
        if (objRememberedValue4 == c0765o.getEmpty()) {
            objRememberedValue4 = t1.j.a(-1, 6, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue4);
        }
        t1.g gVar = (t1.g) objRememberedValue4;
        boolean zChangedInstance = ((((i2 & 14) ^ 6) > 4 && interfaceC0768p.changedInstance(t2)) || (i2 & 6) == 4) | interfaceC0768p.changedInstance(gVar);
        Object objRememberedValue5 = interfaceC0768p.rememberedValue();
        if (zChangedInstance || objRememberedValue5 == c0765o.getEmpty()) {
            objRememberedValue5 = new I.g(1, gVar, t2);
            interfaceC0768p.updateRememberedValue(objRememberedValue5);
        }
        androidx.compose.runtime.Z.SideEffect((h1.a) objRememberedValue5, interfaceC0768p, 0);
        boolean zChangedInstance2 = interfaceC0768p.changedInstance(gVar) | interfaceC0768p.changedInstance(c0297a) | interfaceC0768p.changed(d2VarRememberUpdatedState2) | interfaceC0768p.changed(d2VarRememberUpdatedState);
        Object objRememberedValue6 = interfaceC0768p.rememberedValue();
        if (zChangedInstance2 || objRememberedValue6 == c0765o.getEmpty()) {
            objRememberedValue6 = new a(gVar, c0297a, d2VarRememberUpdatedState2, d2VarRememberUpdatedState, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue6);
        }
        androidx.compose.runtime.Z.LaunchedEffect(gVar, (h1.e) objRememberedValue6, interfaceC0768p, 0);
        d2 d2VarAsState = (d2) b03.getValue();
        if (d2VarAsState == null) {
            d2VarAsState = c0297a.asState();
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAsState;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <T> h1.c animateValueAsState$lambda$4(d2 d2Var) {
        return (h1.c) d2Var.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <T> InterfaceC0313i animateValueAsState$lambda$6(d2 d2Var) {
        return (InterfaceC0313i) d2Var.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n animateValueAsState$lambda$9$lambda$8(t1.g gVar, Object obj) {
        gVar.l(obj);
        return U0.n.f1521a;
    }

    @U0.a
    public static final /* synthetic */ d2 animateRectAsState(J.h hVar, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = rectDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-782613967, i2, -1, "androidx.compose.animation.core.animateRectAsState (AnimateAsState.kt:516)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(hVar, E0.getVectorConverter(J.h.Companion), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | ((i2 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    public static final /* synthetic */ d2 animateIntAsState(int i2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i3, int i4) {
        if ((i4 & 2) != 0) {
            interfaceC0313i = intDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i4 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-842612981, i3, -1, "androidx.compose.animation.core.animateIntAsState (AnimateAsState.kt:534)");
        }
        d2 d2VarAnimateValueAsState = animateValueAsState(Integer.valueOf(i2), E0.getVectorConverter(kotlin.jvm.internal.m.f3126a), interfaceC0313i2, null, null, cVar2, interfaceC0768p, (i3 & 14) | ((i3 << 3) & 896) | ((i3 << 9) & 458752), 24);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }

    @U0.a
    public static final /* synthetic */ d2 animateFloatAsState(float f2, InterfaceC0313i interfaceC0313i, float f3, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = defaultAnimation;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            f3 = 0.01f;
        }
        float f4 = f3;
        if ((i3 & 8) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1091643291, i2, -1, "androidx.compose.animation.core.animateFloatAsState (AnimateAsState.kt:446)");
        }
        d2 d2VarAnimateFloatAsState = animateFloatAsState(f2, interfaceC0313i2, f4, null, cVar2, interfaceC0768p, (i2 & 1022) | ((i2 << 3) & 57344), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateFloatAsState;
    }

    @U0.a
    public static final /* synthetic */ d2 animateValueAsState(Object obj, B0 b02, InterfaceC0313i interfaceC0313i, Object obj2, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2;
        if ((i3 & 4) != 0) {
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            interfaceC0313i2 = (C0316j0) objRememberedValue;
        } else {
            interfaceC0313i2 = interfaceC0313i;
        }
        Object obj3 = (i3 & 8) != 0 ? null : obj2;
        h1.c cVar2 = (i3 & 16) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-846382129, i2, -1, "androidx.compose.animation.core.animateValueAsState (AnimateAsState.kt:591)");
        }
        int i4 = i2 & 8;
        d2 d2VarAnimateValueAsState = animateValueAsState(obj, b02, interfaceC0313i2, obj3, "ValueAnimation", cVar2, interfaceC0768p, (i4 << 9) | i4 | 24576 | (i2 & 14) | (i2 & 112) | (i2 & 896) | (i2 & 7168) | ((i2 << 3) & 458752), 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }
}
