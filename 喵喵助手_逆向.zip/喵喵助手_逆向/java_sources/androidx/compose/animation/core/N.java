package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import java.util.List;
import kotlin.jvm.internal.AbstractC1378g;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class N {
    public static final int $stable = 8;
    private final String label;
    private final androidx.compose.runtime.collection.c _animations = new androidx.compose.runtime.collection.c(new a[16], 0);
    private final androidx.compose.runtime.B0 refreshChildNeeded$delegate = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
    private long startTimeNanos = Long.MIN_VALUE;
    private final androidx.compose.runtime.B0 isRunning$delegate = V1.mutableStateOf$default(Boolean.TRUE, null, 2, null);

    public final class a implements d2 {
        private C0335t0 animation;
        private InterfaceC0313i animationSpec;
        private Object initialValue;
        private boolean isFinished;
        private final String label;
        private long playTimeNanosOffset;
        private boolean startOnTheNextFrame;
        private Object targetValue;
        private final B0 typeConverter;
        private final androidx.compose.runtime.B0 value$delegate;

        public a(Object obj, Object obj2, B0 b02, InterfaceC0313i interfaceC0313i, String str) {
            this.initialValue = obj;
            this.targetValue = obj2;
            this.typeConverter = b02;
            this.label = str;
            this.value$delegate = V1.mutableStateOf$default(obj, null, 2, null);
            this.animationSpec = interfaceC0313i;
            this.animation = new C0335t0(interfaceC0313i, b02, this.initialValue, this.targetValue, (AbstractC0329q) null, 16, (AbstractC1378g) null);
        }

        public final C0335t0 getAnimation() {
            return this.animation;
        }

        public final InterfaceC0313i getAnimationSpec() {
            return this.animationSpec;
        }

        public final Object getInitialValue$animation_core() {
            return this.initialValue;
        }

        public final String getLabel() {
            return this.label;
        }

        public final Object getTargetValue$animation_core() {
            return this.targetValue;
        }

        public final B0 getTypeConverter() {
            return this.typeConverter;
        }

        @Override // androidx.compose.runtime.d2
        public Object getValue() {
            return this.value$delegate.getValue();
        }

        public final boolean isFinished$animation_core() {
            return this.isFinished;
        }

        public final void onPlayTimeChanged$animation_core(long j2) {
            N.this.setRefreshChildNeeded(false);
            if (this.startOnTheNextFrame) {
                this.startOnTheNextFrame = false;
                this.playTimeNanosOffset = j2;
            }
            long j3 = j2 - this.playTimeNanosOffset;
            setValue$animation_core(this.animation.getValueFromNanos(j3));
            this.isFinished = this.animation.isFinishedFromNanos(j3);
        }

        public final void reset$animation_core() {
            this.startOnTheNextFrame = true;
        }

        public final void setAnimation$animation_core(C0335t0 c0335t0) {
            this.animation = c0335t0;
        }

        public final void setFinished$animation_core(boolean z2) {
            this.isFinished = z2;
        }

        public final void setInitialValue$animation_core(Object obj) {
            this.initialValue = obj;
        }

        public final void setTargetValue$animation_core(Object obj) {
            this.targetValue = obj;
        }

        public void setValue$animation_core(Object obj) {
            this.value$delegate.setValue(obj);
        }

        public final void skipToEnd$animation_core() {
            setValue$animation_core(this.animation.getTargetValue());
            this.startOnTheNextFrame = true;
        }

        public final void updateValues$animation_core(Object obj, Object obj2, InterfaceC0313i interfaceC0313i) {
            this.initialValue = obj;
            this.targetValue = obj2;
            this.animationSpec = interfaceC0313i;
            this.animation = new C0335t0(interfaceC0313i, this.typeConverter, obj, obj2, (AbstractC0329q) null, 16, (AbstractC1378g) null);
            N.this.setRefreshChildNeeded(true);
            this.isFinished = false;
            this.startOnTheNextFrame = true;
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ androidx.compose.runtime.B0 $toolingOverride;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ N this$0;

        public static final class a extends a1.j implements h1.e {
            /* synthetic */ float F$0;
            int label;

            public a(Y0.c cVar) {
                super(2, cVar);
            }

            @Override // a1.a
            public final Y0.c create(Object obj, Y0.c cVar) {
                a aVar = new a(cVar);
                aVar.F$0 = ((Number) obj).floatValue();
                return aVar;
            }

            public final Object invoke(float f2, Y0.c cVar) {
                return ((a) create(Float.valueOf(f2), cVar)).invokeSuspend(U0.n.f1521a);
            }

            @Override // a1.a
            public final Object invokeSuspend(Object obj) {
                Z0.a aVar = Z0.a.f1616b;
                if (this.label != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
                return Boolean.valueOf(this.F$0 > 0.0f);
            }

            @Override // h1.e
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
                return invoke(((Number) obj).floatValue(), (Y0.c) obj2);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(androidx.compose.runtime.B0 b02, N n2, Y0.c cVar) {
            super(2, cVar);
            this.$toolingOverride = b02;
            this.this$0 = n2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$2(androidx.compose.runtime.B0 b02, N n2, kotlin.jvm.internal.B b2, InterfaceC1474x interfaceC1474x, long j2) {
            d2 d2Var = (d2) b02.getValue();
            long jLongValue = d2Var != null ? ((Number) d2Var.getValue()).longValue() : j2;
            if (n2.startTimeNanos == Long.MIN_VALUE || b2.f3115b != AbstractC0333s0.getDurationScale(interfaceC1474x.getCoroutineContext())) {
                n2.startTimeNanos = j2;
                androidx.compose.runtime.collection.c cVar = n2._animations;
                Object[] objArr = cVar.content;
                int size = cVar.getSize();
                for (int i2 = 0; i2 < size; i2++) {
                    ((a) objArr[i2]).reset$animation_core();
                }
                b2.f3115b = AbstractC0333s0.getDurationScale(interfaceC1474x.getCoroutineContext());
            }
            if (b2.f3115b == 0.0f) {
                androidx.compose.runtime.collection.c cVar2 = n2._animations;
                Object[] objArr2 = cVar2.content;
                int size2 = cVar2.getSize();
                for (int i3 = 0; i3 < size2; i3++) {
                    ((a) objArr2[i3]).skipToEnd$animation_core();
                }
            } else {
                n2.onFrame((long) ((jLongValue - n2.startTimeNanos) / b2.f3115b));
            }
            return U0.n.f1521a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final float invokeSuspend$lambda$3(InterfaceC1474x interfaceC1474x) {
            return AbstractC0333s0.getDurationScale(interfaceC1474x.getCoroutineContext());
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            b bVar = new b(this.$toolingOverride, this.this$0, cVar);
            bVar.L$0 = obj;
            return bVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0053 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:16:0x005b  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:15:0x0059 -> B:11:0x003e). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0075 -> B:11:0x003e). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // a1.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            /*
                r7 = this;
                Z0.a r0 = Z0.a.f1616b
                int r1 = r7.label
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L2e
                if (r1 == r3) goto L21
                if (r1 != r2) goto L19
                java.lang.Object r1 = r7.L$1
                kotlin.jvm.internal.B r1 = (kotlin.jvm.internal.B) r1
                java.lang.Object r4 = r7.L$0
                r1.x r4 = (r1.InterfaceC1474x) r4
                a.AbstractC0292a.H(r8)
                r8 = r4
                goto L3e
            L19:
                java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r8.<init>(r0)
                throw r8
            L21:
                java.lang.Object r1 = r7.L$1
                kotlin.jvm.internal.B r1 = (kotlin.jvm.internal.B) r1
                java.lang.Object r4 = r7.L$0
                r1.x r4 = (r1.InterfaceC1474x) r4
                a.AbstractC0292a.H(r8)
                r8 = r4
                goto L54
            L2e:
                a.AbstractC0292a.H(r8)
                java.lang.Object r8 = r7.L$0
                r1.x r8 = (r1.InterfaceC1474x) r8
                kotlin.jvm.internal.B r1 = new kotlin.jvm.internal.B
                r1.<init>()
                r4 = 1065353216(0x3f800000, float:1.0)
                r1.f3115b = r4
            L3e:
                androidx.compose.runtime.B0 r4 = r7.$toolingOverride
                androidx.compose.animation.core.N r5 = r7.this$0
                M0.q r6 = new M0.q
                r6.<init>(r4, r5, r1, r8)
                r7.L$0 = r8
                r7.L$1 = r1
                r7.label = r3
                java.lang.Object r4 = androidx.compose.animation.core.L.withInfiniteAnimationFrameNanos(r6, r7)
                if (r4 != r0) goto L54
                return r0
            L54:
                float r4 = r1.f3115b
                r5 = 0
                int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
                if (r4 != 0) goto L3e
                E0.f r4 = new E0.f
                r5 = 5
                r4.<init>(r8, r5)
                u1.d r4 = androidx.compose.runtime.Q1.snapshotFlow(r4)
                androidx.compose.animation.core.N$b$a r5 = new androidx.compose.animation.core.N$b$a
                r6 = 0
                r5.<init>(r6)
                r7.L$0 = r8
                r7.L$1 = r1
                r7.label = r2
                java.lang.Object r4 = u1.D.h(r4, r5, r7)
                if (r4 != r0) goto L3e
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.compose.animation.core.N.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public N(String str) {
        this.label = str;
    }

    private final boolean getRefreshChildNeeded() {
        return ((Boolean) this.refreshChildNeeded$delegate.getValue()).booleanValue();
    }

    private final boolean isRunning() {
        return ((Boolean) this.isRunning$delegate.getValue()).booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onFrame(long j2) {
        androidx.compose.runtime.collection.c cVar = this._animations;
        Object[] objArr = cVar.content;
        int size = cVar.getSize();
        boolean z2 = true;
        for (int i2 = 0; i2 < size; i2++) {
            a aVar = (a) objArr[i2];
            if (!aVar.isFinished$animation_core()) {
                aVar.onPlayTimeChanged$animation_core(j2);
            }
            if (!aVar.isFinished$animation_core()) {
                z2 = false;
            }
        }
        setRunning(!z2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n run$lambda$2(N n2, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        n2.run$animation_core(interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1));
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setRefreshChildNeeded(boolean z2) {
        this.refreshChildNeeded$delegate.setValue(Boolean.valueOf(z2));
    }

    private final void setRunning(boolean z2) {
        this.isRunning$delegate.setValue(Boolean.valueOf(z2));
    }

    public final void addAnimation$animation_core(a aVar) {
        this._animations.add(aVar);
        setRefreshChildNeeded(true);
    }

    public final List<a> getAnimations() {
        return this._animations.asMutableList();
    }

    public final String getLabel() {
        return this.label;
    }

    public final void removeAnimation$animation_core(a aVar) {
        this._animations.remove(aVar);
    }

    public final void run$animation_core(InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-318043801);
        if ((i2 & 6) == 0) {
            i3 = (interfaceC0768pStartRestartGroup.changedInstance(this) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-318043801, i3, -1, "androidx.compose.animation.core.InfiniteTransition.run (InfiniteTransition.kt:164)");
            }
            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
            C0765o c0765o = InterfaceC0768p.Companion;
            if (objRememberedValue == c0765o.getEmpty()) {
                objRememberedValue = V1.mutableStateOf$default(null, null, 2, null);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.B0 b02 = (androidx.compose.runtime.B0) objRememberedValue;
            if (isRunning() || getRefreshChildNeeded()) {
                interfaceC0768pStartRestartGroup.startReplaceGroup(-144783432);
                boolean zChangedInstance = interfaceC0768pStartRestartGroup.changedInstance(this);
                Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue2 == c0765o.getEmpty()) {
                    objRememberedValue2 = new b(b02, this, null);
                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                androidx.compose.runtime.Z.LaunchedEffect(this, (h1.e) objRememberedValue2, interfaceC0768pStartRestartGroup, i3 & 14);
                interfaceC0768pStartRestartGroup.endReplaceGroup();
            } else {
                interfaceC0768pStartRestartGroup.startReplaceGroup(-143396709);
                interfaceC0768pStartRestartGroup.endReplaceGroup();
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new M0.k(this, i2, 2));
        }
    }
}
