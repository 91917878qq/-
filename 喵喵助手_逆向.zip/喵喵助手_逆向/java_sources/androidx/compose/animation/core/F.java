package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface F extends InterfaceC0313i {
    @Override // androidx.compose.animation.core.InterfaceC0313i
    /* synthetic */ F0 vectorize(B0 b02);

    @Override // androidx.compose.animation.core.InterfaceC0313i
    <V extends AbstractC0329q> J0 vectorize(B0 b02);
}
