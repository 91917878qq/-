package androidx.compose.animation.core;

import j.AbstractC1353k;
import j.AbstractC1355m;
import j.C1331B;
import j.C1332C;
import java.util.Iterator;
import java.util.Map;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class O0 implements I0 {
    public static final int $stable = 8;
    private C0336u arcSpline;
    private final C defaultEasing;
    private final int delayMillis;
    private final int durationMillis;
    private final int initialArcMode;
    private final AbstractC1355m keyframes;
    private AbstractC0329q lastInitialValue;
    private AbstractC0329q lastTargetValue;
    private int[] modes;
    private float[] posArray;
    private float[] slopeArray;
    private float[] times;
    private final AbstractC1353k timestamps;
    private AbstractC0329q valueVector;
    private AbstractC0329q velocityVector;

    public /* synthetic */ O0(AbstractC1353k abstractC1353k, AbstractC1355m abstractC1355m, int i2, int i3, C c2, int i4, AbstractC1378g abstractC1378g) {
        this(abstractC1353k, abstractC1355m, i2, i3, c2, i4);
    }

    private final int findEntryForTimeMillis(int i2) {
        int iA = AbstractC1353k.a(this.timestamps, i2);
        return iA < -1 ? -(iA + 2) : iA;
    }

    private final float getEasedTime(int i2) {
        return getEasedTimeFromIndex(findEntryForTimeMillis(i2), i2, false);
    }

    private final float getEasedTimeFromIndex(int i2, int i3, boolean z2) {
        C easing;
        float f2;
        AbstractC1353k abstractC1353k = this.timestamps;
        if (i2 >= abstractC1353k.f3020b - 1) {
            f2 = i3;
        } else {
            int iB = abstractC1353k.b(i2);
            int iB2 = this.timestamps.b(i2 + 1);
            if (i3 == iB) {
                f2 = iB;
            } else {
                int i4 = iB2 - iB;
                N0 n0 = (N0) this.keyframes.b(iB);
                if (n0 == null || (easing = n0.getEasing()) == null) {
                    easing = this.defaultEasing;
                }
                float f3 = i4;
                float fTransform = easing.transform((i3 - iB) / f3);
                if (z2) {
                    return fTransform;
                }
                f2 = (f3 * fTransform) + iB;
            }
        }
        return f2 / 1000;
    }

    private final void init(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        float[] fArr;
        boolean z2 = this.arcSpline != G0.EmptyArcSpline;
        if (this.valueVector == null) {
            this.valueVector = r.newInstance(abstractC0329q);
            this.velocityVector = r.newInstance(abstractC0329q3);
            int i2 = this.timestamps.f3020b;
            float[] fArr2 = new float[i2];
            for (int i3 = 0; i3 < i2; i3++) {
                fArr2[i3] = this.timestamps.b(i3) / 1000;
            }
            this.times = fArr2;
            int i4 = this.timestamps.f3020b;
            int[] iArr = new int[i4];
            for (int i5 = 0; i5 < i4; i5++) {
                N0 n0 = (N0) this.keyframes.b(this.timestamps.b(i5));
                int iM584getArcMode9TMq4 = n0 != null ? n0.m584getArcMode9TMq4() : this.initialArcMode;
                if (!C0334t.m636equalsimpl0(iM584getArcMode9TMq4, C0334t.Companion.m642getArcLinear9TMq4())) {
                    z2 = true;
                }
                iArr[i5] = iM584getArcMode9TMq4;
            }
            this.modes = iArr;
        }
        if (z2) {
            if (this.arcSpline != G0.EmptyArcSpline && kotlin.jvm.internal.o.a(this.lastInitialValue, abstractC0329q) && kotlin.jvm.internal.o.a(this.lastTargetValue, abstractC0329q2)) {
                return;
            }
            this.lastInitialValue = abstractC0329q;
            this.lastTargetValue = abstractC0329q2;
            int size$animation_core = abstractC0329q.getSize$animation_core() + (abstractC0329q.getSize$animation_core() % 2);
            this.posArray = new float[size$animation_core];
            this.slopeArray = new float[size$animation_core];
            int i6 = this.timestamps.f3020b;
            float[][] fArr3 = new float[i6][];
            for (int i7 = 0; i7 < i6; i7++) {
                int iB = this.timestamps.b(i7);
                N0 n02 = (N0) this.keyframes.b(iB);
                if (iB == 0 && n02 == null) {
                    fArr = new float[size$animation_core];
                    for (int i8 = 0; i8 < size$animation_core; i8++) {
                        fArr[i8] = abstractC0329q.get$animation_core(i8);
                    }
                } else if (iB == getDurationMillis() && n02 == null) {
                    fArr = new float[size$animation_core];
                    for (int i9 = 0; i9 < size$animation_core; i9++) {
                        fArr[i9] = abstractC0329q2.get$animation_core(i9);
                    }
                } else {
                    kotlin.jvm.internal.o.b(n02);
                    AbstractC0329q vectorValue = n02.getVectorValue();
                    float[] fArr4 = new float[size$animation_core];
                    for (int i10 = 0; i10 < size$animation_core; i10++) {
                        fArr4[i10] = vectorValue.get$animation_core(i10);
                    }
                    fArr = fArr4;
                }
                fArr3[i7] = fArr;
            }
            this.arcSpline = new C0336u(this.modes, this.times, fArr3);
        }
    }

    @Override // androidx.compose.animation.core.I0
    public int getDelayMillis() {
        return this.delayMillis;
    }

    @Override // androidx.compose.animation.core.I0
    public int getDurationMillis() {
        return this.durationMillis;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        AbstractC0329q vectorValue;
        AbstractC0329q vectorValue2;
        int iClampPlayTime = (int) G0.clampPlayTime(this, j2 / AbstractC0307f.MillisToNanos);
        N0 n0 = (N0) this.keyframes.b(iClampPlayTime);
        if (n0 != null) {
            return n0.getVectorValue();
        }
        if (iClampPlayTime >= getDurationMillis()) {
            return abstractC0329q2;
        }
        if (iClampPlayTime <= 0) {
            return abstractC0329q;
        }
        init(abstractC0329q, abstractC0329q2, abstractC0329q3);
        AbstractC0329q abstractC0329q4 = this.valueVector;
        kotlin.jvm.internal.o.b(abstractC0329q4);
        int i2 = 0;
        if (this.arcSpline != G0.EmptyArcSpline) {
            float easedTime = getEasedTime(iClampPlayTime);
            float[] fArr = this.posArray;
            this.arcSpline.getPos(easedTime, fArr);
            int length = fArr.length;
            while (i2 < length) {
                abstractC0329q4.set$animation_core(i2, fArr[i2]);
                i2++;
            }
            return abstractC0329q4;
        }
        int iFindEntryForTimeMillis = findEntryForTimeMillis(iClampPlayTime);
        float easedTimeFromIndex = getEasedTimeFromIndex(iFindEntryForTimeMillis, iClampPlayTime, true);
        N0 n02 = (N0) this.keyframes.b(this.timestamps.b(iFindEntryForTimeMillis));
        if (n02 != null && (vectorValue2 = n02.getVectorValue()) != null) {
            abstractC0329q = vectorValue2;
        }
        N0 n03 = (N0) this.keyframes.b(this.timestamps.b(iFindEntryForTimeMillis + 1));
        if (n03 != null && (vectorValue = n03.getVectorValue()) != null) {
            abstractC0329q2 = vectorValue;
        }
        int size$animation_core = abstractC0329q4.getSize$animation_core();
        while (i2 < size$animation_core) {
            abstractC0329q4.set$animation_core(i2, (abstractC0329q2.get$animation_core(i2) * easedTimeFromIndex) + ((1 - easedTimeFromIndex) * abstractC0329q.get$animation_core(i2)));
            i2++;
        }
        return abstractC0329q4;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        long jClampPlayTime = G0.clampPlayTime(this, j2 / AbstractC0307f.MillisToNanos);
        if (jClampPlayTime < 0) {
            return abstractC0329q3;
        }
        init(abstractC0329q, abstractC0329q2, abstractC0329q3);
        AbstractC0329q abstractC0329q4 = this.velocityVector;
        kotlin.jvm.internal.o.b(abstractC0329q4);
        int i2 = 0;
        if (this.arcSpline == G0.EmptyArcSpline) {
            AbstractC0329q valueFromMillis = G0.getValueFromMillis(this, jClampPlayTime - 1, abstractC0329q, abstractC0329q2, abstractC0329q3);
            AbstractC0329q valueFromMillis2 = G0.getValueFromMillis(this, jClampPlayTime, abstractC0329q, abstractC0329q2, abstractC0329q3);
            int size$animation_core = valueFromMillis.getSize$animation_core();
            while (i2 < size$animation_core) {
                abstractC0329q4.set$animation_core(i2, (valueFromMillis.get$animation_core(i2) - valueFromMillis2.get$animation_core(i2)) * 1000.0f);
                i2++;
            }
            return abstractC0329q4;
        }
        float easedTime = getEasedTime((int) jClampPlayTime);
        float[] fArr = this.slopeArray;
        this.arcSpline.getSlope(easedTime, fArr);
        int length = fArr.length;
        while (i2 < length) {
            abstractC0329q4.set$animation_core(i2, fArr[i2]);
            i2++;
        }
        return abstractC0329q4;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }

    private O0(AbstractC1353k abstractC1353k, AbstractC1355m abstractC1355m, int i2, int i3, C c2, int i4) {
        this.timestamps = abstractC1353k;
        this.keyframes = abstractC1355m;
        this.durationMillis = i2;
        this.delayMillis = i3;
        this.defaultEasing = c2;
        this.initialArcMode = i4;
        this.modes = G0.EmptyIntArray;
        this.times = G0.EmptyFloatArray;
        this.posArray = G0.EmptyFloatArray;
        this.slopeArray = G0.EmptyFloatArray;
        this.arcSpline = G0.EmptyArcSpline;
    }

    public /* synthetic */ O0(Map map, int i2, int i3, int i4, AbstractC1378g abstractC1378g) {
        this(map, i2, (i4 & 4) != 0 ? 0 : i3);
    }

    public O0(Map<Integer, ? extends U0.g> map, int i2, int i3) {
        C1331B c1331b = new C1331B(map.size() + 2);
        Iterator<Map.Entry<Integer, ? extends U0.g>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            c1331b.d(it.next().getKey().intValue());
        }
        if (!map.containsKey(0)) {
            c1331b.c();
        }
        if (!map.containsKey(Integer.valueOf(i2))) {
            c1331b.d(i2);
        }
        c1331b.h();
        C1332C c1332c = new C1332C();
        for (Map.Entry<Integer, ? extends U0.g> entry : map.entrySet()) {
            int iIntValue = entry.getKey().intValue();
            U0.g value = entry.getValue();
            c1332c.i(iIntValue, new N0((AbstractC0329q) value.f1511b, (C) value.f1512c, C0334t.Companion.m642getArcLinear9TMq4(), null));
        }
        this(c1331b, c1332c, i2, i3, E.getLinearEasing(), C0334t.Companion.m642getArcLinear9TMq4(), null);
    }
}
