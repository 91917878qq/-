package androidx.compose.animation.core;

import a.AbstractC0292a;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0297a {
    public static final int $stable = 8;
    private final C0316j0 defaultSpringSpec;
    private final C0317k internalState;
    private final androidx.compose.runtime.B0 isRunning$delegate;
    private final String label;
    private Object lowerBound;
    private AbstractC0329q lowerBoundVector;
    private final C0298a0 mutatorMutex;
    private final AbstractC0329q negativeInfinityBounds;
    private final AbstractC0329q positiveInfinityBounds;
    private final androidx.compose.runtime.B0 targetValue$delegate;
    private final B0 typeConverter;
    private Object upperBound;
    private AbstractC0329q upperBoundVector;
    private final Object visibilityThreshold;

    /* JADX INFO: renamed from: androidx.compose.animation.core.a$a, reason: collision with other inner class name */
    public static final class C0014a extends a1.j implements h1.c {
        final /* synthetic */ InterfaceC0303d $animation;
        final /* synthetic */ h1.c $block;
        final /* synthetic */ Object $initialVelocity;
        final /* synthetic */ long $startTime;
        Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0014a(Object obj, InterfaceC0303d interfaceC0303d, long j2, h1.c cVar, Y0.c cVar2) {
            super(1, cVar2);
            this.$initialVelocity = obj;
            this.$animation = interfaceC0303d;
            this.$startTime = j2;
            this.$block = cVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final U0.n invokeSuspend$lambda$0(C0297a c0297a, C0317k c0317k, h1.c cVar, kotlin.jvm.internal.A a2, C0311h c0311h) {
            AbstractC0333s0.updateState(c0311h, c0297a.getInternalState$animation_core());
            Object objClampToBounds = c0297a.clampToBounds(c0311h.getValue());
            if (!kotlin.jvm.internal.o.a(objClampToBounds, c0311h.getValue())) {
                c0297a.getInternalState$animation_core().setValue$animation_core(objClampToBounds);
                c0317k.setValue$animation_core(objClampToBounds);
                if (cVar != null) {
                    cVar.invoke(c0297a);
                }
                c0311h.cancelAnimation();
                a2.f3114b = true;
            } else if (cVar != null) {
                cVar.invoke(c0297a);
            }
            return U0.n.f1521a;
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return C0297a.this.new C0014a(this.$initialVelocity, this.$animation, this.$startTime, this.$block, cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((C0014a) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            C0317k c0317k;
            kotlin.jvm.internal.A a2;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            try {
                if (i2 == 0) {
                    AbstractC0292a.H(obj);
                    C0297a.this.getInternalState$animation_core().setVelocityVector$animation_core((AbstractC0329q) C0297a.this.getTypeConverter().getConvertToVector().invoke(this.$initialVelocity));
                    C0297a.this.setTargetValue(this.$animation.getTargetValue());
                    C0297a.this.setRunning(true);
                    C0317k c0317kCopy$default = AbstractC0319l.copy$default(C0297a.this.getInternalState$animation_core(), (Object) null, (AbstractC0329q) null, 0L, Long.MIN_VALUE, false, 23, (Object) null);
                    kotlin.jvm.internal.A a3 = new kotlin.jvm.internal.A();
                    InterfaceC0303d interfaceC0303d = this.$animation;
                    long j2 = this.$startTime;
                    M0.q qVar = new M0.q(C0297a.this, c0317kCopy$default, this.$block, a3);
                    this.L$0 = c0317kCopy$default;
                    this.L$1 = a3;
                    this.label = 1;
                    if (AbstractC0333s0.animate(c0317kCopy$default, interfaceC0303d, j2, qVar, this) == aVar) {
                        return aVar;
                    }
                    c0317k = c0317kCopy$default;
                    a2 = a3;
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    a2 = (kotlin.jvm.internal.A) this.L$1;
                    c0317k = (C0317k) this.L$0;
                    AbstractC0292a.H(obj);
                }
                EnumC0305e enumC0305e = a2.f3114b ? EnumC0305e.BoundReached : EnumC0305e.Finished;
                C0297a.this.endAnimation();
                return new C0309g(c0317k, enumC0305e);
            } catch (CancellationException e2) {
                C0297a.this.endAnimation();
                throw e2;
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.a$b */
    public static final class b extends a1.j implements h1.c {
        final /* synthetic */ Object $targetValue;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(Object obj, Y0.c cVar) {
            super(1, cVar);
            this.$targetValue = obj;
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return C0297a.this.new b(this.$targetValue, cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((b) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            C0297a.this.endAnimation();
            Object objClampToBounds = C0297a.this.clampToBounds(this.$targetValue);
            C0297a.this.getInternalState$animation_core().setValue$animation_core(objClampToBounds);
            C0297a.this.setTargetValue(objClampToBounds);
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.core.a$c */
    public static final class c extends a1.j implements h1.c {
        int label;

        public c(Y0.c cVar) {
            super(1, cVar);
        }

        @Override // a1.a
        public final Y0.c create(Y0.c cVar) {
            return C0297a.this.new c(cVar);
        }

        @Override // h1.c
        public final Object invoke(Y0.c cVar) {
            return ((c) create(cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0292a.H(obj);
            C0297a.this.endAnimation();
            return U0.n.f1521a;
        }
    }

    public C0297a(Object obj, B0 b02, Object obj2, String str) {
        this.typeConverter = b02;
        this.visibilityThreshold = obj2;
        this.label = str;
        this.internalState = new C0317k(b02, obj, null, 0L, 0L, false, 60, null);
        this.isRunning$delegate = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
        this.targetValue$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.mutatorMutex = new C0298a0();
        this.defaultSpringSpec = new C0316j0(0.0f, 0.0f, obj2, 3, null);
        AbstractC0329q velocityVector = getVelocityVector();
        AbstractC0329q abstractC0329q = velocityVector instanceof C0321m ? AbstractC0299b.negativeInfinityBounds1D : velocityVector instanceof C0323n ? AbstractC0299b.negativeInfinityBounds2D : velocityVector instanceof C0325o ? AbstractC0299b.negativeInfinityBounds3D : AbstractC0299b.negativeInfinityBounds4D;
        kotlin.jvm.internal.o.c(abstractC0329q, "null cannot be cast to non-null type V of androidx.compose.animation.core.Animatable");
        this.negativeInfinityBounds = abstractC0329q;
        AbstractC0329q velocityVector2 = getVelocityVector();
        AbstractC0329q abstractC0329q2 = velocityVector2 instanceof C0321m ? AbstractC0299b.positiveInfinityBounds1D : velocityVector2 instanceof C0323n ? AbstractC0299b.positiveInfinityBounds2D : velocityVector2 instanceof C0325o ? AbstractC0299b.positiveInfinityBounds3D : AbstractC0299b.positiveInfinityBounds4D;
        kotlin.jvm.internal.o.c(abstractC0329q2, "null cannot be cast to non-null type V of androidx.compose.animation.core.Animatable");
        this.positiveInfinityBounds = abstractC0329q2;
        this.lowerBoundVector = abstractC0329q;
        this.upperBoundVector = abstractC0329q2;
    }

    public static /* synthetic */ Object animateDecay$default(C0297a c0297a, Object obj, InterfaceC0341y interfaceC0341y, h1.c cVar, Y0.c cVar2, int i2, Object obj2) {
        if ((i2 & 4) != 0) {
            cVar = null;
        }
        return c0297a.animateDecay(obj, interfaceC0341y, cVar, cVar2);
    }

    public static /* synthetic */ Object animateTo$default(C0297a c0297a, Object obj, InterfaceC0313i interfaceC0313i, Object obj2, h1.c cVar, Y0.c cVar2, int i2, Object obj3) {
        if ((i2 & 2) != 0) {
            interfaceC0313i = c0297a.defaultSpringSpec;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i2 & 4) != 0) {
            obj2 = c0297a.getVelocity();
        }
        Object obj4 = obj2;
        if ((i2 & 8) != 0) {
            cVar = null;
        }
        return c0297a.animateTo(obj, interfaceC0313i2, obj4, cVar, cVar2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object clampToBounds(Object obj) {
        if (kotlin.jvm.internal.o.a(this.lowerBoundVector, this.negativeInfinityBounds) && kotlin.jvm.internal.o.a(this.upperBoundVector, this.positiveInfinityBounds)) {
            return obj;
        }
        AbstractC0329q abstractC0329q = (AbstractC0329q) this.typeConverter.getConvertToVector().invoke(obj);
        int size$animation_core = abstractC0329q.getSize$animation_core();
        boolean z2 = false;
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            if (abstractC0329q.get$animation_core(i2) < this.lowerBoundVector.get$animation_core(i2) || abstractC0329q.get$animation_core(i2) > this.upperBoundVector.get$animation_core(i2)) {
                abstractC0329q.set$animation_core(i2, j1.a.n(abstractC0329q.get$animation_core(i2), this.lowerBoundVector.get$animation_core(i2), this.upperBoundVector.get$animation_core(i2)));
                z2 = true;
            }
        }
        return z2 ? this.typeConverter.getConvertFromVector().invoke(abstractC0329q) : obj;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void endAnimation() {
        C0317k c0317k = this.internalState;
        c0317k.getVelocityVector().reset$animation_core();
        c0317k.setLastFrameTimeNanos$animation_core(Long.MIN_VALUE);
        setRunning(false);
    }

    private static /* synthetic */ void getNegativeInfinityBounds$annotations() {
    }

    private static /* synthetic */ void getPositiveInfinityBounds$annotations() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object runAnimation(InterfaceC0303d interfaceC0303d, Object obj, h1.c cVar, Y0.c cVar2) {
        return C0298a0.mutate$default(this.mutatorMutex, null, new C0014a(obj, interfaceC0303d, this.internalState.getLastFrameTimeNanos(), cVar, null), cVar2, 1, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setRunning(boolean z2) {
        this.isRunning$delegate.setValue(Boolean.valueOf(z2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setTargetValue(Object obj) {
        this.targetValue$delegate.setValue(obj);
    }

    public static /* synthetic */ void updateBounds$default(C0297a c0297a, Object obj, Object obj2, int i2, Object obj3) {
        if ((i2 & 1) != 0) {
            obj = c0297a.lowerBound;
        }
        if ((i2 & 2) != 0) {
            obj2 = c0297a.upperBound;
        }
        c0297a.updateBounds(obj, obj2);
    }

    public final Object animateDecay(Object obj, InterfaceC0341y interfaceC0341y, h1.c cVar, Y0.c cVar2) {
        return runAnimation(new C0340x(interfaceC0341y, this.typeConverter, getValue(), (AbstractC0329q) this.typeConverter.getConvertToVector().invoke(obj)), obj, cVar, cVar2);
    }

    public final Object animateTo(Object obj, InterfaceC0313i interfaceC0313i, Object obj2, h1.c cVar, Y0.c cVar2) {
        return runAnimation(AbstractC0307f.TargetBasedAnimation(interfaceC0313i, this.typeConverter, getValue(), obj, obj2), obj2, cVar, cVar2);
    }

    public final d2 asState() {
        return this.internalState;
    }

    public final C0316j0 getDefaultSpringSpec$animation_core() {
        return this.defaultSpringSpec;
    }

    public final C0317k getInternalState$animation_core() {
        return this.internalState;
    }

    public final String getLabel() {
        return this.label;
    }

    public final Object getLowerBound() {
        return this.lowerBound;
    }

    public final Object getTargetValue() {
        return this.targetValue$delegate.getValue();
    }

    public final B0 getTypeConverter() {
        return this.typeConverter;
    }

    public final Object getUpperBound() {
        return this.upperBound;
    }

    public final Object getValue() {
        return this.internalState.getValue();
    }

    public final Object getVelocity() {
        return this.typeConverter.getConvertFromVector().invoke(getVelocityVector());
    }

    public final AbstractC0329q getVelocityVector() {
        return this.internalState.getVelocityVector();
    }

    public final boolean isRunning() {
        return ((Boolean) this.isRunning$delegate.getValue()).booleanValue();
    }

    public final Object snapTo(Object obj, Y0.c cVar) {
        Object objMutate$default = C0298a0.mutate$default(this.mutatorMutex, null, new b(obj, null), cVar, 1, null);
        return objMutate$default == Z0.a.f1616b ? objMutate$default : U0.n.f1521a;
    }

    public final Object stop(Y0.c cVar) {
        Object objMutate$default = C0298a0.mutate$default(this.mutatorMutex, null, new c(null), cVar, 1, null);
        return objMutate$default == Z0.a.f1616b ? objMutate$default : U0.n.f1521a;
    }

    public final void updateBounds(Object obj, Object obj2) {
        AbstractC0329q abstractC0329q;
        AbstractC0329q abstractC0329q2;
        if (obj == null || (abstractC0329q = (AbstractC0329q) this.typeConverter.getConvertToVector().invoke(obj)) == null) {
            abstractC0329q = this.negativeInfinityBounds;
        }
        if (obj2 == null || (abstractC0329q2 = (AbstractC0329q) this.typeConverter.getConvertToVector().invoke(obj2)) == null) {
            abstractC0329q2 = this.positiveInfinityBounds;
        }
        int size$animation_core = abstractC0329q.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            if (!(abstractC0329q.get$animation_core(i2) <= abstractC0329q2.get$animation_core(i2))) {
                AbstractC0300b0.throwIllegalStateException("Lower bound must be no greater than upper bound on *all* dimensions. The provided lower bound: " + abstractC0329q + " is greater than upper bound " + abstractC0329q2 + " on index " + i2);
            }
        }
        this.lowerBoundVector = abstractC0329q;
        this.upperBoundVector = abstractC0329q2;
        this.upperBound = obj2;
        this.lowerBound = obj;
        if (isRunning()) {
            return;
        }
        Object objClampToBounds = clampToBounds(getValue());
        if (kotlin.jvm.internal.o.a(objClampToBounds, getValue())) {
            return;
        }
        this.internalState.setValue$animation_core(objClampToBounds);
    }

    public /* synthetic */ C0297a(Object obj, B0 b02, Object obj2, String str, int i2, AbstractC1378g abstractC1378g) {
        this(obj, b02, (i2 & 4) != 0 ? null : obj2, (i2 & 8) != 0 ? "Animatable" : str);
    }

    public /* synthetic */ C0297a(Object obj, B0 b02, Object obj2, int i2, AbstractC1378g abstractC1378g) {
        this(obj, b02, (i2 & 4) != 0 ? null : obj2);
    }

    @U0.a
    public /* synthetic */ C0297a(Object obj, B0 b02, Object obj2) {
        this(obj, b02, obj2, "Animatable");
    }
}
