package androidx.compose.animation.core;

import j.C1331B;
import j.C1332C;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class Q implements B {
    public static final int $stable = 0;
    private final b config;

    public static final class a extends P {
        public static final int $stable = 8;
        private int arcMode;

        public /* synthetic */ a(Object obj, C c2, int i2, AbstractC1378g abstractC1378g) {
            this(obj, c2, i2);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return kotlin.jvm.internal.o.a(aVar.getValue$animation_core(), getValue$animation_core()) && kotlin.jvm.internal.o.a(aVar.getEasing$animation_core(), getEasing$animation_core()) && C0334t.m636equalsimpl0(aVar.arcMode, this.arcMode);
        }

        /* JADX INFO: renamed from: getArcMode--9T-Mq4$animation_core, reason: not valid java name */
        public final int m585getArcMode9TMq4$animation_core() {
            return this.arcMode;
        }

        public int hashCode() {
            Object value$animation_core = getValue$animation_core();
            return getEasing$animation_core().hashCode() + ((C0334t.m637hashCodeimpl(this.arcMode) + ((value$animation_core != null ? value$animation_core.hashCode() : 0) * 31)) * 31);
        }

        /* JADX INFO: renamed from: setArcMode-Rur9ykg$animation_core, reason: not valid java name */
        public final void m586setArcModeRur9ykg$animation_core(int i2) {
            this.arcMode = i2;
        }

        public /* synthetic */ a(Object obj, C c2, int i2, int i3, AbstractC1378g abstractC1378g) {
            this(obj, (i3 & 2) != 0 ? E.getLinearEasing() : c2, (i3 & 4) != 0 ? C0334t.Companion.m642getArcLinear9TMq4() : i2, null);
        }

        private a(Object obj, C c2, int i2) {
            super(obj, c2, null);
            this.arcMode = i2;
        }
    }

    public static final class b extends S {
        public static final int $stable = 8;

        public b() {
            super(null);
        }

        /* JADX INFO: renamed from: using-ngzHuyU, reason: not valid java name */
        public final a m587usingngzHuyU(a aVar, int i2) {
            aVar.m586setArcModeRur9ykg$animation_core(i2);
            return aVar;
        }

        @U0.a
        public final void with(a aVar, C c2) {
            aVar.setEasing$animation_core(c2);
        }

        @Override // androidx.compose.animation.core.S
        public a at(Object obj, int i2) {
            a aVar = new a(obj, null, 0, 6, null);
            getKeyframes$animation_core().i(i2, aVar);
            return aVar;
        }

        @Override // androidx.compose.animation.core.S
        public a atFraction(Object obj, float f2) {
            return at(obj, Math.round(getDurationMillis() * f2));
        }

        @Override // androidx.compose.animation.core.S
        public a createEntityFor$animation_core(Object obj) {
            return new a(obj, null, 0, 6, null);
        }
    }

    public Q(b bVar) {
        this.config = bVar;
    }

    public final b getConfig() {
        return this.config;
    }

    @Override // androidx.compose.animation.core.B, androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> O0 vectorize(B0 b02) {
        long[] jArr;
        int[] iArr;
        long[] jArr2;
        int[] iArr2;
        int i2;
        C1331B c1331b = new C1331B(this.config.getKeyframes$animation_core().f3042e + 2);
        C1332C c1332c = new C1332C(this.config.getKeyframes$animation_core().f3042e);
        C1332C keyframes$animation_core = this.config.getKeyframes$animation_core();
        int[] iArr3 = keyframes$animation_core.f3039b;
        Object[] objArr = keyframes$animation_core.f3040c;
        long[] jArr3 = keyframes$animation_core.f3038a;
        int length = jArr3.length - 2;
        if (length >= 0) {
            int i3 = 0;
            while (true) {
                long j2 = jArr3[i3];
                if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i4 = 8;
                    int i5 = 8 - ((~(i3 - length)) >>> 31);
                    int i6 = 0;
                    while (i6 < i5) {
                        if ((255 & j2) < 128) {
                            int i7 = (i3 << 3) + i6;
                            int i8 = iArr3[i7];
                            a aVar = (a) objArr[i7];
                            c1331b.d(i8);
                            jArr2 = jArr3;
                            iArr2 = iArr3;
                            c1332c.i(i8, new N0((AbstractC0329q) b02.getConvertToVector().invoke(aVar.getValue$animation_core()), aVar.getEasing$animation_core(), aVar.m585getArcMode9TMq4$animation_core(), null));
                            i2 = 8;
                        } else {
                            jArr2 = jArr3;
                            iArr2 = iArr3;
                            i2 = i4;
                        }
                        j2 >>= i2;
                        i6++;
                        i4 = i2;
                        jArr3 = jArr2;
                        iArr3 = iArr2;
                    }
                    jArr = jArr3;
                    iArr = iArr3;
                    if (i5 != i4) {
                        break;
                    }
                } else {
                    jArr = jArr3;
                    iArr = iArr3;
                }
                if (i3 == length) {
                    break;
                }
                i3++;
                jArr3 = jArr;
                iArr3 = iArr;
            }
        }
        if (!this.config.getKeyframes$animation_core().a(0)) {
            c1331b.c();
        }
        if (!this.config.getKeyframes$animation_core().a(this.config.getDurationMillis())) {
            c1331b.d(this.config.getDurationMillis());
        }
        c1331b.h();
        return new O0(c1331b, c1332c, this.config.getDurationMillis(), this.config.getDelayMillis(), E.getLinearEasing(), C0334t.Companion.m642getArcLinear9TMq4(), null);
    }
}
