package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface I0 extends J0 {
    int getDelayMillis();

    int getDurationMillis();

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    default long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return ((long) (getDurationMillis() + getDelayMillis())) * AbstractC0307f.MillisToNanos;
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    /* bridge */ /* synthetic */ default AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    /* synthetic */ AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3);

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    /* synthetic */ AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3);

    @Override // androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    /* bridge */ /* synthetic */ default boolean isInfinite() {
        return super.isInfinite();
    }
}
