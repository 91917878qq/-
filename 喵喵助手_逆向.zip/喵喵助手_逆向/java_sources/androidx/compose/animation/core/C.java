package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface C {
    float transform(float f2);
}
