package androidx.compose.animation.core;

import androidx.compose.animation.core.Q;
import androidx.compose.animation.core.T;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0315j {
    /* JADX INFO: Access modifiers changed from: private */
    public static final <T, V extends AbstractC0329q> V convert(B0 b02, T t2) {
        if (t2 == null) {
            return null;
        }
        return (V) b02.getConvertToVector().invoke(t2);
    }

    public static final <T> InterfaceC0313i delayed(InterfaceC0313i interfaceC0313i, long j2) {
        return new C0318k0(interfaceC0313i, j2);
    }

    @U0.a
    public static final /* synthetic */ M infiniteRepeatable(B b2, EnumC0302c0 enumC0302c0) {
        return new M(b2, enumC0302c0, C0322m0.m616constructorimpl$default(0, 0, 2, null), (AbstractC1378g) null);
    }

    public static /* synthetic */ M infiniteRepeatable$default(B b2, EnumC0302c0 enumC0302c0, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            enumC0302c0 = EnumC0302c0.Restart;
        }
        return infiniteRepeatable(b2, enumC0302c0);
    }

    /* JADX INFO: renamed from: infiniteRepeatable-9IiC70o, reason: not valid java name */
    public static final <T> M m609infiniteRepeatable9IiC70o(B b2, EnumC0302c0 enumC0302c0, long j2) {
        return new M(b2, enumC0302c0, j2, (AbstractC1378g) null);
    }

    /* JADX INFO: renamed from: infiniteRepeatable-9IiC70o$default, reason: not valid java name */
    public static /* synthetic */ M m610infiniteRepeatable9IiC70o$default(B b2, EnumC0302c0 enumC0302c0, long j2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            enumC0302c0 = EnumC0302c0.Restart;
        }
        if ((i2 & 4) != 0) {
            j2 = C0322m0.m616constructorimpl$default(0, 0, 2, null);
        }
        return m609infiniteRepeatable9IiC70o(b2, enumC0302c0, j2);
    }

    public static final <T> Q keyframes(h1.c cVar) {
        Q.b bVar = new Q.b();
        cVar.invoke(bVar);
        return new Q(bVar);
    }

    public static final <T> T keyframesWithSpline(h1.c cVar) {
        T.a aVar = new T.a();
        cVar.invoke(aVar);
        return new T(aVar);
    }

    @U0.a
    public static final /* synthetic */ C0304d0 repeatable(int i2, B b2, EnumC0302c0 enumC0302c0) {
        return new C0304d0(i2, b2, enumC0302c0, C0322m0.m616constructorimpl$default(0, 0, 2, null), (AbstractC1378g) null);
    }

    public static /* synthetic */ C0304d0 repeatable$default(int i2, B b2, EnumC0302c0 enumC0302c0, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            enumC0302c0 = EnumC0302c0.Restart;
        }
        return repeatable(i2, b2, enumC0302c0);
    }

    /* JADX INFO: renamed from: repeatable-91I0pcU, reason: not valid java name */
    public static final <T> C0304d0 m611repeatable91I0pcU(int i2, B b2, EnumC0302c0 enumC0302c0, long j2) {
        return new C0304d0(i2, b2, enumC0302c0, j2, (AbstractC1378g) null);
    }

    /* JADX INFO: renamed from: repeatable-91I0pcU$default, reason: not valid java name */
    public static /* synthetic */ C0304d0 m612repeatable91I0pcU$default(int i2, B b2, EnumC0302c0 enumC0302c0, long j2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            enumC0302c0 = EnumC0302c0.Restart;
        }
        if ((i3 & 8) != 0) {
            j2 = C0322m0.m616constructorimpl$default(0, 0, 2, null);
        }
        return m611repeatable91I0pcU(i2, b2, enumC0302c0, j2);
    }

    public static final <T> C0310g0 snap(int i2) {
        return new C0310g0(i2);
    }

    public static /* synthetic */ C0310g0 snap$default(int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i2 = 0;
        }
        return snap(i2);
    }

    public static final <T> C0316j0 spring(float f2, float f3, T t2) {
        return new C0316j0(f2, f3, t2);
    }

    public static /* synthetic */ C0316j0 spring$default(float f2, float f3, Object obj, int i2, Object obj2) {
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        if ((i2 & 2) != 0) {
            f3 = 1500.0f;
        }
        if ((i2 & 4) != 0) {
            obj = null;
        }
        return spring(f2, f3, obj);
    }

    public static final <T> A0 tween(int i2, int i3, C c2) {
        return new A0(i2, i3, c2);
    }

    public static /* synthetic */ A0 tween$default(int i2, int i3, C c2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i2 = 300;
        }
        if ((i4 & 2) != 0) {
            i3 = 0;
        }
        if ((i4 & 4) != 0) {
            c2 = E.getFastOutSlowInEasing();
        }
        return tween(i2, i3, c2);
    }

    public static final <T> T keyframesWithSpline(float f2, h1.c cVar) {
        T.a aVar = new T.a();
        cVar.invoke(aVar);
        return new T(aVar, f2);
    }
}
