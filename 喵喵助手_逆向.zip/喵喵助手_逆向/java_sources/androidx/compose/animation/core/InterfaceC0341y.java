package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0341y {
    <V extends AbstractC0329q> H0 vectorize(B0 b02);
}
