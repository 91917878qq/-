package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final class C0 implements B0 {
    private final h1.c convertFromVector;
    private final h1.c convertToVector;

    public C0(h1.c cVar, h1.c cVar2) {
        this.convertToVector = cVar;
        this.convertFromVector = cVar2;
    }

    @Override // androidx.compose.animation.core.B0
    public h1.c getConvertFromVector() {
        return this.convertFromVector;
    }

    @Override // androidx.compose.animation.core.B0
    public h1.c getConvertToVector() {
        return this.convertToVector;
    }
}
