package androidx.compose.animation.core;

import java.util.Arrays;

/* JADX INFO: renamed from: androidx.compose.animation.core.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0336u {
    public static final int $stable = 8;
    private final a[][] arcs;
    private final boolean isExtrapolate = true;

    /* JADX INFO: renamed from: androidx.compose.animation.core.u$a */
    public static final class a {
        public static final int $stable = 8;
        private float arcDistance;
        private final float arcVelocity;
        public final float ellipseA;
        public final float ellipseB;
        public final float ellipseCenterX;
        public final float ellipseCenterY;
        public final boolean isLinear;
        private final float[] lut;
        private final float oneOverDeltaTime;
        private final float time1;
        private final float time2;
        private float tmpCosAngle;
        private float tmpSinAngle;
        private final float vertical;
        private final float x1;
        private final float x2;

        /* JADX INFO: renamed from: y1, reason: collision with root package name */
        private final float f1656y1;
        private final float y2;

        public a(int i2, float f2, float f3, float f4, float f5, float f6, float f7) {
            this.time1 = f2;
            this.time2 = f3;
            this.x1 = f4;
            this.f1656y1 = f5;
            this.x2 = f6;
            this.y2 = f7;
            float f8 = f6 - f4;
            float f9 = f7 - f5;
            boolean z2 = true;
            boolean z3 = i2 == 1 || (i2 == 4 ? f9 > 0.0f : !(i2 != 5 || f9 >= 0.0f));
            float f10 = z3 ? -1.0f : 1.0f;
            this.vertical = f10;
            float f11 = 1 / (f3 - f2);
            this.oneOverDeltaTime = f11;
            this.lut = new float[101];
            boolean z4 = i2 == 3;
            if (z4 || Math.abs(f8) < 0.001f || Math.abs(f9) < 0.001f) {
                float fHypot = (float) Math.hypot(f9, f8);
                this.arcDistance = fHypot;
                this.arcVelocity = fHypot * f11;
                this.ellipseCenterX = f8 * f11;
                this.ellipseCenterY = f9 * f11;
                this.ellipseA = Float.NaN;
                this.ellipseB = Float.NaN;
            } else {
                this.ellipseA = f8 * f10;
                this.ellipseB = f9 * (-f10);
                this.ellipseCenterX = z3 ? f6 : f4;
                this.ellipseCenterY = z3 ? f5 : f7;
                buildTable$animation_core(f4, f5, f6, f7);
                this.arcVelocity = this.arcDistance * f11;
                z2 = z4;
            }
            this.isLinear = z2;
        }

        private final float calcAngle(float f2) {
            return lookup((this.vertical == -1.0f ? this.time2 - f2 : f2 - this.time1) * this.oneOverDeltaTime) * 1.5707964f;
        }

        private final float lookup(float f2) {
            if (f2 <= 0.0f) {
                return 0.0f;
            }
            if (f2 >= 1.0f) {
                return 1.0f;
            }
            float f3 = f2 * 100;
            int i2 = (int) f3;
            float f4 = f3 - i2;
            float[] fArr = this.lut;
            float f5 = fArr[i2];
            return ((fArr[i2 + 1] - f5) * f4) + f5;
        }

        public final void buildTable$animation_core(float f2, float f3, float f4, float f5) {
            float f6;
            float fHypot;
            float f7 = f4 - f2;
            float f8 = f3 - f5;
            float[] fArr = AbstractC0338v.OurPercentCache;
            int length = fArr.length - 1;
            float f9 = length;
            float[] fArr2 = this.lut;
            if (1 <= length) {
                float f10 = f8;
                int i2 = 1;
                fHypot = 0.0f;
                float f11 = 0.0f;
                while (true) {
                    f6 = f9;
                    double radians = (float) Math.toRadians((((double) i2) * 90.0d) / ((double) length));
                    float fSin = ((float) Math.sin(radians)) * f7;
                    float fCos = ((float) Math.cos(radians)) * f8;
                    fHypot += (float) Math.hypot(fSin - f11, fCos - f10);
                    fArr[i2] = fHypot;
                    if (i2 == length) {
                        break;
                    }
                    i2++;
                    f9 = f6;
                    f10 = fCos;
                    f11 = fSin;
                }
            } else {
                f6 = f9;
                fHypot = 0.0f;
            }
            this.arcDistance = fHypot;
            if (1 <= length) {
                int i3 = 1;
                while (true) {
                    fArr[i3] = fArr[i3] / fHypot;
                    if (i3 == length) {
                        break;
                    } else {
                        i3++;
                    }
                }
            }
            int length2 = fArr2.length;
            for (int i4 = 0; i4 < length2; i4++) {
                float f12 = i4 / 100.0f;
                int iBinarySearch = Arrays.binarySearch(fArr, 0, fArr.length, f12);
                if (iBinarySearch >= 0) {
                    fArr2[i4] = iBinarySearch / f6;
                } else if (iBinarySearch == -1) {
                    fArr2[i4] = 0.0f;
                } else {
                    int i5 = -iBinarySearch;
                    int i6 = i5 - 2;
                    float f13 = i6;
                    float f14 = fArr[i6];
                    fArr2[i4] = (((f12 - f14) / (fArr[i5 - 1] - f14)) + f13) / f6;
                }
            }
        }

        public final float calcDX() {
            float f2 = this.ellipseA * this.tmpCosAngle;
            return f2 * this.vertical * (this.arcVelocity / ((float) Math.hypot(f2, (-this.ellipseB) * this.tmpSinAngle)));
        }

        public final float calcDY() {
            float f2 = this.ellipseA * this.tmpCosAngle;
            float f3 = (-this.ellipseB) * this.tmpSinAngle;
            return f3 * this.vertical * (this.arcVelocity / ((float) Math.hypot(f2, f3)));
        }

        public final float calcX() {
            return (this.tmpSinAngle * this.ellipseA) + this.ellipseCenterX;
        }

        public final float calcY() {
            return (this.tmpCosAngle * this.ellipseB) + this.ellipseCenterY;
        }

        public final float getLinearDX$animation_core() {
            return this.ellipseCenterX;
        }

        public final float getLinearDY$animation_core() {
            return this.ellipseCenterY;
        }

        public final float getLinearX(float f2) {
            float f3 = (f2 - this.time1) * this.oneOverDeltaTime;
            float f4 = this.x1;
            return ((this.x2 - f4) * f3) + f4;
        }

        public final float getLinearY(float f2) {
            float f3 = (f2 - this.time1) * this.oneOverDeltaTime;
            float f4 = this.f1656y1;
            return ((this.y2 - f4) * f3) + f4;
        }

        public final float getTime1() {
            return this.time1;
        }

        public final float getTime2() {
            return this.time2;
        }

        public final void setPoint(float f2) {
            double dLookup = lookup((this.vertical == -1.0f ? this.time2 - f2 : f2 - this.time1) * this.oneOverDeltaTime) * 1.5707964f;
            this.tmpSinAngle = (float) Math.sin(dLookup);
            this.tmpCosAngle = (float) Math.cos(dLookup);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0027 A[PHI: r10
  0x0027: PHI (r10v1 int) = (r10v0 int), (r10v3 int), (r10v4 int) binds: [B:5:0x0018, B:10:0x0021, B:12:0x0024] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public C0336u(int[] r27, float[] r28, float[][] r29) {
        /*
            r26 = this;
            r0 = r26
            r1 = r28
            r26.<init>()
            r2 = 1
            r0.isExtrapolate = r2
            int r3 = r1.length
            int r3 = r3 - r2
            androidx.compose.animation.core.u$a[][] r4 = new androidx.compose.animation.core.C0336u.a[r3][]
            r5 = 0
            r7 = r2
            r8 = r7
            r6 = r5
        L12:
            if (r6 >= r3) goto L70
            r9 = r27[r6]
            r10 = 3
            r11 = 2
            if (r9 == 0) goto L27
            if (r9 == r2) goto L30
            if (r9 == r11) goto L2e
            if (r9 == r10) goto L29
            r10 = 4
            if (r9 == r10) goto L27
            r10 = 5
            if (r9 == r10) goto L27
            goto L32
        L27:
            r8 = r10
            goto L32
        L29:
            if (r7 != r2) goto L30
            goto L2e
        L2c:
            r8 = r7
            goto L32
        L2e:
            r7 = r11
            goto L2c
        L30:
            r7 = r2
            goto L2c
        L32:
            r9 = r29[r6]
            int r10 = r6 + 1
            r20 = r29[r10]
            r21 = r1[r6]
            r22 = r1[r10]
            int r12 = r9.length
            int r12 = r12 / r11
            int r13 = r9.length
            int r13 = r13 % r11
            int r11 = r13 + r12
            androidx.compose.animation.core.u$a[] r15 = new androidx.compose.animation.core.C0336u.a[r11]
            r14 = r5
        L45:
            if (r14 >= r11) goto L6a
            int r12 = r14 * 2
            androidx.compose.animation.core.u$a r23 = new androidx.compose.animation.core.u$a
            r16 = r9[r12]
            int r13 = r12 + 1
            r17 = r9[r13]
            r18 = r20[r12]
            r19 = r20[r13]
            r12 = r23
            r13 = r8
            r24 = r14
            r14 = r21
            r25 = r15
            r15 = r22
            r12.<init>(r13, r14, r15, r16, r17, r18, r19)
            r25[r24] = r23
            int r14 = r24 + 1
            r15 = r25
            goto L45
        L6a:
            r25 = r15
            r4[r6] = r25
            r6 = r10
            goto L12
        L70:
            r0.arcs = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.animation.core.C0336u.<init>(int[], float[], float[][]):void");
    }

    public final void getPos(float f2, float[] fArr) {
        a[][] aVarArr = this.arcs;
        int length = aVarArr.length - 1;
        int i2 = 0;
        float time1 = aVarArr[0][0].getTime1();
        float time2 = aVarArr[length][0].getTime2();
        int length2 = fArr.length;
        if (!this.isExtrapolate) {
            f2 = Math.min(Math.max(f2, time1), time2);
        } else if (f2 < time1 || f2 > time2) {
            if (f2 > time2) {
                time1 = time2;
            } else {
                length = 0;
            }
            float f3 = f2 - time1;
            int i3 = 0;
            while (i2 < length2 - 1) {
                a aVar = aVarArr[length][i3];
                if (aVar.isLinear) {
                    fArr[i2] = (aVar.ellipseCenterX * f3) + aVar.getLinearX(time1);
                    fArr[i2 + 1] = (aVar.ellipseCenterY * f3) + aVar.getLinearY(time1);
                } else {
                    aVar.setPoint(time1);
                    fArr[i2] = (aVar.calcDX() * f3) + (aVar.tmpSinAngle * aVar.ellipseA) + aVar.ellipseCenterX;
                    fArr[i2 + 1] = (aVar.calcDY() * f3) + (aVar.tmpCosAngle * aVar.ellipseB) + aVar.ellipseCenterY;
                }
                i2 += 2;
                i3++;
            }
            return;
        }
        boolean z2 = false;
        for (a[] aVarArr2 : aVarArr) {
            int i4 = 0;
            int i5 = 0;
            while (i4 < length2 - 1) {
                a aVar2 = aVarArr2[i5];
                if (f2 <= aVar2.getTime2()) {
                    if (aVar2.isLinear) {
                        fArr[i4] = aVar2.getLinearX(f2);
                        fArr[i4 + 1] = aVar2.getLinearY(f2);
                    } else {
                        aVar2.setPoint(f2);
                        fArr[i4] = (aVar2.tmpSinAngle * aVar2.ellipseA) + aVar2.ellipseCenterX;
                        fArr[i4 + 1] = (aVar2.tmpCosAngle * aVar2.ellipseB) + aVar2.ellipseCenterY;
                    }
                    z2 = true;
                }
                i4 += 2;
                i5++;
            }
            if (z2) {
                return;
            }
        }
    }

    public final void getSlope(float f2, float[] fArr) {
        a[][] aVarArr = this.arcs;
        float time1 = aVarArr[0][0].getTime1();
        float time2 = aVarArr[aVarArr.length - 1][0].getTime2();
        if (f2 < time1) {
            f2 = time1;
        }
        if (f2 <= time2) {
            time2 = f2;
        }
        int length = fArr.length;
        boolean z2 = false;
        for (a[] aVarArr2 : aVarArr) {
            int i2 = 0;
            int i3 = 0;
            while (i2 < length - 1) {
                a aVar = aVarArr2[i3];
                if (time2 <= aVar.getTime2()) {
                    if (aVar.isLinear) {
                        fArr[i2] = aVar.ellipseCenterX;
                        fArr[i2 + 1] = aVar.ellipseCenterY;
                    } else {
                        aVar.setPoint(time2);
                        fArr[i2] = aVar.calcDX();
                        fArr[i2 + 1] = aVar.calcDY();
                    }
                    z2 = true;
                }
                i2 += 2;
                i3++;
            }
            if (z2) {
                return;
            }
        }
    }
}
