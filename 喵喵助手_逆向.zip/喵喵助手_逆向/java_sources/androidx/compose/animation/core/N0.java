package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class N0 {
    public static final int $stable = 0;
    private final int arcMode;
    private final C easing;
    private final AbstractC0329q vectorValue;

    public /* synthetic */ N0(AbstractC0329q abstractC0329q, C c2, int i2, AbstractC1378g abstractC1378g) {
        this(abstractC0329q, c2, i2);
    }

    /* JADX INFO: renamed from: copy-2NF0KzA$default, reason: not valid java name */
    public static /* synthetic */ N0 m581copy2NF0KzA$default(N0 n0, AbstractC0329q abstractC0329q, C c2, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            abstractC0329q = n0.vectorValue;
        }
        if ((i3 & 2) != 0) {
            c2 = n0.easing;
        }
        if ((i3 & 4) != 0) {
            i2 = n0.arcMode;
        }
        return n0.m583copy2NF0KzA(abstractC0329q, c2, i2);
    }

    public final AbstractC0329q component1() {
        return this.vectorValue;
    }

    public final C component2() {
        return this.easing;
    }

    /* JADX INFO: renamed from: component3--9T-Mq4, reason: not valid java name */
    public final int m582component39TMq4() {
        return this.arcMode;
    }

    /* JADX INFO: renamed from: copy-2NF0KzA, reason: not valid java name */
    public final N0 m583copy2NF0KzA(AbstractC0329q abstractC0329q, C c2, int i2) {
        return new N0(abstractC0329q, c2, i2, null);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof N0)) {
            return false;
        }
        N0 n0 = (N0) obj;
        return kotlin.jvm.internal.o.a(this.vectorValue, n0.vectorValue) && kotlin.jvm.internal.o.a(this.easing, n0.easing) && C0334t.m636equalsimpl0(this.arcMode, n0.arcMode);
    }

    /* JADX INFO: renamed from: getArcMode--9T-Mq4, reason: not valid java name */
    public final int m584getArcMode9TMq4() {
        return this.arcMode;
    }

    public final C getEasing() {
        return this.easing;
    }

    public final AbstractC0329q getVectorValue() {
        return this.vectorValue;
    }

    public int hashCode() {
        return C0334t.m637hashCodeimpl(this.arcMode) + ((this.easing.hashCode() + (this.vectorValue.hashCode() * 31)) * 31);
    }

    public String toString() {
        return "VectorizedKeyframeSpecElementInfo(vectorValue=" + this.vectorValue + ", easing=" + this.easing + ", arcMode=" + ((Object) C0334t.m638toStringimpl(this.arcMode)) + ')';
    }

    private N0(AbstractC0329q abstractC0329q, C c2, int i2) {
        this.vectorValue = abstractC0329q;
        this.easing = c2;
        this.arcMode = i2;
    }
}
