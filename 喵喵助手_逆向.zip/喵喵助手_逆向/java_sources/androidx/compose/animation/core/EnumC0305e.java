package androidx.compose.animation.core;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.compose.animation.core.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0305e {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ EnumC0305e[] $VALUES;
    public static final EnumC0305e BoundReached = new EnumC0305e("BoundReached", 0);
    public static final EnumC0305e Finished = new EnumC0305e("Finished", 1);

    private static final /* synthetic */ EnumC0305e[] $values() {
        return new EnumC0305e[]{BoundReached, Finished};
    }

    static {
        EnumC0305e[] enumC0305eArr$values = $values();
        $VALUES = enumC0305eArr$values;
        $ENTRIES = AbstractC0292a.q(enumC0305eArr$values);
    }

    private EnumC0305e(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static EnumC0305e valueOf(String str) {
        return (EnumC0305e) Enum.valueOf(EnumC0305e.class, str);
    }

    public static EnumC0305e[] values() {
        return (EnumC0305e[]) $VALUES.clone();
    }
}
