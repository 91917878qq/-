package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0327p extends AbstractC0329q {
    public static final int $stable = 8;
    private final int size;

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    private float f1646v1;
    private float v2;
    private float v3;
    private float v4;

    public C0327p(float f2, float f3, float f4, float f5) {
        super(null);
        this.f1646v1 = f2;
        this.v2 = f3;
        this.v3 = f4;
        this.v4 = f5;
        this.size = 4;
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0327p) {
            C0327p c0327p = (C0327p) obj;
            if (c0327p.f1646v1 == this.f1646v1 && c0327p.v2 == this.v2 && c0327p.v3 == this.v3 && c0327p.v4 == this.v4) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public float get$animation_core(int i2) {
        if (i2 == 0) {
            return this.f1646v1;
        }
        if (i2 == 1) {
            return this.v2;
        }
        if (i2 == 2) {
            return this.v3;
        }
        if (i2 != 3) {
            return 0.0f;
        }
        return this.v4;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public int getSize$animation_core() {
        return this.size;
    }

    public final float getV1() {
        return this.f1646v1;
    }

    public final float getV2() {
        return this.v2;
    }

    public final float getV3() {
        return this.v3;
    }

    public final float getV4() {
        return this.v4;
    }

    public int hashCode() {
        return Float.hashCode(this.v4) + D0.d.a(this.v3, D0.d.a(this.v2, Float.hashCode(this.f1646v1) * 31, 31), 31);
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void reset$animation_core() {
        this.f1646v1 = 0.0f;
        this.v2 = 0.0f;
        this.v3 = 0.0f;
        this.v4 = 0.0f;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void set$animation_core(int i2, float f2) {
        if (i2 == 0) {
            this.f1646v1 = f2;
            return;
        }
        if (i2 == 1) {
            this.v2 = f2;
        } else if (i2 == 2) {
            this.v3 = f2;
        } else {
            if (i2 != 3) {
                return;
            }
            this.v4 = f2;
        }
    }

    public final void setV1$animation_core(float f2) {
        this.f1646v1 = f2;
    }

    public final void setV2$animation_core(float f2) {
        this.v2 = f2;
    }

    public final void setV3$animation_core(float f2) {
        this.v3 = f2;
    }

    public final void setV4$animation_core(float f2) {
        this.v4 = f2;
    }

    public String toString() {
        return "AnimationVector4D: v1 = " + this.f1646v1 + ", v2 = " + this.v2 + ", v3 = " + this.v3 + ", v4 = " + this.v4;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public C0327p newVector$animation_core() {
        return new C0327p(0.0f, 0.0f, 0.0f, 0.0f);
    }
}
