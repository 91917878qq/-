package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public abstract class D {
    private static final C Ease = new C0339w(0.25f, 0.1f, 0.25f, 1.0f);
    private static final C EaseOut = new C0339w(0.0f, 0.0f, 0.58f, 1.0f);
    private static final C EaseIn = new C0339w(0.42f, 0.0f, 1.0f, 1.0f);
    private static final C EaseInOut = new C0339w(0.42f, 0.0f, 0.58f, 1.0f);
    private static final C EaseInSine = new C0339w(0.12f, 0.0f, 0.39f, 0.0f);
    private static final C EaseOutSine = new C0339w(0.61f, 1.0f, 0.88f, 1.0f);
    private static final C EaseInOutSine = new C0339w(0.37f, 0.0f, 0.63f, 1.0f);
    private static final C EaseInCubic = new C0339w(0.32f, 0.0f, 0.67f, 0.0f);
    private static final C EaseOutCubic = new C0339w(0.33f, 1.0f, 0.68f, 1.0f);
    private static final C EaseInOutCubic = new C0339w(0.65f, 0.0f, 0.35f, 1.0f);
    private static final C EaseInQuint = new C0339w(0.64f, 0.0f, 0.78f, 0.0f);
    private static final C EaseOutQuint = new C0339w(0.22f, 1.0f, 0.36f, 1.0f);
    private static final C EaseInOutQuint = new C0339w(0.83f, 0.0f, 0.17f, 1.0f);
    private static final C EaseInCirc = new C0339w(0.55f, 0.0f, 1.0f, 0.45f);
    private static final C EaseOutCirc = new C0339w(0.0f, 0.55f, 0.45f, 1.0f);
    private static final C EaseInOutCirc = new C0339w(0.85f, 0.0f, 0.15f, 1.0f);
    private static final C EaseInQuad = new C0339w(0.11f, 0.0f, 0.5f, 0.0f);
    private static final C EaseOutQuad = new C0339w(0.5f, 1.0f, 0.89f, 1.0f);
    private static final C EaseInOutQuad = new C0339w(0.45f, 0.0f, 0.55f, 1.0f);
    private static final C EaseInQuart = new C0339w(0.5f, 0.0f, 0.75f, 0.0f);
    private static final C EaseOutQuart = new C0339w(0.25f, 1.0f, 0.5f, 1.0f);
    private static final C EaseInOutQuart = new C0339w(0.76f, 0.0f, 0.24f, 1.0f);
    private static final C EaseInExpo = new C0339w(0.7f, 0.0f, 0.84f, 0.0f);
    private static final C EaseOutExpo = new C0339w(0.16f, 1.0f, 0.3f, 1.0f);
    private static final C EaseInOutExpo = new C0339w(0.87f, 0.0f, 0.13f, 1.0f);
    private static final C EaseInBack = new C0339w(0.36f, 0.0f, 0.66f, -0.56f);
    private static final C EaseOutBack = new C0339w(0.34f, 1.56f, 0.64f, 1.0f);
    private static final C EaseInOutBack = new C0339w(0.68f, -0.6f, 0.32f, 1.6f);
    private static final C EaseInElastic = new R0.j(2);
    private static final C EaseOutElastic = new R0.j(3);
    private static final C EaseInOutElastic = new R0.j(4);
    private static final C EaseOutBounce = new R0.j(5);
    private static final C EaseInBounce = new R0.j(6);
    private static final C EaseInOutBounce = new R0.j(7);

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseInBounce$lambda$4(float f2) {
        return 1 - EaseOutBounce.transform(1.0f - f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseInElastic$lambda$0(float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        if (f2 == 1.0f) {
            return 1.0f;
        }
        return (float) (Math.sin(((double) ((f2 * 10.0f) - 10.75f)) * 2.0943951023931953d) * ((double) (-((float) Math.pow(2.0f, r6 - 10.0f)))));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseInOutBounce$lambda$5(float f2) {
        if (f2 < 0.5d) {
            return (1 - EaseOutBounce.transform(1.0f - (f2 * 2.0f))) / 2.0f;
        }
        return (EaseOutBounce.transform((f2 * 2.0f) - 1.0f) + 1) / 2.0f;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseInOutElastic$lambda$2(float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        if (f2 == 1.0f) {
            return 1.0f;
        }
        if (0.0f > f2 || f2 > 0.5f) {
            double d2 = 2.0f;
            return ((float) ((Math.sin(((double) ((f2 * 20.0f) - 11.125f)) * 1.3962634015954636d) * ((double) ((float) Math.pow(d2, ((-20.0f) * f2) + 10.0f)))) / d2)) + 1.0f;
        }
        double d3 = 2.0f;
        return (float) ((-(Math.sin(((double) ((f2 * 20.0f) - 11.125f)) * 1.3962634015954636d) * ((double) ((float) Math.pow(d3, r12 - 10.0f))))) / d3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseOutBounce$lambda$3(float f2) {
        float f3;
        float f4;
        if (f2 < 0.36363637f) {
            return 7.5625f * f2 * f2;
        }
        if (f2 < 0.72727275f) {
            float f5 = f2 - 0.54545456f;
            f3 = 7.5625f * f5 * f5;
            f4 = 0.75f;
        } else if (f2 < 0.90909094f) {
            float f6 = f2 - 0.8181818f;
            f3 = 7.5625f * f6 * f6;
            f4 = 0.9375f;
        } else {
            float f7 = f2 - 0.95454544f;
            f3 = 7.5625f * f7 * f7;
            f4 = 0.984375f;
        }
        return f3 + f4;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float EaseOutElastic$lambda$1(float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        if (f2 == 1.0f) {
            return 1.0f;
        }
        return (float) ((Math.sin(((double) ((f2 * 10.0f) - 0.75f)) * 2.0943951023931953d) * ((double) ((float) Math.pow(2.0f, (-10.0f) * f2)))) + ((double) 1.0f));
    }

    public static final C getEase() {
        return Ease;
    }

    public static final C getEaseIn() {
        return EaseIn;
    }

    public static final C getEaseInBack() {
        return EaseInBack;
    }

    public static final C getEaseInBounce() {
        return EaseInBounce;
    }

    public static final C getEaseInCirc() {
        return EaseInCirc;
    }

    public static final C getEaseInCubic() {
        return EaseInCubic;
    }

    public static final C getEaseInElastic() {
        return EaseInElastic;
    }

    public static final C getEaseInExpo() {
        return EaseInExpo;
    }

    public static final C getEaseInOut() {
        return EaseInOut;
    }

    public static final C getEaseInOutBack() {
        return EaseInOutBack;
    }

    public static final C getEaseInOutBounce() {
        return EaseInOutBounce;
    }

    public static final C getEaseInOutCirc() {
        return EaseInOutCirc;
    }

    public static final C getEaseInOutCubic() {
        return EaseInOutCubic;
    }

    public static final C getEaseInOutElastic() {
        return EaseInOutElastic;
    }

    public static final C getEaseInOutExpo() {
        return EaseInOutExpo;
    }

    public static final C getEaseInOutQuad() {
        return EaseInOutQuad;
    }

    public static final C getEaseInOutQuart() {
        return EaseInOutQuart;
    }

    public static final C getEaseInOutQuint() {
        return EaseInOutQuint;
    }

    public static final C getEaseInOutSine() {
        return EaseInOutSine;
    }

    public static final C getEaseInQuad() {
        return EaseInQuad;
    }

    public static final C getEaseInQuart() {
        return EaseInQuart;
    }

    public static final C getEaseInQuint() {
        return EaseInQuint;
    }

    public static final C getEaseInSine() {
        return EaseInSine;
    }

    public static final C getEaseOut() {
        return EaseOut;
    }

    public static final C getEaseOutBack() {
        return EaseOutBack;
    }

    public static final C getEaseOutBounce() {
        return EaseOutBounce;
    }

    public static final C getEaseOutCirc() {
        return EaseOutCirc;
    }

    public static final C getEaseOutCubic() {
        return EaseOutCubic;
    }

    public static final C getEaseOutElastic() {
        return EaseOutElastic;
    }

    public static final C getEaseOutExpo() {
        return EaseOutExpo;
    }

    public static final C getEaseOutQuad() {
        return EaseOutQuad;
    }

    public static final C getEaseOutQuart() {
        return EaseOutQuart;
    }

    public static final C getEaseOutQuint() {
        return EaseOutQuint;
    }

    public static final C getEaseOutSine() {
        return EaseOutSine;
    }
}
