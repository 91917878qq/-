package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0334t {
    private final int value;
    public static final a Companion = new a(null);
    private static final int ArcAbove = m634constructorimpl(5);
    private static final int ArcBelow = m634constructorimpl(4);
    private static final int ArcLinear = m634constructorimpl(0);

    /* JADX INFO: renamed from: androidx.compose.animation.core.t$a */
    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: renamed from: getArcAbove--9T-Mq4, reason: not valid java name */
        public final int m640getArcAbove9TMq4() {
            return C0334t.ArcAbove;
        }

        /* JADX INFO: renamed from: getArcBelow--9T-Mq4, reason: not valid java name */
        public final int m641getArcBelow9TMq4() {
            return C0334t.ArcBelow;
        }

        /* JADX INFO: renamed from: getArcLinear--9T-Mq4, reason: not valid java name */
        public final int m642getArcLinear9TMq4() {
            return C0334t.ArcLinear;
        }

        private a() {
        }
    }

    private /* synthetic */ C0334t(int i2) {
        this.value = i2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ C0334t m633boximpl(int i2) {
        return new C0334t(i2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    public static int m634constructorimpl(int i2) {
        return i2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m635equalsimpl(int i2, Object obj) {
        return (obj instanceof C0334t) && i2 == ((C0334t) obj).m639unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m636equalsimpl0(int i2, int i3) {
        return i2 == i3;
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m637hashCodeimpl(int i2) {
        return Integer.hashCode(i2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m638toStringimpl(int i2) {
        return D0.d.o("ArcMode(value=", i2, ')');
    }

    public boolean equals(Object obj) {
        return m635equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m637hashCodeimpl(this.value);
    }

    public String toString() {
        return m638toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ int m639unboximpl() {
        return this.value;
    }
}
