package androidx.compose.animation.core;

import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0317k implements d2 {
    public static final int $stable = 0;
    private long finishedTimeNanos;
    private boolean isRunning;
    private long lastFrameTimeNanos;
    private final B0 typeConverter;
    private final androidx.compose.runtime.B0 value$delegate;
    private AbstractC0329q velocityVector;

    public C0317k(B0 b02, Object obj, AbstractC0329q abstractC0329q, long j2, long j3, boolean z2) {
        AbstractC0329q abstractC0329qCopy;
        this.typeConverter = b02;
        this.value$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.velocityVector = (abstractC0329q == null || (abstractC0329qCopy = r.copy(abstractC0329q)) == null) ? AbstractC0319l.createZeroVectorFrom(b02, obj) : abstractC0329qCopy;
        this.lastFrameTimeNanos = j2;
        this.finishedTimeNanos = j3;
        this.isRunning = z2;
    }

    public final long getFinishedTimeNanos() {
        return this.finishedTimeNanos;
    }

    public final long getLastFrameTimeNanos() {
        return this.lastFrameTimeNanos;
    }

    public final B0 getTypeConverter() {
        return this.typeConverter;
    }

    @Override // androidx.compose.runtime.d2
    public Object getValue() {
        return this.value$delegate.getValue();
    }

    public final Object getVelocity() {
        return this.typeConverter.getConvertFromVector().invoke(this.velocityVector);
    }

    public final AbstractC0329q getVelocityVector() {
        return this.velocityVector;
    }

    public final boolean isRunning() {
        return this.isRunning;
    }

    public final void setFinishedTimeNanos$animation_core(long j2) {
        this.finishedTimeNanos = j2;
    }

    public final void setLastFrameTimeNanos$animation_core(long j2) {
        this.lastFrameTimeNanos = j2;
    }

    public final void setRunning$animation_core(boolean z2) {
        this.isRunning = z2;
    }

    public void setValue$animation_core(Object obj) {
        this.value$delegate.setValue(obj);
    }

    public final void setVelocityVector$animation_core(AbstractC0329q abstractC0329q) {
        this.velocityVector = abstractC0329q;
    }

    public String toString() {
        return "AnimationState(value=" + getValue() + ", velocity=" + getVelocity() + ", isRunning=" + this.isRunning + ", lastFrameTimeNanos=" + this.lastFrameTimeNanos + ", finishedTimeNanos=" + this.finishedTimeNanos + ')';
    }

    public /* synthetic */ C0317k(B0 b02, Object obj, AbstractC0329q abstractC0329q, long j2, long j3, boolean z2, int i2, AbstractC1378g abstractC1378g) {
        this(b02, obj, (i2 & 4) != 0 ? null : abstractC0329q, (i2 & 8) != 0 ? Long.MIN_VALUE : j2, (i2 & 16) != 0 ? Long.MIN_VALUE : j3, (i2 & 32) != 0 ? false : z2);
    }
}
