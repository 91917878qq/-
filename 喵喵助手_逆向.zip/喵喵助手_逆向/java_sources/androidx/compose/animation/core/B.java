package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface B extends F {
    @Override // androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    /* synthetic */ F0 vectorize(B0 b02);

    @Override // androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    <V extends AbstractC0329q> I0 vectorize(B0 b02);

    @Override // androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    /* synthetic */ J0 vectorize(B0 b02);
}
