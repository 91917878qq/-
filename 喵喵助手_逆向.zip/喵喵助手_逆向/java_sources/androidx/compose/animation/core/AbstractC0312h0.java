package androidx.compose.animation.core;

import androidx.compose.runtime.snapshots.AbstractC0794p;

/* JADX INFO: renamed from: androidx.compose.animation.core.h0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0312h0 {
    private static final long MAX_LONG_MILLIS = 9223372036854L;

    public static final long estimateAnimationDurationMillis(float f2, float f3, float f4, float f5, float f6) {
        return f3 == 0.0f ? MAX_LONG_MILLIS : estimateAnimationDurationMillis(f2, f3, f4, f5, f6);
    }

    private static final double estimateCriticallyDamped(double d2, double d3, double d4, double d5) {
        double d6 = d5;
        double d7 = d2 * d3;
        double d8 = d4 - d7;
        double dLog = Math.log(Math.abs(d6 / d3)) / d2;
        double dLog2 = Math.log(Math.abs(d6 / d8));
        int i2 = 0;
        double dLog3 = dLog2;
        for (int i3 = 0; i3 < 6; i3++) {
            dLog3 = dLog2 - Math.log(Math.abs(dLog3 / d2));
        }
        double d9 = dLog3 / d2;
        if (!((Double.doubleToRawLongBits(dLog) & AbstractC0794p.SnapshotIdMax) < 9218868437227405312L)) {
            dLog = d9;
        } else if ((Double.doubleToRawLongBits(d9) & AbstractC0794p.SnapshotIdMax) < 9218868437227405312L) {
            dLog = Math.max(dLog, d9);
        }
        double d10 = (-(d7 + d8)) / (d2 * d8);
        double d11 = d2 * d10;
        double dExp = (Math.exp(d11) * d8 * d10) + (Math.exp(d11) * d3);
        if (Double.isNaN(d10) || d10 <= 0.0d) {
            d6 = -d6;
        } else if (d10 <= 0.0d || (-dExp) >= d6) {
            dLog = (-(2.0d / d2)) - (d3 / d8);
        } else {
            if (d8 < 0.0d && d3 > 0.0d) {
                dLog = 0.0d;
            }
            d6 = -d6;
        }
        double d12 = Double.MAX_VALUE;
        while (d12 > 0.001d && i2 < 100) {
            i2++;
            double d13 = d2 * dLog;
            double dExp2 = dLog - (((Math.exp(d13) * ((d8 * dLog) + d3)) + d6) / (Math.exp(d13) * (((((double) 1) + d13) * d8) + d7)));
            double dAbs = Math.abs(dLog - dExp2);
            dLog = dExp2;
            d12 = dAbs;
        }
        return dLog;
    }

    private static final long estimateDurationInternal(double d2, double d3, double d4, double d5, double d6, double d7, double d8) {
        double d9 = d6;
        if (d7 == 0.0d && d9 == 0.0d) {
            return 0L;
        }
        if (d7 < 0.0d) {
            d9 = -d9;
        }
        double dAbs = Math.abs(d7);
        return (long) ((d5 > 1.0d ? estimateOverDamped(d2, d4, dAbs, d9, d8) : d5 < 1.0d ? estimateUnderDamped(d2, d3, dAbs, d9, d8) : estimateCriticallyDamped(d2, dAbs, d9, d8)) * 1000.0d);
    }

    private static final double estimateOverDamped(double d2, double d3, double d4, double d5, double d6) {
        double dLog;
        double d7;
        double d8 = d2 - d3;
        double d9 = ((d2 * d4) - d5) / d8;
        double d10 = d4 - d9;
        double dLog2 = Math.log(Math.abs(d6 / d10)) / d2;
        double dLog3 = Math.log(Math.abs(d6 / d9)) / d3;
        if ((Double.doubleToRawLongBits(dLog2) & AbstractC0794p.SnapshotIdMax) < 9218868437227405312L) {
            if ((Double.doubleToRawLongBits(dLog3) & AbstractC0794p.SnapshotIdMax) < 9218868437227405312L) {
                dLog2 = Math.max(dLog2, dLog3);
            }
            dLog = dLog2;
        } else {
            dLog = dLog3;
        }
        double d11 = d10 * d2;
        double dLog4 = Math.log(d11 / ((-d9) * d3)) / (d3 - d2);
        if (Double.isNaN(dLog4) || dLog4 <= 0.0d) {
            d7 = -d6;
        } else if (dLog4 <= 0.0d || (-estimateOverDamped$xInflection(d10, d2, dLog4, d9, d3)) >= d6) {
            dLog = Math.log((-((d9 * d3) * d3)) / (d11 * d2)) / d8;
            d7 = d6;
        } else {
            if (d9 > 0.0d && d10 < 0.0d) {
                dLog = 0.0d;
            }
            d7 = -d6;
        }
        double d12 = d9 * d3;
        if (Math.abs((Math.exp(d3 * dLog) * d12) + (Math.exp(d2 * dLog) * d11)) < 1.0E-4d) {
            return dLog;
        }
        double d13 = Double.MAX_VALUE;
        int i2 = 0;
        while (d13 > 0.001d && i2 < 100) {
            i2++;
            double d14 = d2 * dLog;
            double d15 = d3 * dLog;
            double dExp = dLog - ((((Math.exp(d15) * d9) + (Math.exp(d14) * d10)) + d7) / ((Math.exp(d15) * d12) + (Math.exp(d14) * d11)));
            double dAbs = Math.abs(dLog - dExp);
            dLog = dExp;
            d13 = dAbs;
        }
        return dLog;
    }

    private static final double estimateOverDamped$xInflection(double d2, double d3, double d4, double d5, double d6) {
        return (Math.exp(d6 * d4) * d5) + (Math.exp(d3 * d4) * d2);
    }

    private static final double estimateUnderDamped(double d2, double d3, double d4, double d5, double d6) {
        double d7 = (d5 - (d2 * d4)) / d3;
        return Math.log(d6 / Math.sqrt((d7 * d7) + (d4 * d4))) / d2;
    }

    private static final boolean isNotFinite(double d2) {
        return !((Double.doubleToRawLongBits(d2) & AbstractC0794p.SnapshotIdMax) < 9218868437227405312L);
    }

    private static final double iterateNewtonsMethod(double d2, h1.c cVar, h1.c cVar2) {
        return d2 - (((Number) cVar.invoke(Double.valueOf(d2))).doubleValue() / ((Number) cVar2.invoke(Double.valueOf(d2))).doubleValue());
    }

    public static final long estimateAnimationDurationMillis(double d2, double d3, double d4, double d5, double d6) {
        double dSqrt = Math.sqrt(d2) * 2.0d * d3;
        double d7 = (dSqrt * dSqrt) - (4.0d * d2);
        double dSqrt2 = d7 < 0.0d ? 0.0d : Math.sqrt(d7);
        double dSqrt3 = d7 < 0.0d ? Math.sqrt(Math.abs(d7)) : 0.0d;
        double d8 = -dSqrt;
        return estimateDurationInternal((d8 + dSqrt2) * 0.5d, dSqrt3 * 0.5d, (d8 - dSqrt2) * 0.5d, d3, d4, d5, d6);
    }

    public static final long estimateAnimationDurationMillis(double d2, double d3, double d4, double d5, double d6, double d7) {
        double dSqrt = d3 / (Math.sqrt(d2 * d4) * 2.0d);
        double d8 = (d3 * d3) - ((4.0d * d4) * d2);
        double d9 = 1.0d / (2.0d * d4);
        double dSqrt2 = d8 < 0.0d ? 0.0d : Math.sqrt(d8);
        double d10 = -d3;
        return estimateDurationInternal((d10 + dSqrt2) * d9, (d8 < 0.0d ? Math.sqrt(Math.abs(d8)) : 0.0d) * d9, (d10 - dSqrt2) * d9, dSqrt, d5, d6, d7);
    }
}
