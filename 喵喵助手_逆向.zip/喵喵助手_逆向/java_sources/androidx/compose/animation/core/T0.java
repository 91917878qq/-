package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class T0 implements I0 {
    public static final int $stable = 8;
    private final K0 anim;
    private final int delayMillis;
    private final int durationMillis;
    private final C easing;

    public T0() {
        this(0, 0, null, 7, null);
    }

    @Override // androidx.compose.animation.core.I0
    public int getDelayMillis() {
        return this.delayMillis;
    }

    @Override // androidx.compose.animation.core.I0
    public int getDurationMillis() {
        return this.durationMillis;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    public final C getEasing() {
        return this.easing;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.anim.getValueFromNanos(j2, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.anim.getVelocityFromNanos(j2, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }

    public T0(int i2, int i3, C c2) {
        this.durationMillis = i2;
        this.delayMillis = i3;
        this.easing = c2;
        this.anim = new K0(new K(getDurationMillis(), getDelayMillis(), c2));
    }

    public /* synthetic */ T0(int i2, int i3, C c2, int i4, AbstractC1378g abstractC1378g) {
        this((i4 & 1) != 0 ? 300 : i2, (i4 & 2) != 0 ? 0 : i3, (i4 & 4) != 0 ? E.getFastOutSlowInEasing() : c2);
    }
}
