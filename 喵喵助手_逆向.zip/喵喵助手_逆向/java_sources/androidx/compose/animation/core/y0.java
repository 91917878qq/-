package androidx.compose.animation.core;

import G.C0178h;
import a.AbstractC0292a;
import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.v0.a;
import androidx.compose.animation.core.v0.c;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.d2;
import androidx.compose.runtime.snapshots.AbstractC0788j;
import e0.C1311h;
import kotlin.jvm.internal.C1379h;
import r1.InterfaceC1458g;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public abstract class y0 {
    public static final int AnimationDebugDurationScale = 1;
    private static final float NoReset = -1.0f;
    private static final float ResetAnimationSnap = -3.0f;
    private static final float ResetAnimationSnapCurrent = -4.0f;
    private static final float ResetAnimationSnapTarget = -5.0f;
    private static final float ResetNoSnap = -2.0f;
    private static final U0.d SeekableStateObserver$delegate;
    private static final h1.c SeekableTransitionStateTotalDurationChanged = new O0.L0(15);

    public static final class a implements h1.f {
        public static final a INSTANCE = new a();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1953972046);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1953972046, i2, -1, "androidx.compose.animation.core.animateDp.<anonymous> (Transition.kt:1977)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, C1311h.m5074boximpl(U0.getVisibilityThreshold(C1311h.Companion)), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class b implements h1.f {
        public static final b INSTANCE = new b();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-985243360);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-985243360, i2, -1, "androidx.compose.animation.core.animateFloat.<anonymous> (Transition.kt:1947)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class c implements h1.f {
        public static final c INSTANCE = new c();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(2109424115);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(2109424115, i2, -1, "androidx.compose.animation.core.animateInt.<anonymous> (Transition.kt:2101)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, 1, 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class d implements h1.f {
        public static final d INSTANCE = new d();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-428458074);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-428458074, i2, -1, "androidx.compose.animation.core.animateIntOffset.<anonymous> (Transition.kt:2070)");
            }
            long j2 = 1;
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, e0.o.m5187boximpl(e0.o.m5190constructorimpl((j2 & 4294967295L) | (j2 << 32))), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class e implements h1.f {
        public static final e INSTANCE = new e();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(811932052);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(811932052, i2, -1, "androidx.compose.animation.core.animateIntSize.<anonymous> (Transition.kt:2132)");
            }
            long j2 = 1;
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, e0.s.m5231boximpl(e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32))), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class f implements h1.f {
        public static final f INSTANCE = new f();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-1662821959);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-1662821959, i2, -1, "androidx.compose.animation.core.animateOffset.<anonymous> (Transition.kt:2007)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, J.f.m39boximpl(U0.getVisibilityThreshold(J.f.Companion)), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class g implements h1.f {
        public static final g INSTANCE = new g();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(946173386);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(946173386, i2, -1, "androidx.compose.animation.core.animateRect.<anonymous> (Transition.kt:2162)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, U0.getVisibilityThreshold(J.h.Companion), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class h implements h1.f {
        public static final h INSTANCE = new h();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(493329511);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(493329511, i2, -1, "androidx.compose.animation.core.animateSize.<anonymous> (Transition.kt:2037)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, J.l.m107boximpl(U0.getVisibilityThreshold(J.l.Companion)), 3, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class i implements h1.f {
        public static final i INSTANCE = new i();

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((w0) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final C0316j0 invoke(w0 w0Var, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(-2137771706);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-2137771706, i2, -1, "androidx.compose.animation.core.animateValue.<anonymous> (Transition.kt:1834)");
            }
            C0316j0 c0316j0Spring$default = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return c0316j0Spring$default;
        }
    }

    public static final class j implements h1.a {
        final /* synthetic */ v0 $this_animateValue;

        public j(v0 v0Var) {
            this.$this_animateValue = v0Var;
        }

        @Override // h1.a
        public final w0 invoke() {
            return this.$this_animateValue.getSegment();
        }
    }

    public static final class k implements h1.a {
        final /* synthetic */ v0 $this_animateValue;

        public k(v0 v0Var) {
            this.$this_animateValue = v0Var;
        }

        /* JADX WARN: Type inference failed for: r0v1, types: [S, java.lang.Object] */
        @Override // h1.a
        public final S invoke() {
            return this.$this_animateValue.getTargetState();
        }
    }

    public static final class l implements androidx.compose.runtime.V {
        final /* synthetic */ v0 $this_createChildTransitionInternal$inlined;
        final /* synthetic */ v0 $transition$inlined;

        public l(v0 v0Var, v0 v0Var2) {
            this.$this_createChildTransitionInternal$inlined = v0Var;
            this.$transition$inlined = v0Var2;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$this_createChildTransitionInternal$inlined.removeTransition$animation_core(this.$transition$inlined);
        }
    }

    public static final class m implements androidx.compose.runtime.V {
        final /* synthetic */ v0.a $lazyAnim$inlined;
        final /* synthetic */ v0 $this_createDeferredAnimation$inlined;

        public m(v0 v0Var, v0.a aVar) {
            this.$this_createDeferredAnimation$inlined = v0Var;
            this.$lazyAnim$inlined = aVar;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$this_createDeferredAnimation$inlined.removeAnimation$animation_core((androidx.compose.animation.core.v0.a) this.$lazyAnim$inlined);
        }
    }

    public static final class n implements androidx.compose.runtime.V {
        final /* synthetic */ v0 $this_createTransitionAnimation$inlined;
        final /* synthetic */ v0.c $transitionAnimation$inlined;

        public n(v0 v0Var, v0.c cVar) {
            this.$this_createTransitionAnimation$inlined = v0Var;
            this.$transitionAnimation$inlined = cVar;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$this_createTransitionAnimation$inlined.removeAnimation$animation_core((androidx.compose.animation.core.v0.c) this.$transitionAnimation$inlined);
        }
    }

    public static final class o extends a1.j implements h1.e {
        final /* synthetic */ z0 $transitionState;
        Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public o(z0 z0Var, Y0.c cVar) {
            super(2, cVar);
            this.$transitionState = z0Var;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new o(this.$transitionState, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            z0 z0Var;
            z1.a aVar;
            Z0.a aVar2 = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                ((C0308f0) this.$transitionState).observeTotalDuration$animation_core();
                z1.a compositionContinuationMutex$animation_core = ((C0308f0) this.$transitionState).getCompositionContinuationMutex$animation_core();
                z0 z0Var2 = this.$transitionState;
                this.L$0 = compositionContinuationMutex$animation_core;
                this.L$1 = z0Var2;
                this.label = 1;
                z1.d dVar = (z1.d) compositionContinuationMutex$animation_core;
                if (dVar.d(null, this) == aVar2) {
                    return aVar2;
                }
                z0Var = z0Var2;
                aVar = dVar;
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                z0Var = (z0) this.L$1;
                aVar = (z1.a) this.L$0;
                AbstractC0292a.H(obj);
            }
            try {
                ((C0308f0) z0Var).setComposedTargetState$animation_core(((C0308f0) z0Var).getTargetState());
                InterfaceC1458g compositionContinuation$animation_core = ((C0308f0) z0Var).getCompositionContinuation$animation_core();
                if (compositionContinuation$animation_core != null) {
                    compositionContinuation$animation_core.resumeWith(((C0308f0) z0Var).getTargetState());
                }
                ((C0308f0) z0Var).setCompositionContinuation$animation_core(null);
                ((z1.d) aVar).f(null);
                return U0.n.f1521a;
            } catch (Throwable th) {
                ((z1.d) aVar).f(null);
                throw th;
            }
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((o) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class p implements androidx.compose.runtime.V {
        final /* synthetic */ v0 $transition$inlined;

        public p(v0 v0Var) {
            this.$transition$inlined = v0Var;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$transition$inlined.onDisposed$animation_core();
        }
    }

    public static final class q implements androidx.compose.runtime.V {
        final /* synthetic */ v0 $transition$inlined;

        public q(v0 v0Var) {
            this.$transition$inlined = v0Var;
        }

        @Override // androidx.compose.runtime.V
        public void dispose() {
            this.$transition$inlined.onDisposed$animation_core();
        }
    }

    static {
        U0.e[] eVarArr = U0.e.f1510b;
        SeekableStateObserver$delegate = j1.a.K(new F0.a(9));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.snapshots.A SeekableStateObserver_delegate$lambda$7() {
        androidx.compose.runtime.snapshots.A a2 = new androidx.compose.runtime.snapshots.A(new O0.L0(16));
        a2.start();
        return a2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n SeekableStateObserver_delegate$lambda$7$lambda$5(h1.a aVar) {
        aVar.invoke();
        return U0.n.f1521a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n SeekableTransitionStateTotalDurationChanged$lambda$4(C0308f0 c0308f0) {
        c0308f0.onTotalDurationChanged$animation_core();
        return U0.n.f1521a;
    }

    private static final <S, T, V extends AbstractC0329q> void UpdateInitialAndTargetValues(v0 v0Var, androidx.compose.animation.core.v0.c cVar, T t2, T t3, F f2, InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(867041821);
        if ((i2 & 6) == 0) {
            i3 = (interfaceC0768pStartRestartGroup.changed(v0Var) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(cVar) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            i3 |= (i2 & 512) == 0 ? interfaceC0768pStartRestartGroup.changed(t2) : interfaceC0768pStartRestartGroup.changedInstance(t2) ? 256 : 128;
        }
        if ((i2 & 3072) == 0) {
            i3 |= (i2 & 4096) == 0 ? interfaceC0768pStartRestartGroup.changed(t3) : interfaceC0768pStartRestartGroup.changedInstance(t3) ? 2048 : 1024;
        }
        if ((i2 & 24576) == 0) {
            i3 |= (32768 & i2) == 0 ? interfaceC0768pStartRestartGroup.changed(f2) : interfaceC0768pStartRestartGroup.changedInstance(f2) ? 16384 : 8192;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i3 & 9363) != 9362, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(867041821, i3, -1, "androidx.compose.animation.core.UpdateInitialAndTargetValues (Transition.kt:1907)");
            }
            if (v0Var.isSeeking()) {
                cVar.updateInitialAndTargetValue$animation_core(t2, t3, f2);
            } else {
                cVar.updateTargetValue$animation_core(t3, f2);
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new C0178h(v0Var, (v0.c) cVar, (Object) t2, (Object) t3, f2, i2));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final U0.n UpdateInitialAndTargetValues$lambda$32(v0 v0Var, v0.c cVar, Object obj, Object obj2, F f2, int i2, InterfaceC0768p interfaceC0768p, int i3) {
        UpdateInitialAndTargetValues(v0Var, cVar, obj, obj2, f2, interfaceC0768p, AbstractC0743g1.updateChangedFlags(i2 | 1));
        return U0.n.f1521a;
    }

    public static final <S> d2 animateDp(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = a.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "DpAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(C1311h.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateFloat(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = b.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "FloatAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(C1379h.f3125a);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateInt(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = c.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "IntAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(kotlin.jvm.internal.m.f3126a);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateIntOffset(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = d.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "IntOffsetAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(e0.o.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateIntSize(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = e.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "IntSizeAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(e0.s.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateOffset(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = f.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "OffsetAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(J.f.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateRect(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = g.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "RectAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(J.h.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S> d2 animateSize(v0 v0Var, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        if ((i3 & 1) != 0) {
            fVar = h.INSTANCE;
        }
        if ((i3 & 2) != 0) {
            str = "SizeAnimation";
        }
        String str2 = str;
        B0 vectorConverter = E0.getVectorConverter(J.l.Companion);
        int i4 = i2 & 14;
        int i5 = i2 << 3;
        int i6 = i4 | (i5 & 896) | (i5 & 7168) | (i5 & 57344);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i6 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i7 = (i6 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i7));
        int i8 = i6 & 14;
        int i9 = i8 ^ 6;
        boolean z3 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i7));
        boolean z4 = (i9 > 4 && interfaceC0768p.changed(v0Var)) || (i6 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i6 >> 3) & 112)), vectorConverter, str2, interfaceC0768p, i8 | ((i6 << 6) & 458752));
    }

    public static final <S, T, V extends AbstractC0329q> d2 animateValue(v0 v0Var, B0 b02, h1.f fVar, String str, h1.f fVar2, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        Object currentState;
        h1.f fVar3 = (i3 & 2) != 0 ? i.INSTANCE : fVar;
        String str2 = (i3 & 4) != 0 ? "ValueAnimation" : str;
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(1666853325);
            interfaceC0768p.endReplaceGroup();
            currentState = v0Var.getCurrentState();
        } else {
            interfaceC0768p.startReplaceGroup(1666599280);
            boolean z2 = (((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
            currentState = interfaceC0768p.rememberedValue();
            if (z2 || currentState == InterfaceC0768p.Companion.getEmpty()) {
                AbstractC0788j.a aVar = AbstractC0788j.Companion;
                AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
                h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
                AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
                try {
                    Object currentState2 = v0Var.getCurrentState();
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    interfaceC0768p.updateRememberedValue(currentState2);
                    currentState = currentState2;
                } catch (Throwable th) {
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                    throw th;
                }
            }
            interfaceC0768p.endReplaceGroup();
        }
        int i4 = (i2 >> 9) & 112;
        Object objInvoke = fVar2.invoke(currentState, interfaceC0768p, Integer.valueOf(i4));
        int i5 = i2 & 14;
        int i6 = i5 ^ 6;
        boolean z3 = (i6 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = Q1.derivedStateOf(new k(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        Object objInvoke2 = fVar2.invoke(((d2) objRememberedValue).getValue(), interfaceC0768p, Integer.valueOf(i4));
        boolean z4 = (i6 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (z4 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = Q1.derivedStateOf(new j(v0Var));
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        return createTransitionAnimation(v0Var, objInvoke, objInvoke2, (F) fVar3.invoke(((d2) objRememberedValue2).getValue(), interfaceC0768p, Integer.valueOf((i2 >> 3) & 112)), b02, str2, interfaceC0768p, (57344 & (i2 << 9)) | i5 | (458752 & (i2 << 6)));
    }

    public static final <S, T> v0 createChildTransition(v0 v0Var, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        boolean z2 = true;
        if ((i3 & 1) != 0) {
            str = "ChildTransition";
        }
        String str2 = str;
        int i4 = i2 & 14;
        if (((i4 ^ 6) <= 4 || !interfaceC0768p.changed(v0Var)) && (i2 & 6) != 4) {
            z2 = false;
        }
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = v0Var.getCurrentState();
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        if (v0Var.isSeeking()) {
            objRememberedValue = v0Var.getCurrentState();
        }
        int i5 = (i2 >> 3) & 112;
        return createChildTransitionInternal(v0Var, fVar.invoke(objRememberedValue, interfaceC0768p, Integer.valueOf(i5)), fVar.invoke(v0Var.getTargetState(), interfaceC0768p, Integer.valueOf(i5)), str2, interfaceC0768p, i4 | ((i2 << 6) & 7168));
    }

    public static final <S, T> v0 createChildTransitionInternal(v0 v0Var, T t2, T t3, String str, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-198307638, i2, -1, "androidx.compose.animation.core.createChildTransitionInternal (Transition.kt:1780)");
        }
        int i3 = (i2 & 14) ^ 6;
        boolean z2 = true;
        boolean z3 = (i3 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = new v0(new X(t2), v0Var, v0Var.getLabel() + " > " + str);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        v0 v0Var2 = (v0) objRememberedValue;
        if ((i3 <= 4 || !interfaceC0768p.changed(v0Var)) && (i2 & 6) != 4) {
            z2 = false;
        }
        boolean zChanged = interfaceC0768p.changed(v0Var2) | z2;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = new M0.m(8, v0Var, v0Var2);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.Z.DisposableEffect(v0Var2, (h1.c) objRememberedValue2, interfaceC0768p, 0);
        if (v0Var.isSeeking()) {
            v0Var2.seek(t2, t3, v0Var.getLastSeekedTimeNanos$animation_core());
        } else {
            v0Var2.updateTarget$animation_core(t3);
            v0Var2.setSeeking$animation_core(false);
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return v0Var2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V createChildTransitionInternal$lambda$22$lambda$21(v0 v0Var, v0 v0Var2, androidx.compose.runtime.W w2) {
        v0Var.addTransition$animation_core(v0Var2);
        return new l(v0Var, v0Var2);
    }

    public static final <S, T, V extends AbstractC0329q> androidx.compose.animation.core.v0.a createDeferredAnimation(v0 v0Var, B0 b02, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            str = "DeferredAnimation";
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1714122528, i2, -1, "androidx.compose.animation.core.createDeferredAnimation (Transition.kt:1738)");
        }
        int i4 = (i2 & 14) ^ 6;
        boolean z2 = true;
        boolean z3 = (i4 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = v0Var.new a(b02, str);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        v0.a aVar = (v0.a) objRememberedValue;
        if ((i4 <= 4 || !interfaceC0768p.changed(v0Var)) && (i2 & 6) != 4) {
            z2 = false;
        }
        boolean zChangedInstance = interfaceC0768p.changedInstance(aVar) | z2;
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (zChangedInstance || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = new M0.m(9, v0Var, aVar);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.Z.DisposableEffect(aVar, (h1.c) objRememberedValue2, interfaceC0768p, 0);
        if (v0Var.isSeeking()) {
            aVar.setupSeeking$animation_core();
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V createDeferredAnimation$lambda$17$lambda$16(v0 v0Var, v0.a aVar, androidx.compose.runtime.W w2) {
        return new m(v0Var, aVar);
    }

    public static final <S, T, V extends AbstractC0329q> d2 createTransitionAnimation(v0 v0Var, T t2, T t3, F f2, B0 b02, String str, InterfaceC0768p interfaceC0768p, int i2) throws Throwable {
        AbstractC0788j abstractC0788j;
        h1.c cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-304821198, i2, -1, "androidx.compose.animation.core.createTransitionAnimation (Transition.kt:1869)");
        }
        int i3 = i2 & 14;
        int i4 = i3 ^ 6;
        boolean z2 = (i4 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            AbstractC0788j.a aVar = AbstractC0788j.Companion;
            AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
            h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
            AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
            try {
                abstractC0788j = abstractC0788jMakeCurrentNonObservable;
                cVar = readObserver;
                try {
                    Object cVar2 = v0Var.new c(t2, AbstractC0319l.createZeroVectorFrom(b02, t3), b02, str);
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788j, cVar);
                    interfaceC0768p.updateRememberedValue(cVar2);
                    objRememberedValue = cVar2;
                } catch (Throwable th) {
                    th = th;
                    aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788j, cVar);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                abstractC0788j = abstractC0788jMakeCurrentNonObservable;
                cVar = readObserver;
            }
        }
        v0.c cVar3 = (v0.c) objRememberedValue;
        int i5 = (i2 >> 3) & 8;
        int i6 = i2 << 3;
        UpdateInitialAndTargetValues(v0Var, cVar3, t2, t3, f2, interfaceC0768p, (i5 << 9) | (i5 << 6) | i3 | (i6 & 896) | (i6 & 7168) | (57344 & i6));
        boolean zChanged = ((i4 > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4) | interfaceC0768p.changed(cVar3);
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue2 = new M0.m(10, v0Var, cVar3);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.Z.DisposableEffect(cVar3, (h1.c) objRememberedValue2, interfaceC0768p, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return cVar3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V createTransitionAnimation$lambda$31$lambda$30(v0 v0Var, v0.c cVar, androidx.compose.runtime.W w2) {
        v0Var.addAnimation$animation_core(cVar);
        return new n(v0Var, cVar);
    }

    public static final androidx.compose.runtime.snapshots.A getSeekableStateObserver() {
        return (androidx.compose.runtime.snapshots.A) SeekableStateObserver$delegate.getValue();
    }

    public static final <T> v0 rememberTransition(z0 z0Var, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            str = null;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(1643203617, i2, -1, "androidx.compose.animation.core.rememberTransition (Transition.kt:804)");
        }
        int i4 = (i2 & 14) ^ 6;
        boolean z2 = true;
        boolean z3 = (i4 > 4 && interfaceC0768p.changed(z0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z3 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            AbstractC0788j.a aVar = AbstractC0788j.Companion;
            AbstractC0788j currentThreadSnapshot = aVar.getCurrentThreadSnapshot();
            h1.c readObserver = currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null;
            AbstractC0788j abstractC0788jMakeCurrentNonObservable = aVar.makeCurrentNonObservable(currentThreadSnapshot);
            try {
                Object v0Var = new v0(z0Var, str);
                aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                interfaceC0768p.updateRememberedValue(v0Var);
                objRememberedValue = v0Var;
            } catch (Throwable th) {
                aVar.restoreNonObservable(currentThreadSnapshot, abstractC0788jMakeCurrentNonObservable, readObserver);
                throw th;
            }
        }
        v0 v0Var2 = (v0) objRememberedValue;
        if (z0Var instanceof C0308f0) {
            interfaceC0768p.startReplaceGroup(-1357588631);
            C0308f0 c0308f0 = (C0308f0) z0Var;
            Object currentState = c0308f0.getCurrentState();
            Object targetState = c0308f0.getTargetState();
            if ((i4 <= 4 || !interfaceC0768p.changed(z0Var)) && (i2 & 6) != 4) {
                z2 = false;
            }
            Object objRememberedValue2 = interfaceC0768p.rememberedValue();
            if (z2 || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue2 = new o(z0Var, null);
                interfaceC0768p.updateRememberedValue(objRememberedValue2);
            }
            androidx.compose.runtime.Z.LaunchedEffect(currentState, targetState, (h1.e) objRememberedValue2, interfaceC0768p, 0);
            interfaceC0768p.endReplaceGroup();
        } else {
            interfaceC0768p.startReplaceGroup(-1357127072);
            v0Var2.animateTo$animation_core(z0Var.getTargetState(), interfaceC0768p, 0);
            interfaceC0768p.endReplaceGroup();
        }
        boolean zChanged = interfaceC0768p.changed(v0Var2);
        Object objRememberedValue3 = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue3 = new x0(v0Var2, 0);
            interfaceC0768p.updateRememberedValue(objRememberedValue3);
        }
        androidx.compose.runtime.Z.DisposableEffect(v0Var2, (h1.c) objRememberedValue3, interfaceC0768p, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return v0Var2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V rememberTransition$lambda$13$lambda$12(v0 v0Var, androidx.compose.runtime.W w2) {
        return new p(v0Var);
    }

    public static final <T> v0 updateTransition(T t2, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            str = null;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(2029166765, i2, -1, "androidx.compose.animation.core.updateTransition (Transition.kt:87)");
        }
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        C0765o c0765o = InterfaceC0768p.Companion;
        if (objRememberedValue == c0765o.getEmpty()) {
            objRememberedValue = new v0(t2, str);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        v0 v0Var = (v0) objRememberedValue;
        v0Var.animateTo$animation_core(t2, interfaceC0768p, (i2 & 8) | 48 | (i2 & 14));
        Object objRememberedValue2 = interfaceC0768p.rememberedValue();
        if (objRememberedValue2 == c0765o.getEmpty()) {
            objRememberedValue2 = new x0(v0Var, 1);
            interfaceC0768p.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.Z.DisposableEffect(v0Var, (h1.c) objRememberedValue2, interfaceC0768p, 54);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return v0Var;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.V updateTransition$lambda$3$lambda$2(v0 v0Var, androidx.compose.runtime.W w2) {
        return new q(v0Var);
    }

    @U0.a
    public static final <T> v0 updateTransition(X x2, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            str = null;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(882913843, i2, -1, "androidx.compose.animation.core.updateTransition (Transition.kt:863)");
        }
        v0 v0VarRememberTransition = rememberTransition(x2, str, interfaceC0768p, i2 & 126, 0);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return v0VarRememberTransition;
    }
}
