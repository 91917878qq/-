package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0310g0 implements B {
    public static final int $stable = 0;
    private final int delay;

    public C0310g0() {
        this(0, 1, null);
    }

    public boolean equals(Object obj) {
        return (obj instanceof C0310g0) && ((C0310g0) obj).delay == this.delay;
    }

    public final int getDelay() {
        return this.delay;
    }

    public int hashCode() {
        return this.delay;
    }

    public C0310g0(int i2) {
        this.delay = i2;
    }

    public /* synthetic */ C0310g0(int i2, int i3, AbstractC1378g abstractC1378g) {
        this((i3 & 1) != 0 ? 0 : i2);
    }

    @Override // androidx.compose.animation.core.B, androidx.compose.animation.core.F, androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> I0 vectorize(B0 b02) {
        return new R0(this.delay);
    }
}
