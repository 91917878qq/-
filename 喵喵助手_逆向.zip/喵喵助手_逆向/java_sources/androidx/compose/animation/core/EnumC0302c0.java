package androidx.compose.animation.core;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.compose.animation.core.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0302c0 {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ EnumC0302c0[] $VALUES;
    public static final EnumC0302c0 Restart = new EnumC0302c0("Restart", 0);
    public static final EnumC0302c0 Reverse = new EnumC0302c0("Reverse", 1);

    private static final /* synthetic */ EnumC0302c0[] $values() {
        return new EnumC0302c0[]{Restart, Reverse};
    }

    static {
        EnumC0302c0[] enumC0302c0Arr$values = $values();
        $VALUES = enumC0302c0Arr$values;
        $ENTRIES = AbstractC0292a.q(enumC0302c0Arr$values);
    }

    private EnumC0302c0(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static EnumC0302c0 valueOf(String str) {
        return (EnumC0302c0) Enum.valueOf(EnumC0302c0.class, str);
    }

    public static EnumC0302c0[] values() {
        return (EnumC0302c0[]) $VALUES.clone();
    }
}
