package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface B0 {
    h1.c getConvertFromVector();

    h1.c getConvertToVector();
}
