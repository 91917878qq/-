package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public interface F0 {
    long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3);

    default AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return getVelocityFromNanos(getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3), abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3);

    AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3);

    boolean isInfinite();
}
