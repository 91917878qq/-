package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0332s {
    G get(int i2);
}
