package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0339w implements C {
    public static final int $stable = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final float f1659a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final float f1660b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final float f1661c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final float f1662d;
    private final float max;
    private final float min;

    public C0339w(float f2, float f3, float f4, float f5) {
        this.f1659a = f2;
        this.f1660b = f3;
        this.f1661c = f4;
        this.f1662d = f5;
        if (!((Float.isNaN(f2) || Float.isNaN(f3) || Float.isNaN(f4) || Float.isNaN(f5)) ? false : true)) {
            AbstractC0300b0.throwIllegalArgumentException("Parameters to CubicBezierEasing cannot be NaN. Actual parameters are: " + f2 + ", " + f3 + ", " + f4 + ", " + f5 + '.');
        }
        long jComputeCubicVerticalBounds = androidx.compose.ui.graphics.J.computeCubicVerticalBounds(0.0f, f3, f5, 1.0f, new float[5], 0);
        this.min = Float.intBitsToFloat((int) (jComputeCubicVerticalBounds >> 32));
        this.max = Float.intBitsToFloat((int) (jComputeCubicVerticalBounds & 4294967295L));
    }

    private final void throwNoSolution(float f2) {
        throw new IllegalArgumentException("The cubic curve with parameters (" + this.f1659a + ", " + this.f1660b + ", " + this.f1661c + ", " + this.f1662d + ") has no solution at " + f2);
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0339w) {
            C0339w c0339w = (C0339w) obj;
            if (this.f1659a == c0339w.f1659a && this.f1660b == c0339w.f1660b && this.f1661c == c0339w.f1661c && this.f1662d == c0339w.f1662d) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return Float.hashCode(this.f1662d) + D0.d.a(this.f1661c, D0.d.a(this.f1660b, Float.hashCode(this.f1659a) * 31, 31), 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("CubicBezierEasing(a=");
        sb.append(this.f1659a);
        sb.append(", b=");
        sb.append(this.f1660b);
        sb.append(", c=");
        sb.append(this.f1661c);
        sb.append(", d=");
        return D0.d.p(sb, this.f1662d, ')');
    }

    @Override // androidx.compose.animation.core.C
    public float transform(float f2) {
        if (f2 <= 0.0f || f2 >= 1.0f) {
            return f2;
        }
        float fMax = Math.max(f2, 1.1920929E-7f);
        float fFindFirstCubicRoot = androidx.compose.ui.graphics.J.findFirstCubicRoot(0.0f - fMax, this.f1659a - fMax, this.f1661c - fMax, 1.0f - fMax);
        if (Float.isNaN(fFindFirstCubicRoot)) {
            throwNoSolution(f2);
        }
        float fEvaluateCubic = androidx.compose.ui.graphics.J.evaluateCubic(this.f1660b, this.f1662d, fFindFirstCubicRoot);
        float f3 = this.min;
        float f4 = this.max;
        if (fEvaluateCubic < f3) {
            fEvaluateCubic = f3;
        }
        return fEvaluateCubic > f4 ? f4 : fEvaluateCubic;
    }
}
