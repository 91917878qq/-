package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.n0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0324n0 {
    public static final a Companion = new a(null);
    private static final int Delay = m625constructorimpl(-1);
    private static final int FastForward = m625constructorimpl(1);
    private final int value;

    /* JADX INFO: renamed from: androidx.compose.animation.core.n0$a */
    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: renamed from: getDelay-Eo1U57Q, reason: not valid java name */
        public final int m631getDelayEo1U57Q() {
            return C0324n0.Delay;
        }

        /* JADX INFO: renamed from: getFastForward-Eo1U57Q, reason: not valid java name */
        public final int m632getFastForwardEo1U57Q() {
            return C0324n0.FastForward;
        }

        private a() {
        }
    }

    private /* synthetic */ C0324n0(int i2) {
        this.value = i2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ C0324n0 m624boximpl(int i2) {
        return new C0324n0(i2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    private static int m625constructorimpl(int i2) {
        return i2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m626equalsimpl(int i2, Object obj) {
        return (obj instanceof C0324n0) && i2 == ((C0324n0) obj).m630unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m627equalsimpl0(int i2, int i3) {
        return i2 == i3;
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m628hashCodeimpl(int i2) {
        return Integer.hashCode(i2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m629toStringimpl(int i2) {
        return D0.d.o("StartOffsetType(value=", i2, ')');
    }

    public boolean equals(Object obj) {
        return m626equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m628hashCodeimpl(this.value);
    }

    public String toString() {
        return m629toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ int m630unboximpl() {
        return this.value;
    }
}
