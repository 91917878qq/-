package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.i0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0314i0 {
    public static final int $stable = 8;
    private float finalPosition;
    private double naturalFreq = Math.sqrt(50.0d);
    private float dampingRatio = 1.0f;

    public C0314i0(float f2) {
        this.finalPosition = f2;
    }

    public final float getAcceleration(float f2, float f3) {
        float f4 = f2 - this.finalPosition;
        double d2 = this.naturalFreq;
        return (float) (((-(d2 * d2)) * ((double) f4)) - (((d2 * 2.0d) * ((double) this.dampingRatio)) * ((double) f3)));
    }

    public final float getDampingRatio() {
        return this.dampingRatio;
    }

    public final float getFinalPosition() {
        return this.finalPosition;
    }

    public final float getStiffness() {
        double d2 = this.naturalFreq;
        return (float) (d2 * d2);
    }

    public final void setDampingRatio(float f2) {
        if (f2 < 0.0f) {
            AbstractC0300b0.throwIllegalArgumentException("Damping ratio must be non-negative");
        }
        this.dampingRatio = f2;
    }

    public final void setFinalPosition(float f2) {
        this.finalPosition = f2;
    }

    public final void setStiffness(float f2) {
        if (getStiffness() <= 0.0f) {
            AbstractC0300b0.throwIllegalArgumentException("Spring stiffness constant must be positive.");
        }
        this.naturalFreq = Math.sqrt(f2);
    }

    /* JADX INFO: renamed from: updateValues-IJZedt4$animation_core, reason: not valid java name */
    public final long m608updateValuesIJZedt4$animation_core(float f2, float f3, long j2) {
        double dSin;
        double dCos;
        double dExp;
        double dExp2;
        float f4 = f2 - this.finalPosition;
        double d2 = j2 / 1000.0d;
        float f5 = this.dampingRatio;
        double d3 = ((double) f5) * ((double) f5);
        double d4 = this.naturalFreq;
        double d5 = ((double) (-f5)) * d4;
        if (f5 > 1.0f) {
            double dSqrt = Math.sqrt(d3 - ((double) 1)) * d4;
            double d6 = d5 + dSqrt;
            double d7 = d5 - dSqrt;
            double d8 = f4;
            double d9 = ((d7 * d8) - ((double) f3)) / (d7 - d6);
            double d10 = d8 - d9;
            double d11 = d7 * d2;
            double d12 = d2 * d6;
            dSin = (Math.exp(d12) * d9) + (Math.exp(d11) * d10);
            dExp = Math.exp(d11) * d10 * d7;
            dExp2 = Math.exp(d12) * d9 * d6;
        } else {
            if (f5 != 1.0f) {
                double d13 = 1;
                double dSqrt2 = Math.sqrt(d13 - d3) * d4;
                double d14 = f4;
                double d15 = (((-d5) * d14) + ((double) f3)) * (d13 / dSqrt2);
                double d16 = dSqrt2 * d2;
                double d17 = d2 * d5;
                dSin = ((Math.sin(d16) * d15) + (Math.cos(d16) * d14)) * Math.exp(d17);
                dCos = (((Math.cos(d16) * dSqrt2 * d15) + (Math.sin(d16) * (-dSqrt2) * d14)) * Math.exp(d17)) + (d5 * dSin);
                return W.m589constructorimpl((((long) Float.floatToRawIntBits((float) dCos)) & 4294967295L) | (Float.floatToRawIntBits((float) (dSin + ((double) this.finalPosition))) << 32));
            }
            double d18 = f4;
            double d19 = (d4 * d18) + ((double) f3);
            double d20 = (-d4) * d2;
            double d21 = (d2 * d19) + d18;
            dSin = Math.exp(d20) * d21;
            dExp = Math.exp(d20) * d21 * (-this.naturalFreq);
            dExp2 = Math.exp(d20) * d19;
        }
        dCos = dExp2 + dExp;
        return W.m589constructorimpl((((long) Float.floatToRawIntBits((float) dCos)) & 4294967295L) | (Float.floatToRawIntBits((float) (dSin + ((double) this.finalPosition))) << 32));
    }
}
