package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class R0 implements I0 {
    public static final int $stable = 0;
    private final int delayMillis;

    public R0() {
        this(0, 1, null);
    }

    @Override // androidx.compose.animation.core.I0
    public int getDelayMillis() {
        return this.delayMillis;
    }

    @Override // androidx.compose.animation.core.I0
    public int getDurationMillis() {
        return 0;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return j2 < ((long) getDelayMillis()) * AbstractC0307f.MillisToNanos ? abstractC0329q : abstractC0329q2;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return abstractC0329q3;
    }

    @Override // androidx.compose.animation.core.I0, androidx.compose.animation.core.J0, androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ boolean isInfinite() {
        return super.isInfinite();
    }

    public R0(int i2) {
        this.delayMillis = i2;
    }

    public /* synthetic */ R0(int i2, int i3, AbstractC1378g abstractC1378g) {
        this((i3 & 1) != 0 ? 0 : i2);
    }
}
