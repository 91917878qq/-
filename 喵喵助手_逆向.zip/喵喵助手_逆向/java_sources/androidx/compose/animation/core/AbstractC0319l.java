package androidx.compose.animation.core;

import kotlin.jvm.internal.C1379h;

/* JADX INFO: renamed from: androidx.compose.animation.core.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0319l {
    public static final C0317k AnimationState(float f2, float f3, long j2, long j3, boolean z2) {
        return new C0317k(E0.getVectorConverter(C1379h.f3125a), Float.valueOf(f2), r.AnimationVector(f3), j2, j3, z2);
    }

    public static /* synthetic */ C0317k AnimationState$default(float f2, float f3, long j2, long j3, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        long j4 = (i2 & 4) != 0 ? Long.MIN_VALUE : j2;
        long j5 = (i2 & 8) == 0 ? j3 : Long.MIN_VALUE;
        if ((i2 & 16) != 0) {
            z2 = false;
        }
        return AnimationState(f2, f3, j4, j5, z2);
    }

    public static final <T, V extends AbstractC0329q> C0317k copy(C0317k c0317k, T t2, V v2, long j2, long j3, boolean z2) {
        return new C0317k(c0317k.getTypeConverter(), t2, v2, j2, j3, z2);
    }

    public static /* synthetic */ C0317k copy$default(C0317k c0317k, Object obj, AbstractC0329q abstractC0329q, long j2, long j3, boolean z2, int i2, Object obj2) {
        if ((i2 & 1) != 0) {
            obj = c0317k.getValue();
        }
        if ((i2 & 2) != 0) {
            abstractC0329q = r.copy(c0317k.getVelocityVector());
        }
        AbstractC0329q abstractC0329q2 = abstractC0329q;
        if ((i2 & 4) != 0) {
            j2 = c0317k.getLastFrameTimeNanos();
        }
        long j4 = j2;
        if ((i2 & 8) != 0) {
            j3 = c0317k.getFinishedTimeNanos();
        }
        long j5 = j3;
        if ((i2 & 16) != 0) {
            z2 = c0317k.isRunning();
        }
        return copy(c0317k, obj, abstractC0329q2, j4, j5, z2);
    }

    public static final <T, V extends AbstractC0329q> V createZeroVectorFrom(B0 b02, T t2) {
        V v2 = (V) b02.getConvertToVector().invoke(t2);
        v2.reset$animation_core();
        return v2;
    }

    public static final boolean isFinished(C0317k c0317k) {
        return c0317k.getFinishedTimeNanos() != Long.MIN_VALUE;
    }

    public static final C0317k copy(C0317k c0317k, float f2, float f3, long j2, long j3, boolean z2) {
        return new C0317k(c0317k.getTypeConverter(), Float.valueOf(f2), r.AnimationVector(f3), j2, j3, z2);
    }

    public static final <T, V extends AbstractC0329q> C0317k AnimationState(B0 b02, T t2, T t3, long j2, long j3, boolean z2) {
        return new C0317k(b02, t2, (AbstractC0329q) b02.getConvertToVector().invoke(t3), j2, j3, z2);
    }

    public static /* synthetic */ C0317k copy$default(C0317k c0317k, float f2, float f3, long j2, long j3, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = ((Number) c0317k.getValue()).floatValue();
        }
        if ((i2 & 2) != 0) {
            f3 = ((C0321m) c0317k.getVelocityVector()).getValue();
        }
        float f4 = f3;
        if ((i2 & 4) != 0) {
            j2 = c0317k.getLastFrameTimeNanos();
        }
        long j4 = j2;
        if ((i2 & 8) != 0) {
            j3 = c0317k.getFinishedTimeNanos();
        }
        long j5 = j3;
        if ((i2 & 16) != 0) {
            z2 = c0317k.isRunning();
        }
        return copy(c0317k, f2, f4, j4, j5, z2);
    }
}
