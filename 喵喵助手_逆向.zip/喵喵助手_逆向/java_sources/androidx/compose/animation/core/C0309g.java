package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0309g {
    public static final int $stable = 0;
    private final EnumC0305e endReason;
    private final C0317k endState;

    public C0309g(C0317k c0317k, EnumC0305e enumC0305e) {
        this.endState = c0317k;
        this.endReason = enumC0305e;
    }

    public final EnumC0305e getEndReason() {
        return this.endReason;
    }

    public final C0317k getEndState() {
        return this.endState;
    }

    public String toString() {
        return "AnimationResult(endReason=" + this.endReason + ", endState=" + this.endState + ')';
    }
}
