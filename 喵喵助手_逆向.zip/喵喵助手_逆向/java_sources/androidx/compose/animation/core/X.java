package androidx.compose.animation.core;

import androidx.compose.runtime.V1;

/* JADX INFO: loaded from: classes.dex */
public final class X extends z0 {
    public static final int $stable = 0;
    private final androidx.compose.runtime.B0 currentState$delegate;
    private final androidx.compose.runtime.B0 targetState$delegate;

    public X(Object obj) {
        super(null);
        this.currentState$delegate = V1.mutableStateOf$default(obj, null, 2, null);
        this.targetState$delegate = V1.mutableStateOf$default(obj, null, 2, null);
    }

    @Override // androidx.compose.animation.core.z0
    public Object getCurrentState() {
        return this.currentState$delegate.getValue();
    }

    @Override // androidx.compose.animation.core.z0
    public Object getTargetState() {
        return this.targetState$delegate.getValue();
    }

    public final boolean isIdle() {
        return kotlin.jvm.internal.o.a(getCurrentState(), getTargetState()) && !isRunning$animation_core();
    }

    @Override // androidx.compose.animation.core.z0
    public void setCurrentState$animation_core(Object obj) {
        this.currentState$delegate.setValue(obj);
    }

    @Override // androidx.compose.animation.core.z0
    /* JADX INFO: renamed from: setTargetState, reason: merged with bridge method [inline-methods] */
    public void setTargetState$animation_core(Object obj) {
        this.targetState$delegate.setValue(obj);
    }

    @Override // androidx.compose.animation.core.z0
    public void transitionConfigured$animation_core(v0 v0Var) {
    }

    @Override // androidx.compose.animation.core.z0
    public void transitionRemoved$animation_core() {
    }
}
