package androidx.compose.animation.core;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.core.m0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0322m0 {
    private final long value;

    private /* synthetic */ C0322m0(long j2) {
        this.value = j2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ C0322m0 m613boximpl(long j2) {
        return new C0322m0(j2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    private static long m615constructorimpl(long j2) {
        return j2;
    }

    /* JADX INFO: renamed from: constructor-impl$default, reason: not valid java name */
    public static /* synthetic */ long m616constructorimpl$default(int i2, int i3, int i4, AbstractC1378g abstractC1378g) {
        if ((i4 & 2) != 0) {
            i3 = C0324n0.Companion.m631getDelayEo1U57Q();
        }
        return m614constructorimpl(i2, i3);
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m617equalsimpl(long j2, Object obj) {
        return (obj instanceof C0322m0) && j2 == ((C0322m0) obj).m623unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m618equalsimpl0(long j2, long j3) {
        return j2 == j3;
    }

    /* JADX INFO: renamed from: getOffsetMillis-impl, reason: not valid java name */
    public static final int m619getOffsetMillisimpl(long j2) {
        return Math.abs((int) j2);
    }

    /* JADX INFO: renamed from: getOffsetType-Eo1U57Q, reason: not valid java name */
    public static final int m620getOffsetTypeEo1U57Q(long j2) {
        boolean z2 = j2 > 0;
        if (z2) {
            return C0324n0.Companion.m632getFastForwardEo1U57Q();
        }
        if (z2) {
            throw new H0.c();
        }
        return C0324n0.Companion.m631getDelayEo1U57Q();
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m621hashCodeimpl(long j2) {
        return Long.hashCode(j2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m622toStringimpl(long j2) {
        return "StartOffset(value=" + j2 + ')';
    }

    public boolean equals(Object obj) {
        return m617equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m621hashCodeimpl(this.value);
    }

    public String toString() {
        return m622toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ long m623unboximpl() {
        return this.value;
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    public static long m614constructorimpl(int i2, int i3) {
        return m615constructorimpl(i2 * i3);
    }
}
