package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.l0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0320l0 implements F0 {
    private final long startDelayNanos;
    private final F0 vectorizedAnimationSpec;

    public C0320l0(F0 f02, long j2) {
        this.vectorizedAnimationSpec = f02;
        this.startDelayNanos = j2;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0320l0)) {
            return false;
        }
        C0320l0 c0320l0 = (C0320l0) obj;
        return c0320l0.startDelayNanos == this.startDelayNanos && kotlin.jvm.internal.o.a(c0320l0.vectorizedAnimationSpec, this.vectorizedAnimationSpec);
    }

    @Override // androidx.compose.animation.core.F0
    public long getDurationNanos(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return this.vectorizedAnimationSpec.getDurationNanos(abstractC0329q, abstractC0329q2, abstractC0329q3) + this.startDelayNanos;
    }

    @Override // androidx.compose.animation.core.F0
    public /* bridge */ /* synthetic */ AbstractC0329q getEndVelocity(AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        return super.getEndVelocity(abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    public final long getStartDelayNanos() {
        return this.startDelayNanos;
    }

    @Override // androidx.compose.animation.core.F0
    public AbstractC0329q getValueFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        long j3 = this.startDelayNanos;
        return j2 < j3 ? abstractC0329q : this.vectorizedAnimationSpec.getValueFromNanos(j2 - j3, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    public final F0 getVectorizedAnimationSpec() {
        return this.vectorizedAnimationSpec;
    }

    @Override // androidx.compose.animation.core.F0
    public AbstractC0329q getVelocityFromNanos(long j2, AbstractC0329q abstractC0329q, AbstractC0329q abstractC0329q2, AbstractC0329q abstractC0329q3) {
        long j3 = this.startDelayNanos;
        return j2 < j3 ? abstractC0329q3 : this.vectorizedAnimationSpec.getVelocityFromNanos(j2 - j3, abstractC0329q, abstractC0329q2, abstractC0329q3);
    }

    public int hashCode() {
        return Long.hashCode(this.startDelayNanos) + (this.vectorizedAnimationSpec.hashCode() * 31);
    }

    @Override // androidx.compose.animation.core.F0
    public boolean isInfinite() {
        return this.vectorizedAnimationSpec.isInfinite();
    }
}
