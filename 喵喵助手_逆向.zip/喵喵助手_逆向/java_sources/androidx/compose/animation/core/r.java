package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public abstract class r {
    public static final C0321m AnimationVector(float f2) {
        return new C0321m(f2);
    }

    public static final <T extends AbstractC0329q> T copy(T t2) {
        T t3 = (T) newInstance(t2);
        int size$animation_core = t3.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            t3.set$animation_core(i2, t2.get$animation_core(i2));
        }
        return t3;
    }

    public static final <T extends AbstractC0329q> void copyFrom(T t2, T t3) {
        int size$animation_core = t2.getSize$animation_core();
        for (int i2 = 0; i2 < size$animation_core; i2++) {
            t2.set$animation_core(i2, t3.get$animation_core(i2));
        }
    }

    public static final <T extends AbstractC0329q> T newInstance(T t2) {
        T t3 = (T) t2.newVector$animation_core();
        kotlin.jvm.internal.o.c(t3, "null cannot be cast to non-null type T of androidx.compose.animation.core.AnimationVectorsKt.newInstance");
        return t3;
    }

    public static final C0323n AnimationVector(float f2, float f3) {
        return new C0323n(f2, f3);
    }

    public static final C0325o AnimationVector(float f2, float f3, float f4) {
        return new C0325o(f2, f3, f4);
    }

    public static final C0327p AnimationVector(float f2, float f3, float f4, float f5) {
        return new C0327p(f2, f3, f4, f5);
    }
}
