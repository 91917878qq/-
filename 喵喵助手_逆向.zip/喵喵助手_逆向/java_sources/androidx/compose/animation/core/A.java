package androidx.compose.animation.core;

import kotlin.jvm.internal.C1379h;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {
    public static final <T, V extends AbstractC0329q> T calculateTargetValue(InterfaceC0341y interfaceC0341y, B0 b02, T t2, T t3) {
        return (T) b02.getConvertFromVector().invoke(interfaceC0341y.vectorize(b02).getTargetValue((AbstractC0329q) b02.getConvertToVector().invoke(t2), (AbstractC0329q) b02.getConvertToVector().invoke(t3)));
    }

    public static final <T> InterfaceC0341y exponentialDecay(float f2, float f3) {
        return generateDecayAnimationSpec(new I(f2, f3));
    }

    public static /* synthetic */ InterfaceC0341y exponentialDecay$default(float f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = 1.0f;
        }
        if ((i2 & 2) != 0) {
            f3 = 0.1f;
        }
        return exponentialDecay(f2, f3);
    }

    public static final <T> InterfaceC0341y generateDecayAnimationSpec(H h2) {
        return new C0342z(h2);
    }

    public static final float calculateTargetValue(InterfaceC0341y interfaceC0341y, float f2, float f3) {
        return ((C0321m) interfaceC0341y.vectorize(E0.getVectorConverter(C1379h.f3125a)).getTargetValue(r.AnimationVector(f2), r.AnimationVector(f3))).getValue();
    }
}
