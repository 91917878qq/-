package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.k0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0318k0 implements InterfaceC0313i {
    private final InterfaceC0313i animationSpec;
    private final long startDelayNanos;

    public C0318k0(InterfaceC0313i interfaceC0313i, long j2) {
        this.animationSpec = interfaceC0313i;
        this.startDelayNanos = j2;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0318k0)) {
            return false;
        }
        C0318k0 c0318k0 = (C0318k0) obj;
        return c0318k0.startDelayNanos == this.startDelayNanos && kotlin.jvm.internal.o.a(c0318k0.animationSpec, this.animationSpec);
    }

    public final InterfaceC0313i getAnimationSpec() {
        return this.animationSpec;
    }

    public final long getStartDelayNanos() {
        return this.startDelayNanos;
    }

    public int hashCode() {
        return Long.hashCode(this.startDelayNanos) + (this.animationSpec.hashCode() * 31);
    }

    @Override // androidx.compose.animation.core.InterfaceC0313i
    public <V extends AbstractC0329q> F0 vectorize(B0 b02) {
        return new C0320l0(this.animationSpec.vectorize(b02), this.startDelayNanos);
    }
}
