package androidx.compose.animation.core;

/* JADX INFO: renamed from: androidx.compose.animation.core.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0323n extends AbstractC0329q {
    public static final int $stable = 8;
    private final int size;

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    private float f1637v1;
    private float v2;

    public C0323n(float f2, float f3) {
        super(null);
        this.f1637v1 = f2;
        this.v2 = f3;
        this.size = 2;
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0323n) {
            C0323n c0323n = (C0323n) obj;
            if (c0323n.f1637v1 == this.f1637v1 && c0323n.v2 == this.v2) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public float get$animation_core(int i2) {
        if (i2 == 0) {
            return this.f1637v1;
        }
        if (i2 != 1) {
            return 0.0f;
        }
        return this.v2;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public int getSize$animation_core() {
        return this.size;
    }

    public final float getV1() {
        return this.f1637v1;
    }

    public final float getV2() {
        return this.v2;
    }

    public int hashCode() {
        return Float.hashCode(this.v2) + (Float.hashCode(this.f1637v1) * 31);
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void reset$animation_core() {
        this.f1637v1 = 0.0f;
        this.v2 = 0.0f;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public void set$animation_core(int i2, float f2) {
        if (i2 == 0) {
            this.f1637v1 = f2;
        } else {
            if (i2 != 1) {
                return;
            }
            this.v2 = f2;
        }
    }

    public final void setV1$animation_core(float f2) {
        this.f1637v1 = f2;
    }

    public final void setV2$animation_core(float f2) {
        this.v2 = f2;
    }

    public String toString() {
        return "AnimationVector2D: v1 = " + this.f1637v1 + ", v2 = " + this.v2;
    }

    @Override // androidx.compose.animation.core.AbstractC0329q
    public C0323n newVector$animation_core() {
        return new C0323n(0.0f, 0.0f);
    }
}
