package androidx.compose.animation.core;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class x0 implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1663b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ v0 f1664c;

    public /* synthetic */ x0(v0 v0Var, int i2) {
        this.f1663b = i2;
        this.f1664c = v0Var;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f1663b) {
            case 0:
                return y0.rememberTransition$lambda$13$lambda$12(this.f1664c, (androidx.compose.runtime.W) obj);
            default:
                return y0.updateTransition$lambda$3$lambda$2(this.f1664c, (androidx.compose.runtime.W) obj);
        }
    }
}
