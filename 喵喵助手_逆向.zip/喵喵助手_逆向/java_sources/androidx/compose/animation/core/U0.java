package androidx.compose.animation.core;

import J.f;
import J.h;
import J.l;
import e0.C1311h;
import e0.j;
import e0.o;
import e0.s;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.C1379h;

/* JADX INFO: loaded from: classes.dex */
public abstract class U0 {
    private static final float DpVisibilityThreshold = 0.1f;
    private static final float PxVisibilityThreshold = 0.5f;
    private static final J.h RectVisibilityThreshold;
    private static final Map<B0, Float> VisibilityThresholdMap;

    static {
        Float fValueOf = Float.valueOf(0.5f);
        RectVisibilityThreshold = new J.h(0.5f, 0.5f, 0.5f, 0.5f);
        B0 vectorConverter = E0.getVectorConverter(kotlin.jvm.internal.m.f3126a);
        Float fValueOf2 = Float.valueOf(1.0f);
        U0.g[] gVarArr = {new U0.g(vectorConverter, fValueOf2), new U0.g(E0.getVectorConverter(e0.s.Companion), fValueOf2), new U0.g(E0.getVectorConverter(e0.o.Companion), fValueOf2), new U0.g(E0.getVectorConverter(C1379h.f3125a), Float.valueOf(0.01f)), new U0.g(E0.getVectorConverter(J.h.Companion), fValueOf), new U0.g(E0.getVectorConverter(J.l.Companion), fValueOf), new U0.g(E0.getVectorConverter(J.f.Companion), fValueOf), new U0.g(E0.getVectorConverter(C1311h.Companion), Float.valueOf(DpVisibilityThreshold)), new U0.g(E0.getVectorConverter(e0.j.Companion), Float.valueOf(DpVisibilityThreshold))};
        LinkedHashMap linkedHashMap = new LinkedHashMap(V0.E.J(9));
        V0.E.M(linkedHashMap, gVarArr);
        VisibilityThresholdMap = linkedHashMap;
    }

    public static final int getVisibilityThreshold(kotlin.jvm.internal.m mVar) {
        return 1;
    }

    public static final Map<B0, Float> getVisibilityThresholdMap() {
        return VisibilityThresholdMap;
    }

    public static /* synthetic */ void getVisibilityThresholdMap$annotations() {
    }

    public static final long getVisibilityThreshold(j.a aVar) {
        C1311h.a aVar2 = C1311h.Companion;
        float visibilityThreshold = getVisibilityThreshold(aVar2);
        float visibilityThreshold2 = getVisibilityThreshold(aVar2);
        return e0.j.m5132constructorimpl((((long) Float.floatToRawIntBits(visibilityThreshold)) << 32) | (((long) Float.floatToRawIntBits(visibilityThreshold2)) & 4294967295L));
    }

    public static final J.h getVisibilityThreshold(h.a aVar) {
        return RectVisibilityThreshold;
    }

    public static final long getVisibilityThreshold(o.a aVar) {
        long j2 = 1;
        return e0.o.m5190constructorimpl((j2 & 4294967295L) | (j2 << 32));
    }

    public static final long getVisibilityThreshold(f.a aVar) {
        return J.f.m42constructorimpl((((long) Float.floatToRawIntBits(0.5f)) << 32) | (((long) Float.floatToRawIntBits(0.5f)) & 4294967295L));
    }

    public static final float getVisibilityThreshold(C1311h.a aVar) {
        return C1311h.m5076constructorimpl(DpVisibilityThreshold);
    }

    public static final long getVisibilityThreshold(l.a aVar) {
        return J.l.m110constructorimpl((((long) Float.floatToRawIntBits(0.5f)) << 32) | (((long) Float.floatToRawIntBits(0.5f)) & 4294967295L));
    }

    public static final long getVisibilityThreshold(s.a aVar) {
        long j2 = 1;
        return e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32));
    }
}
