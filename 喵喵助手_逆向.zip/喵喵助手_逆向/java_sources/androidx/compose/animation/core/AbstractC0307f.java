package androidx.compose.animation.core;

import kotlin.jvm.internal.C1379h;

/* JADX INFO: renamed from: androidx.compose.animation.core.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0307f {
    public static final long MillisToNanos = 1000000;
    public static final long SecondsToMillis = 1000;

    public static final C0340x DecayAnimation(H h2, float f2, float f3) {
        return new C0340x(A.generateDecayAnimationSpec(h2), E0.getVectorConverter(C1379h.f3125a), (Object) Float.valueOf(f2), (AbstractC0329q) r.AnimationVector(f3));
    }

    public static /* synthetic */ C0340x DecayAnimation$default(H h2, float f2, float f3, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            f3 = 0.0f;
        }
        return DecayAnimation(h2, f2, f3);
    }

    public static final <T, V extends AbstractC0329q> C0335t0 TargetBasedAnimation(InterfaceC0313i interfaceC0313i, B0 b02, T t2, T t3, T t4) {
        return new C0335t0(interfaceC0313i, b02, t2, t3, (AbstractC0329q) b02.getConvertToVector().invoke(t4));
    }

    public static final <V extends AbstractC0329q> C0335t0 createAnimation(F0 f02, V v2, V v3, V v4) {
        return new C0335t0(f02, E0.TwoWayConverter(new O0.L0(10), new O0.L0(11)), v2, v3, v4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final AbstractC0329q createAnimation$lambda$0(AbstractC0329q abstractC0329q) {
        return abstractC0329q;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final AbstractC0329q createAnimation$lambda$1(AbstractC0329q abstractC0329q) {
        return abstractC0329q;
    }

    public static final long getDurationMillis(InterfaceC0303d interfaceC0303d) {
        return interfaceC0303d.getDurationNanos() / MillisToNanos;
    }

    public static final <T, V extends AbstractC0329q> T getVelocityFromNanos(InterfaceC0303d interfaceC0303d, long j2) {
        return (T) interfaceC0303d.getTypeConverter().getConvertFromVector().invoke(interfaceC0303d.getVelocityVectorFromNanos(j2));
    }
}
