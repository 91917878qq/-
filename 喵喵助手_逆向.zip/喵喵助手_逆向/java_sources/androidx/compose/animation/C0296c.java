package androidx.compose.animation;

import androidx.compose.animation.AnimatedContentTransitionScopeImpl;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.animation.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0296c implements InterfaceC0933c0 {
    private final AnimatedContentTransitionScopeImpl rootScope;

    /* JADX INFO: renamed from: androidx.compose.animation.c$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ int $maxHeight;
        final /* synthetic */ int $maxWidth;
        final /* synthetic */ AbstractC0974x0[] $placeables;
        final /* synthetic */ C0296c this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(AbstractC0974x0[] abstractC0974x0Arr, C0296c c0296c, int i2, int i3) {
            super(1);
            this.$placeables = abstractC0974x0Arr;
            this.this$0 = c0296c;
            this.$maxWidth = i2;
            this.$maxHeight = i3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            AbstractC0974x0[] abstractC0974x0Arr;
            AbstractC0974x0[] abstractC0974x0Arr2 = this.$placeables;
            C0296c c0296c = this.this$0;
            int i2 = this.$maxWidth;
            int i3 = this.$maxHeight;
            int length = abstractC0974x0Arr2.length;
            int i4 = 0;
            while (i4 < length) {
                AbstractC0974x0 abstractC0974x0 = abstractC0974x0Arr2[i4];
                if (abstractC0974x0 != null) {
                    abstractC0974x0Arr = abstractC0974x0Arr2;
                    long jMo2803alignKFBX0sM = c0296c.getRootScope().getContentAlignment().mo2803alignKFBX0sM(e0.s.m5234constructorimpl((((long) abstractC0974x0.getWidth()) << 32) | (((long) abstractC0974x0.getHeight()) & 4294967295L)), e0.s.m5234constructorimpl((((long) i3) & 4294967295L) | (((long) i2) << 32)), e0.u.Ltr);
                    AbstractC0974x0.a.place$default(aVar, abstractC0974x0, e0.o.m5196getXimpl(jMo2803alignKFBX0sM), e0.o.m5197getYimpl(jMo2803alignKFBX0sM), 0.0f, 4, null);
                } else {
                    abstractC0974x0Arr = abstractC0974x0Arr2;
                }
                i4++;
                abstractC0974x0Arr2 = abstractC0974x0Arr;
            }
        }
    }

    public C0296c(AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
        this.rootScope = animatedContentTransitionScopeImpl;
    }

    public final AnimatedContentTransitionScopeImpl getRootScope() {
        return this.rootScope;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        Integer numValueOf;
        if (list.isEmpty()) {
            numValueOf = null;
        } else {
            numValueOf = Integer.valueOf(list.get(0).maxIntrinsicHeight(i2));
            int iE = j1.a.E(list);
            int i3 = 1;
            if (1 <= iE) {
                while (true) {
                    Integer numValueOf2 = Integer.valueOf(list.get(i3).maxIntrinsicHeight(i2));
                    if (numValueOf2.compareTo(numValueOf) > 0) {
                        numValueOf = numValueOf2;
                    }
                    if (i3 == iE) {
                        break;
                    }
                    i3++;
                }
            }
        }
        if (numValueOf != null) {
            return numValueOf.intValue();
        }
        return 0;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        Integer numValueOf;
        if (list.isEmpty()) {
            numValueOf = null;
        } else {
            numValueOf = Integer.valueOf(list.get(0).maxIntrinsicWidth(i2));
            int iE = j1.a.E(list);
            int i3 = 1;
            if (1 <= iE) {
                while (true) {
                    Integer numValueOf2 = Integer.valueOf(list.get(i3).maxIntrinsicWidth(i2));
                    if (numValueOf2.compareTo(numValueOf) > 0) {
                        numValueOf = numValueOf2;
                    }
                    if (i3 == iE) {
                        break;
                    }
                    i3++;
                }
            }
        }
        if (numValueOf != null) {
            return numValueOf.intValue();
        }
        return 0;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s, reason: not valid java name */
    public InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        int i2;
        AbstractC0974x0 abstractC0974x0;
        int width;
        int i3;
        AbstractC0974x0 abstractC0974x02;
        int height;
        int size = list.size();
        AbstractC0974x0[] abstractC0974x0Arr = new AbstractC0974x0[size];
        long jM5244getZeroYbymL2g = e0.s.Companion.m5244getZeroYbymL2g();
        int size2 = list.size();
        int i4 = 0;
        while (true) {
            i2 = 1;
            if (i4 >= size2) {
                break;
            }
            InterfaceC0931b0 interfaceC0931b0 = list.get(i4);
            Object parentData = interfaceC0931b0.getParentData();
            AnimatedContentTransitionScopeImpl.a aVar = parentData instanceof AnimatedContentTransitionScopeImpl.a ? (AnimatedContentTransitionScopeImpl.a) parentData : null;
            if (aVar != null && aVar.isTarget()) {
                AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
                long jM5234constructorimpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
                abstractC0974x0Arr[i4] = abstractC0974x0Mo3865measureBRTryo0;
                jM5244getZeroYbymL2g = jM5234constructorimpl;
            }
            i4++;
        }
        int size3 = list.size();
        for (int i5 = 0; i5 < size3; i5++) {
            InterfaceC0931b0 interfaceC0931b02 = list.get(i5);
            if (abstractC0974x0Arr[i5] == null) {
                abstractC0974x0Arr[i5] = interfaceC0931b02.mo3865measureBRTryo0(j2);
            }
        }
        if (interfaceC0937e0.isLookingAhead()) {
            width = (int) (jM5244getZeroYbymL2g >> 32);
        } else {
            if (size == 0) {
                abstractC0974x0 = null;
            } else {
                abstractC0974x0 = abstractC0974x0Arr[0];
                int i6 = size - 1;
                if (i6 != 0) {
                    int width2 = abstractC0974x0 != null ? abstractC0974x0.getWidth() : 0;
                    if (1 <= i6) {
                        int i7 = 1;
                        while (true) {
                            AbstractC0974x0 abstractC0974x03 = abstractC0974x0Arr[i7];
                            int width3 = abstractC0974x03 != null ? abstractC0974x03.getWidth() : 0;
                            if (width2 < width3) {
                                abstractC0974x0 = abstractC0974x03;
                                width2 = width3;
                            }
                            if (i7 == i6) {
                                break;
                            }
                            i7++;
                        }
                    }
                }
            }
            width = abstractC0974x0 != null ? abstractC0974x0.getWidth() : 0;
        }
        if (interfaceC0937e0.isLookingAhead()) {
            height = (int) (jM5244getZeroYbymL2g & 4294967295L);
        } else {
            if (size == 0) {
                i3 = 0;
                abstractC0974x02 = null;
            } else {
                i3 = 0;
                abstractC0974x02 = abstractC0974x0Arr[0];
                int i8 = size - 1;
                if (i8 != 0) {
                    int height2 = abstractC0974x02 != null ? abstractC0974x02.getHeight() : 0;
                    if (1 <= i8) {
                        while (true) {
                            AbstractC0974x0 abstractC0974x04 = abstractC0974x0Arr[i2];
                            int height3 = abstractC0974x04 != null ? abstractC0974x04.getHeight() : 0;
                            if (height2 < height3) {
                                abstractC0974x02 = abstractC0974x04;
                                height2 = height3;
                            }
                            if (i2 == i8) {
                                break;
                            }
                            i2++;
                        }
                    }
                }
            }
            height = abstractC0974x02 != null ? abstractC0974x02.getHeight() : i3;
        }
        if (!interfaceC0937e0.isLookingAhead()) {
            this.rootScope.m554setMeasuredSizeozmzZPI$animation(e0.s.m5234constructorimpl((((long) width) << 32) | (((long) height) & 4294967295L)));
        }
        return InterfaceC0937e0.layout$default(interfaceC0937e0, width, height, null, new a(abstractC0974x0Arr, this, width, height), 4, null);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        Integer numValueOf;
        if (list.isEmpty()) {
            numValueOf = null;
        } else {
            numValueOf = Integer.valueOf(list.get(0).minIntrinsicHeight(i2));
            int iE = j1.a.E(list);
            int i3 = 1;
            if (1 <= iE) {
                while (true) {
                    Integer numValueOf2 = Integer.valueOf(list.get(i3).minIntrinsicHeight(i2));
                    if (numValueOf2.compareTo(numValueOf) > 0) {
                        numValueOf = numValueOf2;
                    }
                    if (i3 == iE) {
                        break;
                    }
                    i3++;
                }
            }
        }
        if (numValueOf != null) {
            return numValueOf.intValue();
        }
        return 0;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        Integer numValueOf;
        if (list.isEmpty()) {
            numValueOf = null;
        } else {
            numValueOf = Integer.valueOf(list.get(0).minIntrinsicWidth(i2));
            int iE = j1.a.E(list);
            int i3 = 1;
            if (1 <= iE) {
                while (true) {
                    Integer numValueOf2 = Integer.valueOf(list.get(i3).minIntrinsicWidth(i2));
                    if (numValueOf2.compareTo(numValueOf) > 0) {
                        numValueOf = numValueOf2;
                    }
                    if (i3 == iE) {
                        break;
                    }
                    i3++;
                }
            }
        }
        if (numValueOf != null) {
            return numValueOf.intValue();
        }
        return 0;
    }
}
