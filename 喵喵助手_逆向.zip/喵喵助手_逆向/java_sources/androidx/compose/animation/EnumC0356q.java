package androidx.compose.animation;

import a.AbstractC0292a;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.compose.animation.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0356q {
    private static final /* synthetic */ b1.a $ENTRIES;
    private static final /* synthetic */ EnumC0356q[] $VALUES;
    public static final EnumC0356q PreEnter = new EnumC0356q("PreEnter", 0);
    public static final EnumC0356q Visible = new EnumC0356q("Visible", 1);
    public static final EnumC0356q PostExit = new EnumC0356q("PostExit", 2);

    private static final /* synthetic */ EnumC0356q[] $values() {
        return new EnumC0356q[]{PreEnter, Visible, PostExit};
    }

    static {
        EnumC0356q[] enumC0356qArr$values = $values();
        $VALUES = enumC0356qArr$values;
        $ENTRIES = AbstractC0292a.q(enumC0356qArr$values);
    }

    private EnumC0356q(String str, int i2) {
    }

    public static b1.a getEntries() {
        return $ENTRIES;
    }

    public static EnumC0356q valueOf(String str) {
        return (EnumC0356q) Enum.valueOf(EnumC0356q.class, str);
    }

    public static EnumC0356q[] values() {
        return (EnumC0356q[]) $VALUES.clone();
    }
}
