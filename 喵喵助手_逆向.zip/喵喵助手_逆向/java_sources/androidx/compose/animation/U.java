package androidx.compose.animation;

import java.util.Map;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class U {
    public static final int $stable = 0;
    private final C0352m changeSize;
    private final Map<W, V> effectsMap;
    private final E fade;
    private final boolean hold;
    private final K scale;
    private final P slide;

    public U() {
        this(null, null, null, null, false, null, 63, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ U copy$default(U u2, E e2, P p2, C0352m c0352m, K k2, boolean z2, Map map, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            e2 = u2.fade;
        }
        if ((i2 & 2) != 0) {
            p2 = u2.slide;
        }
        P p3 = p2;
        if ((i2 & 4) != 0) {
            c0352m = u2.changeSize;
        }
        C0352m c0352m2 = c0352m;
        if ((i2 & 8) != 0) {
            k2 = u2.scale;
        }
        K k3 = k2;
        if ((i2 & 16) != 0) {
            z2 = u2.hold;
        }
        boolean z3 = z2;
        if ((i2 & 32) != 0) {
            map = u2.effectsMap;
        }
        return u2.copy(e2, p3, c0352m2, k3, z3, map);
    }

    public final E component1() {
        return this.fade;
    }

    public final P component2() {
        return this.slide;
    }

    public final C0352m component3() {
        return this.changeSize;
    }

    public final K component4() {
        return this.scale;
    }

    public final boolean component5() {
        return this.hold;
    }

    public final Map<W, V> component6() {
        return this.effectsMap;
    }

    public final U copy(E e2, P p2, C0352m c0352m, K k2, boolean z2, Map<W, ? extends V> map) {
        return new U(e2, p2, c0352m, k2, z2, map);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof U)) {
            return false;
        }
        U u2 = (U) obj;
        return kotlin.jvm.internal.o.a(this.fade, u2.fade) && kotlin.jvm.internal.o.a(this.slide, u2.slide) && kotlin.jvm.internal.o.a(this.changeSize, u2.changeSize) && kotlin.jvm.internal.o.a(this.scale, u2.scale) && this.hold == u2.hold && kotlin.jvm.internal.o.a(this.effectsMap, u2.effectsMap);
    }

    public final C0352m getChangeSize() {
        return this.changeSize;
    }

    public final Map<W, V> getEffectsMap() {
        return this.effectsMap;
    }

    public final E getFade() {
        return this.fade;
    }

    public final boolean getHold() {
        return this.hold;
    }

    public final K getScale() {
        return this.scale;
    }

    public final P getSlide() {
        return this.slide;
    }

    public int hashCode() {
        E e2 = this.fade;
        int iHashCode = (e2 == null ? 0 : e2.hashCode()) * 31;
        P p2 = this.slide;
        int iHashCode2 = (iHashCode + (p2 == null ? 0 : p2.hashCode())) * 31;
        C0352m c0352m = this.changeSize;
        int iHashCode3 = (iHashCode2 + (c0352m == null ? 0 : c0352m.hashCode())) * 31;
        K k2 = this.scale;
        return this.effectsMap.hashCode() + D0.d.c((iHashCode3 + (k2 != null ? k2.hashCode() : 0)) * 31, 31, this.hold);
    }

    public String toString() {
        return "TransitionData(fade=" + this.fade + ", slide=" + this.slide + ", changeSize=" + this.changeSize + ", scale=" + this.scale + ", hold=" + this.hold + ", effectsMap=" + this.effectsMap + ')';
    }

    /* JADX WARN: Multi-variable type inference failed */
    public U(E e2, P p2, C0352m c0352m, K k2, boolean z2, Map<W, ? extends V> map) {
        this.fade = e2;
        this.slide = p2;
        this.changeSize = c0352m;
        this.scale = k2;
        this.hold = z2;
        this.effectsMap = map;
    }

    public /* synthetic */ U(E e2, P p2, C0352m c0352m, K k2, boolean z2, Map map, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? null : e2, (i2 & 2) != 0 ? null : p2, (i2 & 4) != 0 ? null : c0352m, (i2 & 8) == 0 ? k2 : null, (i2 & 16) != 0 ? false : z2, (i2 & 32) != 0 ? V0.B.f1525b : map);
    }
}
