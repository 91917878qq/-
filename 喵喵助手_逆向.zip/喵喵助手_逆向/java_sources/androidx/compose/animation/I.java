package androidx.compose.animation;

import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;

/* JADX INFO: loaded from: classes.dex */
public abstract class I extends androidx.compose.ui.w implements androidx.compose.ui.node.M {
    public static final int $stable = androidx.compose.ui.w.$stable;

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.maxIntrinsicWidth(i2);
    }

    /* JADX INFO: renamed from: measure-3p2s80s */
    public abstract /* synthetic */ InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2);

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicHeight(i2);
    }

    @Override // androidx.compose.ui.node.M
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, androidx.compose.ui.layout.E e2, int i2) {
        return e2.minIntrinsicWidth(i2);
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }
}
