package androidx.compose.animation;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class V {
    public static final int $stable = 0;

    public /* synthetic */ V(AbstractC1378g abstractC1378g) {
        this();
    }

    public abstract W getKey$animation();

    private V() {
    }
}
