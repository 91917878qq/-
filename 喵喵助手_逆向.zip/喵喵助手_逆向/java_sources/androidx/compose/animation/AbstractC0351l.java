package androidx.compose.animation;

import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.U0;
import androidx.compose.ui.InterfaceC0849g;

/* JADX INFO: renamed from: androidx.compose.animation.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0351l {
    private static final long InvalidSize;

    static {
        long j2 = Integer.MIN_VALUE;
        InvalidSize = e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32));
    }

    public static final androidx.compose.ui.x animateContentSize(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, h1.e eVar) {
        return androidx.compose.ui.draw.h.clipToBounds(xVar).then(new SizeAnimationModifierElement(f2, InterfaceC0849g.Companion.getTopStart(), eVar));
    }

    public static /* synthetic */ androidx.compose.ui.x animateContentSize$default(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, h1.e eVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            eVar = null;
        }
        return animateContentSize(xVar, f2, eVar);
    }

    public static final long getInvalidSize() {
        return InvalidSize;
    }

    /* JADX INFO: renamed from: isValid-ozmzZPI, reason: not valid java name */
    public static final boolean m660isValidozmzZPI(long j2) {
        return !e0.s.m5237equalsimpl0(j2, InvalidSize);
    }

    public static final androidx.compose.ui.x animateContentSize(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, h1.e eVar) {
        return androidx.compose.ui.draw.h.clipToBounds(xVar).then(new SizeAnimationModifierElement(f2, interfaceC0849g, eVar));
    }

    public static /* synthetic */ androidx.compose.ui.x animateContentSize$default(androidx.compose.ui.x xVar, androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, h1.e eVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0849g = InterfaceC0849g.Companion.getTopStart();
        }
        if ((i2 & 4) != 0) {
            eVar = null;
        }
        return animateContentSize(xVar, f2, interfaceC0849g, eVar);
    }
}
