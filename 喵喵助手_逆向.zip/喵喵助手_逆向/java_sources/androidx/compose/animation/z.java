package androidx.compose.animation;

import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.w0;
import androidx.compose.runtime.d2;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;

/* JADX INFO: loaded from: classes.dex */
public final class z extends I {
    private InterfaceC0849g currentAlignment;
    private A enter;
    private C exit;
    private H graphicsLayerBlock;
    private h1.a isEnabled;
    private boolean lookaheadConstraintsAvailable;
    private androidx.compose.animation.core.v0.a offsetAnimation;
    private androidx.compose.animation.core.v0.a sizeAnimation;
    private androidx.compose.animation.core.v0.a slideAnimation;
    private v0 transition;
    private long lookaheadSize = AbstractC0351l.getInvalidSize();
    private long lookaheadConstraints = AbstractC1306c.Constraints$default(0, 0, 0, 0, 15, null);
    private final h1.c sizeTransitionSpec = new h();
    private final h1.c slideSpec = new i();

    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ AbstractC0974x0 $placeable;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(AbstractC0974x0 abstractC0974x0) {
            super(1);
            this.$placeable = abstractC0974x0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            AbstractC0974x0.a.place$default(aVar, this.$placeable, 0, 0, 0.0f, 4, null);
        }
    }

    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $layerBlock;
        final /* synthetic */ long $offset;
        final /* synthetic */ long $offsetDelta;
        final /* synthetic */ AbstractC0974x0 $placeable;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(AbstractC0974x0 abstractC0974x0, long j2, long j3, h1.c cVar) {
            super(1);
            this.$placeable = abstractC0974x0;
            this.$offset = j2;
            this.$offsetDelta = j3;
            this.$layerBlock = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            aVar.placeWithLayer(this.$placeable, e0.o.m5196getXimpl(this.$offsetDelta) + e0.o.m5196getXimpl(this.$offset), e0.o.m5197getYimpl(this.$offsetDelta) + e0.o.m5197getYimpl(this.$offset), 0.0f, this.$layerBlock);
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ AbstractC0974x0 $this_run;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(AbstractC0974x0 abstractC0974x0) {
            super(1);
            this.$this_run = abstractC0974x0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            AbstractC0974x0.a.place$default(aVar, this.$this_run, 0, 0, 0.0f, 4, null);
        }
    }

    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ long $target;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(long j2) {
            super(1);
            this.$target = j2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m685invokeYEO4UFw((EnumC0356q) obj));
        }

        /* JADX INFO: renamed from: invoke-YEO4UFw, reason: not valid java name */
        public final long m685invokeYEO4UFw(EnumC0356q enumC0356q) {
            return z.this.m682sizeByStateUzc_VyU(enumC0356q, this.$target);
        }
    }

    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        public static final e INSTANCE = new e();

        public e() {
            super(1);
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            return AbstractC0359u.DefaultOffsetAnimationSpec;
        }
    }

    public static final class f extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ long $target;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(long j2) {
            super(1);
            this.$target = j2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m686invokeBjo55l4((EnumC0356q) obj));
        }

        /* JADX INFO: renamed from: invoke-Bjo55l4, reason: not valid java name */
        public final long m686invokeBjo55l4(EnumC0356q enumC0356q) {
            return z.this.m684targetOffsetByStateoFUgxo0(enumC0356q, this.$target);
        }
    }

    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ long $target;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(long j2) {
            super(1);
            this.$target = j2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m687invokeBjo55l4((EnumC0356q) obj));
        }

        /* JADX INFO: renamed from: invoke-Bjo55l4, reason: not valid java name */
        public final long m687invokeBjo55l4(EnumC0356q enumC0356q) {
            return z.this.m683slideTargetValueByStateoFUgxo0(enumC0356q, this.$target);
        }
    }

    public static final class h extends kotlin.jvm.internal.p implements h1.c {
        public h() {
            super(1);
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            EnumC0356q enumC0356q = EnumC0356q.PreEnter;
            EnumC0356q enumC0356q2 = EnumC0356q.Visible;
            androidx.compose.animation.core.F animationSpec = null;
            if (w0Var.isTransitioningTo(enumC0356q, enumC0356q2)) {
                C0352m changeSize = z.this.getEnter().getData$animation().getChangeSize();
                if (changeSize != null) {
                    animationSpec = changeSize.getAnimationSpec();
                }
            } else if (w0Var.isTransitioningTo(enumC0356q2, EnumC0356q.PostExit)) {
                C0352m changeSize2 = z.this.getExit().getData$animation().getChangeSize();
                if (changeSize2 != null) {
                    animationSpec = changeSize2.getAnimationSpec();
                }
            } else {
                animationSpec = AbstractC0359u.DefaultSizeAnimationSpec;
            }
            return animationSpec == null ? AbstractC0359u.DefaultSizeAnimationSpec : animationSpec;
        }
    }

    public static final class i extends kotlin.jvm.internal.p implements h1.c {
        public i() {
            super(1);
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            androidx.compose.animation.core.F animationSpec;
            androidx.compose.animation.core.F animationSpec2;
            EnumC0356q enumC0356q = EnumC0356q.PreEnter;
            EnumC0356q enumC0356q2 = EnumC0356q.Visible;
            if (w0Var.isTransitioningTo(enumC0356q, enumC0356q2)) {
                P slide = z.this.getEnter().getData$animation().getSlide();
                return (slide == null || (animationSpec2 = slide.getAnimationSpec()) == null) ? AbstractC0359u.DefaultOffsetAnimationSpec : animationSpec2;
            }
            if (!w0Var.isTransitioningTo(enumC0356q2, EnumC0356q.PostExit)) {
                return AbstractC0359u.DefaultOffsetAnimationSpec;
            }
            P slide2 = z.this.getExit().getData$animation().getSlide();
            return (slide2 == null || (animationSpec = slide2.getAnimationSpec()) == null) ? AbstractC0359u.DefaultOffsetAnimationSpec : animationSpec;
        }
    }

    public z(v0 v0Var, androidx.compose.animation.core.v0.a aVar, androidx.compose.animation.core.v0.a aVar2, androidx.compose.animation.core.v0.a aVar3, A a2, C c2, h1.a aVar4, H h2) {
        this.transition = v0Var;
        this.sizeAnimation = aVar;
        this.offsetAnimation = aVar2;
        this.slideAnimation = aVar3;
        this.enter = a2;
        this.exit = c2;
        this.isEnabled = aVar4;
        this.graphicsLayerBlock = h2;
    }

    /* JADX INFO: renamed from: setLookaheadConstraints-BRTryo0, reason: not valid java name */
    private final void m681setLookaheadConstraintsBRTryo0(long j2) {
        this.lookaheadConstraintsAvailable = true;
        this.lookaheadConstraints = j2;
    }

    public final InterfaceC0849g getAlignment() {
        InterfaceC0849g alignment;
        if (this.transition.getSegment().isTransitioningTo(EnumC0356q.PreEnter, EnumC0356q.Visible)) {
            C0352m changeSize = this.enter.getData$animation().getChangeSize();
            if (changeSize == null || (alignment = changeSize.getAlignment()) == null) {
                C0352m changeSize2 = this.exit.getData$animation().getChangeSize();
                if (changeSize2 != null) {
                    return changeSize2.getAlignment();
                }
                return null;
            }
        } else {
            C0352m changeSize3 = this.exit.getData$animation().getChangeSize();
            if (changeSize3 == null || (alignment = changeSize3.getAlignment()) == null) {
                C0352m changeSize4 = this.enter.getData$animation().getChangeSize();
                if (changeSize4 != null) {
                    return changeSize4.getAlignment();
                }
                return null;
            }
        }
        return alignment;
    }

    public final InterfaceC0849g getCurrentAlignment() {
        return this.currentAlignment;
    }

    public final A getEnter() {
        return this.enter;
    }

    public final C getExit() {
        return this.exit;
    }

    public final H getGraphicsLayerBlock() {
        return this.graphicsLayerBlock;
    }

    public final androidx.compose.animation.core.v0.a getOffsetAnimation() {
        return this.offsetAnimation;
    }

    public final androidx.compose.animation.core.v0.a getSizeAnimation() {
        return this.sizeAnimation;
    }

    public final h1.c getSizeTransitionSpec() {
        return this.sizeTransitionSpec;
    }

    public final androidx.compose.animation.core.v0.a getSlideAnimation() {
        return this.slideAnimation;
    }

    public final h1.c getSlideSpec() {
        return this.slideSpec;
    }

    public final v0 getTransition() {
        return this.transition;
    }

    public final h1.a isEnabled() {
        return this.isEnabled;
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        d2 d2VarAnimate;
        d2 d2VarAnimate2;
        if (this.transition.getCurrentState() == this.transition.getTargetState()) {
            this.currentAlignment = null;
        } else if (this.currentAlignment == null) {
            InterfaceC0849g alignment = getAlignment();
            if (alignment == null) {
                alignment = InterfaceC0849g.Companion.getTopStart();
            }
            this.currentAlignment = alignment;
        }
        if (interfaceC0937e0.isLookingAhead()) {
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
            long jM5234constructorimpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
            this.lookaheadSize = jM5234constructorimpl;
            m681setLookaheadConstraintsBRTryo0(j2);
            return InterfaceC0937e0.layout$default(interfaceC0937e0, (int) (jM5234constructorimpl >> 32), (int) (jM5234constructorimpl & 4294967295L), null, new a(abstractC0974x0Mo3865measureBRTryo0), 4, null);
        }
        if (!((Boolean) this.isEnabled.invoke()).booleanValue()) {
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo02 = interfaceC0931b0.mo3865measureBRTryo0(j2);
            return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo02.getWidth(), abstractC0974x0Mo3865measureBRTryo02.getHeight(), null, new c(abstractC0974x0Mo3865measureBRTryo02), 4, null);
        }
        h1.c cVarInit = ((r) this.graphicsLayerBlock).init();
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo03 = interfaceC0931b0.mo3865measureBRTryo0(j2);
        long jM5234constructorimpl2 = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo03.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo03.getHeight()) & 4294967295L));
        long j3 = AbstractC0351l.m660isValidozmzZPI(this.lookaheadSize) ? this.lookaheadSize : jM5234constructorimpl2;
        androidx.compose.animation.core.v0.a aVar = this.sizeAnimation;
        d2 d2VarAnimate3 = aVar != null ? aVar.animate(this.sizeTransitionSpec, new d(j3)) : null;
        if (d2VarAnimate3 != null) {
            jM5234constructorimpl2 = ((e0.s) d2VarAnimate3.getValue()).m5243unboximpl();
        }
        long jM5055constrain4WqzIAM = AbstractC1306c.m5055constrain4WqzIAM(j2, jM5234constructorimpl2);
        androidx.compose.animation.core.v0.a aVar2 = this.offsetAnimation;
        long jM5207getZeronOccac = (aVar2 == null || (d2VarAnimate2 = aVar2.animate(e.INSTANCE, new f(j3))) == null) ? e0.o.Companion.m5207getZeronOccac() : ((e0.o) d2VarAnimate2.getValue()).m5205unboximpl();
        androidx.compose.animation.core.v0.a aVar3 = this.slideAnimation;
        long jM5207getZeronOccac2 = (aVar3 == null || (d2VarAnimate = aVar3.animate(this.slideSpec, new g(j3))) == null) ? e0.o.Companion.m5207getZeronOccac() : ((e0.o) d2VarAnimate.getValue()).m5205unboximpl();
        InterfaceC0849g interfaceC0849g = this.currentAlignment;
        return InterfaceC0937e0.layout$default(interfaceC0937e0, (int) (jM5055constrain4WqzIAM >> 32), (int) (jM5055constrain4WqzIAM & 4294967295L), null, new b(abstractC0974x0Mo3865measureBRTryo03, e0.o.m5200plusqkQi6aY(interfaceC0849g != null ? interfaceC0849g.mo2803alignKFBX0sM(j3, jM5055constrain4WqzIAM, e0.u.Ltr) : e0.o.Companion.m5207getZeronOccac(), jM5207getZeronOccac2), jM5207getZeronOccac, cVarInit), 4, null);
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        super.onAttach();
        this.lookaheadConstraintsAvailable = false;
        this.lookaheadSize = AbstractC0351l.getInvalidSize();
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    public final void setCurrentAlignment(InterfaceC0849g interfaceC0849g) {
        this.currentAlignment = interfaceC0849g;
    }

    public final void setEnabled(h1.a aVar) {
        this.isEnabled = aVar;
    }

    public final void setEnter(A a2) {
        this.enter = a2;
    }

    public final void setExit(C c2) {
        this.exit = c2;
    }

    public final void setGraphicsLayerBlock(H h2) {
        this.graphicsLayerBlock = h2;
    }

    public final void setOffsetAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.offsetAnimation = aVar;
    }

    public final void setSizeAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.sizeAnimation = aVar;
    }

    public final void setSlideAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.slideAnimation = aVar;
    }

    public final void setTransition(v0 v0Var) {
        this.transition = v0Var;
    }

    /* JADX INFO: renamed from: sizeByState-Uzc_VyU, reason: not valid java name */
    public final long m682sizeByStateUzc_VyU(EnumC0356q enumC0356q, long j2) {
        h1.c size;
        h1.c size2;
        int i2 = y.$EnumSwitchMapping$0[enumC0356q.ordinal()];
        if (i2 == 1) {
            return j2;
        }
        if (i2 == 2) {
            C0352m changeSize = this.enter.getData$animation().getChangeSize();
            return (changeSize == null || (size = changeSize.getSize()) == null) ? j2 : ((e0.s) size.invoke(e0.s.m5231boximpl(j2))).m5243unboximpl();
        }
        if (i2 != 3) {
            throw new H0.c();
        }
        C0352m changeSize2 = this.exit.getData$animation().getChangeSize();
        return (changeSize2 == null || (size2 = changeSize2.getSize()) == null) ? j2 : ((e0.s) size2.invoke(e0.s.m5231boximpl(j2))).m5243unboximpl();
    }

    /* JADX INFO: renamed from: slideTargetValueByState-oFUgxo0, reason: not valid java name */
    public final long m683slideTargetValueByStateoFUgxo0(EnumC0356q enumC0356q, long j2) {
        h1.c slideOffset;
        h1.c slideOffset2;
        P slide = this.enter.getData$animation().getSlide();
        long jM5207getZeronOccac = (slide == null || (slideOffset2 = slide.getSlideOffset()) == null) ? e0.o.Companion.m5207getZeronOccac() : ((e0.o) slideOffset2.invoke(e0.s.m5231boximpl(j2))).m5205unboximpl();
        P slide2 = this.exit.getData$animation().getSlide();
        long jM5207getZeronOccac2 = (slide2 == null || (slideOffset = slide2.getSlideOffset()) == null) ? e0.o.Companion.m5207getZeronOccac() : ((e0.o) slideOffset.invoke(e0.s.m5231boximpl(j2))).m5205unboximpl();
        int i2 = y.$EnumSwitchMapping$0[enumC0356q.ordinal()];
        if (i2 == 1) {
            return e0.o.Companion.m5207getZeronOccac();
        }
        if (i2 == 2) {
            return jM5207getZeronOccac;
        }
        if (i2 == 3) {
            return jM5207getZeronOccac2;
        }
        throw new H0.c();
    }

    /* JADX INFO: renamed from: targetOffsetByState-oFUgxo0, reason: not valid java name */
    public final long m684targetOffsetByStateoFUgxo0(EnumC0356q enumC0356q, long j2) {
        int i2;
        if (this.currentAlignment != null && getAlignment() != null && !kotlin.jvm.internal.o.a(this.currentAlignment, getAlignment()) && (i2 = y.$EnumSwitchMapping$0[enumC0356q.ordinal()]) != 1 && i2 != 2) {
            if (i2 != 3) {
                throw new H0.c();
            }
            C0352m changeSize = this.exit.getData$animation().getChangeSize();
            if (changeSize == null) {
                return e0.o.Companion.m5207getZeronOccac();
            }
            long jM5243unboximpl = ((e0.s) changeSize.getSize().invoke(e0.s.m5231boximpl(j2))).m5243unboximpl();
            InterfaceC0849g alignment = getAlignment();
            kotlin.jvm.internal.o.b(alignment);
            e0.u uVar = e0.u.Ltr;
            long jMo2803alignKFBX0sM = alignment.mo2803alignKFBX0sM(j2, jM5243unboximpl, uVar);
            InterfaceC0849g interfaceC0849g = this.currentAlignment;
            kotlin.jvm.internal.o.b(interfaceC0849g);
            return e0.o.m5199minusqkQi6aY(jMo2803alignKFBX0sM, interfaceC0849g.mo2803alignKFBX0sM(j2, jM5243unboximpl, uVar));
        }
        return e0.o.Companion.m5207getZeronOccac();
    }
}
