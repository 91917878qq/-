package androidx.compose.animation;

import androidx.compose.animation.AnimatedContentTransitionScopeImpl;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.C0316j0;
import androidx.compose.animation.core.U0;
import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.y0;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.Z;
import androidx.compose.runtime.h2;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import androidx.compose.ui.platform.L0;
import e0.C1305b;
import j.d0;
import java.util.Iterator;

/* JADX INFO: renamed from: androidx.compose.animation.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0295b {
    private static final long UnspecifiedSize;

    /* JADX INFO: renamed from: androidx.compose.animation.b$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        public static final a INSTANCE = new a();

        public a() {
            super(1);
        }

        @Override // h1.c
        public final C0355p invoke(InterfaceC0346g interfaceC0346g) {
            return AbstractC0295b.togetherWith(AbstractC0359u.fadeIn$default(AbstractC0315j.tween$default(220, 90, null, 4, null), 0.0f, 2, null).plus(AbstractC0359u.m667scaleInL8ZKhE$default(AbstractC0315j.tween$default(220, 90, null, 4, null), 0.92f, 0L, 4, null)), AbstractC0359u.fadeOut$default(AbstractC0315j.tween$default(90, 0, null, 6, null), 0.0f, 2, null));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$b, reason: collision with other inner class name */
    public static final class C0010b extends kotlin.jvm.internal.p implements h1.c {
        public static final C0010b INSTANCE = new C0010b();

        public C0010b() {
            super(1);
        }

        @Override // h1.c
        public final S invoke(S s2) {
            return s2;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$c */
    public static final class c extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.g $content;
        final /* synthetic */ InterfaceC0849g $contentAlignment;
        final /* synthetic */ h1.c $contentKey;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ S $targetState;
        final /* synthetic */ h1.c $transitionSpec;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(S s2, androidx.compose.ui.x xVar, h1.c cVar, InterfaceC0849g interfaceC0849g, String str, h1.c cVar2, h1.g gVar, int i2, int i3) {
            super(2);
            this.$targetState = s2;
            this.$modifier = xVar;
            this.$transitionSpec = cVar;
            this.$contentAlignment = interfaceC0849g;
            this.$label = str;
            this.$contentKey = cVar2;
            this.$content = gVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0295b.AnimatedContent(this.$targetState, this.$modifier, this.$transitionSpec, this.$contentAlignment, this.$label, this.$contentKey, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$d */
    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        public static final d INSTANCE = new d();

        public d() {
            super(1);
        }

        @Override // h1.c
        public final C0355p invoke(InterfaceC0346g interfaceC0346g) {
            return AbstractC0295b.togetherWith(AbstractC0359u.fadeIn$default(AbstractC0315j.tween$default(220, 90, null, 4, null), 0.0f, 2, null).plus(AbstractC0359u.m667scaleInL8ZKhE$default(AbstractC0315j.tween$default(220, 90, null, 4, null), 0.92f, 0L, 4, null)), AbstractC0359u.fadeOut$default(AbstractC0315j.tween$default(90, 0, null, 6, null), 0.0f, 2, null));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$e */
    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        public static final e INSTANCE = new e();

        public e() {
            super(1);
        }

        @Override // h1.c
        public final S invoke(S s2) {
            return s2;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$f */
    public static final class f extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ h1.g $content;
        final /* synthetic */ androidx.compose.runtime.snapshots.w $currentlyVisible;
        final /* synthetic */ AnimatedContentTransitionScopeImpl $rootScope;
        final /* synthetic */ S $stateForContent;
        final /* synthetic */ v0 $this_AnimatedContent;
        final /* synthetic */ h1.c $transitionSpec;

        /* JADX INFO: renamed from: androidx.compose.animation.b$f$a */
        public static final class a extends kotlin.jvm.internal.p implements h1.f {
            final /* synthetic */ C0355p $specOnEnter;

            /* JADX INFO: renamed from: androidx.compose.animation.b$f$a$a, reason: collision with other inner class name */
            public static final class C0011a extends kotlin.jvm.internal.p implements h1.c {
                final /* synthetic */ AbstractC0974x0 $placeable;
                final /* synthetic */ C0355p $specOnEnter;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0011a(AbstractC0974x0 abstractC0974x0, C0355p c0355p) {
                    super(1);
                    this.$placeable = abstractC0974x0;
                    this.$specOnEnter = c0355p;
                }

                @Override // h1.c
                public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                    invoke((AbstractC0974x0.a) obj);
                    return U0.n.f1521a;
                }

                public final void invoke(AbstractC0974x0.a aVar) {
                    aVar.place(this.$placeable, 0, 0, this.$specOnEnter.getTargetContentZIndex());
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(C0355p c0355p) {
                super(3);
                this.$specOnEnter = c0355p;
            }

            @Override // h1.f
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                return m577invoke3p2s80s((InterfaceC0937e0) obj, (InterfaceC0931b0) obj2, ((C1305b) obj3).m5047unboximpl());
            }

            /* JADX INFO: renamed from: invoke-3p2s80s, reason: not valid java name */
            public final InterfaceC0935d0 m577invoke3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
                AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
                return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new C0011a(abstractC0974x0Mo3865measureBRTryo0, this.$specOnEnter), 4, null);
            }
        }

        /* JADX INFO: renamed from: androidx.compose.animation.b$f$b, reason: collision with other inner class name */
        public static final class C0012b extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ S $stateForContent;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0012b(S s2) {
                super(1);
                this.$stateForContent = s2;
            }

            @Override // h1.c
            public final Boolean invoke(S s2) {
                return Boolean.valueOf(kotlin.jvm.internal.o.a(s2, this.$stateForContent));
            }
        }

        /* JADX INFO: renamed from: androidx.compose.animation.b$f$c */
        public static final class c extends kotlin.jvm.internal.p implements h1.e {
            final /* synthetic */ C $exit;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(C c2) {
                super(2);
                this.$exit = c2;
            }

            @Override // h1.e
            public final Boolean invoke(EnumC0356q enumC0356q, EnumC0356q enumC0356q2) {
                EnumC0356q enumC0356q3 = EnumC0356q.PostExit;
                return Boolean.valueOf(enumC0356q == enumC0356q3 && enumC0356q2 == enumC0356q3 && !this.$exit.getData$animation().getHold());
            }
        }

        /* JADX INFO: renamed from: androidx.compose.animation.b$f$d */
        public static final class d extends kotlin.jvm.internal.p implements h1.f {
            final /* synthetic */ h1.g $content;
            final /* synthetic */ androidx.compose.runtime.snapshots.w $currentlyVisible;
            final /* synthetic */ AnimatedContentTransitionScopeImpl $rootScope;
            final /* synthetic */ S $stateForContent;

            /* JADX INFO: renamed from: androidx.compose.animation.b$f$d$a */
            public static final class a extends kotlin.jvm.internal.p implements h1.c {
                final /* synthetic */ androidx.compose.runtime.snapshots.w $currentlyVisible;
                final /* synthetic */ AnimatedContentTransitionScopeImpl $rootScope;
                final /* synthetic */ S $stateForContent;

                /* JADX INFO: renamed from: androidx.compose.animation.b$f$d$a$a, reason: collision with other inner class name */
                public static final class C0013a implements androidx.compose.runtime.V {
                    final /* synthetic */ androidx.compose.runtime.snapshots.w $currentlyVisible$inlined;
                    final /* synthetic */ AnimatedContentTransitionScopeImpl $rootScope$inlined;
                    final /* synthetic */ Object $stateForContent$inlined;

                    public C0013a(androidx.compose.runtime.snapshots.w wVar, Object obj, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
                        this.$currentlyVisible$inlined = wVar;
                        this.$stateForContent$inlined = obj;
                        this.$rootScope$inlined = animatedContentTransitionScopeImpl;
                    }

                    @Override // androidx.compose.runtime.V
                    public void dispose() {
                        this.$currentlyVisible$inlined.remove(this.$stateForContent$inlined);
                        this.$rootScope$inlined.getTargetSizeMap$animation().j(this.$stateForContent$inlined);
                    }
                }

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public a(androidx.compose.runtime.snapshots.w wVar, S s2, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl) {
                    super(1);
                    this.$currentlyVisible = wVar;
                    this.$stateForContent = s2;
                    this.$rootScope = animatedContentTransitionScopeImpl;
                }

                @Override // h1.c
                public final androidx.compose.runtime.V invoke(androidx.compose.runtime.W w2) {
                    return new C0013a(this.$currentlyVisible, this.$stateForContent, this.$rootScope);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public d(androidx.compose.runtime.snapshots.w wVar, S s2, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl, h1.g gVar) {
                super(3);
                this.$currentlyVisible = wVar;
                this.$stateForContent = s2;
                this.$rootScope = animatedContentTransitionScopeImpl;
                this.$content = gVar;
            }

            @Override // h1.f
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                invoke((InterfaceC0349j) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
                return U0.n.f1521a;
            }

            public final void invoke(InterfaceC0349j interfaceC0349j, InterfaceC0768p interfaceC0768p, int i2) {
                if ((i2 & 6) == 0) {
                    i2 |= (i2 & 8) == 0 ? interfaceC0768p.changed(interfaceC0349j) : interfaceC0768p.changedInstance(interfaceC0349j) ? 4 : 2;
                }
                if (!interfaceC0768p.shouldExecute((i2 & 19) != 18, i2 & 1)) {
                    interfaceC0768p.skipToGroupEnd();
                    return;
                }
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventStart(-143346359, i2, -1, "androidx.compose.animation.AnimatedContent.<anonymous>.<anonymous>.<anonymous> (AnimatedContent.kt:854)");
                }
                boolean zChanged = interfaceC0768p.changed(this.$currentlyVisible) | interfaceC0768p.changedInstance(this.$stateForContent) | interfaceC0768p.changedInstance(this.$rootScope);
                androidx.compose.runtime.snapshots.w wVar = this.$currentlyVisible;
                S s2 = this.$stateForContent;
                AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl = this.$rootScope;
                Object objRememberedValue = interfaceC0768p.rememberedValue();
                if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = new a(wVar, s2, animatedContentTransitionScopeImpl);
                    interfaceC0768p.updateRememberedValue(objRememberedValue);
                }
                Z.DisposableEffect(interfaceC0349j, (h1.c) objRememberedValue, interfaceC0768p, i2 & 14);
                j.S targetSizeMap$animation = this.$rootScope.getTargetSizeMap$animation();
                Object obj = this.$stateForContent;
                kotlin.jvm.internal.o.c(interfaceC0349j, "null cannot be cast to non-null type androidx.compose.animation.AnimatedVisibilityScopeImpl");
                targetSizeMap$animation.l(obj, ((C0350k) interfaceC0349j).getTargetSize$animation());
                Object objRememberedValue2 = interfaceC0768p.rememberedValue();
                if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue2 = new C0344e(interfaceC0349j);
                    interfaceC0768p.updateRememberedValue(objRememberedValue2);
                }
                this.$content.invoke((C0344e) objRememberedValue2, this.$stateForContent, interfaceC0768p, 0);
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventEnd();
                }
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(v0 v0Var, S s2, h1.c cVar, AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl, androidx.compose.runtime.snapshots.w wVar, h1.g gVar) {
            super(2);
            this.$this_AnimatedContent = v0Var;
            this.$stateForContent = s2;
            this.$transitionSpec = cVar;
            this.$rootScope = animatedContentTransitionScopeImpl;
            this.$currentlyVisible = wVar;
            this.$content = gVar;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            if (!interfaceC0768p.shouldExecute((i2 & 3) != 2, i2 & 1)) {
                interfaceC0768p.skipToGroupEnd();
                return;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-23915175, i2, -1, "androidx.compose.animation.AnimatedContent.<anonymous>.<anonymous> (AnimatedContent.kt:818)");
            }
            h1.c cVar = this.$transitionSpec;
            AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl = this.$rootScope;
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            C0765o c0765o = InterfaceC0768p.Companion;
            if (objRememberedValue == c0765o.getEmpty()) {
                objRememberedValue = (C0355p) cVar.invoke(animatedContentTransitionScopeImpl);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            C0355p c0355p = (C0355p) objRememberedValue;
            boolean zChanged = interfaceC0768p.changed(kotlin.jvm.internal.o.a(this.$this_AnimatedContent.getSegment().getTargetState(), this.$stateForContent));
            v0 v0Var = this.$this_AnimatedContent;
            S s2 = this.$stateForContent;
            h1.c cVar2 = this.$transitionSpec;
            AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl2 = this.$rootScope;
            Object objRememberedValue2 = interfaceC0768p.rememberedValue();
            if (zChanged || objRememberedValue2 == c0765o.getEmpty()) {
                objRememberedValue2 = kotlin.jvm.internal.o.a(v0Var.getSegment().getTargetState(), s2) ? C.Companion.getNone() : ((C0355p) cVar2.invoke(animatedContentTransitionScopeImpl2)).getInitialContentExit();
                interfaceC0768p.updateRememberedValue(objRememberedValue2);
            }
            C c2 = (C) objRememberedValue2;
            S s3 = this.$stateForContent;
            v0 v0Var2 = this.$this_AnimatedContent;
            Object objRememberedValue3 = interfaceC0768p.rememberedValue();
            if (objRememberedValue3 == c0765o.getEmpty()) {
                objRememberedValue3 = new AnimatedContentTransitionScopeImpl.a(kotlin.jvm.internal.o.a(s3, v0Var2.getTargetState()));
                interfaceC0768p.updateRememberedValue(objRememberedValue3);
            }
            AnimatedContentTransitionScopeImpl.a aVar = (AnimatedContentTransitionScopeImpl.a) objRememberedValue3;
            A targetContentEnter = c0355p.getTargetContentEnter();
            androidx.compose.ui.u uVar = androidx.compose.ui.x.Companion;
            boolean zChangedInstance = interfaceC0768p.changedInstance(c0355p);
            Object objRememberedValue4 = interfaceC0768p.rememberedValue();
            if (zChangedInstance || objRememberedValue4 == c0765o.getEmpty()) {
                objRememberedValue4 = new a(c0355p);
                interfaceC0768p.updateRememberedValue(objRememberedValue4);
            }
            androidx.compose.ui.x xVarLayout = androidx.compose.ui.layout.S.layout(uVar, (h1.f) objRememberedValue4);
            aVar.setTarget(kotlin.jvm.internal.o.a(this.$stateForContent, this.$this_AnimatedContent.getTargetState()));
            androidx.compose.ui.x xVarThen = xVarLayout.then(aVar);
            v0 v0Var3 = this.$this_AnimatedContent;
            boolean zChangedInstance2 = interfaceC0768p.changedInstance(this.$stateForContent);
            S s4 = this.$stateForContent;
            Object objRememberedValue5 = interfaceC0768p.rememberedValue();
            if (zChangedInstance2 || objRememberedValue5 == c0765o.getEmpty()) {
                objRememberedValue5 = new C0012b(s4);
                interfaceC0768p.updateRememberedValue(objRememberedValue5);
            }
            h1.c cVar3 = (h1.c) objRememberedValue5;
            boolean zChanged2 = interfaceC0768p.changed(c2);
            Object objRememberedValue6 = interfaceC0768p.rememberedValue();
            if (zChanged2 || objRememberedValue6 == c0765o.getEmpty()) {
                objRememberedValue6 = new c(c2);
                interfaceC0768p.updateRememberedValue(objRememberedValue6);
            }
            AbstractC0348i.AnimatedEnterExitImpl(v0Var3, cVar3, xVarThen, targetContentEnter, c2, (h1.e) objRememberedValue6, null, G.v.rememberComposableLambda(-143346359, true, new d(this.$currentlyVisible, this.$stateForContent, this.$rootScope, this.$content), interfaceC0768p, 54), interfaceC0768p, 12582912, 64);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$g */
    public static final class g extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.g $content;
        final /* synthetic */ InterfaceC0849g $contentAlignment;
        final /* synthetic */ h1.c $contentKey;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ v0 $this_AnimatedContent;
        final /* synthetic */ h1.c $transitionSpec;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(v0 v0Var, androidx.compose.ui.x xVar, h1.c cVar, InterfaceC0849g interfaceC0849g, h1.c cVar2, h1.g gVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedContent = v0Var;
            this.$modifier = xVar;
            this.$transitionSpec = cVar;
            this.$contentAlignment = interfaceC0849g;
            this.$contentKey = cVar2;
            this.$content = gVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0295b.AnimatedContent(this.$this_AnimatedContent, this.$modifier, this.$transitionSpec, this.$contentAlignment, this.$contentKey, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.b$h */
    public static final class h extends kotlin.jvm.internal.p implements h1.e {
        public static final h INSTANCE = new h();

        public h() {
            super(2);
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return m578invokeTemP2vQ(((e0.s) obj).m5243unboximpl(), ((e0.s) obj2).m5243unboximpl());
        }

        /* JADX INFO: renamed from: invoke-TemP2vQ, reason: not valid java name */
        public final C0316j0 m578invokeTemP2vQ(long j2, long j3) {
            return AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
    }

    static {
        long j2 = Integer.MIN_VALUE;
        UnspecifiedSize = e0.s.m5234constructorimpl((j2 & 4294967295L) | (j2 << 32));
    }

    /* JADX WARN: Removed duplicated region for block: B:116:0x0175  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0184  */
    /* JADX WARN: Removed duplicated region for block: B:121:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x00df  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x00e8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final <S> void AnimatedContent(S s2, androidx.compose.ui.x xVar, h1.c cVar, InterfaceC0849g interfaceC0849g, String str, h1.c cVar2, h1.g gVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        int i6;
        InterfaceC0849g interfaceC0849g2;
        int i7;
        String str2;
        int i8;
        h1.c cVar3;
        androidx.compose.ui.x xVar2;
        h1.c cVar4;
        String str3;
        h1.c cVar5;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        h1.c cVar6;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1501828832);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = ((i2 & 8) == 0 ? interfaceC0768pStartRestartGroup.changed(s2) : interfaceC0768pStartRestartGroup.changedInstance(s2) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i9 = i3 & 2;
        if (i9 != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar) ? 32 : 16;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 384;
            } else {
                if ((i2 & 384) == 0) {
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 256 : 128;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 3072;
                } else {
                    if ((i2 & 3072) == 0) {
                        interfaceC0849g2 = interfaceC0849g;
                        i4 |= interfaceC0768pStartRestartGroup.changed(interfaceC0849g2) ? 2048 : 1024;
                    }
                    i7 = i3 & 16;
                    if (i7 == 0) {
                        i4 |= 24576;
                    } else {
                        if ((i2 & 24576) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 16384 : 8192;
                        }
                        i8 = i3 & 32;
                        if (i8 != 0) {
                            i4 |= 196608;
                        } else {
                            if ((196608 & i2) == 0) {
                                cVar3 = cVar2;
                                i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar3) ? 131072 : 65536;
                            }
                            if ((i3 & 64) != 0) {
                                if ((i2 & 1572864) == 0) {
                                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(gVar) ? 1048576 : 524288;
                                }
                                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                                    androidx.compose.ui.x xVar3 = i9 != 0 ? androidx.compose.ui.x.Companion : xVar;
                                    if (i5 != 0) {
                                        Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                                        if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                            objRememberedValue = a.INSTANCE;
                                            interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                                        }
                                        cVar4 = (h1.c) objRememberedValue;
                                    } else {
                                        cVar4 = cVar;
                                    }
                                    InterfaceC0849g topStart = i6 != 0 ? InterfaceC0849g.Companion.getTopStart() : interfaceC0849g2;
                                    String str4 = i7 != 0 ? "AnimatedContent" : str2;
                                    if (i8 != 0) {
                                        Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                                        if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                                            objRememberedValue2 = C0010b.INSTANCE;
                                            interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                                        }
                                        cVar6 = (h1.c) objRememberedValue2;
                                    } else {
                                        cVar6 = cVar3;
                                    }
                                    if (AbstractC0776s.isTraceInProgress()) {
                                        AbstractC0776s.traceEventStart(1501828832, i4, -1, "androidx.compose.animation.AnimatedContent (AnimatedContent.kt:140)");
                                    }
                                    v0 v0VarUpdateTransition = y0.updateTransition(s2, str4, interfaceC0768pStartRestartGroup, (i4 & 14) | ((i4 >> 9) & 112), 0);
                                    int i10 = i4 & 8176;
                                    int i11 = i4 >> 3;
                                    AnimatedContent(v0VarUpdateTransition, xVar3, cVar4, topStart, cVar6, gVar, interfaceC0768pStartRestartGroup, i10 | (57344 & i11) | (i11 & 458752), 0);
                                    if (AbstractC0776s.isTraceInProgress()) {
                                        AbstractC0776s.traceEventEnd();
                                    }
                                    xVar2 = xVar3;
                                    interfaceC0849g2 = topStart;
                                    str3 = str4;
                                    cVar5 = cVar6;
                                } else {
                                    interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                    xVar2 = xVar;
                                    cVar4 = cVar;
                                    str3 = str2;
                                    cVar5 = cVar3;
                                }
                                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                                if (interfaceC0811x1EndRestartGroup != null) {
                                    interfaceC0811x1EndRestartGroup.updateScope(new c(s2, xVar2, cVar4, interfaceC0849g2, str3, cVar5, gVar, i2, i3));
                                    return;
                                }
                                return;
                            }
                            i4 |= 1572864;
                            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                            }
                            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                            if (interfaceC0811x1EndRestartGroup != null) {
                            }
                        }
                        cVar3 = cVar2;
                        if ((i3 & 64) != 0) {
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                        }
                    }
                    str2 = str;
                    i8 = i3 & 32;
                    if (i8 != 0) {
                    }
                    cVar3 = cVar2;
                    if ((i3 & 64) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                interfaceC0849g2 = interfaceC0849g;
                i7 = i3 & 16;
                if (i7 == 0) {
                }
                str2 = str;
                i8 = i3 & 32;
                if (i8 != 0) {
                }
                cVar3 = cVar2;
                if ((i3 & 64) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            interfaceC0849g2 = interfaceC0849g;
            i7 = i3 & 16;
            if (i7 == 0) {
            }
            str2 = str;
            i8 = i3 & 32;
            if (i8 != 0) {
            }
            cVar3 = cVar2;
            if ((i3 & 64) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        interfaceC0849g2 = interfaceC0849g;
        i7 = i3 & 16;
        if (i7 == 0) {
        }
        str2 = str;
        i8 = i3 & 32;
        if (i8 != 0) {
        }
        cVar3 = cVar2;
        if ((i3 & 64) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((i4 & 599187) != 599186, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    public static final N SizeTransform(boolean z2, h1.e eVar) {
        return new O(z2, eVar);
    }

    public static /* synthetic */ N SizeTransform$default(boolean z2, h1.e eVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z2 = true;
        }
        if ((i2 & 2) != 0) {
            eVar = h.INSTANCE;
        }
        return SizeTransform(z2, eVar);
    }

    public static final C0355p togetherWith(A a2, C c2) {
        return new C0355p(a2, c2, 0.0f, null, 12, null);
    }

    @U0.a
    public static final C0355p with(A a2, C c2) {
        return new C0355p(a2, c2, 0.0f, null, 12, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:193:0x03a4  */
    /* JADX WARN: Removed duplicated region for block: B:196:0x03b1  */
    /* JADX WARN: Removed duplicated region for block: B:204:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00cc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final <S> void AnimatedContent(v0 v0Var, androidx.compose.ui.x xVar, h1.c cVar, InterfaceC0849g interfaceC0849g, h1.c cVar2, h1.g gVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        h1.c cVar3;
        int i6;
        InterfaceC0849g topStart;
        int i7;
        h1.c cVar4;
        androidx.compose.ui.x xVar3;
        h1.c cVar5;
        InterfaceC0849g interfaceC0849g2;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0849g interfaceC0849g3;
        j.S s2;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(511725103);
        if ((i3 & Integer.MIN_VALUE) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(v0Var) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 1;
        if (i8 != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 32 : 16;
            }
            i5 = i3 & 2;
            if (i5 == 0) {
                i4 |= 384;
            } else {
                if ((i2 & 384) == 0) {
                    h1.c cVar6 = cVar;
                    i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar6) ? 256 : 128;
                    cVar3 = cVar6;
                }
                i6 = i3 & 4;
                if (i6 != 0) {
                    i4 |= 3072;
                } else {
                    if ((i2 & 3072) == 0) {
                        topStart = interfaceC0849g;
                        i4 |= interfaceC0768pStartRestartGroup.changed(topStart) ? 2048 : 1024;
                    }
                    i7 = i3 & 8;
                    if (i7 == 0) {
                        i4 |= 24576;
                    } else {
                        if ((i2 & 24576) == 0) {
                            cVar4 = cVar2;
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar4) ? 16384 : 8192;
                        }
                        if ((i3 & 16) == 0) {
                            if ((i2 & 196608) == 0) {
                                i4 |= interfaceC0768pStartRestartGroup.changedInstance(gVar) ? 131072 : 65536;
                            }
                            if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
                                androidx.compose.ui.x xVar4 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                                if (i5 != 0) {
                                    Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                                    if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                        objRememberedValue = d.INSTANCE;
                                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                                    }
                                    cVar3 = (h1.c) objRememberedValue;
                                }
                                if (i6 != 0) {
                                    topStart = InterfaceC0849g.Companion.getTopStart();
                                }
                                if (i7 != 0) {
                                    Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                                    if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                                        objRememberedValue2 = e.INSTANCE;
                                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                                    }
                                    cVar4 = (h1.c) objRememberedValue2;
                                }
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventStart(511725103, i4, -1, "androidx.compose.animation.AnimatedContent (AnimatedContent.kt:773)");
                                }
                                e0.u uVar = (e0.u) interfaceC0768pStartRestartGroup.consume(L0.getLocalLayoutDirection());
                                int i9 = i4 & 14;
                                boolean z2 = i9 == 4;
                                Object objRememberedValue3 = interfaceC0768pStartRestartGroup.rememberedValue();
                                if (z2 || objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
                                    objRememberedValue3 = new AnimatedContentTransitionScopeImpl(v0Var, topStart, uVar);
                                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue3);
                                }
                                AnimatedContentTransitionScopeImpl animatedContentTransitionScopeImpl = (AnimatedContentTransitionScopeImpl) objRememberedValue3;
                                boolean z3 = i9 == 4;
                                Object objRememberedValue4 = interfaceC0768pStartRestartGroup.rememberedValue();
                                if (z3 || objRememberedValue4 == InterfaceC0768p.Companion.getEmpty()) {
                                    objRememberedValue4 = Q1.mutableStateListOf(v0Var.getCurrentState());
                                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue4);
                                }
                                androidx.compose.runtime.snapshots.w wVar = (androidx.compose.runtime.snapshots.w) objRememberedValue4;
                                boolean z4 = i9 == 4;
                                Object objRememberedValue5 = interfaceC0768pStartRestartGroup.rememberedValue();
                                if (z4 || objRememberedValue5 == InterfaceC0768p.Companion.getEmpty()) {
                                    long[] jArr = d0.f2979a;
                                    objRememberedValue5 = new j.S();
                                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue5);
                                }
                                j.S s3 = (j.S) objRememberedValue5;
                                if (!wVar.contains(v0Var.getCurrentState())) {
                                    wVar.clear();
                                    wVar.add(v0Var.getCurrentState());
                                }
                                if (kotlin.jvm.internal.o.a(v0Var.getCurrentState(), v0Var.getTargetState())) {
                                    if (wVar.size() != 1 || !kotlin.jvm.internal.o.a(wVar.get(0), v0Var.getCurrentState())) {
                                        wVar.clear();
                                        wVar.add(v0Var.getCurrentState());
                                    }
                                    if (s3.f2974e != 1 || s3.b(v0Var.getCurrentState())) {
                                        s3.f();
                                    }
                                    animatedContentTransitionScopeImpl.setContentAlignment(topStart);
                                    animatedContentTransitionScopeImpl.setLayoutDirection$animation(uVar);
                                }
                                if (!kotlin.jvm.internal.o.a(v0Var.getCurrentState(), v0Var.getTargetState()) && !wVar.contains(v0Var.getTargetState())) {
                                    Iterator it = wVar.iterator();
                                    int i10 = 0;
                                    while (true) {
                                        if (!it.hasNext()) {
                                            i10 = -1;
                                            break;
                                        } else if (kotlin.jvm.internal.o.a(cVar4.invoke(it.next()), cVar4.invoke(v0Var.getTargetState()))) {
                                            break;
                                        } else {
                                            i10++;
                                        }
                                    }
                                    if (i10 == -1) {
                                        wVar.add(v0Var.getTargetState());
                                    } else {
                                        wVar.set(i10, v0Var.getTargetState());
                                    }
                                }
                                if (s3.b(v0Var.getTargetState()) && s3.b(v0Var.getCurrentState())) {
                                    interfaceC0768pStartRestartGroup.startReplaceGroup(1969054067);
                                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                                    interfaceC0849g3 = topStart;
                                    s2 = s3;
                                } else {
                                    interfaceC0768pStartRestartGroup.startReplaceGroup(1966468977);
                                    s3.f();
                                    int size = wVar.size();
                                    int i11 = 0;
                                    while (i11 < size) {
                                        Object obj = wVar.get(i11);
                                        InterfaceC0849g interfaceC0849g4 = topStart;
                                        j.S s4 = s3;
                                        s4.l(obj, G.v.rememberComposableLambda(-23915175, true, new f(v0Var, obj, cVar3, animatedContentTransitionScopeImpl, wVar, gVar), interfaceC0768pStartRestartGroup, 54));
                                        i11++;
                                        s3 = s4;
                                        size = size;
                                        topStart = interfaceC0849g4;
                                    }
                                    interfaceC0849g3 = topStart;
                                    s2 = s3;
                                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                                }
                                boolean zChanged = interfaceC0768pStartRestartGroup.changed(v0Var.getSegment()) | interfaceC0768pStartRestartGroup.changed(animatedContentTransitionScopeImpl);
                                Object objRememberedValue6 = interfaceC0768pStartRestartGroup.rememberedValue();
                                if (zChanged || objRememberedValue6 == InterfaceC0768p.Companion.getEmpty()) {
                                    objRememberedValue6 = (C0355p) cVar3.invoke(animatedContentTransitionScopeImpl);
                                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue6);
                                }
                                androidx.compose.ui.x xVarThen = xVar4.then(animatedContentTransitionScopeImpl.createSizeAnimationModifier$animation((C0355p) objRememberedValue6, interfaceC0768pStartRestartGroup, 0));
                                Object objRememberedValue7 = interfaceC0768pStartRestartGroup.rememberedValue();
                                if (objRememberedValue7 == InterfaceC0768p.Companion.getEmpty()) {
                                    objRememberedValue7 = new C0296c(animatedContentTransitionScopeImpl);
                                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue7);
                                }
                                C0296c c0296c = (C0296c) objRememberedValue7;
                                int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768pStartRestartGroup, 0));
                                androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768pStartRestartGroup.getCurrentCompositionLocalMap();
                                androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768pStartRestartGroup, xVarThen);
                                C0997j c0997j = InterfaceC0999k.Companion;
                                h1.a constructor = c0997j.getConstructor();
                                if (interfaceC0768pStartRestartGroup.getApplier() == null) {
                                    AbstractC0750j.invalidApplier();
                                }
                                interfaceC0768pStartRestartGroup.startReusableNode();
                                if (interfaceC0768pStartRestartGroup.getInserting()) {
                                    interfaceC0768pStartRestartGroup.createNode(constructor);
                                } else {
                                    interfaceC0768pStartRestartGroup.useNode();
                                }
                                InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768pStartRestartGroup);
                                h2.m2599setimpl(interfaceC0768pM2592constructorimpl, c0296c, c0997j.getSetMeasurePolicy());
                                h2.m2599setimpl(interfaceC0768pM2592constructorimpl, currentCompositionLocalMap, c0997j.getSetResolvedCompositionLocals());
                                h1.e setCompositeKeyHash = c0997j.getSetCompositeKeyHash();
                                if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                    D0.d.z(setCompositeKeyHash, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
                                }
                                h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
                                interfaceC0768pStartRestartGroup.startReplaceGroup(-860173498);
                                int size2 = wVar.size();
                                for (int i12 = 0; i12 < size2; i12++) {
                                    Object obj2 = wVar.get(i12);
                                    interfaceC0768pStartRestartGroup.startMovableGroup(-2026002954, cVar4.invoke(obj2));
                                    h1.e eVar = (h1.e) s2.d(obj2);
                                    if (eVar == null) {
                                        interfaceC0768pStartRestartGroup.startReplaceGroup(1618454323);
                                        interfaceC0768pStartRestartGroup.endReplaceGroup();
                                    } else {
                                        interfaceC0768pStartRestartGroup.startReplaceGroup(-2026001778);
                                        eVar.invoke(interfaceC0768pStartRestartGroup, 0);
                                        interfaceC0768pStartRestartGroup.endReplaceGroup();
                                    }
                                    interfaceC0768pStartRestartGroup.endMovableGroup();
                                }
                                interfaceC0768pStartRestartGroup.endReplaceGroup();
                                interfaceC0768pStartRestartGroup.endNode();
                                if (AbstractC0776s.isTraceInProgress()) {
                                    AbstractC0776s.traceEventEnd();
                                }
                                interfaceC0849g2 = interfaceC0849g3;
                                xVar3 = xVar4;
                                cVar5 = cVar3;
                            } else {
                                interfaceC0768pStartRestartGroup.skipToGroupEnd();
                                xVar3 = xVar2;
                                cVar5 = cVar3;
                                interfaceC0849g2 = topStart;
                            }
                            h1.c cVar7 = cVar4;
                            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                            if (interfaceC0811x1EndRestartGroup == null) {
                                interfaceC0811x1EndRestartGroup.updateScope(new g(v0Var, xVar3, cVar5, interfaceC0849g2, cVar7, gVar, i2, i3));
                                return;
                            }
                            return;
                        }
                        i4 |= 196608;
                        if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
                        }
                        h1.c cVar72 = cVar4;
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup == null) {
                        }
                    }
                    cVar4 = cVar2;
                    if ((i3 & 16) == 0) {
                    }
                    if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
                    }
                    h1.c cVar722 = cVar4;
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup == null) {
                    }
                }
                topStart = interfaceC0849g;
                i7 = i3 & 8;
                if (i7 == 0) {
                }
                cVar4 = cVar2;
                if ((i3 & 16) == 0) {
                }
                if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
                }
                h1.c cVar7222 = cVar4;
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup == null) {
                }
            }
            cVar3 = cVar;
            i6 = i3 & 4;
            if (i6 != 0) {
            }
            topStart = interfaceC0849g;
            i7 = i3 & 8;
            if (i7 == 0) {
            }
            cVar4 = cVar2;
            if ((i3 & 16) == 0) {
            }
            if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
            }
            h1.c cVar72222 = cVar4;
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup == null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 2;
        if (i5 == 0) {
        }
        cVar3 = cVar;
        i6 = i3 & 4;
        if (i6 != 0) {
        }
        topStart = interfaceC0849g;
        i7 = i3 & 8;
        if (i7 == 0) {
        }
        cVar4 = cVar2;
        if ((i3 & 16) == 0) {
        }
        if (!interfaceC0768pStartRestartGroup.shouldExecute((i4 & 74899) == 74898, i4 & 1)) {
        }
        h1.c cVar722222 = cVar4;
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup == null) {
        }
    }
}
