package androidx.compose.animation;

import a.AbstractC0292a;
import androidx.compose.animation.core.X;
import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.y0;
import androidx.compose.foundation.layout.InterfaceC0445x;
import androidx.compose.foundation.layout.u0;
import androidx.compose.runtime.AbstractC0743g1;
import androidx.compose.runtime.AbstractC0750j;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.InterfaceC0715a1;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import androidx.compose.runtime.h2;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import androidx.compose.ui.node.C0997j;
import androidx.compose.ui.node.InterfaceC0999k;
import e0.C1305b;
import u1.InterfaceC1491d;
import u1.InterfaceC1492e;

/* JADX INFO: renamed from: androidx.compose.animation.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0348i {

    /* JADX INFO: renamed from: androidx.compose.animation.i$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.f {
        final /* synthetic */ J $onLookaheadMeasured;

        /* JADX INFO: renamed from: androidx.compose.animation.i$a$a, reason: collision with other inner class name */
        public static final class C0018a extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ AbstractC0974x0 $this_run;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0018a(AbstractC0974x0 abstractC0974x0) {
                super(1);
                this.$this_run = abstractC0974x0;
            }

            @Override // h1.c
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                invoke((AbstractC0974x0.a) obj);
                return U0.n.f1521a;
            }

            public final void invoke(AbstractC0974x0.a aVar) {
                AbstractC0974x0.a.place$default(aVar, this.$this_run, 0, 0, 0.0f, 4, null);
            }
        }

        public a(J j2) {
            super(3);
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return m658invoke3p2s80s((InterfaceC0937e0) obj, (InterfaceC0931b0) obj2, ((C1305b) obj3).m5047unboximpl());
        }

        /* JADX INFO: renamed from: invoke-3p2s80s, reason: not valid java name */
        public final InterfaceC0935d0 m658invoke3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
            if (!interfaceC0937e0.isLookingAhead()) {
                return InterfaceC0937e0.layout$default(interfaceC0937e0, abstractC0974x0Mo3865measureBRTryo0.getWidth(), abstractC0974x0Mo3865measureBRTryo0.getHeight(), null, new C0018a(abstractC0974x0Mo3865measureBRTryo0), 4, null);
            }
            e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L) | (((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32));
            throw null;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ J $onLookaheadMeasured;
        final /* synthetic */ h1.e $shouldDisposeBlock;
        final /* synthetic */ v0 $transition;
        final /* synthetic */ h1.c $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.e eVar, J j2, h1.f fVar, int i2, int i3) {
            super(2);
            this.$transition = v0Var;
            this.$visible = cVar;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$shouldDisposeBlock = eVar;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedEnterExitImpl(this.$transition, this.$visible, this.$modifier, this.$enter, this.$exit, this.$shouldDisposeBlock, null, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$c */
    public static final class c extends a1.j implements h1.e {
        final /* synthetic */ v0 $childTransition;
        final /* synthetic */ d2 $shouldDisposeBlockUpdated$delegate;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX INFO: renamed from: androidx.compose.animation.i$c$a */
        public static final class a extends kotlin.jvm.internal.p implements h1.a {
            final /* synthetic */ v0 $childTransition;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(v0 v0Var) {
                super(0);
                this.$childTransition = v0Var;
            }

            @Override // h1.a
            public final Boolean invoke() {
                return Boolean.valueOf(AbstractC0348i.getExitFinished(this.$childTransition));
            }
        }

        /* JADX INFO: renamed from: androidx.compose.animation.i$c$b */
        public static final class b implements InterfaceC1492e {
            final /* synthetic */ InterfaceC0715a1 $$this$produceState;
            final /* synthetic */ v0 $childTransition;
            final /* synthetic */ d2 $shouldDisposeBlockUpdated$delegate;

            public b(InterfaceC0715a1 interfaceC0715a1, v0 v0Var, d2 d2Var) {
                this.$$this$produceState = interfaceC0715a1;
                this.$childTransition = v0Var;
                this.$shouldDisposeBlockUpdated$delegate = d2Var;
            }

            @Override // u1.InterfaceC1492e
            public /* bridge */ /* synthetic */ Object emit(Object obj, Y0.c cVar) {
                return emit(((Boolean) obj).booleanValue(), cVar);
            }

            public final Object emit(boolean z2, Y0.c cVar) {
                this.$$this$produceState.setValue(Boolean.valueOf(z2 ? ((Boolean) AbstractC0348i.AnimatedEnterExitImpl$lambda$9(this.$shouldDisposeBlockUpdated$delegate).invoke(this.$childTransition.getCurrentState(), this.$childTransition.getTargetState())).booleanValue() : false));
                return U0.n.f1521a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(v0 v0Var, d2 d2Var, Y0.c cVar) {
            super(2, cVar);
            this.$childTransition = v0Var;
            this.$shouldDisposeBlockUpdated$delegate = d2Var;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            c cVar2 = new c(this.$childTransition, this.$shouldDisposeBlockUpdated$delegate, cVar);
            cVar2.L$0 = obj;
            return cVar2;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC0715a1 interfaceC0715a1, Y0.c cVar) {
            return ((c) create(interfaceC0715a1, cVar)).invokeSuspend(U0.n.f1521a);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                InterfaceC0715a1 interfaceC0715a1 = (InterfaceC0715a1) this.L$0;
                InterfaceC1491d interfaceC1491dSnapshotFlow = Q1.snapshotFlow(new a(this.$childTransition));
                b bVar = new b(interfaceC0715a1, this.$childTransition, this.$shouldDisposeBlockUpdated$delegate);
                this.label = 1;
                if (interfaceC1491dSnapshotFlow.b(bVar, this) == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            return U0.n.f1521a;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$d */
    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        public static final d INSTANCE = new d();

        public d() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$e */
    public static final class e extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ u0 $this_AnimatedVisibility;
        final /* synthetic */ X $visibleState;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(u0 u0Var, X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedVisibility = u0Var;
            this.$visibleState = x2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$this_AnimatedVisibility, this.$visibleState, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$f */
    public static final class f extends kotlin.jvm.internal.p implements h1.c {
        public static final f INSTANCE = new f();

        public f() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$g */
    public static final class g extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ InterfaceC0445x $this_AnimatedVisibility;
        final /* synthetic */ X $visibleState;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(InterfaceC0445x interfaceC0445x, X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedVisibility = interfaceC0445x;
            this.$visibleState = x2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$this_AnimatedVisibility, this.$visibleState, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$h */
    public static final class h extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ v0 $this_AnimatedVisibility;
        final /* synthetic */ h1.c $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.f fVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedVisibility = v0Var;
            this.$visible = cVar;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$this_AnimatedVisibility, this.$visible, this.$modifier, this.$enter, this.$exit, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$i, reason: collision with other inner class name */
    public static final class C0019i extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ boolean $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0019i(boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$visible = z2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$visible, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$j */
    public static final class j extends kotlin.jvm.internal.p implements h1.c {
        public static final j INSTANCE = new j();

        public j() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$k */
    public static final class k extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ u0 $this_AnimatedVisibility;
        final /* synthetic */ boolean $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public k(u0 u0Var, boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedVisibility = u0Var;
            this.$visible = z2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$this_AnimatedVisibility, this.$visible, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$l */
    public static final class l extends kotlin.jvm.internal.p implements h1.c {
        public static final l INSTANCE = new l();

        public l() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$m */
    public static final class m extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ InterfaceC0445x $this_AnimatedVisibility;
        final /* synthetic */ boolean $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public m(InterfaceC0445x interfaceC0445x, boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$this_AnimatedVisibility = interfaceC0445x;
            this.$visible = z2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$this_AnimatedVisibility, this.$visible, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$n */
    public static final class n extends kotlin.jvm.internal.p implements h1.c {
        public static final n INSTANCE = new n();

        public n() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$o */
    public static final class o extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ int $$default;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ X $visibleState;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public o(X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, int i2, int i3) {
            super(2);
            this.$visibleState = x2;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
            this.$content = fVar;
            this.$$changed = i2;
            this.$$default = i3;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibility(this.$visibleState, this.$modifier, this.$enter, this.$exit, this.$label, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1), this.$$default);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$p */
    public static final class p extends kotlin.jvm.internal.p implements h1.c {
        public static final p INSTANCE = new p();

        public p() {
            super(1);
        }

        public final Boolean invoke(boolean z2) {
            return Boolean.valueOf(z2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Boolean) obj).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$q */
    public static final class q extends kotlin.jvm.internal.p implements h1.f {
        final /* synthetic */ v0 $transition;
        final /* synthetic */ h1.c $visible;

        /* JADX INFO: renamed from: androidx.compose.animation.i$q$a */
        public static final class a extends kotlin.jvm.internal.p implements h1.c {
            final /* synthetic */ AbstractC0974x0 $placeable;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(AbstractC0974x0 abstractC0974x0) {
                super(1);
                this.$placeable = abstractC0974x0;
            }

            @Override // h1.c
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                invoke((AbstractC0974x0.a) obj);
                return U0.n.f1521a;
            }

            public final void invoke(AbstractC0974x0.a aVar) {
                AbstractC0974x0.a.place$default(aVar, this.$placeable, 0, 0, 0.0f, 4, null);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public q(h1.c cVar, v0 v0Var) {
            super(3);
            this.$visible = cVar;
            this.$transition = v0Var;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return m659invoke3p2s80s((InterfaceC0937e0) obj, (InterfaceC0931b0) obj2, ((C1305b) obj3).m5047unboximpl());
        }

        /* JADX INFO: renamed from: invoke-3p2s80s, reason: not valid java name */
        public final InterfaceC0935d0 m659invoke3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
            long jM5234constructorimpl;
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
            if (!interfaceC0937e0.isLookingAhead() || ((Boolean) this.$visible.invoke(this.$transition.getTargetState())).booleanValue()) {
                jM5234constructorimpl = e0.s.m5234constructorimpl((((long) abstractC0974x0Mo3865measureBRTryo0.getWidth()) << 32) | (((long) abstractC0974x0Mo3865measureBRTryo0.getHeight()) & 4294967295L));
            } else {
                jM5234constructorimpl = e0.s.Companion.m5244getZeroYbymL2g();
            }
            return InterfaceC0937e0.layout$default(interfaceC0937e0, (int) (jM5234constructorimpl >> 32), (int) (jM5234constructorimpl & 4294967295L), null, new a(abstractC0974x0Mo3865measureBRTryo0), 4, null);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$r */
    public static final class r extends kotlin.jvm.internal.p implements h1.e {
        public static final r INSTANCE = new r();

        public r() {
            super(2);
        }

        @Override // h1.e
        public final Boolean invoke(EnumC0356q enumC0356q, EnumC0356q enumC0356q2) {
            return Boolean.valueOf(enumC0356q == enumC0356q2 && enumC0356q2 == EnumC0356q.PostExit);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.i$s */
    public static final class s extends kotlin.jvm.internal.p implements h1.e {
        final /* synthetic */ int $$changed;
        final /* synthetic */ h1.f $content;
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ androidx.compose.ui.x $modifier;
        final /* synthetic */ v0 $transition;
        final /* synthetic */ h1.c $visible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public s(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.f fVar, int i2) {
            super(2);
            this.$transition = v0Var;
            this.$visible = cVar;
            this.$modifier = xVar;
            this.$enter = a2;
            this.$exit = c2;
            this.$content = fVar;
            this.$$changed = i2;
        }

        @Override // h1.e
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((InterfaceC0768p) obj, ((Number) obj2).intValue());
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0768p interfaceC0768p, int i2) {
            AbstractC0348i.AnimatedVisibilityImpl(this.$transition, this.$visible, this.$modifier, this.$enter, this.$exit, this.$content, interfaceC0768p, AbstractC0743g1.updateChangedFlags(this.$$changed | 1));
        }
    }

    public static final <T> void AnimatedEnterExitImpl(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.e eVar, J j2, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        InterfaceC0768p interfaceC0768p2;
        J j3;
        int i5;
        int i6;
        androidx.compose.ui.x xVarLayout;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1912839215);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(v0Var) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 32 : 16;
        }
        if ((i3 & 4) != 0) {
            i4 |= 384;
        } else if ((i2 & 384) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(xVar) ? 256 : 128;
        }
        if ((i3 & 8) != 0) {
            i4 |= 3072;
        } else if ((i2 & 3072) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(a2) ? 2048 : 1024;
        }
        if ((i3 & 16) != 0) {
            i4 |= 24576;
        } else if ((i2 & 24576) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changed(c2) ? 16384 : 8192;
        }
        if ((i3 & 32) != 0) {
            i4 |= 196608;
        } else if ((i2 & 196608) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(eVar) ? 131072 : 65536;
        }
        int i7 = i3 & 64;
        int i8 = 1572864;
        if (i7 != 0) {
            i4 |= i8;
        } else if ((i2 & 1572864) == 0) {
            i8 = (i2 & 2097152) == 0 ? interfaceC0768pStartRestartGroup.changed(j2) : interfaceC0768pStartRestartGroup.changedInstance(j2) ? 1048576 : 524288;
            i4 |= i8;
        }
        if ((i3 & 128) != 0) {
            i4 |= 12582912;
        } else if ((i2 & 12582912) == 0) {
            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 8388608 : 4194304;
        }
        int i9 = i4;
        int i10 = 1;
        if (interfaceC0768pStartRestartGroup.shouldExecute((4793491 & i9) != 4793490, i9 & 1)) {
            J j4 = i7 != 0 ? null : j2;
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1912839215, i9, -1, "androidx.compose.animation.AnimatedEnterExitImpl (AnimatedVisibility.kt:715)");
            }
            if (((Boolean) cVar.invoke(v0Var.getTargetState())).booleanValue() || ((Boolean) cVar.invoke(v0Var.getCurrentState())).booleanValue() || v0Var.isSeeking() || v0Var.getHasInitialValueAnimations()) {
                interfaceC0768pStartRestartGroup.startReplaceGroup(-232323267);
                int i11 = i9 & 14;
                int i12 = i11 | 48;
                int i13 = i12 & 14;
                J j5 = j4;
                boolean z2 = ((i13 ^ 6) > 4 && interfaceC0768pStartRestartGroup.changed(v0Var)) || (i12 & 6) == 4;
                Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue = v0Var.getCurrentState();
                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                if (v0Var.isSeeking()) {
                    objRememberedValue = v0Var.getCurrentState();
                }
                interfaceC0768pStartRestartGroup.startReplaceGroup(1844425648);
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventStart(1844425648, 0, -1, "androidx.compose.animation.AnimatedEnterExitImpl.<anonymous> (AnimatedVisibility.kt:724)");
                }
                int i14 = i9 & 126;
                EnumC0356q enumC0356qTargetEnterExit = targetEnterExit(v0Var, cVar, objRememberedValue, interfaceC0768pStartRestartGroup, i14);
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventEnd();
                }
                interfaceC0768pStartRestartGroup.endReplaceGroup();
                Object targetState = v0Var.getTargetState();
                interfaceC0768pStartRestartGroup.startReplaceGroup(1844425648);
                if (AbstractC0776s.isTraceInProgress()) {
                    i5 = i9;
                    i6 = 0;
                    AbstractC0776s.traceEventStart(1844425648, 0, -1, "androidx.compose.animation.AnimatedEnterExitImpl.<anonymous> (AnimatedVisibility.kt:724)");
                } else {
                    i5 = i9;
                    i6 = 0;
                }
                EnumC0356q enumC0356qTargetEnterExit2 = targetEnterExit(v0Var, cVar, targetState, interfaceC0768pStartRestartGroup, i14);
                if (AbstractC0776s.isTraceInProgress()) {
                    AbstractC0776s.traceEventEnd();
                }
                interfaceC0768pStartRestartGroup.endReplaceGroup();
                int i15 = i6;
                j3 = j5;
                int i16 = i5;
                v0 v0VarCreateChildTransitionInternal = y0.createChildTransitionInternal(v0Var, enumC0356qTargetEnterExit, enumC0356qTargetEnterExit2, "EnterExitTransition", interfaceC0768pStartRestartGroup, i13 | 3072);
                d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(eVar, interfaceC0768pStartRestartGroup, (i16 >> 15) & 14);
                Object objInvoke = eVar.invoke(v0VarCreateChildTransitionInternal.getCurrentState(), v0VarCreateChildTransitionInternal.getTargetState());
                boolean zChanged = interfaceC0768pStartRestartGroup.changed(v0VarCreateChildTransitionInternal) | interfaceC0768pStartRestartGroup.changed(d2VarRememberUpdatedState);
                Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
                if (zChanged || objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                    objRememberedValue2 = new c(v0VarCreateChildTransitionInternal, d2VarRememberUpdatedState, null);
                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                d2 d2VarProduceState = Q1.produceState(objInvoke, (h1.e) objRememberedValue2, interfaceC0768pStartRestartGroup, i15);
                if (getExitFinished(v0VarCreateChildTransitionInternal) && AnimatedEnterExitImpl$lambda$11(d2VarProduceState)) {
                    interfaceC0768pStartRestartGroup.startReplaceGroup(-230155437);
                    interfaceC0768pStartRestartGroup.endReplaceGroup();
                    interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                } else {
                    interfaceC0768pStartRestartGroup.startReplaceGroup(-231293261);
                    int i17 = i11 == 4 ? 1 : i15;
                    Object objRememberedValue3 = interfaceC0768pStartRestartGroup.rememberedValue();
                    if (i17 != 0 || objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue3 = new C0350k(v0VarCreateChildTransitionInternal);
                        interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue3);
                    }
                    C0350k c0350k = (C0350k) objRememberedValue3;
                    int i18 = i16 >> 6;
                    int i19 = (i18 & 112) | 24576 | (i18 & 896);
                    interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                    androidx.compose.ui.x xVarCreateModifier = AbstractC0359u.createModifier(v0VarCreateChildTransitionInternal, a2, c2, null, "Built-in", interfaceC0768p2, i19, 4);
                    if (j3 != null) {
                        interfaceC0768p2.startReplaceGroup(-230873924);
                        androidx.compose.ui.u uVar = androidx.compose.ui.x.Companion;
                        if ((i16 & 3670016) != 1048576 && ((i16 & 2097152) == 0 || !interfaceC0768p2.changedInstance(j3))) {
                            i10 = i15;
                        }
                        Object objRememberedValue4 = interfaceC0768p2.rememberedValue();
                        if (i10 != 0 || objRememberedValue4 == InterfaceC0768p.Companion.getEmpty()) {
                            objRememberedValue4 = new a(j3);
                            interfaceC0768p2.updateRememberedValue(objRememberedValue4);
                        }
                        xVarLayout = androidx.compose.ui.layout.S.layout(uVar, (h1.f) objRememberedValue4);
                        interfaceC0768p2.endReplaceGroup();
                    } else {
                        interfaceC0768p2.startReplaceGroup(-7429769);
                        interfaceC0768p2.endReplaceGroup();
                        xVarLayout = androidx.compose.ui.x.Companion;
                    }
                    androidx.compose.ui.x xVarThen = xVar.then(xVarCreateModifier.then(xVarLayout));
                    Object objRememberedValue5 = interfaceC0768p2.rememberedValue();
                    if (objRememberedValue5 == InterfaceC0768p.Companion.getEmpty()) {
                        objRememberedValue5 = new C0347h(c0350k);
                        interfaceC0768p2.updateRememberedValue(objRememberedValue5);
                    }
                    C0347h c0347h = (C0347h) objRememberedValue5;
                    int iHashCode = Long.hashCode(AbstractC0750j.getCurrentCompositeKeyHashCode(interfaceC0768p2, i15));
                    androidx.compose.runtime.F currentCompositionLocalMap = interfaceC0768p2.getCurrentCompositionLocalMap();
                    androidx.compose.ui.x xVarMaterializeModifier = androidx.compose.ui.n.materializeModifier(interfaceC0768p2, xVarThen);
                    C0997j c0997j = InterfaceC0999k.Companion;
                    h1.a constructor = c0997j.getConstructor();
                    if (interfaceC0768p2.getApplier() == null) {
                        AbstractC0750j.invalidApplier();
                    }
                    interfaceC0768p2.startReusableNode();
                    if (interfaceC0768p2.getInserting()) {
                        interfaceC0768p2.createNode(constructor);
                    } else {
                        interfaceC0768p2.useNode();
                    }
                    InterfaceC0768p interfaceC0768pM2592constructorimpl = h2.m2592constructorimpl(interfaceC0768p2);
                    h2.m2599setimpl(interfaceC0768pM2592constructorimpl, c0347h, c0997j.getSetMeasurePolicy());
                    h2.m2599setimpl(interfaceC0768pM2592constructorimpl, currentCompositionLocalMap, c0997j.getSetResolvedCompositionLocals());
                    h1.e setCompositeKeyHash = c0997j.getSetCompositeKeyHash();
                    if (interfaceC0768pM2592constructorimpl.getInserting() || !kotlin.jvm.internal.o.a(interfaceC0768pM2592constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                        D0.d.z(setCompositeKeyHash, iHashCode, interfaceC0768pM2592constructorimpl, iHashCode);
                    }
                    h2.m2599setimpl(interfaceC0768pM2592constructorimpl, xVarMaterializeModifier, c0997j.getSetModifier());
                    fVar.invoke(c0350k, interfaceC0768p2, Integer.valueOf((i16 >> 18) & 112));
                    interfaceC0768p2.endNode();
                    interfaceC0768p2.endReplaceGroup();
                }
                interfaceC0768p2.endReplaceGroup();
            } else {
                interfaceC0768pStartRestartGroup.startReplaceGroup(-230149485);
                interfaceC0768pStartRestartGroup.endReplaceGroup();
                j3 = j4;
                interfaceC0768p2 = interfaceC0768pStartRestartGroup;
            }
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768p2 = interfaceC0768pStartRestartGroup;
            interfaceC0768p2.skipToGroupEnd();
            j3 = j2;
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768p2.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new b(v0Var, cVar, xVar, a2, c2, eVar, j3, fVar, i2, i3));
        }
    }

    private static final boolean AnimatedEnterExitImpl$lambda$11(d2 d2Var) {
        return ((Boolean) d2Var.getValue()).booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final h1.e AnimatedEnterExitImpl$lambda$9(d2 d2Var) {
        return (h1.e) d2Var.getValue();
    }

    /* JADX WARN: Removed duplicated region for block: B:101:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00bb  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c6  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0176  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1448730565);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(z2) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 32 : 16;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 384;
            } else {
                if ((i2 & 384) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 256 : 128;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 3072;
                } else {
                    if ((i2 & 3072) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 2048 : 1024;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((i2 & 24576) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 16384 : 8192;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 196608;
                        } else if ((i2 & 196608) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 131072 : 65536;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                            xVar3 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.fadeIn$default(null, 0.0f, 3, null).plus(AbstractC0359u.expandIn$default(null, null, false, null, 15, null)) : a3;
                            C cPlus = i6 != 0 ? AbstractC0359u.shrinkOut$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeOut$default(null, 0.0f, 3, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-1448730565, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:130)");
                            }
                            v0 v0VarUpdateTransition = y0.updateTransition(Boolean.valueOf(z2), str4, interfaceC0768pStartRestartGroup, (i4 & 14) | ((i4 >> 9) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = d.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            h1.c cVar = (h1.c) objRememberedValue;
                            int i9 = i4 << 3;
                            int i10 = (i9 & 57344) | (i9 & 896) | 48 | (i9 & 7168) | (i4 & 458752);
                            String str5 = str4;
                            AnimatedVisibilityImpl(v0VarUpdateTransition, cVar, xVar3, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, i10);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            c3 = cPlus;
                            str3 = str5;
                            a4 = aPlus;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new C0019i(z2, xVar3, a4, c3, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 24576;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    public static final <T> void AnimatedVisibilityImpl(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1706321816);
        if ((i2 & 6) == 0) {
            i3 = (interfaceC0768pStartRestartGroup.changed(v0Var) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(xVar) ? 256 : 128;
        }
        if ((i2 & 3072) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(a2) ? 2048 : 1024;
        }
        if ((i2 & 24576) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(c2) ? 16384 : 8192;
        }
        if ((i2 & 196608) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 131072 : 65536;
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i3) != 74898, i3 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1706321816, i3, -1, "androidx.compose.animation.AnimatedVisibilityImpl (AnimatedVisibility.kt:677)");
            }
            int i4 = i3 & 112;
            int i5 = i3 & 14;
            boolean z2 = (i4 == 32) | (i5 == 4);
            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
            if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = new q(cVar, v0Var);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.ui.x xVarLayout = androidx.compose.ui.layout.S.layout(xVar, (h1.f) objRememberedValue);
            Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
            if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue2 = r.INSTANCE;
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            AnimatedEnterExitImpl(v0Var, cVar, xVarLayout, a2, c2, (h1.e) objRememberedValue2, null, fVar, interfaceC0768pStartRestartGroup, i4 | 196608 | i5 | (i3 & 7168) | (57344 & i3) | ((i3 << 6) & 29360128), 64);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new s(v0Var, cVar, xVar, a2, c2, fVar, i2));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean getExitFinished(v0 v0Var) {
        Object currentState = v0Var.getCurrentState();
        EnumC0356q enumC0356q = EnumC0356q.PostExit;
        return currentState == enumC0356q && v0Var.getTargetState() == enumC0356q;
    }

    private static final <T> EnumC0356q targetEnterExit(v0 v0Var, h1.c cVar, T t2, InterfaceC0768p interfaceC0768p, int i2) {
        EnumC0356q enumC0356q;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(361571134, i2, -1, "androidx.compose.animation.targetEnterExit (AnimatedVisibility.kt:833)");
        }
        interfaceC0768p.startMovableGroup(-422486105, v0Var);
        if (v0Var.isSeeking()) {
            interfaceC0768p.startReplaceGroup(-212146657);
            interfaceC0768p.endReplaceGroup();
            enumC0356q = ((Boolean) cVar.invoke(t2)).booleanValue() ? EnumC0356q.Visible : ((Boolean) cVar.invoke(v0Var.getCurrentState())).booleanValue() ? EnumC0356q.PostExit : EnumC0356q.PreEnter;
        } else {
            interfaceC0768p.startReplaceGroup(-211872524);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = V1.mutableStateOf$default(Boolean.FALSE, null, 2, null);
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            B0 b02 = (B0) objRememberedValue;
            if (((Boolean) cVar.invoke(v0Var.getCurrentState())).booleanValue()) {
                b02.setValue(Boolean.TRUE);
            }
            enumC0356q = ((Boolean) cVar.invoke(t2)).booleanValue() ? EnumC0356q.Visible : ((Boolean) b02.getValue()).booleanValue() ? EnumC0356q.PostExit : EnumC0356q.PreEnter;
            interfaceC0768p.endReplaceGroup();
        }
        interfaceC0768p.endMovableGroup();
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return enumC0356q;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0177  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(u0 u0Var, boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        C cPlus;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(234057107);
        if ((i3 & 1) != 0) {
            i4 = i2 | 48;
        } else if ((i2 & 48) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(z2) ? 32 : 16) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 2048 : 1024;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 24576;
                } else {
                    if ((i2 & 24576) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 16384 : 8192;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((196608 & i2) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 131072 : 65536;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 1572864;
                        } else if ((i2 & 1572864) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 1048576 : 524288;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                            androidx.compose.ui.x xVar4 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.fadeIn$default(null, 0.0f, 3, null).plus(AbstractC0359u.expandHorizontally$default(null, null, false, null, 15, null)) : a3;
                            cPlus = i6 != 0 ? AbstractC0359u.fadeOut$default(null, 0.0f, 3, null).plus(AbstractC0359u.shrinkHorizontally$default(null, null, false, null, 15, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(234057107, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:204)");
                            }
                            int i9 = i4 >> 3;
                            v0 v0VarUpdateTransition = y0.updateTransition(Boolean.valueOf(z2), str4, interfaceC0768pStartRestartGroup, (i9 & 14) | ((i4 >> 12) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = j.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            AnimatedVisibilityImpl(v0VarUpdateTransition, (h1.c) objRememberedValue, xVar4, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, (i4 & 57344) | (i4 & 896) | 48 | (i4 & 7168) | (i9 & 458752));
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            xVar3 = xVar4;
                            a4 = aPlus;
                            str3 = str4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            cPlus = c3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new k(u0Var, z2, xVar3, a4, cPlus, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 196608;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:101:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0177  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(InterfaceC0445x interfaceC0445x, boolean z2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        C cPlus;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1799879339);
        if ((i3 & 1) != 0) {
            i4 = i2 | 48;
        } else if ((i2 & 48) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(z2) ? 32 : 16) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 2048 : 1024;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 24576;
                } else {
                    if ((i2 & 24576) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 16384 : 8192;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((196608 & i2) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 131072 : 65536;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 1572864;
                        } else if ((i2 & 1572864) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 1048576 : 524288;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                            androidx.compose.ui.x xVar4 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.fadeIn$default(null, 0.0f, 3, null).plus(AbstractC0359u.expandVertically$default(null, null, false, null, 15, null)) : a3;
                            cPlus = i6 != 0 ? AbstractC0359u.fadeOut$default(null, 0.0f, 3, null).plus(AbstractC0359u.shrinkVertically$default(null, null, false, null, 15, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(1799879339, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:277)");
                            }
                            int i9 = i4 >> 3;
                            v0 v0VarUpdateTransition = y0.updateTransition(Boolean.valueOf(z2), str4, interfaceC0768pStartRestartGroup, (i9 & 14) | ((i4 >> 12) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = l.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            AnimatedVisibilityImpl(v0VarUpdateTransition, (h1.c) objRememberedValue, xVar4, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, (i4 & 57344) | (i4 & 896) | 48 | (i4 & 7168) | (i9 & 458752));
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            xVar3 = xVar4;
                            a4 = aPlus;
                            str3 = str4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            cPlus = c3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new m(interfaceC0445x, z2, xVar3, a4, cPlus, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 196608;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0179  */
    /* JADX WARN: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c1  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x016d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(657024243);
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = ((i2 & 8) == 0 ? interfaceC0768pStartRestartGroup.changed(x2) : interfaceC0768pStartRestartGroup.changedInstance(x2) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 32 : 16;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 384;
            } else {
                if ((i2 & 384) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 256 : 128;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 3072;
                } else {
                    if ((i2 & 3072) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 2048 : 1024;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((i2 & 24576) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 16384 : 8192;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 196608;
                        } else if ((i2 & 196608) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 131072 : 65536;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                            xVar3 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.fadeIn$default(null, 0.0f, 3, null).plus(AbstractC0359u.expandIn$default(null, null, false, null, 15, null)) : a3;
                            C cPlus = i6 != 0 ? AbstractC0359u.fadeOut$default(null, 0.0f, 3, null).plus(AbstractC0359u.shrinkOut$default(null, null, false, null, 15, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(657024243, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:376)");
                            }
                            v0 v0VarRememberTransition = y0.rememberTransition(x2, str4, interfaceC0768pStartRestartGroup, X.$stable | (i4 & 14) | ((i4 >> 9) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = n.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            h1.c cVar = (h1.c) objRememberedValue;
                            int i9 = i4 << 3;
                            int i10 = (i9 & 57344) | (i9 & 896) | 48 | (i9 & 7168) | (i4 & 458752);
                            String str5 = str4;
                            AnimatedVisibilityImpl(v0VarRememberTransition, cVar, xVar3, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, i10);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            c3 = cPlus;
                            str3 = str5;
                            a4 = aPlus;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new o(x2, xVar3, a4, c3, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 24576;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00c1  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x016d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(u0 u0Var, X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        C cPlus;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(1763490971);
        if ((i3 & 1) != 0) {
            i4 = i2 | 48;
        } else if ((i2 & 48) == 0) {
            i4 = ((i2 & 64) == 0 ? interfaceC0768pStartRestartGroup.changed(x2) : interfaceC0768pStartRestartGroup.changedInstance(x2) ? 32 : 16) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 2048 : 1024;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 24576;
                } else {
                    if ((i2 & 24576) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 16384 : 8192;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((196608 & i2) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 131072 : 65536;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 1572864;
                        } else if ((i2 & 1572864) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 1048576 : 524288;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                            androidx.compose.ui.x xVar4 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.expandHorizontally$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeIn$default(null, 0.0f, 3, null)) : a3;
                            cPlus = i6 != 0 ? AbstractC0359u.shrinkHorizontally$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeOut$default(null, 0.0f, 3, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(1763490971, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:448)");
                            }
                            int i9 = i4 >> 3;
                            v0 v0VarRememberTransition = y0.rememberTransition(x2, str4, interfaceC0768pStartRestartGroup, X.$stable | (i9 & 14) | ((i4 >> 12) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = p.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            AnimatedVisibilityImpl(v0VarRememberTransition, (h1.c) objRememberedValue, xVar4, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, (i4 & 57344) | (i4 & 896) | 48 | (i4 & 7168) | (i9 & 458752));
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            xVar3 = xVar4;
                            a4 = aPlus;
                            str3 = str4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            cPlus = c3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new e(u0Var, x2, xVar3, a4, cPlus, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 196608;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00c1  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x016d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AnimatedVisibility(InterfaceC0445x interfaceC0445x, X x2, androidx.compose.ui.x xVar, A a2, C c2, String str, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        androidx.compose.ui.x xVar2;
        int i5;
        A a3;
        int i6;
        C c3;
        int i7;
        String str2;
        androidx.compose.ui.x xVar3;
        A a4;
        C cPlus;
        String str3;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1238803325);
        if ((i3 & 1) != 0) {
            i4 = i2 | 48;
        } else if ((i2 & 48) == 0) {
            i4 = ((i2 & 64) == 0 ? interfaceC0768pStartRestartGroup.changed(x2) : interfaceC0768pStartRestartGroup.changedInstance(x2) ? 32 : 16) | i2;
        } else {
            i4 = i2;
        }
        int i8 = i3 & 2;
        if (i8 != 0) {
            i4 |= 384;
        } else {
            if ((i2 & 384) == 0) {
                xVar2 = xVar;
                i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
            }
            i5 = i3 & 4;
            if (i5 == 0) {
                i4 |= 3072;
            } else {
                if ((i2 & 3072) == 0) {
                    a3 = a2;
                    i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 2048 : 1024;
                }
                i6 = i3 & 8;
                if (i6 != 0) {
                    i4 |= 24576;
                } else {
                    if ((i2 & 24576) == 0) {
                        c3 = c2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 16384 : 8192;
                    }
                    i7 = i3 & 16;
                    if (i7 != 0) {
                        if ((196608 & i2) == 0) {
                            str2 = str;
                            i4 |= interfaceC0768pStartRestartGroup.changed(str2) ? 131072 : 65536;
                        }
                        if ((i3 & 32) != 0) {
                            i4 |= 1572864;
                        } else if ((i2 & 1572864) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 1048576 : 524288;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                            androidx.compose.ui.x xVar4 = i8 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i5 != 0 ? AbstractC0359u.expandVertically$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeIn$default(null, 0.0f, 3, null)) : a3;
                            cPlus = i6 != 0 ? AbstractC0359u.shrinkVertically$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeOut$default(null, 0.0f, 3, null)) : c3;
                            String str4 = i7 != 0 ? "AnimatedVisibility" : str2;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-1238803325, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:522)");
                            }
                            int i9 = i4 >> 3;
                            v0 v0VarRememberTransition = y0.rememberTransition(x2, str4, interfaceC0768pStartRestartGroup, X.$stable | (i9 & 14) | ((i4 >> 12) & 112), 0);
                            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
                            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                                objRememberedValue = f.INSTANCE;
                                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
                            }
                            AnimatedVisibilityImpl(v0VarRememberTransition, (h1.c) objRememberedValue, xVar4, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, (i4 & 57344) | (i4 & 896) | 48 | (i4 & 7168) | (i9 & 458752));
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            xVar3 = xVar4;
                            a4 = aPlus;
                            str3 = str4;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            a4 = a3;
                            cPlus = c3;
                            str3 = str2;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new g(interfaceC0445x, x2, xVar3, a4, cPlus, str3, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 196608;
                    str2 = str;
                    if ((i3 & 32) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                c3 = c2;
                i7 = i3 & 16;
                if (i7 != 0) {
                }
                str2 = str;
                if ((i3 & 32) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            a3 = a2;
            i6 = i3 & 8;
            if (i6 != 0) {
            }
            c3 = c2;
            i7 = i3 & 16;
            if (i7 != 0) {
            }
            str2 = str;
            if ((i3 & 32) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        xVar2 = xVar;
        i5 = i3 & 4;
        if (i5 == 0) {
        }
        a3 = a2;
        i6 = i3 & 8;
        if (i6 != 0) {
        }
        c3 = c2;
        i7 = i3 & 16;
        if (i7 != 0) {
        }
        str2 = str;
        if ((i3 & 32) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((599185 & i4) != 599184, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00c7  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:95:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final <T> void AnimatedVisibility(v0 v0Var, h1.c cVar, androidx.compose.ui.x xVar, A a2, C c2, h1.f fVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        int i4;
        int i5;
        androidx.compose.ui.x xVar2;
        int i6;
        A a3;
        int i7;
        C c3;
        androidx.compose.ui.x xVar3;
        C c4;
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-1699747442);
        if ((i3 & Integer.MIN_VALUE) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (interfaceC0768pStartRestartGroup.changed(v0Var) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 1) != 0) {
            i4 |= 48;
        } else {
            if ((i2 & 48) == 0) {
                i4 |= interfaceC0768pStartRestartGroup.changedInstance(cVar) ? 32 : 16;
            }
            i5 = i3 & 2;
            if (i5 == 0) {
                i4 |= 384;
            } else {
                if ((i2 & 384) == 0) {
                    xVar2 = xVar;
                    i4 |= interfaceC0768pStartRestartGroup.changed(xVar2) ? 256 : 128;
                }
                i6 = i3 & 4;
                if (i6 != 0) {
                    i4 |= 3072;
                } else {
                    if ((i2 & 3072) == 0) {
                        a3 = a2;
                        i4 |= interfaceC0768pStartRestartGroup.changed(a3) ? 2048 : 1024;
                    }
                    i7 = i3 & 8;
                    if (i7 != 0) {
                        if ((i2 & 24576) == 0) {
                            c3 = c2;
                            i4 |= interfaceC0768pStartRestartGroup.changed(c3) ? 16384 : 8192;
                        }
                        if ((i3 & 16) != 0) {
                            i4 |= 196608;
                        } else if ((i2 & 196608) == 0) {
                            i4 |= interfaceC0768pStartRestartGroup.changedInstance(fVar) ? 131072 : 65536;
                        }
                        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                            androidx.compose.ui.x xVar4 = i5 != 0 ? androidx.compose.ui.x.Companion : xVar2;
                            A aPlus = i6 != 0 ? AbstractC0359u.fadeIn$default(null, 0.0f, 3, null).plus(AbstractC0359u.expandIn$default(null, null, false, null, 15, null)) : a3;
                            C cPlus = i7 != 0 ? AbstractC0359u.shrinkOut$default(null, null, false, null, 15, null).plus(AbstractC0359u.fadeOut$default(null, 0.0f, 3, null)) : c3;
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventStart(-1699747442, i4, -1, "androidx.compose.animation.AnimatedVisibility (AnimatedVisibility.kt:593)");
                            }
                            AnimatedVisibilityImpl(v0Var, cVar, xVar4, aPlus, cPlus, fVar, interfaceC0768pStartRestartGroup, 524286 & i4);
                            if (AbstractC0776s.isTraceInProgress()) {
                                AbstractC0776s.traceEventEnd();
                            }
                            xVar3 = xVar4;
                            c4 = cPlus;
                            a3 = aPlus;
                        } else {
                            interfaceC0768pStartRestartGroup.skipToGroupEnd();
                            xVar3 = xVar2;
                            c4 = c3;
                        }
                        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                        if (interfaceC0811x1EndRestartGroup != null) {
                            interfaceC0811x1EndRestartGroup.updateScope(new h(v0Var, cVar, xVar3, a3, c4, fVar, i2, i3));
                            return;
                        }
                        return;
                    }
                    i4 |= 24576;
                    c3 = c2;
                    if ((i3 & 16) != 0) {
                    }
                    if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                    }
                    interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                    if (interfaceC0811x1EndRestartGroup != null) {
                    }
                }
                a3 = a2;
                i7 = i3 & 8;
                if (i7 != 0) {
                }
                c3 = c2;
                if ((i3 & 16) != 0) {
                }
                if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
                }
                interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
                if (interfaceC0811x1EndRestartGroup != null) {
                }
            }
            xVar2 = xVar;
            i6 = i3 & 4;
            if (i6 != 0) {
            }
            a3 = a2;
            i7 = i3 & 8;
            if (i7 != 0) {
            }
            c3 = c2;
            if ((i3 & 16) != 0) {
            }
            if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
            }
            interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
            if (interfaceC0811x1EndRestartGroup != null) {
            }
        }
        i5 = i3 & 2;
        if (i5 == 0) {
        }
        xVar2 = xVar;
        i6 = i3 & 4;
        if (i6 != 0) {
        }
        a3 = a2;
        i7 = i3 & 8;
        if (i7 != 0) {
        }
        c3 = c2;
        if ((i3 & 16) != 0) {
        }
        if (interfaceC0768pStartRestartGroup.shouldExecute((74899 & i4) != 74898, i4 & 1)) {
        }
        interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
        }
    }
}
