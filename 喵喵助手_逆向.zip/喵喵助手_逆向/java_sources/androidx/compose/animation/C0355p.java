package androidx.compose.animation;

import androidx.compose.runtime.InterfaceC0813y0;
import androidx.compose.runtime.W0;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0355p {
    public static final int $stable = 8;
    private final C initialContentExit;
    private N sizeTransform;
    private final A targetContentEnter;
    private final InterfaceC0813y0 targetContentZIndex$delegate;

    public C0355p(A a2, C c2, float f2, N n2) {
        this.targetContentEnter = a2;
        this.initialContentExit = c2;
        this.targetContentZIndex$delegate = W0.mutableFloatStateOf(f2);
        this.sizeTransform = n2;
    }

    public final C getInitialContentExit() {
        return this.initialContentExit;
    }

    public final N getSizeTransform() {
        return this.sizeTransform;
    }

    public final A getTargetContentEnter() {
        return this.targetContentEnter;
    }

    public final float getTargetContentZIndex() {
        return this.targetContentZIndex$delegate.getFloatValue();
    }

    public final void setSizeTransform$animation(N n2) {
        this.sizeTransform = n2;
    }

    public final void setTargetContentZIndex(float f2) {
        this.targetContentZIndex$delegate.setFloatValue(f2);
    }

    public /* synthetic */ C0355p(A a2, C c2, float f2, N n2, int i2, AbstractC1378g abstractC1378g) {
        this(a2, c2, (i2 & 4) != 0 ? 0.0f : f2, (i2 & 8) != 0 ? AbstractC0295b.SizeTransform$default(false, null, 3, null) : n2);
    }
}
