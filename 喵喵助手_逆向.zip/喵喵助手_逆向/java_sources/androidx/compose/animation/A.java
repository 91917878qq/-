package androidx.compose.animation;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {
    public static final int $stable = 0;
    public static final a Companion = new a(null);
    private static final A None = new B(new U(null, null, null, null, false, null, 63, null));

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final A getNone() {
            return A.None;
        }

        private a() {
        }
    }

    public /* synthetic */ A(AbstractC1378g abstractC1378g) {
        this();
    }

    public boolean equals(Object obj) {
        return (obj instanceof A) && kotlin.jvm.internal.o.a(((A) obj).getData$animation(), getData$animation());
    }

    public abstract U getData$animation();

    public int hashCode() {
        return getData$animation().hashCode();
    }

    public final A plus(A a2) {
        E fade = a2.getData$animation().getFade();
        if (fade == null) {
            fade = getData$animation().getFade();
        }
        E e2 = fade;
        P slide = a2.getData$animation().getSlide();
        if (slide == null) {
            slide = getData$animation().getSlide();
        }
        P p2 = slide;
        C0352m changeSize = a2.getData$animation().getChangeSize();
        if (changeSize == null) {
            changeSize = getData$animation().getChangeSize();
        }
        C0352m c0352m = changeSize;
        K scale = a2.getData$animation().getScale();
        if (scale == null) {
            scale = getData$animation().getScale();
        }
        K k2 = scale;
        Map<W, V> effectsMap = getData$animation().getEffectsMap();
        Map<W, V> map = a2.getData$animation().getEffectsMap();
        kotlin.jvm.internal.o.e(effectsMap, "<this>");
        kotlin.jvm.internal.o.e(map, "map");
        LinkedHashMap linkedHashMap = new LinkedHashMap(effectsMap);
        linkedHashMap.putAll(map);
        return new B(new U(e2, p2, c0352m, k2, false, linkedHashMap, 16, null));
    }

    public String toString() {
        if (equals(None)) {
            return "EnterTransition.None";
        }
        U data$animation = getData$animation();
        StringBuilder sb = new StringBuilder("EnterTransition: \nFade - ");
        E fade = data$animation.getFade();
        sb.append(fade != null ? fade.toString() : null);
        sb.append(",\nSlide - ");
        P slide = data$animation.getSlide();
        sb.append(slide != null ? slide.toString() : null);
        sb.append(",\nShrink - ");
        C0352m changeSize = data$animation.getChangeSize();
        sb.append(changeSize != null ? changeSize.toString() : null);
        sb.append(",\nScale - ");
        K scale = data$animation.getScale();
        sb.append(scale != null ? scale.toString() : null);
        return sb.toString();
    }

    private A() {
    }
}
