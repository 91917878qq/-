package androidx.compose.animation;

import androidx.compose.animation.core.C0323n;
import androidx.compose.ui.graphics.s1;

/* JADX INFO: renamed from: androidx.compose.animation.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0357s extends kotlin.jvm.internal.p implements h1.c {
    public static final C0357s INSTANCE = new C0357s();

    public C0357s() {
        super(1);
    }

    @Override // h1.c
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        return m664invoke__ExYCQ(((s1) obj).m3514unboximpl());
    }

    /* JADX INFO: renamed from: invoke-__ExYCQ, reason: not valid java name */
    public final C0323n m664invoke__ExYCQ(long j2) {
        return new C0323n(s1.m3510getPivotFractionXimpl(j2), s1.m3511getPivotFractionYimpl(j2));
    }
}
