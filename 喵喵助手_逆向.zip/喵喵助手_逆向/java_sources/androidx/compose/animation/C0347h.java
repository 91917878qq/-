package androidx.compose.animation;

import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0933c0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: androidx.compose.animation.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0347h implements InterfaceC0933c0 {
    private boolean hasLookaheadOccurred;
    private final C0350k scope;

    /* JADX INFO: renamed from: androidx.compose.animation.h$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ List<AbstractC0974x0> $placeables;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(List<? extends AbstractC0974x0> list) {
            super(1);
            this.$placeables = list;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            List<AbstractC0974x0> list = this.$placeables;
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                AbstractC0974x0.a.place$default(aVar, list.get(i2), 0, 0, 0.0f, 4, null);
            }
        }
    }

    public C0347h(C0350k c0350k) {
        this.scope = c0350k;
    }

    public final boolean getHasLookaheadOccurred() {
        return this.hasLookaheadOccurred;
    }

    public final C0350k getScope() {
        return this.scope;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMaxIntrinsicHeight = list.get(0).maxIntrinsicHeight(i2);
        int iE = j1.a.E(list);
        int i3 = 1;
        if (1 <= iE) {
            while (true) {
                int iMaxIntrinsicHeight2 = list.get(i3).maxIntrinsicHeight(i2);
                if (iMaxIntrinsicHeight2 > iMaxIntrinsicHeight) {
                    iMaxIntrinsicHeight = iMaxIntrinsicHeight2;
                }
                if (i3 == iE) {
                    break;
                }
                i3++;
            }
        }
        return iMaxIntrinsicHeight;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int maxIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMaxIntrinsicWidth = list.get(0).maxIntrinsicWidth(i2);
        int iE = j1.a.E(list);
        int i3 = 1;
        if (1 <= iE) {
            while (true) {
                int iMaxIntrinsicWidth2 = list.get(i3).maxIntrinsicWidth(i2);
                if (iMaxIntrinsicWidth2 > iMaxIntrinsicWidth) {
                    iMaxIntrinsicWidth = iMaxIntrinsicWidth2;
                }
                if (i3 == iE) {
                    break;
                }
                i3++;
            }
        }
        return iMaxIntrinsicWidth;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo579measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, List<? extends InterfaceC0931b0> list, long j2) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int iMax = 0;
        int iMax2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0 = list.get(i2).mo3865measureBRTryo0(j2);
            iMax = Math.max(iMax, abstractC0974x0Mo3865measureBRTryo0.getWidth());
            iMax2 = Math.max(iMax2, abstractC0974x0Mo3865measureBRTryo0.getHeight());
            arrayList.add(abstractC0974x0Mo3865measureBRTryo0);
        }
        if (interfaceC0937e0.isLookingAhead()) {
            this.hasLookaheadOccurred = true;
            this.scope.getTargetSize$animation().setValue(e0.s.m5231boximpl(e0.s.m5234constructorimpl((4294967295L & ((long) iMax2)) | (((long) iMax) << 32))));
        } else if (!this.hasLookaheadOccurred) {
            this.scope.getTargetSize$animation().setValue(e0.s.m5231boximpl(e0.s.m5234constructorimpl((4294967295L & ((long) iMax2)) | (((long) iMax) << 32))));
        }
        return InterfaceC0937e0.layout$default(interfaceC0937e0, iMax, iMax2, null, new a(arrayList), 4, null);
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicHeight(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMinIntrinsicHeight = list.get(0).minIntrinsicHeight(i2);
        int iE = j1.a.E(list);
        int i3 = 1;
        if (1 <= iE) {
            while (true) {
                int iMinIntrinsicHeight2 = list.get(i3).minIntrinsicHeight(i2);
                if (iMinIntrinsicHeight2 > iMinIntrinsicHeight) {
                    iMinIntrinsicHeight = iMinIntrinsicHeight2;
                }
                if (i3 == iE) {
                    break;
                }
                i3++;
            }
        }
        return iMinIntrinsicHeight;
    }

    @Override // androidx.compose.ui.layout.InterfaceC0933c0
    public int minIntrinsicWidth(androidx.compose.ui.layout.F f2, List<? extends androidx.compose.ui.layout.E> list, int i2) {
        if (list.isEmpty()) {
            return 0;
        }
        int iMinIntrinsicWidth = list.get(0).minIntrinsicWidth(i2);
        int iE = j1.a.E(list);
        int i3 = 1;
        if (1 <= iE) {
            while (true) {
                int iMinIntrinsicWidth2 = list.get(i3).minIntrinsicWidth(i2);
                if (iMinIntrinsicWidth2 > iMinIntrinsicWidth) {
                    iMinIntrinsicWidth = iMinIntrinsicWidth2;
                }
                if (i3 == iE) {
                    break;
                }
                i3++;
            }
        }
        return iMinIntrinsicWidth;
    }

    public final void setHasLookaheadOccurred(boolean z2) {
        this.hasLookaheadOccurred = z2;
    }
}
