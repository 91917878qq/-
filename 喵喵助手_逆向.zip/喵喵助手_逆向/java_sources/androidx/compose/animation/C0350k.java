package androidx.compose.animation;

import androidx.compose.animation.core.v0;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.V1;

/* JADX INFO: renamed from: androidx.compose.animation.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0350k implements InterfaceC0349j {
    public static final int $stable = 8;
    private final B0 targetSize = V1.mutableStateOf$default(e0.s.m5231boximpl(e0.s.Companion.m5244getZeroYbymL2g()), null, 2, null);
    private v0 transition;

    public C0350k(v0 v0Var) {
        this.transition = v0Var;
    }

    @Override // androidx.compose.animation.InterfaceC0349j
    public /* bridge */ /* synthetic */ androidx.compose.ui.x animateEnterExit(androidx.compose.ui.x xVar, A a2, C c2, String str) {
        return super.animateEnterExit(xVar, a2, c2, str);
    }

    public final B0 getTargetSize$animation() {
        return this.targetSize;
    }

    @Override // androidx.compose.animation.InterfaceC0349j
    public v0 getTransition() {
        return this.transition;
    }

    public void setTransition(v0 v0Var) {
        this.transition = v0Var;
    }
}
