package androidx.compose.animation;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public abstract class C {
    public static final int $stable = 0;
    public static final a Companion = new a(null);
    private static final C KeepUntilTransitionsFinished;
    private static final C None;

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final C getKeepUntilTransitionsFinished$animation() {
            return C.KeepUntilTransitionsFinished;
        }

        public final C getNone() {
            return C.None;
        }

        private a() {
        }
    }

    static {
        AbstractC1378g abstractC1378g = null;
        E e2 = null;
        P p2 = null;
        C0352m c0352m = null;
        K k2 = null;
        Map map = null;
        None = new D(new U(e2, p2, c0352m, k2, false, map, 63, abstractC1378g));
        KeepUntilTransitionsFinished = new D(new U(e2, p2, c0352m, k2, true, map, 47, abstractC1378g));
    }

    public /* synthetic */ C(AbstractC1378g abstractC1378g) {
        this();
    }

    public boolean equals(Object obj) {
        return (obj instanceof C) && kotlin.jvm.internal.o.a(((C) obj).getData$animation(), getData$animation());
    }

    public abstract U getData$animation();

    public int hashCode() {
        return getData$animation().hashCode();
    }

    public final C plus(C c2) {
        E fade = c2.getData$animation().getFade();
        if (fade == null) {
            fade = getData$animation().getFade();
        }
        E e2 = fade;
        P slide = c2.getData$animation().getSlide();
        if (slide == null) {
            slide = getData$animation().getSlide();
        }
        P p2 = slide;
        C0352m changeSize = c2.getData$animation().getChangeSize();
        if (changeSize == null) {
            changeSize = getData$animation().getChangeSize();
        }
        C0352m c0352m = changeSize;
        K scale = c2.getData$animation().getScale();
        if (scale == null) {
            scale = getData$animation().getScale();
        }
        K k2 = scale;
        boolean z2 = c2.getData$animation().getHold() || getData$animation().getHold();
        Map<W, V> effectsMap = getData$animation().getEffectsMap();
        Map<W, V> map = c2.getData$animation().getEffectsMap();
        kotlin.jvm.internal.o.e(effectsMap, "<this>");
        kotlin.jvm.internal.o.e(map, "map");
        LinkedHashMap linkedHashMap = new LinkedHashMap(effectsMap);
        linkedHashMap.putAll(map);
        return new D(new U(e2, p2, c0352m, k2, z2, linkedHashMap));
    }

    public String toString() {
        if (equals(None)) {
            return "ExitTransition.None";
        }
        if (equals(KeepUntilTransitionsFinished)) {
            return "ExitTransition.KeepUntilTransitionsFinished";
        }
        U data$animation = getData$animation();
        StringBuilder sb = new StringBuilder("ExitTransition: \nFade - ");
        E fade = data$animation.getFade();
        sb.append(fade != null ? fade.toString() : null);
        sb.append(",\nSlide - ");
        P slide = data$animation.getSlide();
        sb.append(slide != null ? slide.toString() : null);
        sb.append(",\nShrink - ");
        C0352m changeSize = data$animation.getChangeSize();
        sb.append(changeSize != null ? changeSize.toString() : null);
        sb.append(",\nScale - ");
        K scale = data$animation.getScale();
        sb.append(scale != null ? scale.toString() : null);
        sb.append(",\nKeepUntilTransitionsFinished - ");
        sb.append(data$animation.getHold());
        return sb.toString();
    }

    private C() {
    }
}
