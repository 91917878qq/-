package androidx.compose.animation;

import androidx.compose.animation.core.v0;

/* JADX INFO: renamed from: androidx.compose.animation.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0343d extends InterfaceC0349j {
    @Override // androidx.compose.animation.InterfaceC0349j
    /* bridge */ /* synthetic */ default androidx.compose.ui.x animateEnterExit(androidx.compose.ui.x xVar, A a2, C c2, String str) {
        return super.animateEnterExit(xVar, a2, c2, str);
    }

    @Override // androidx.compose.animation.InterfaceC0349j
    /* synthetic */ v0 getTransition();
}
