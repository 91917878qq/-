package androidx.compose.animation;

import androidx.compose.animation.core.B0;
import androidx.compose.animation.core.C0327p;
import androidx.compose.animation.core.E0;
import androidx.compose.ui.graphics.AbstractC0851a0;
import androidx.compose.ui.graphics.Y;

/* JADX INFO: renamed from: androidx.compose.animation.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0353n extends kotlin.jvm.internal.p implements h1.c {
    public static final C0353n INSTANCE = new C0353n();

    /* JADX INFO: renamed from: androidx.compose.animation.n$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        public static final a INSTANCE = new a();

        public a() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return m662invoke8_81llA(((Y) obj).m3030unboximpl());
        }

        /* JADX INFO: renamed from: invoke-8_81llA, reason: not valid java name */
        public final C0327p m662invoke8_81llA(long j2) {
            long jM3017convertvNxB06k = Y.m3017convertvNxB06k(j2, androidx.compose.ui.graphics.colorspace.f.INSTANCE.getOklab());
            return new C0327p(Y.m3022getAlphaimpl(jM3017convertvNxB06k), Y.m3026getRedimpl(jM3017convertvNxB06k), Y.m3025getGreenimpl(jM3017convertvNxB06k), Y.m3023getBlueimpl(jM3017convertvNxB06k));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.n$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.ui.graphics.colorspace.c $colorSpace;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(androidx.compose.ui.graphics.colorspace.c cVar) {
            super(1);
            this.$colorSpace = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return Y.m3010boximpl(m663invokevNxB06k((C0327p) obj));
        }

        /* JADX INFO: renamed from: invoke-vNxB06k, reason: not valid java name */
        public final long m663invokevNxB06k(C0327p c0327p) {
            float v2 = c0327p.getV2();
            if (v2 < 0.0f) {
                v2 = 0.0f;
            }
            if (v2 > 1.0f) {
                v2 = 1.0f;
            }
            float v3 = c0327p.getV3();
            if (v3 < -0.5f) {
                v3 = -0.5f;
            }
            if (v3 > 0.5f) {
                v3 = 0.5f;
            }
            float v4 = c0327p.getV4();
            float f2 = v4 >= -0.5f ? v4 : -0.5f;
            float f3 = f2 <= 0.5f ? f2 : 0.5f;
            float v12 = c0327p.getV1();
            float f4 = v12 >= 0.0f ? v12 : 0.0f;
            return Y.m3017convertvNxB06k(AbstractC0851a0.Color(v2, v3, f3, f4 <= 1.0f ? f4 : 1.0f, androidx.compose.ui.graphics.colorspace.f.INSTANCE.getOklab()), this.$colorSpace);
        }
    }

    public C0353n() {
        super(1);
    }

    @Override // h1.c
    public final B0 invoke(androidx.compose.ui.graphics.colorspace.c cVar) {
        return E0.TwoWayConverter(a.INSTANCE, new b(cVar));
    }
}
