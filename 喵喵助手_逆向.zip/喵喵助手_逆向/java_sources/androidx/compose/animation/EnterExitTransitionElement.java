package androidx.compose.animation;

import androidx.compose.animation.core.v0;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class EnterExitTransitionElement extends AbstractC1000k0 {
    private A enter;
    private C exit;
    private H graphicsLayerBlock;
    private h1.a isEnabled;
    private androidx.compose.animation.core.v0.a offsetAnimation;
    private androidx.compose.animation.core.v0.a sizeAnimation;
    private androidx.compose.animation.core.v0.a slideAnimation;
    private final v0 transition;

    public EnterExitTransitionElement(v0 v0Var, androidx.compose.animation.core.v0.a aVar, androidx.compose.animation.core.v0.a aVar2, androidx.compose.animation.core.v0.a aVar3, A a2, C c2, h1.a aVar4, H h2) {
        this.transition = v0Var;
        this.sizeAnimation = aVar;
        this.offsetAnimation = aVar2;
        this.slideAnimation = aVar3;
        this.enter = a2;
        this.exit = c2;
        this.isEnabled = aVar4;
        this.graphicsLayerBlock = h2;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    public final v0 component1() {
        return this.transition;
    }

    public final androidx.compose.animation.core.v0.a component2() {
        return this.sizeAnimation;
    }

    public final androidx.compose.animation.core.v0.a component3() {
        return this.offsetAnimation;
    }

    public final androidx.compose.animation.core.v0.a component4() {
        return this.slideAnimation;
    }

    public final A component5() {
        return this.enter;
    }

    public final C component6() {
        return this.exit;
    }

    public final h1.a component7() {
        return this.isEnabled;
    }

    public final H component8() {
        return this.graphicsLayerBlock;
    }

    public final EnterExitTransitionElement copy(v0 v0Var, androidx.compose.animation.core.v0.a aVar, androidx.compose.animation.core.v0.a aVar2, androidx.compose.animation.core.v0.a aVar3, A a2, C c2, h1.a aVar4, H h2) {
        return new EnterExitTransitionElement(v0Var, aVar, aVar2, aVar3, a2, c2, aVar4, h2);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EnterExitTransitionElement)) {
            return false;
        }
        EnterExitTransitionElement enterExitTransitionElement = (EnterExitTransitionElement) obj;
        return kotlin.jvm.internal.o.a(this.transition, enterExitTransitionElement.transition) && kotlin.jvm.internal.o.a(this.sizeAnimation, enterExitTransitionElement.sizeAnimation) && kotlin.jvm.internal.o.a(this.offsetAnimation, enterExitTransitionElement.offsetAnimation) && kotlin.jvm.internal.o.a(this.slideAnimation, enterExitTransitionElement.slideAnimation) && kotlin.jvm.internal.o.a(this.enter, enterExitTransitionElement.enter) && kotlin.jvm.internal.o.a(this.exit, enterExitTransitionElement.exit) && kotlin.jvm.internal.o.a(this.isEnabled, enterExitTransitionElement.isEnabled) && kotlin.jvm.internal.o.a(this.graphicsLayerBlock, enterExitTransitionElement.graphicsLayerBlock);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final A getEnter() {
        return this.enter;
    }

    public final C getExit() {
        return this.exit;
    }

    public final H getGraphicsLayerBlock() {
        return this.graphicsLayerBlock;
    }

    public final androidx.compose.animation.core.v0.a getOffsetAnimation() {
        return this.offsetAnimation;
    }

    public final androidx.compose.animation.core.v0.a getSizeAnimation() {
        return this.sizeAnimation;
    }

    public final androidx.compose.animation.core.v0.a getSlideAnimation() {
        return this.slideAnimation;
    }

    public final v0 getTransition() {
        return this.transition;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        int iHashCode = this.transition.hashCode() * 31;
        androidx.compose.animation.core.v0.a aVar = this.sizeAnimation;
        int iHashCode2 = (iHashCode + (aVar == null ? 0 : aVar.hashCode())) * 31;
        androidx.compose.animation.core.v0.a aVar2 = this.offsetAnimation;
        int iHashCode3 = (iHashCode2 + (aVar2 == null ? 0 : aVar2.hashCode())) * 31;
        androidx.compose.animation.core.v0.a aVar3 = this.slideAnimation;
        return this.graphicsLayerBlock.hashCode() + ((this.isEnabled.hashCode() + ((this.exit.hashCode() + ((this.enter.hashCode() + ((iHashCode3 + (aVar3 != null ? aVar3.hashCode() : 0)) * 31)) * 31)) * 31)) * 31);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("enterExitTransition");
        c1065l1.getProperties().set("transition", this.transition);
        c1065l1.getProperties().set("sizeAnimation", this.sizeAnimation);
        c1065l1.getProperties().set("offsetAnimation", this.offsetAnimation);
        c1065l1.getProperties().set("slideAnimation", this.slideAnimation);
        c1065l1.getProperties().set("enter", this.enter);
        c1065l1.getProperties().set("exit", this.exit);
        c1065l1.getProperties().set("graphicsLayerBlock", this.graphicsLayerBlock);
    }

    public final h1.a isEnabled() {
        return this.isEnabled;
    }

    public final void setEnabled(h1.a aVar) {
        this.isEnabled = aVar;
    }

    public final void setEnter(A a2) {
        this.enter = a2;
    }

    public final void setExit(C c2) {
        this.exit = c2;
    }

    public final void setGraphicsLayerBlock(H h2) {
        this.graphicsLayerBlock = h2;
    }

    public final void setOffsetAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.offsetAnimation = aVar;
    }

    public final void setSizeAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.sizeAnimation = aVar;
    }

    public final void setSlideAnimation(androidx.compose.animation.core.v0.a aVar) {
        this.slideAnimation = aVar;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public String toString() {
        return "EnterExitTransitionElement(transition=" + this.transition + ", sizeAnimation=" + this.sizeAnimation + ", offsetAnimation=" + this.offsetAnimation + ", slideAnimation=" + this.slideAnimation + ", enter=" + this.enter + ", exit=" + this.exit + ", isEnabled=" + this.isEnabled + ", graphicsLayerBlock=" + this.graphicsLayerBlock + ')';
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public z create() {
        return new z(this.transition, this.sizeAnimation, this.offsetAnimation, this.slideAnimation, this.enter, this.exit, this.isEnabled, this.graphicsLayerBlock);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(z zVar) {
        zVar.setTransition(this.transition);
        zVar.setSizeAnimation(this.sizeAnimation);
        zVar.setOffsetAnimation(this.offsetAnimation);
        zVar.setSlideAnimation(this.slideAnimation);
        zVar.setEnter(this.enter);
        zVar.setExit(this.exit);
        zVar.setEnabled(this.isEnabled);
        zVar.setGraphicsLayerBlock(this.graphicsLayerBlock);
    }
}
