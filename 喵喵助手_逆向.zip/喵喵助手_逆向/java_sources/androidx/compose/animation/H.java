package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public interface H {
    h1.c init();
}
