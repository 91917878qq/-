package androidx.compose.animation;

import androidx.compose.animation.C;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.U0;
import androidx.compose.animation.core.w0;
import androidx.compose.ui.InterfaceC0849g;

/* JADX INFO: renamed from: androidx.compose.animation.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0346g extends w0 {

    /* JADX INFO: renamed from: androidx.compose.animation.g$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        public static final a INSTANCE = new a();

        public a() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf(i2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.g$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        public static final b INSTANCE = new b();

        public b() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf(i2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    static /* synthetic */ void getKeepUntilTransitionsFinished$annotations(C.a aVar) {
    }

    /* JADX INFO: renamed from: slideIntoContainer-mOhB8PU$default, reason: not valid java name */
    static /* synthetic */ A m656slideIntoContainermOhB8PU$default(InterfaceC0346g interfaceC0346g, int i2, androidx.compose.animation.core.F f2, h1.c cVar, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: slideIntoContainer-mOhB8PU");
        }
        if ((i3 & 2) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 0.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 3, null);
        }
        if ((i3 & 4) != 0) {
            cVar = a.INSTANCE;
        }
        return interfaceC0346g.mo555slideIntoContainermOhB8PU(i2, f2, cVar);
    }

    /* JADX INFO: renamed from: slideOutOfContainer-mOhB8PU$default, reason: not valid java name */
    static /* synthetic */ C m657slideOutOfContainermOhB8PU$default(InterfaceC0346g interfaceC0346g, int i2, androidx.compose.animation.core.F f2, h1.c cVar, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: slideOutOfContainer-mOhB8PU");
        }
        if ((i3 & 2) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 0.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 3, null);
        }
        if ((i3 & 4) != 0) {
            cVar = b.INSTANCE;
        }
        return interfaceC0346g.mo556slideOutOfContainermOhB8PU(i2, f2, cVar);
    }

    InterfaceC0849g getContentAlignment();

    @Override // androidx.compose.animation.core.w0
    /* synthetic */ Object getInitialState();

    default C getKeepUntilTransitionsFinished(C.a aVar) {
        return aVar.getKeepUntilTransitionsFinished$animation();
    }

    @Override // androidx.compose.animation.core.w0
    /* synthetic */ Object getTargetState();

    @Override // androidx.compose.animation.core.w0
    /* bridge */ /* synthetic */ default boolean isTransitioningTo(Object obj, Object obj2) {
        return super.isTransitioningTo(obj, obj2);
    }

    /* JADX INFO: renamed from: slideIntoContainer-mOhB8PU */
    A mo555slideIntoContainermOhB8PU(int i2, androidx.compose.animation.core.F f2, h1.c cVar);

    /* JADX INFO: renamed from: slideOutOfContainer-mOhB8PU */
    C mo556slideOutOfContainermOhB8PU(int i2, androidx.compose.animation.core.F f2, h1.c cVar);

    C0355p using(C0355p c0355p, N n2);
}
