package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public final class D extends C {
    private final U data;

    public D(U u2) {
        super(null);
        this.data = u2;
    }

    @Override // androidx.compose.animation.C
    public U getData$animation() {
        return this.data;
    }
}
