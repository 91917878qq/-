package androidx.compose.animation;

import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class F {
    public static final int $stable = 0;
    private final InterfaceC1307d density;
    private final float friction;
    private final float magicPhysicalCoefficient;

    public static final class a {
        public static final int $stable = 0;
        private final float distance;
        private final long duration;
        private final float initialVelocity;

        public a(float f2, float f3, long j2) {
            this.initialVelocity = f2;
            this.distance = f3;
            this.duration = j2;
        }

        public static /* synthetic */ a copy$default(a aVar, float f2, float f3, long j2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                f2 = aVar.initialVelocity;
            }
            if ((i2 & 2) != 0) {
                f3 = aVar.distance;
            }
            if ((i2 & 4) != 0) {
                j2 = aVar.duration;
            }
            return aVar.copy(f2, f3, j2);
        }

        public final float component1() {
            return this.initialVelocity;
        }

        public final float component2() {
            return this.distance;
        }

        public final long component3() {
            return this.duration;
        }

        public final a copy(float f2, float f3, long j2) {
            return new a(f2, f3, j2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return Float.compare(this.initialVelocity, aVar.initialVelocity) == 0 && Float.compare(this.distance, aVar.distance) == 0 && this.duration == aVar.duration;
        }

        public final float getDistance() {
            return this.distance;
        }

        public final long getDuration() {
            return this.duration;
        }

        public final float getInitialVelocity() {
            return this.initialVelocity;
        }

        public int hashCode() {
            return Long.hashCode(this.duration) + D0.d.a(this.distance, Float.hashCode(this.initialVelocity) * 31, 31);
        }

        public final float position(long j2) {
            long j3 = this.duration;
            return C0294a.INSTANCE.flingPosition(j3 > 0 ? j2 / j3 : 1.0f).getDistanceCoefficient() * Math.signum(this.initialVelocity) * this.distance;
        }

        public String toString() {
            return "FlingInfo(initialVelocity=" + this.initialVelocity + ", distance=" + this.distance + ", duration=" + this.duration + ')';
        }

        public final float velocity(long j2) {
            long j3 = this.duration;
            return (((Math.signum(this.initialVelocity) * C0294a.INSTANCE.flingPosition(j3 > 0 ? j2 / j3 : 1.0f).getVelocityCoefficient()) * this.distance) / this.duration) * 1000.0f;
        }
    }

    public F(float f2, InterfaceC1307d interfaceC1307d) {
        this.friction = f2;
        this.density = interfaceC1307d;
        this.magicPhysicalCoefficient = computeDeceleration(interfaceC1307d);
    }

    private final float computeDeceleration(InterfaceC1307d interfaceC1307d) {
        return G.computeDeceleration(0.84f, interfaceC1307d.getDensity());
    }

    private final double getSplineDeceleration(float f2) {
        return C0294a.INSTANCE.deceleration(f2, this.friction * this.magicPhysicalCoefficient);
    }

    public final float flingDistance(float f2) {
        double splineDeceleration = getSplineDeceleration(f2);
        double d2 = ((double) G.DecelerationRate) - 1.0d;
        return (float) (Math.exp((((double) G.DecelerationRate) / d2) * splineDeceleration) * ((double) (this.friction * this.magicPhysicalCoefficient)));
    }

    public final long flingDuration(float f2) {
        return (long) (Math.exp(getSplineDeceleration(f2) / (((double) G.DecelerationRate) - 1.0d)) * 1000.0d);
    }

    public final a flingInfo(float f2) {
        double splineDeceleration = getSplineDeceleration(f2);
        double d2 = ((double) G.DecelerationRate) - 1.0d;
        return new a(f2, (float) (Math.exp((((double) G.DecelerationRate) / d2) * splineDeceleration) * ((double) (this.friction * this.magicPhysicalCoefficient))), (long) (Math.exp(splineDeceleration / d2) * 1000.0d));
    }

    public final InterfaceC1307d getDensity() {
        return this.density;
    }
}
