package androidx.compose.animation;

import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.B0;
import androidx.compose.animation.core.C0316j0;
import androidx.compose.animation.core.E0;
import androidx.compose.animation.core.U0;
import androidx.compose.animation.core.v0;
import androidx.compose.animation.core.w0;
import androidx.compose.animation.core.y0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.d2;
import androidx.compose.ui.C0821d;
import androidx.compose.ui.InterfaceC0822e;
import androidx.compose.ui.InterfaceC0823f;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.graphics.AbstractC0884r0;
import androidx.compose.ui.graphics.InterfaceC0886s0;
import androidx.compose.ui.graphics.s1;
import kotlin.jvm.internal.C1379h;

/* JADX INFO: renamed from: androidx.compose.animation.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0359u {
    private static final B0 TransformOriginVectorConverter = E0.TwoWayConverter(C0357s.INSTANCE, C0358t.INSTANCE);
    private static final C0316j0 DefaultAlphaAndScaleSpring = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
    private static final C0316j0 DefaultOffsetAnimationSpec = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
    private static final C0316j0 DefaultSizeAnimationSpec = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);

    /* JADX INFO: renamed from: androidx.compose.animation.u$A */
    public static final class A extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffsetY;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public A(h1.c cVar) {
            super(1);
            this.$targetOffsetY = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m670invokemHKZG7I(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mHKZG7I, reason: not valid java name */
        public final long m670invokemHKZG7I(long j2) {
            return e0.o.m5190constructorimpl((((long) ((Number) this.$targetOffsetY.invoke(Integer.valueOf((int) (j2 & 4294967295L)))).intValue()) & 4294967295L) | (((long) 0) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$a, reason: case insensitive filesystem */
    public static final class C0360a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.animation.A $enter;
        final /* synthetic */ C $exit;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0360a(androidx.compose.animation.A a2, C c2) {
            super(1);
            this.$enter = a2;
            this.$exit = c2;
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            androidx.compose.animation.core.F animationSpec;
            androidx.compose.animation.core.F animationSpec2;
            EnumC0356q enumC0356q = EnumC0356q.PreEnter;
            EnumC0356q enumC0356q2 = EnumC0356q.Visible;
            if (w0Var.isTransitioningTo(enumC0356q, enumC0356q2)) {
                E fade = this.$enter.getData$animation().getFade();
                return (fade == null || (animationSpec2 = fade.getAnimationSpec()) == null) ? AbstractC0359u.DefaultAlphaAndScaleSpring : animationSpec2;
            }
            if (!w0Var.isTransitioningTo(enumC0356q2, EnumC0356q.PostExit)) {
                return AbstractC0359u.DefaultAlphaAndScaleSpring;
            }
            E fade2 = this.$exit.getData$animation().getFade();
            return (fade2 == null || (animationSpec = fade2.getAnimationSpec()) == null) ? AbstractC0359u.DefaultAlphaAndScaleSpring : animationSpec;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.animation.A $enter;
        final /* synthetic */ C $exit;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(androidx.compose.animation.A a2, C c2) {
            super(1);
            this.$enter = a2;
            this.$exit = c2;
        }

        @Override // h1.c
        public final Float invoke(EnumC0356q enumC0356q) {
            int i2 = AbstractC0361v.$EnumSwitchMapping$0[enumC0356q.ordinal()];
            float alpha = 1.0f;
            if (i2 != 1) {
                if (i2 == 2) {
                    E fade = this.$enter.getData$animation().getFade();
                    if (fade != null) {
                        alpha = fade.getAlpha();
                    }
                } else {
                    if (i2 != 3) {
                        throw new H0.c();
                    }
                    E fade2 = this.$exit.getData$animation().getFade();
                    if (fade2 != null) {
                        alpha = fade2.getAlpha();
                    }
                }
            }
            return Float.valueOf(alpha);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$c */
    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ d2 $alpha;
        final /* synthetic */ d2 $scale;
        final /* synthetic */ d2 $transformOrigin;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(d2 d2Var, d2 d2Var2, d2 d2Var3) {
            super(1);
            this.$alpha = d2Var;
            this.$scale = d2Var2;
            this.$transformOrigin = d2Var3;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((InterfaceC0886s0) obj);
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0886s0 interfaceC0886s0) {
            d2 d2Var = this.$alpha;
            interfaceC0886s0.setAlpha(d2Var != null ? ((Number) d2Var.getValue()).floatValue() : 1.0f);
            d2 d2Var2 = this.$scale;
            interfaceC0886s0.setScaleX(d2Var2 != null ? ((Number) d2Var2.getValue()).floatValue() : 1.0f);
            d2 d2Var3 = this.$scale;
            interfaceC0886s0.setScaleY(d2Var3 != null ? ((Number) d2Var3.getValue()).floatValue() : 1.0f);
            d2 d2Var4 = this.$transformOrigin;
            interfaceC0886s0.mo3263setTransformOrigin__ExYCQ(d2Var4 != null ? ((s1) d2Var4.getValue()).m3514unboximpl() : s1.Companion.m3515getCenterSzJe1aQ());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$d */
    public static final class d extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.animation.A $enter;
        final /* synthetic */ C $exit;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(androidx.compose.animation.A a2, C c2) {
            super(1);
            this.$enter = a2;
            this.$exit = c2;
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            androidx.compose.animation.core.F animationSpec;
            androidx.compose.animation.core.F animationSpec2;
            EnumC0356q enumC0356q = EnumC0356q.PreEnter;
            EnumC0356q enumC0356q2 = EnumC0356q.Visible;
            if (w0Var.isTransitioningTo(enumC0356q, enumC0356q2)) {
                K scale = this.$enter.getData$animation().getScale();
                return (scale == null || (animationSpec2 = scale.getAnimationSpec()) == null) ? AbstractC0359u.DefaultAlphaAndScaleSpring : animationSpec2;
            }
            if (!w0Var.isTransitioningTo(enumC0356q2, EnumC0356q.PostExit)) {
                return AbstractC0359u.DefaultAlphaAndScaleSpring;
            }
            K scale2 = this.$exit.getData$animation().getScale();
            return (scale2 == null || (animationSpec = scale2.getAnimationSpec()) == null) ? AbstractC0359u.DefaultAlphaAndScaleSpring : animationSpec;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$e */
    public static final class e extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.animation.A $enter;
        final /* synthetic */ C $exit;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(androidx.compose.animation.A a2, C c2) {
            super(1);
            this.$enter = a2;
            this.$exit = c2;
        }

        @Override // h1.c
        public final Float invoke(EnumC0356q enumC0356q) {
            int i2 = AbstractC0362w.$EnumSwitchMapping$0[enumC0356q.ordinal()];
            float scale = 1.0f;
            if (i2 != 1) {
                if (i2 == 2) {
                    K scale2 = this.$enter.getData$animation().getScale();
                    if (scale2 != null) {
                        scale = scale2.getScale();
                    }
                } else {
                    if (i2 != 3) {
                        throw new H0.c();
                    }
                    K scale3 = this.$exit.getData$animation().getScale();
                    if (scale3 != null) {
                        scale = scale3.getScale();
                    }
                }
            }
            return Float.valueOf(scale);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$f */
    public static final class f extends kotlin.jvm.internal.p implements h1.c {
        public static final f INSTANCE = new f();

        public f() {
            super(1);
        }

        @Override // h1.c
        public final androidx.compose.animation.core.F invoke(w0 w0Var) {
            return AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$g */
    public static final class g extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ androidx.compose.animation.A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ s1 $transformOriginWhenVisible;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(s1 s1Var, androidx.compose.animation.A a2, C c2) {
            super(1);
            this.$transformOriginWhenVisible = s1Var;
            this.$enter = a2;
            this.$exit = c2;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return s1.m3502boximpl(m671invokeLIALnN8((EnumC0356q) obj));
        }

        /* JADX INFO: renamed from: invoke-LIALnN8, reason: not valid java name */
        public final long m671invokeLIALnN8(EnumC0356q enumC0356q) {
            s1 s1VarM3502boximpl;
            int i2 = androidx.compose.animation.x.$EnumSwitchMapping$0[enumC0356q.ordinal()];
            if (i2 != 1) {
                s1VarM3502boximpl = null;
                if (i2 == 2) {
                    K scale = this.$enter.getData$animation().getScale();
                    if (scale != null || (scale = this.$exit.getData$animation().getScale()) != null) {
                        s1VarM3502boximpl = s1.m3502boximpl(scale.m564getTransformOriginSzJe1aQ());
                    }
                } else {
                    if (i2 != 3) {
                        throw new H0.c();
                    }
                    K scale2 = this.$exit.getData$animation().getScale();
                    if (scale2 != null || (scale2 = this.$enter.getData$animation().getScale()) != null) {
                        s1VarM3502boximpl = s1.m3502boximpl(scale2.m564getTransformOriginSzJe1aQ());
                    }
                }
            } else {
                s1VarM3502boximpl = this.$transformOriginWhenVisible;
            }
            return s1VarM3502boximpl != null ? s1VarM3502boximpl.m3514unboximpl() : s1.Companion.m3515getCenterSzJe1aQ();
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$h */
    public static final class h extends kotlin.jvm.internal.p implements h1.a {
        public static final h INSTANCE = new h();

        public h() {
            super(0);
        }

        @Override // h1.a
        public final Boolean invoke() {
            return Boolean.TRUE;
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$i */
    public static final class i extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ boolean $disableClip;
        final /* synthetic */ h1.a $isEnabled;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(boolean z2, h1.a aVar) {
            super(1);
            this.$disableClip = z2;
            this.$isEnabled = aVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((InterfaceC0886s0) obj);
            return U0.n.f1521a;
        }

        public final void invoke(InterfaceC0886s0 interfaceC0886s0) {
            interfaceC0886s0.setClip(!this.$disableClip && ((Boolean) this.$isEnabled.invoke()).booleanValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$j */
    public static final class j extends kotlin.jvm.internal.p implements h1.c {
        public static final j INSTANCE = new j();

        public j() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return 0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$k */
    public static final class k extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialWidth;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public k(h1.c cVar) {
            super(1);
            this.$initialWidth = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m672invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m672invokemzRDjE0(long j2) {
            int iIntValue = ((Number) this.$initialWidth.invoke(Integer.valueOf((int) (j2 >> 32)))).intValue();
            return e0.s.m5234constructorimpl((((long) ((int) (j2 & 4294967295L))) & 4294967295L) | (((long) iIntValue) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$l */
    public static final class l extends kotlin.jvm.internal.p implements h1.c {
        public static final l INSTANCE = new l();

        public l() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m673invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m673invokemzRDjE0(long j2) {
            long j3 = 0;
            return e0.s.m5234constructorimpl((j3 & 4294967295L) | (j3 << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$m */
    public static final class m extends kotlin.jvm.internal.p implements h1.c {
        public static final m INSTANCE = new m();

        public m() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return 0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$n */
    public static final class n extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialHeight;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public n(h1.c cVar) {
            super(1);
            this.$initialHeight = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m674invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m674invokemzRDjE0(long j2) {
            int i2 = (int) (j2 >> 32);
            return e0.s.m5234constructorimpl((((long) ((Number) this.$initialHeight.invoke(Integer.valueOf((int) (j2 & 4294967295L)))).intValue()) & 4294967295L) | (((long) i2) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$o */
    public static final class o extends kotlin.jvm.internal.p implements h1.c {
        public static final o INSTANCE = new o();

        public o() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return 0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$p */
    public static final class p extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetWidth;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public p(h1.c cVar) {
            super(1);
            this.$targetWidth = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m675invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m675invokemzRDjE0(long j2) {
            int iIntValue = ((Number) this.$targetWidth.invoke(Integer.valueOf((int) (j2 >> 32)))).intValue();
            return e0.s.m5234constructorimpl((((long) ((int) (j2 & 4294967295L))) & 4294967295L) | (((long) iIntValue) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$q */
    public static final class q extends kotlin.jvm.internal.p implements h1.c {
        public static final q INSTANCE = new q();

        public q() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m676invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m676invokemzRDjE0(long j2) {
            long j3 = 0;
            return e0.s.m5234constructorimpl((j3 & 4294967295L) | (j3 << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$r */
    public static final class r extends kotlin.jvm.internal.p implements h1.c {
        public static final r INSTANCE = new r();

        public r() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return 0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$s */
    public static final class s extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetHeight;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public s(h1.c cVar) {
            super(1);
            this.$targetHeight = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m677invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m677invokemzRDjE0(long j2) {
            int i2 = (int) (j2 >> 32);
            return e0.s.m5234constructorimpl((((long) ((Number) this.$targetHeight.invoke(Integer.valueOf((int) (j2 & 4294967295L)))).intValue()) & 4294967295L) | (((long) i2) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$t */
    public static final class t extends kotlin.jvm.internal.p implements h1.c {
        public static final t INSTANCE = new t();

        public t() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf((-i2) / 2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$u, reason: collision with other inner class name */
    public static final class C0020u extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffsetX;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0020u(h1.c cVar) {
            super(1);
            this.$initialOffsetX = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m678invokemHKZG7I(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mHKZG7I, reason: not valid java name */
        public final long m678invokemHKZG7I(long j2) {
            return e0.o.m5190constructorimpl((((long) ((Number) this.$initialOffsetX.invoke(Integer.valueOf((int) (j2 >> 32)))).intValue()) << 32) | (((long) 0) & 4294967295L));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$v */
    public static final class v extends kotlin.jvm.internal.p implements h1.c {
        public static final v INSTANCE = new v();

        public v() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf((-i2) / 2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$w */
    public static final class w extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $initialOffsetY;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public w(h1.c cVar) {
            super(1);
            this.$initialOffsetY = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m679invokemHKZG7I(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mHKZG7I, reason: not valid java name */
        public final long m679invokemHKZG7I(long j2) {
            return e0.o.m5190constructorimpl((((long) ((Number) this.$initialOffsetY.invoke(Integer.valueOf((int) (j2 & 4294967295L)))).intValue()) & 4294967295L) | (((long) 0) << 32));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$x */
    public static final class x extends kotlin.jvm.internal.p implements h1.c {
        public static final x INSTANCE = new x();

        public x() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf((-i2) / 2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$y */
    public static final class y extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ h1.c $targetOffsetX;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public y(h1.c cVar) {
            super(1);
            this.$targetOffsetX = cVar;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.o.m5187boximpl(m680invokemHKZG7I(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mHKZG7I, reason: not valid java name */
        public final long m680invokemHKZG7I(long j2) {
            return e0.o.m5190constructorimpl((((long) ((Number) this.$targetOffsetX.invoke(Integer.valueOf((int) (j2 >> 32)))).intValue()) << 32) | (((long) 0) & 4294967295L));
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.u$z */
    public static final class z extends kotlin.jvm.internal.p implements h1.c {
        public static final z INSTANCE = new z();

        public z() {
            super(1);
        }

        public final Integer invoke(int i2) {
            return Integer.valueOf((-i2) / 2);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return invoke(((Number) obj).intValue());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x013b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final H createGraphicsLayerBlock(v0 v0Var, androidx.compose.animation.A a2, C c2, String str, InterfaceC0768p interfaceC0768p, int i2) {
        v0.a aVar;
        v0.a aVar2;
        boolean z2;
        boolean z3;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(642253525, i2, -1, "androidx.compose.animation.createGraphicsLayerBlock (EnterExitTransition.kt:956)");
        }
        boolean z4 = true;
        boolean z5 = (a2.getData$animation().getFade() == null && c2.getData$animation().getFade() == null) ? false : true;
        boolean z6 = (a2.getData$animation().getScale() == null && c2.getData$animation().getScale() == null) ? false : true;
        C1379h c1379h = C1379h.f3125a;
        v0.a aVarCreateDeferredAnimation = null;
        if (z5) {
            interfaceC0768p.startReplaceGroup(-703859581);
            B0 vectorConverter = E0.getVectorConverter(c1379h);
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = str + " alpha";
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            v0.a aVarCreateDeferredAnimation2 = y0.createDeferredAnimation(v0Var, vectorConverter, (String) objRememberedValue, interfaceC0768p, (i2 & 14) | 384, 0);
            interfaceC0768p.endReplaceGroup();
            aVar = aVarCreateDeferredAnimation2;
        } else {
            interfaceC0768p.startReplaceGroup(-703690136);
            interfaceC0768p.endReplaceGroup();
            aVar = null;
        }
        if (z6) {
            interfaceC0768p.startReplaceGroup(-703622493);
            B0 vectorConverter2 = E0.getVectorConverter(c1379h);
            Object objRememberedValue2 = interfaceC0768p.rememberedValue();
            if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue2 = str + " scale";
                interfaceC0768p.updateRememberedValue(objRememberedValue2);
            }
            v0.a aVarCreateDeferredAnimation3 = y0.createDeferredAnimation(v0Var, vectorConverter2, (String) objRememberedValue2, interfaceC0768p, (i2 & 14) | 384, 0);
            interfaceC0768p.endReplaceGroup();
            aVar2 = aVarCreateDeferredAnimation3;
        } else {
            interfaceC0768p.startReplaceGroup(-703453048);
            interfaceC0768p.endReplaceGroup();
            aVar2 = null;
        }
        if (z6) {
            interfaceC0768p.startReplaceGroup(-703375392);
            aVarCreateDeferredAnimation = y0.createDeferredAnimation(v0Var, TransformOriginVectorConverter, "TransformOriginInterruptionHandling", interfaceC0768p, (i2 & 14) | 384, 0);
            interfaceC0768p.endReplaceGroup();
        } else {
            interfaceC0768p.startReplaceGroup(-703203064);
            interfaceC0768p.endReplaceGroup();
        }
        boolean zChangedInstance = interfaceC0768p.changedInstance(aVar);
        if (((i2 & 112) ^ 48) <= 32 || !interfaceC0768p.changed(a2)) {
            z2 = (i2 & 48) == 32;
        }
        boolean z7 = zChangedInstance | z2;
        if (((i2 & 896) ^ 384) <= 256 || !interfaceC0768p.changed(c2)) {
            z3 = (i2 & 384) == 256;
        }
        boolean zChangedInstance2 = z7 | z3 | interfaceC0768p.changedInstance(aVar2);
        if (((i2 & 14) ^ 6) <= 4 || !interfaceC0768p.changed(v0Var)) {
            if ((i2 & 6) != 4) {
                z4 = false;
            }
        }
        boolean zChangedInstance3 = zChangedInstance2 | z4 | interfaceC0768p.changedInstance(aVarCreateDeferredAnimation);
        Object objRememberedValue3 = interfaceC0768p.rememberedValue();
        if (zChangedInstance3 || objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue3 = new androidx.compose.animation.r(aVar, aVar2, v0Var, a2, c2, aVarCreateDeferredAnimation);
            interfaceC0768p.updateRememberedValue(objRememberedValue3);
        }
        H h2 = (H) objRememberedValue3;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return h2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final h1.c createGraphicsLayerBlock$lambda$14$lambda$13(v0.a aVar, v0.a aVar2, v0 v0Var, androidx.compose.animation.A a2, C c2, v0.a aVar3) {
        s1 s1VarM3502boximpl;
        d2 d2VarAnimate = aVar != null ? aVar.animate(new C0360a(a2, c2), new b(a2, c2)) : null;
        d2 d2VarAnimate2 = aVar2 != null ? aVar2.animate(new d(a2, c2), new e(a2, c2)) : null;
        if (v0Var.getCurrentState() == EnumC0356q.PreEnter) {
            K scale = a2.getData$animation().getScale();
            s1VarM3502boximpl = (scale == null && (scale = c2.getData$animation().getScale()) == null) ? null : s1.m3502boximpl(scale.m564getTransformOriginSzJe1aQ());
        } else {
            K scale2 = c2.getData$animation().getScale();
            if (scale2 != null || (scale2 = a2.getData$animation().getScale()) != null) {
                s1VarM3502boximpl = s1.m3502boximpl(scale2.m564getTransformOriginSzJe1aQ());
            }
        }
        return new c(d2VarAnimate, d2VarAnimate2, aVar3 != null ? aVar3.animate(f.INSTANCE, new g(s1VarM3502boximpl, a2, c2)) : null);
    }

    public static final androidx.compose.ui.x createModifier(v0 v0Var, androidx.compose.animation.A a2, C c2, h1.a aVar, String str, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        h1.a aVar2;
        v0.a aVar3;
        v0.a aVar4;
        C0352m changeSize;
        if ((i3 & 4) != 0) {
            Object objRememberedValue = interfaceC0768p.rememberedValue();
            if (objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue = h.INSTANCE;
                interfaceC0768p.updateRememberedValue(objRememberedValue);
            }
            aVar2 = (h1.a) objRememberedValue;
        } else {
            aVar2 = aVar;
        }
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(28261782, i2, -1, "androidx.compose.animation.createModifier (EnterExitTransition.kt:860)");
        }
        int i4 = i2 & 14;
        androidx.compose.animation.A aTrackActiveEnter = trackActiveEnter(v0Var, a2, interfaceC0768p, i2 & 126);
        int i5 = i2 >> 3;
        C cTrackActiveExit = trackActiveExit(v0Var, c2, interfaceC0768p, (i5 & 112) | i4);
        boolean z2 = true;
        boolean z3 = (aTrackActiveEnter.getData$animation().getSlide() == null && cTrackActiveExit.getData$animation().getSlide() == null) ? false : true;
        boolean z4 = (aTrackActiveEnter.getData$animation().getChangeSize() == null && cTrackActiveExit.getData$animation().getChangeSize() == null) ? false : true;
        v0.a aVar5 = null;
        if (z3) {
            interfaceC0768p.startReplaceGroup(133838277);
            B0 vectorConverter = E0.getVectorConverter(e0.o.Companion);
            Object objRememberedValue2 = interfaceC0768p.rememberedValue();
            if (objRememberedValue2 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue2 = str + " slide";
                interfaceC0768p.updateRememberedValue(objRememberedValue2);
            }
            v0.a aVarCreateDeferredAnimation = y0.createDeferredAnimation(v0Var, vectorConverter, (String) objRememberedValue2, interfaceC0768p, i4 | 384, 0);
            interfaceC0768p.endReplaceGroup();
            aVar3 = aVarCreateDeferredAnimation;
        } else {
            interfaceC0768p.startReplaceGroup(133944080);
            interfaceC0768p.endReplaceGroup();
            aVar3 = null;
        }
        if (z4) {
            interfaceC0768p.startReplaceGroup(134035871);
            B0 vectorConverter2 = E0.getVectorConverter(e0.s.Companion);
            Object objRememberedValue3 = interfaceC0768p.rememberedValue();
            if (objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue3 = str + " shrink/expand";
                interfaceC0768p.updateRememberedValue(objRememberedValue3);
            }
            v0.a aVarCreateDeferredAnimation2 = y0.createDeferredAnimation(v0Var, vectorConverter2, (String) objRememberedValue3, interfaceC0768p, i4 | 384, 0);
            interfaceC0768p.endReplaceGroup();
            aVar4 = aVarCreateDeferredAnimation2;
        } else {
            interfaceC0768p.startReplaceGroup(134146695);
            interfaceC0768p.endReplaceGroup();
            aVar4 = null;
        }
        if (z4) {
            interfaceC0768p.startReplaceGroup(134220321);
            B0 vectorConverter3 = E0.getVectorConverter(e0.o.Companion);
            Object objRememberedValue4 = interfaceC0768p.rememberedValue();
            if (objRememberedValue4 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue4 = str + " InterruptionHandlingOffset";
                interfaceC0768p.updateRememberedValue(objRememberedValue4);
            }
            v0.a aVarCreateDeferredAnimation3 = y0.createDeferredAnimation(v0Var, vectorConverter3, (String) objRememberedValue4, interfaceC0768p, i4 | 384, 0);
            interfaceC0768p.endReplaceGroup();
            aVar5 = aVarCreateDeferredAnimation3;
        } else {
            interfaceC0768p.startReplaceGroup(134390727);
            interfaceC0768p.endReplaceGroup();
        }
        C0352m changeSize2 = aTrackActiveEnter.getData$animation().getChangeSize();
        boolean z5 = ((changeSize2 == null || changeSize2.getClip()) && ((changeSize = cTrackActiveExit.getData$animation().getChangeSize()) == null || changeSize.getClip()) && z4) ? false : true;
        H hCreateGraphicsLayerBlock = createGraphicsLayerBlock(v0Var, aTrackActiveEnter, cTrackActiveExit, str, interfaceC0768p, i4 | (i5 & 7168));
        androidx.compose.ui.u uVar = androidx.compose.ui.x.Companion;
        boolean zChanged = interfaceC0768p.changed(z5);
        if ((((i2 & 7168) ^ 3072) <= 2048 || !interfaceC0768p.changed(aVar2)) && (i2 & 3072) != 2048) {
            z2 = false;
        }
        boolean z6 = zChanged | z2;
        Object objRememberedValue5 = interfaceC0768p.rememberedValue();
        if (z6 || objRememberedValue5 == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue5 = new i(z5, aVar2);
            interfaceC0768p.updateRememberedValue(objRememberedValue5);
        }
        androidx.compose.ui.x xVarThen = AbstractC0884r0.graphicsLayer(uVar, (h1.c) objRememberedValue5).then(new EnterExitTransitionElement(v0Var, aVar4, aVar5, aVar3, aTrackActiveEnter, cTrackActiveExit, aVar2, hCreateGraphicsLayerBlock));
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return xVarThen;
    }

    public static final androidx.compose.animation.A expandHorizontally(androidx.compose.animation.core.F f2, InterfaceC0822e interfaceC0822e, boolean z2, h1.c cVar) {
        return expandIn(f2, toAlignment(interfaceC0822e), z2, new k(cVar));
    }

    public static /* synthetic */ androidx.compose.animation.A expandHorizontally$default(androidx.compose.animation.core.F f2, InterfaceC0822e interfaceC0822e, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0822e = InterfaceC0849g.Companion.getEnd();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = j.INSTANCE;
        }
        return expandHorizontally(f2, interfaceC0822e, z2, cVar);
    }

    public static final androidx.compose.animation.A expandIn(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, boolean z2, h1.c cVar) {
        return new B(new U(null, null, new C0352m(interfaceC0849g, cVar, f2, z2), null, false, null, 59, null));
    }

    public static /* synthetic */ androidx.compose.animation.A expandIn$default(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0849g = InterfaceC0849g.Companion.getBottomEnd();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = l.INSTANCE;
        }
        return expandIn(f2, interfaceC0849g, z2, cVar);
    }

    public static final androidx.compose.animation.A expandVertically(androidx.compose.animation.core.F f2, InterfaceC0823f interfaceC0823f, boolean z2, h1.c cVar) {
        return expandIn(f2, toAlignment(interfaceC0823f), z2, new n(cVar));
    }

    public static /* synthetic */ androidx.compose.animation.A expandVertically$default(androidx.compose.animation.core.F f2, InterfaceC0823f interfaceC0823f, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0823f = InterfaceC0849g.Companion.getBottom();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = m.INSTANCE;
        }
        return expandVertically(f2, interfaceC0823f, z2, cVar);
    }

    public static final androidx.compose.animation.A fadeIn(androidx.compose.animation.core.F f2, float f3) {
        return new B(new U(new E(f3, f2), null, null, null, false, null, 62, null));
    }

    public static /* synthetic */ androidx.compose.animation.A fadeIn$default(androidx.compose.animation.core.F f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        return fadeIn(f2, f3);
    }

    public static final C fadeOut(androidx.compose.animation.core.F f2, float f3) {
        return new D(new U(new E(f3, f2), null, null, null, false, null, 62, null));
    }

    public static /* synthetic */ C fadeOut$default(androidx.compose.animation.core.F f2, float f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        return fadeOut(f2, f3);
    }

    public static final <T extends V> T get(androidx.compose.animation.A a2, W w2) {
        V v2 = a2.getData$animation().getEffectsMap().get(w2);
        if (v2 instanceof V) {
            return (T) v2;
        }
        return null;
    }

    /* JADX INFO: renamed from: scaleIn-L8ZKh-E, reason: not valid java name */
    public static final androidx.compose.animation.A m666scaleInL8ZKhE(androidx.compose.animation.core.F f2, float f3, long j2) {
        return new B(new U(null, null, null, new K(f3, j2, f2, null), false, null, 55, null));
    }

    /* JADX INFO: renamed from: scaleIn-L8ZKh-E$default, reason: not valid java name */
    public static /* synthetic */ androidx.compose.animation.A m667scaleInL8ZKhE$default(androidx.compose.animation.core.F f2, float f3, long j2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        if ((i2 & 4) != 0) {
            j2 = s1.Companion.m3515getCenterSzJe1aQ();
        }
        return m666scaleInL8ZKhE(f2, f3, j2);
    }

    /* JADX INFO: renamed from: scaleOut-L8ZKh-E, reason: not valid java name */
    public static final C m668scaleOutL8ZKhE(androidx.compose.animation.core.F f2, float f3, long j2) {
        return new D(new U(null, null, null, new K(f3, j2, f2, null), false, null, 55, null));
    }

    /* JADX INFO: renamed from: scaleOut-L8ZKh-E$default, reason: not valid java name */
    public static /* synthetic */ C m669scaleOutL8ZKhE$default(androidx.compose.animation.core.F f2, float f3, long j2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, null, 5, null);
        }
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        if ((i2 & 4) != 0) {
            j2 = s1.Companion.m3515getCenterSzJe1aQ();
        }
        return m668scaleOutL8ZKhE(f2, f3, j2);
    }

    public static final C shrinkHorizontally(androidx.compose.animation.core.F f2, InterfaceC0822e interfaceC0822e, boolean z2, h1.c cVar) {
        return shrinkOut(f2, toAlignment(interfaceC0822e), z2, new p(cVar));
    }

    public static /* synthetic */ C shrinkHorizontally$default(androidx.compose.animation.core.F f2, InterfaceC0822e interfaceC0822e, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0822e = InterfaceC0849g.Companion.getEnd();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = o.INSTANCE;
        }
        return shrinkHorizontally(f2, interfaceC0822e, z2, cVar);
    }

    public static final C shrinkOut(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, boolean z2, h1.c cVar) {
        return new D(new U(null, null, new C0352m(interfaceC0849g, cVar, f2, z2), null, false, null, 59, null));
    }

    public static /* synthetic */ C shrinkOut$default(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0849g = InterfaceC0849g.Companion.getBottomEnd();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = q.INSTANCE;
        }
        return shrinkOut(f2, interfaceC0849g, z2, cVar);
    }

    public static final C shrinkVertically(androidx.compose.animation.core.F f2, InterfaceC0823f interfaceC0823f, boolean z2, h1.c cVar) {
        return shrinkOut(f2, toAlignment(interfaceC0823f), z2, new s(cVar));
    }

    public static /* synthetic */ C shrinkVertically$default(androidx.compose.animation.core.F f2, InterfaceC0823f interfaceC0823f, boolean z2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.s.m5231boximpl(U0.getVisibilityThreshold(e0.s.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            interfaceC0823f = InterfaceC0849g.Companion.getBottom();
        }
        if ((i2 & 4) != 0) {
            z2 = true;
        }
        if ((i2 & 8) != 0) {
            cVar = r.INSTANCE;
        }
        return shrinkVertically(f2, interfaceC0823f, z2, cVar);
    }

    public static final androidx.compose.animation.A slideIn(androidx.compose.animation.core.F f2, h1.c cVar) {
        return new B(new U(null, new P(cVar, f2), null, null, false, null, 61, null));
    }

    public static /* synthetic */ androidx.compose.animation.A slideIn$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        return slideIn(f2, cVar);
    }

    public static final androidx.compose.animation.A slideInHorizontally(androidx.compose.animation.core.F f2, h1.c cVar) {
        return slideIn(f2, new C0020u(cVar));
    }

    public static /* synthetic */ androidx.compose.animation.A slideInHorizontally$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            cVar = t.INSTANCE;
        }
        return slideInHorizontally(f2, cVar);
    }

    public static final androidx.compose.animation.A slideInVertically(androidx.compose.animation.core.F f2, h1.c cVar) {
        return slideIn(f2, new w(cVar));
    }

    public static /* synthetic */ androidx.compose.animation.A slideInVertically$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            cVar = v.INSTANCE;
        }
        return slideInVertically(f2, cVar);
    }

    public static final C slideOut(androidx.compose.animation.core.F f2, h1.c cVar) {
        return new D(new U(null, new P(cVar, f2), null, null, false, null, 61, null));
    }

    public static /* synthetic */ C slideOut$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        return slideOut(f2, cVar);
    }

    public static final C slideOutHorizontally(androidx.compose.animation.core.F f2, h1.c cVar) {
        return slideOut(f2, new y(cVar));
    }

    public static /* synthetic */ C slideOutHorizontally$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            cVar = x.INSTANCE;
        }
        return slideOutHorizontally(f2, cVar);
    }

    public static final C slideOutVertically(androidx.compose.animation.core.F f2, h1.c cVar) {
        return slideOut(f2, new A(cVar));
    }

    public static /* synthetic */ C slideOutVertically$default(androidx.compose.animation.core.F f2, h1.c cVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = AbstractC0315j.spring$default(0.0f, 400.0f, e0.o.m5187boximpl(U0.getVisibilityThreshold(e0.o.Companion)), 1, null);
        }
        if ((i2 & 2) != 0) {
            cVar = z.INSTANCE;
        }
        return slideOutVertically(f2, cVar);
    }

    private static final InterfaceC0849g toAlignment(InterfaceC0822e interfaceC0822e) {
        C0821d c0821d = InterfaceC0849g.Companion;
        return kotlin.jvm.internal.o.a(interfaceC0822e, c0821d.getStart()) ? c0821d.getCenterStart() : kotlin.jvm.internal.o.a(interfaceC0822e, c0821d.getEnd()) ? c0821d.getCenterEnd() : c0821d.getCenter();
    }

    public static final androidx.compose.animation.A trackActiveEnter(v0 v0Var, androidx.compose.animation.A a2, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(21614502, i2, -1, "androidx.compose.animation.trackActiveEnter (EnterExitTransition.kt:908)");
        }
        boolean z2 = (((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = V1.mutableStateOf$default(a2, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.B0 b02 = (androidx.compose.runtime.B0) objRememberedValue;
        if (v0Var.getCurrentState() == v0Var.getTargetState() && v0Var.getCurrentState() == EnumC0356q.Visible) {
            if (v0Var.isSeeking()) {
                b02.setValue(a2);
            } else {
                b02.setValue(androidx.compose.animation.A.Companion.getNone());
            }
        } else if (v0Var.getTargetState() == EnumC0356q.Visible) {
            b02.setValue(trackActiveEnter$lambda$6(b02).plus(a2));
        }
        androidx.compose.animation.A aTrackActiveEnter$lambda$6 = trackActiveEnter$lambda$6(b02);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return aTrackActiveEnter$lambda$6;
    }

    private static final androidx.compose.animation.A trackActiveEnter$lambda$6(androidx.compose.runtime.B0 b02) {
        return (androidx.compose.animation.A) b02.getValue();
    }

    public static final C trackActiveExit(v0 v0Var, C c2, InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1363864804, i2, -1, "androidx.compose.animation.trackActiveExit (EnterExitTransition.kt:928)");
        }
        boolean z2 = (((i2 & 14) ^ 6) > 4 && interfaceC0768p.changed(v0Var)) || (i2 & 6) == 4;
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (z2 || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = V1.mutableStateOf$default(c2, null, 2, null);
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.B0 b02 = (androidx.compose.runtime.B0) objRememberedValue;
        if (v0Var.getCurrentState() == v0Var.getTargetState() && v0Var.getCurrentState() == EnumC0356q.Visible) {
            if (v0Var.isSeeking()) {
                b02.setValue(c2);
            } else {
                b02.setValue(C.Companion.getNone());
            }
        } else if (v0Var.getTargetState() != EnumC0356q.Visible) {
            b02.setValue(trackActiveExit$lambda$9(b02).plus(c2));
        }
        C cTrackActiveExit$lambda$9 = trackActiveExit$lambda$9(b02);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return cTrackActiveExit$lambda$9;
    }

    private static final C trackActiveExit$lambda$9(androidx.compose.runtime.B0 b02) {
        return (C) b02.getValue();
    }

    public static final androidx.compose.animation.A withEffect(androidx.compose.animation.A a2, V v2) {
        v2.getKey$animation();
        return new B(new U(null, null, null, null, false, V0.E.K(new U0.g(null, v2)), 31, null));
    }

    public static final <T extends V> T get(C c2, W w2) {
        V v2 = c2.getData$animation().getEffectsMap().get(w2);
        if (v2 instanceof V) {
            return (T) v2;
        }
        return null;
    }

    private static final InterfaceC0849g toAlignment(InterfaceC0823f interfaceC0823f) {
        C0821d c0821d = InterfaceC0849g.Companion;
        return kotlin.jvm.internal.o.a(interfaceC0823f, c0821d.getTop()) ? c0821d.getTopCenter() : kotlin.jvm.internal.o.a(interfaceC0823f, c0821d.getBottom()) ? c0821d.getBottomCenter() : c0821d.getCenter();
    }

    public static final C withEffect(C c2, V v2) {
        v2.getKey$animation();
        return new D(new U(null, null, null, null, false, V0.E.K(new U0.g(null, v2)), 31, null));
    }
}
