package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public final class E {
    public static final int $stable = 0;
    private final float alpha;
    private final androidx.compose.animation.core.F animationSpec;

    public E(float f2, androidx.compose.animation.core.F f3) {
        this.alpha = f2;
        this.animationSpec = f3;
    }

    public static /* synthetic */ E copy$default(E e2, float f2, androidx.compose.animation.core.F f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = e2.alpha;
        }
        if ((i2 & 2) != 0) {
            f3 = e2.animationSpec;
        }
        return e2.copy(f2, f3);
    }

    public final float component1() {
        return this.alpha;
    }

    public final androidx.compose.animation.core.F component2() {
        return this.animationSpec;
    }

    public final E copy(float f2, androidx.compose.animation.core.F f3) {
        return new E(f2, f3);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof E)) {
            return false;
        }
        E e2 = (E) obj;
        return Float.compare(this.alpha, e2.alpha) == 0 && kotlin.jvm.internal.o.a(this.animationSpec, e2.animationSpec);
    }

    public final float getAlpha() {
        return this.alpha;
    }

    public final androidx.compose.animation.core.F getAnimationSpec() {
        return this.animationSpec;
    }

    public int hashCode() {
        return this.animationSpec.hashCode() + (Float.hashCode(this.alpha) * 31);
    }

    public String toString() {
        return "Fade(alpha=" + this.alpha + ", animationSpec=" + this.animationSpec + ')';
    }
}
