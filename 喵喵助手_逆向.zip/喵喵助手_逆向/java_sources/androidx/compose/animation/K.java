package androidx.compose.animation;

import androidx.compose.ui.graphics.s1;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class K {
    public static final int $stable = 0;
    private final androidx.compose.animation.core.F animationSpec;
    private final float scale;
    private final long transformOrigin;

    public /* synthetic */ K(float f2, long j2, androidx.compose.animation.core.F f3, AbstractC1378g abstractC1378g) {
        this(f2, j2, f3);
    }

    /* JADX INFO: renamed from: copy-bnNdC4k$default, reason: not valid java name */
    public static /* synthetic */ K m561copybnNdC4k$default(K k2, float f2, long j2, androidx.compose.animation.core.F f3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = k2.scale;
        }
        if ((i2 & 2) != 0) {
            j2 = k2.transformOrigin;
        }
        if ((i2 & 4) != 0) {
            f3 = k2.animationSpec;
        }
        return k2.m563copybnNdC4k(f2, j2, f3);
    }

    public final float component1() {
        return this.scale;
    }

    /* JADX INFO: renamed from: component2-SzJe1aQ, reason: not valid java name */
    public final long m562component2SzJe1aQ() {
        return this.transformOrigin;
    }

    public final androidx.compose.animation.core.F component3() {
        return this.animationSpec;
    }

    /* JADX INFO: renamed from: copy-bnNdC4k, reason: not valid java name */
    public final K m563copybnNdC4k(float f2, long j2, androidx.compose.animation.core.F f3) {
        return new K(f2, j2, f3, null);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof K)) {
            return false;
        }
        K k2 = (K) obj;
        return Float.compare(this.scale, k2.scale) == 0 && s1.m3509equalsimpl0(this.transformOrigin, k2.transformOrigin) && kotlin.jvm.internal.o.a(this.animationSpec, k2.animationSpec);
    }

    public final androidx.compose.animation.core.F getAnimationSpec() {
        return this.animationSpec;
    }

    public final float getScale() {
        return this.scale;
    }

    /* JADX INFO: renamed from: getTransformOrigin-SzJe1aQ, reason: not valid java name */
    public final long m564getTransformOriginSzJe1aQ() {
        return this.transformOrigin;
    }

    public int hashCode() {
        return this.animationSpec.hashCode() + ((s1.m3512hashCodeimpl(this.transformOrigin) + (Float.hashCode(this.scale) * 31)) * 31);
    }

    public String toString() {
        return "Scale(scale=" + this.scale + ", transformOrigin=" + ((Object) s1.m3513toStringimpl(this.transformOrigin)) + ", animationSpec=" + this.animationSpec + ')';
    }

    private K(float f2, long j2, androidx.compose.animation.core.F f3) {
        this.scale = f2;
        this.transformOrigin = j2;
        this.animationSpec = f3;
    }
}
