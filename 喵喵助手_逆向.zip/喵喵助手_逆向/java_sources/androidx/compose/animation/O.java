package androidx.compose.animation;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: loaded from: classes.dex */
public final class O implements N {
    private final boolean clip;
    private final h1.e sizeAnimationSpec;

    public O(boolean z2, h1.e eVar) {
        this.clip = z2;
        this.sizeAnimationSpec = eVar;
    }

    @Override // androidx.compose.animation.N
    /* JADX INFO: renamed from: createAnimationSpec-TemP2vQ */
    public androidx.compose.animation.core.F mo576createAnimationSpecTemP2vQ(long j2, long j3) {
        return (androidx.compose.animation.core.F) this.sizeAnimationSpec.invoke(e0.s.m5231boximpl(j2), e0.s.m5231boximpl(j3));
    }

    @Override // androidx.compose.animation.N
    public boolean getClip() {
        return this.clip;
    }

    public final h1.e getSizeAnimationSpec() {
        return this.sizeAnimationSpec;
    }

    public /* synthetic */ O(boolean z2, h1.e eVar, int i2, AbstractC1378g abstractC1378g) {
        this((i2 & 1) != 0 ? true : z2, eVar);
    }
}
