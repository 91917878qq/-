package androidx.compose.animation;

import androidx.compose.ui.graphics.Y;

/* JADX INFO: renamed from: androidx.compose.animation.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0354o {
    private static final h1.c ColorToVector = C0353n.INSTANCE;

    public static final h1.c getVectorConverter(Y.a aVar) {
        return ColorToVector;
    }
}
