package androidx.compose.animation;

import androidx.compose.animation.core.AbstractC0307f;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public final class S implements androidx.compose.animation.core.H {
    public static final int $stable = 0;
    private final F flingCalculator;

    public S(InterfaceC1307d interfaceC1307d) {
        this.flingCalculator = new F(T.getPlatformFlingScrollFriction(), interfaceC1307d);
    }

    private final float flingDistance(float f2) {
        return Math.signum(f2) * this.flingCalculator.flingDistance(f2);
    }

    @Override // androidx.compose.animation.core.H
    public float getAbsVelocityThreshold() {
        return 0.0f;
    }

    @Override // androidx.compose.animation.core.H
    public long getDurationNanos(float f2, float f3) {
        return this.flingCalculator.flingDuration(f3) * AbstractC0307f.MillisToNanos;
    }

    @Override // androidx.compose.animation.core.H
    public float getTargetValue(float f2, float f3) {
        return f2 + flingDistance(f3);
    }

    @Override // androidx.compose.animation.core.H
    public float getValueFromNanos(long j2, float f2, float f3) {
        return this.flingCalculator.flingInfo(f3).position(j2 / AbstractC0307f.MillisToNanos) + f2;
    }

    @Override // androidx.compose.animation.core.H
    public float getVelocityFromNanos(long j2, float f2, float f3) {
        return this.flingCalculator.flingInfo(f3).velocity(j2 / AbstractC0307f.MillisToNanos);
    }
}
