package androidx.compose.animation;

import androidx.compose.animation.core.AbstractC0301c;
import androidx.compose.animation.core.AbstractC0315j;
import androidx.compose.animation.core.B0;
import androidx.compose.animation.core.C0297a;
import androidx.compose.animation.core.C0316j0;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.d2;
import androidx.compose.ui.graphics.Y;

/* JADX INFO: loaded from: classes.dex */
public abstract class L {
    private static final C0316j0 colorDefaultSpring = AbstractC0315j.spring$default(0.0f, 0.0f, null, 7, null);

    /* JADX INFO: renamed from: Animatable-8_81llA, reason: not valid java name */
    public static final C0297a m565Animatable8_81llA(long j2) {
        return new C0297a(Y.m3010boximpl(j2), (B0) AbstractC0354o.getVectorConverter(Y.Companion).invoke(Y.m3024getColorSpaceimpl(j2)), null, null, 12, null);
    }

    @U0.a
    /* JADX INFO: renamed from: animateColorAsState-KTwxG1Y, reason: not valid java name */
    public static final /* synthetic */ d2 m566animateColorAsStateKTwxG1Y(long j2, InterfaceC0313i interfaceC0313i, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        if ((i3 & 2) != 0) {
            interfaceC0313i = colorDefaultSpring;
        }
        InterfaceC0313i interfaceC0313i2 = interfaceC0313i;
        if ((i3 & 4) != 0) {
            cVar = null;
        }
        h1.c cVar2 = cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-1942442407, i2, -1, "androidx.compose.animation.animateColorAsState (SingleValueAnimation.kt:82)");
        }
        d2 d2VarM567animateColorAsStateeuL9pac = m567animateColorAsStateeuL9pac(j2, interfaceC0313i2, null, cVar2, interfaceC0768p, (i2 & 126) | ((i2 << 3) & 7168), 4);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarM567animateColorAsStateeuL9pac;
    }

    /* JADX INFO: renamed from: animateColorAsState-euL9pac, reason: not valid java name */
    public static final d2 m567animateColorAsStateeuL9pac(long j2, InterfaceC0313i interfaceC0313i, String str, h1.c cVar, InterfaceC0768p interfaceC0768p, int i2, int i3) {
        InterfaceC0313i interfaceC0313i2 = (i3 & 2) != 0 ? colorDefaultSpring : interfaceC0313i;
        String str2 = (i3 & 4) != 0 ? "ColorAnimation" : str;
        h1.c cVar2 = (i3 & 8) != 0 ? null : cVar;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(-451899108, i2, -1, "androidx.compose.animation.animateColorAsState (SingleValueAnimation.kt:61)");
        }
        boolean zChanged = interfaceC0768p.changed(Y.m3024getColorSpaceimpl(j2));
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = (B0) AbstractC0354o.getVectorConverter(Y.Companion).invoke(Y.m3024getColorSpaceimpl(j2));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        int i4 = i2 << 6;
        d2 d2VarAnimateValueAsState = AbstractC0301c.animateValueAsState(Y.m3010boximpl(j2), (B0) objRememberedValue, interfaceC0313i2, null, str2, cVar2, interfaceC0768p, (i2 & 14) | ((i2 << 3) & 896) | (57344 & i4) | (i4 & 458752), 8);
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return d2VarAnimateValueAsState;
    }
}
