package androidx.compose.animation;

import a.AbstractC0292a;
import androidx.compose.animation.core.C0297a;
import androidx.compose.animation.core.C0309g;
import androidx.compose.animation.core.E0;
import androidx.compose.animation.core.EnumC0305e;
import androidx.compose.animation.core.InterfaceC0313i;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.V1;
import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.layout.AbstractC0974x0;
import androidx.compose.ui.layout.InterfaceC0931b0;
import androidx.compose.ui.layout.InterfaceC0935d0;
import androidx.compose.ui.layout.InterfaceC0937e0;
import e0.AbstractC1306c;
import kotlin.jvm.internal.AbstractC1378g;
import r1.AbstractC1476z;
import r1.InterfaceC1474x;

/* JADX INFO: loaded from: classes.dex */
public final class M extends I {
    private InterfaceC0849g alignment;
    private final B0 animData$delegate;
    private InterfaceC0313i animationSpec;
    private h1.e listener;
    private long lookaheadConstraints;
    private boolean lookaheadConstraintsAvailable;
    private long lookaheadSize;

    public static final class a {
        public static final int $stable = 8;
        private final C0297a anim;
        private long startSize;

        public /* synthetic */ a(C0297a c0297a, long j2, AbstractC1378g abstractC1378g) {
            this(c0297a, j2);
        }

        /* JADX INFO: renamed from: copy-O0kMr_c$default, reason: not valid java name */
        public static /* synthetic */ a m571copyO0kMr_c$default(a aVar, C0297a c0297a, long j2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                c0297a = aVar.anim;
            }
            if ((i2 & 2) != 0) {
                j2 = aVar.startSize;
            }
            return aVar.m573copyO0kMr_c(c0297a, j2);
        }

        public final C0297a component1() {
            return this.anim;
        }

        /* JADX INFO: renamed from: component2-YbymL2g, reason: not valid java name */
        public final long m572component2YbymL2g() {
            return this.startSize;
        }

        /* JADX INFO: renamed from: copy-O0kMr_c, reason: not valid java name */
        public final a m573copyO0kMr_c(C0297a c0297a, long j2) {
            return new a(c0297a, j2, null);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return kotlin.jvm.internal.o.a(this.anim, aVar.anim) && e0.s.m5237equalsimpl0(this.startSize, aVar.startSize);
        }

        public final C0297a getAnim() {
            return this.anim;
        }

        /* JADX INFO: renamed from: getStartSize-YbymL2g, reason: not valid java name */
        public final long m574getStartSizeYbymL2g() {
            return this.startSize;
        }

        public int hashCode() {
            return e0.s.m5240hashCodeimpl(this.startSize) + (this.anim.hashCode() * 31);
        }

        /* JADX INFO: renamed from: setStartSize-ozmzZPI, reason: not valid java name */
        public final void m575setStartSizeozmzZPI(long j2) {
            this.startSize = j2;
        }

        public String toString() {
            return "AnimData(anim=" + this.anim + ", startSize=" + ((Object) e0.s.m5242toStringimpl(this.startSize)) + ')';
        }

        private a(C0297a c0297a, long j2) {
            this.anim = c0297a;
            this.startSize = j2;
        }
    }

    public static final class b extends a1.j implements h1.e {
        final /* synthetic */ long $targetSize;
        final /* synthetic */ a $this_apply;
        int label;
        final /* synthetic */ M this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(a aVar, long j2, M m2, Y0.c cVar) {
            super(2, cVar);
            this.$this_apply = aVar;
            this.$targetSize = j2;
            this.this$0 = m2;
        }

        @Override // a1.a
        public final Y0.c create(Object obj, Y0.c cVar) {
            return new b(this.$this_apply, this.$targetSize, this.this$0, cVar);
        }

        @Override // a1.a
        public final Object invokeSuspend(Object obj) {
            h1.e listener;
            Z0.a aVar = Z0.a.f1616b;
            int i2 = this.label;
            if (i2 == 0) {
                AbstractC0292a.H(obj);
                C0297a anim = this.$this_apply.getAnim();
                e0.s sVarM5231boximpl = e0.s.m5231boximpl(this.$targetSize);
                InterfaceC0313i animationSpec = this.this$0.getAnimationSpec();
                this.label = 1;
                obj = C0297a.animateTo$default(anim, sVarM5231boximpl, animationSpec, null, null, this, 12, null);
                if (obj == aVar) {
                    return aVar;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0292a.H(obj);
            }
            C0309g c0309g = (C0309g) obj;
            if (c0309g.getEndReason() == EnumC0305e.Finished && (listener = this.this$0.getListener()) != null) {
                listener.invoke(e0.s.m5231boximpl(this.$this_apply.m574getStartSizeYbymL2g()), c0309g.getEndState().getValue());
            }
            return U0.n.f1521a;
        }

        @Override // h1.e
        public final Object invoke(InterfaceC1474x interfaceC1474x, Y0.c cVar) {
            return ((b) create(interfaceC1474x, cVar)).invokeSuspend(U0.n.f1521a);
        }
    }

    public static final class c extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ int $height;
        final /* synthetic */ long $measuredSize;
        final /* synthetic */ AbstractC0974x0 $placeable;
        final /* synthetic */ InterfaceC0937e0 $this_measure;
        final /* synthetic */ int $width;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(long j2, int i2, int i3, InterfaceC0937e0 interfaceC0937e0, AbstractC0974x0 abstractC0974x0) {
            super(1);
            this.$measuredSize = j2;
            this.$width = i2;
            this.$height = i3;
            this.$this_measure = interfaceC0937e0;
            this.$placeable = abstractC0974x0;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((AbstractC0974x0.a) obj);
            return U0.n.f1521a;
        }

        public final void invoke(AbstractC0974x0.a aVar) {
            AbstractC0974x0.a.m3923place70tqf50$default(aVar, this.$placeable, M.this.getAlignment().mo2803alignKFBX0sM(this.$measuredSize, e0.s.m5234constructorimpl((((long) this.$width) << 32) | (((long) this.$height) & 4294967295L)), this.$this_measure.getLayoutDirection()), 0.0f, 2, null);
        }
    }

    public /* synthetic */ M(InterfaceC0313i interfaceC0313i, InterfaceC0849g interfaceC0849g, h1.e eVar, int i2, AbstractC1378g abstractC1378g) {
        this(interfaceC0313i, (i2 & 2) != 0 ? InterfaceC0849g.Companion.getTopStart() : interfaceC0849g, (i2 & 4) != 0 ? null : eVar);
    }

    /* JADX INFO: renamed from: setLookaheadConstraints-BRTryo0, reason: not valid java name */
    private final void m568setLookaheadConstraintsBRTryo0(long j2) {
        this.lookaheadConstraints = j2;
        this.lookaheadConstraintsAvailable = true;
    }

    /* JADX INFO: renamed from: targetConstraints-ZezNO4M, reason: not valid java name */
    private final long m569targetConstraintsZezNO4M(long j2) {
        return this.lookaheadConstraintsAvailable ? this.lookaheadConstraints : j2;
    }

    /* JADX INFO: renamed from: animateTo-mzRDjE0, reason: not valid java name */
    public final long m570animateTomzRDjE0(long j2) {
        a animData = getAnimData();
        AbstractC1378g abstractC1378g = null;
        if (animData != null) {
            boolean z2 = (e0.s.m5237equalsimpl0(j2, ((e0.s) animData.getAnim().getValue()).m5243unboximpl()) || animData.getAnim().isRunning()) ? false : true;
            if (!e0.s.m5237equalsimpl0(j2, ((e0.s) animData.getAnim().getTargetValue()).m5243unboximpl()) || z2) {
                animData.m575setStartSizeozmzZPI(((e0.s) animData.getAnim().getValue()).m5243unboximpl());
                AbstractC1476z.s(getCoroutineScope(), null, null, new b(animData, j2, this, null), 3);
            }
        } else {
            long j3 = 1;
            animData = new a(new C0297a(e0.s.m5231boximpl(j2), E0.getVectorConverter(e0.s.Companion), e0.s.m5231boximpl(e0.s.m5234constructorimpl((j3 & 4294967295L) | (j3 << 32))), null, 8, null), j2, abstractC1378g);
        }
        setAnimData(animData);
        return ((e0.s) animData.getAnim().getValue()).m5243unboximpl();
    }

    public final InterfaceC0849g getAlignment() {
        return this.alignment;
    }

    public final a getAnimData() {
        return (a) this.animData$delegate.getValue();
    }

    public final InterfaceC0313i getAnimationSpec() {
        return this.animationSpec;
    }

    public final h1.e getListener() {
        return this.listener;
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.node.M
    /* JADX INFO: renamed from: measure-3p2s80s */
    public InterfaceC0935d0 mo559measure3p2s80s(InterfaceC0937e0 interfaceC0937e0, InterfaceC0931b0 interfaceC0931b0, long j2) {
        AbstractC0974x0 abstractC0974x0Mo3865measureBRTryo0;
        long jM5055constrain4WqzIAM;
        if (interfaceC0937e0.isLookingAhead()) {
            m568setLookaheadConstraintsBRTryo0(j2);
            abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(j2);
        } else {
            abstractC0974x0Mo3865measureBRTryo0 = interfaceC0931b0.mo3865measureBRTryo0(m569targetConstraintsZezNO4M(j2));
        }
        AbstractC0974x0 abstractC0974x0 = abstractC0974x0Mo3865measureBRTryo0;
        long jM5234constructorimpl = e0.s.m5234constructorimpl((((long) abstractC0974x0.getWidth()) << 32) | (((long) abstractC0974x0.getHeight()) & 4294967295L));
        if (interfaceC0937e0.isLookingAhead()) {
            this.lookaheadSize = jM5234constructorimpl;
            jM5055constrain4WqzIAM = jM5234constructorimpl;
        } else {
            jM5055constrain4WqzIAM = AbstractC1306c.m5055constrain4WqzIAM(j2, m570animateTomzRDjE0(AbstractC0351l.m660isValidozmzZPI(this.lookaheadSize) ? this.lookaheadSize : jM5234constructorimpl));
        }
        int i2 = (int) (jM5055constrain4WqzIAM >> 32);
        int i3 = (int) (jM5055constrain4WqzIAM & 4294967295L);
        return InterfaceC0937e0.layout$default(interfaceC0937e0, i2, i3, null, new c(jM5234constructorimpl, i2, i3, interfaceC0937e0, abstractC0974x0), 4, null);
    }

    @Override // androidx.compose.ui.w
    public void onAttach() {
        super.onAttach();
        this.lookaheadSize = AbstractC0351l.getInvalidSize();
        this.lookaheadConstraintsAvailable = false;
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onDensityChange() {
        super.onDensityChange();
    }

    @Override // androidx.compose.animation.I, androidx.compose.ui.w, androidx.compose.ui.node.InterfaceC1007o
    public /* bridge */ /* synthetic */ void onLayoutDirectionChange() {
        super.onLayoutDirectionChange();
    }

    @Override // androidx.compose.ui.w
    public void onReset() {
        super.onReset();
        setAnimData(null);
    }

    public final void setAlignment(InterfaceC0849g interfaceC0849g) {
        this.alignment = interfaceC0849g;
    }

    public final void setAnimData(a aVar) {
        this.animData$delegate.setValue(aVar);
    }

    public final void setAnimationSpec(InterfaceC0313i interfaceC0313i) {
        this.animationSpec = interfaceC0313i;
    }

    public final void setListener(h1.e eVar) {
        this.listener = eVar;
    }

    public M(InterfaceC0313i interfaceC0313i, InterfaceC0849g interfaceC0849g, h1.e eVar) {
        this.animationSpec = interfaceC0313i;
        this.alignment = interfaceC0849g;
        this.listener = eVar;
        this.lookaheadSize = AbstractC0351l.getInvalidSize();
        this.lookaheadConstraints = AbstractC1306c.Constraints$default(0, 0, 0, 0, 15, null);
        this.animData$delegate = V1.mutableStateOf$default(null, null, 2, null);
    }
}
