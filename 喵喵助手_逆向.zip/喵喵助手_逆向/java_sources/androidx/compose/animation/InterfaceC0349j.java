package androidx.compose.animation;

import androidx.compose.animation.core.v0;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.AbstractC1056i1;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: renamed from: androidx.compose.animation.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0349j {

    /* JADX INFO: renamed from: androidx.compose.animation.j$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        final /* synthetic */ A $enter$inlined;
        final /* synthetic */ C $exit$inlined;
        final /* synthetic */ String $label$inlined;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(A a2, C c2, String str) {
            super(1);
            this.$enter$inlined = a2;
            this.$exit$inlined = c2;
            this.$label$inlined = str;
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((C1065l1) obj);
            return U0.n.f1521a;
        }

        public final void invoke(C1065l1 c1065l1) {
            c1065l1.setName("animateEnterExit");
            c1065l1.getProperties().set("enter", this.$enter$inlined);
            c1065l1.getProperties().set("exit", this.$exit$inlined);
            c1065l1.getProperties().set("label", this.$label$inlined);
        }
    }

    /* JADX INFO: renamed from: androidx.compose.animation.j$b */
    public static final class b extends kotlin.jvm.internal.p implements h1.f {
        final /* synthetic */ A $enter;
        final /* synthetic */ C $exit;
        final /* synthetic */ String $label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(A a2, C c2, String str) {
            super(3);
            this.$enter = a2;
            this.$exit = c2;
            this.$label = str;
        }

        @Override // h1.f
        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            return invoke((androidx.compose.ui.x) obj, (InterfaceC0768p) obj2, ((Number) obj3).intValue());
        }

        public final androidx.compose.ui.x invoke(androidx.compose.ui.x xVar, InterfaceC0768p interfaceC0768p, int i2) {
            interfaceC0768p.startReplaceGroup(1840112047);
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(1840112047, i2, -1, "androidx.compose.animation.AnimatedVisibilityScope.animateEnterExit.<anonymous> (AnimatedVisibility.kt:654)");
            }
            androidx.compose.ui.x xVarThen = xVar.then(AbstractC0359u.createModifier(InterfaceC0349j.this.getTransition(), this.$enter, this.$exit, null, this.$label, interfaceC0768p, 0, 4));
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
            interfaceC0768p.endReplaceGroup();
            return xVarThen;
        }
    }

    static /* synthetic */ androidx.compose.ui.x animateEnterExit$default(InterfaceC0349j interfaceC0349j, androidx.compose.ui.x xVar, A a2, C c2, String str, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: animateEnterExit");
        }
        if ((i2 & 1) != 0) {
            a2 = AbstractC0359u.fadeIn$default(null, 0.0f, 3, null);
        }
        if ((i2 & 2) != 0) {
            c2 = AbstractC0359u.fadeOut$default(null, 0.0f, 3, null);
        }
        if ((i2 & 4) != 0) {
            str = "animateEnterExit";
        }
        return interfaceC0349j.animateEnterExit(xVar, a2, c2, str);
    }

    default androidx.compose.ui.x animateEnterExit(androidx.compose.ui.x xVar, A a2, C c2, String str) {
        return androidx.compose.ui.n.composed(xVar, AbstractC1056i1.isDebugInspectorInfoEnabled() ? new a(a2, c2, str) : AbstractC1056i1.getNoInspectorInfo(), new b(a2, c2, str));
    }

    v0 getTransition();
}
