package androidx.compose.animation;

import androidx.compose.animation.core.InterfaceC0341y;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public abstract class Q {
    private static final float EndTension = 1.0f;
    private static final float Inflection = 0.35f;
    private static final float P1 = 0.175f;
    private static final float P2 = 0.35000002f;
    private static final float StartTension = 0.5f;

    /* JADX INFO: Access modifiers changed from: private */
    public static final void computeSplineInfo(float[] fArr, float[] fArr2, int i2) {
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10 = 0.0f;
        float f11 = 0.0f;
        for (int i3 = 0; i3 < i2; i3++) {
            float f12 = i3 / i2;
            float f13 = 1.0f;
            while (true) {
                f2 = ((f13 - f10) / 2.0f) + f10;
                f3 = 1.0f - f2;
                f4 = f2 * 3.0f * f3;
                f5 = f2 * f2 * f2;
                float f14 = (((f2 * P2) + (f3 * P1)) * f4) + f5;
                if (Math.abs(f14 - f12) < 1.0E-5d) {
                    break;
                } else if (f14 > f12) {
                    f13 = f2;
                } else {
                    f10 = f2;
                }
            }
            float f15 = 0.5f;
            fArr[i3] = (((f3 * 0.5f) + f2) * f4) + f5;
            float f16 = 1.0f;
            while (true) {
                f6 = ((f16 - f11) / 2.0f) + f11;
                f7 = 1.0f - f6;
                f8 = f6 * 3.0f * f7;
                f9 = f6 * f6 * f6;
                float f17 = (((f7 * f15) + f6) * f8) + f9;
                if (Math.abs(f17 - f12) >= 1.0E-5d) {
                    if (f17 > f12) {
                        f16 = f6;
                    } else {
                        f11 = f6;
                    }
                    f15 = 0.5f;
                }
            }
            fArr2[i3] = (((f6 * P2) + (f7 * P1)) * f8) + f9;
        }
        fArr2[i2] = 1.0f;
        fArr[i2] = 1.0f;
    }

    public static final <T> InterfaceC0341y splineBasedDecay(InterfaceC1307d interfaceC1307d) {
        return androidx.compose.animation.core.A.generateDecayAnimationSpec(new S(interfaceC1307d));
    }
}
