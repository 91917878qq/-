package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public final class B extends A {
    private final U data;

    public B(U u2) {
        super(null);
        this.data = u2;
    }

    @Override // androidx.compose.animation.A
    public U getData$animation() {
        return this.data;
    }
}
