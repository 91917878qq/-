package androidx.compose.animation;

/* JADX INFO: loaded from: classes.dex */
public interface N {
    /* JADX INFO: renamed from: createAnimationSpec-TemP2vQ, reason: not valid java name */
    androidx.compose.animation.core.F mo576createAnimationSpecTemP2vQ(long j2, long j3);

    boolean getClip();
}
