package androidx.compose.animation;

import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0345f {
    private final int value;
    public static final a Companion = new a(null);
    private static final int Left = m644constructorimpl(0);
    private static final int Right = m644constructorimpl(1);
    private static final int Up = m644constructorimpl(2);
    private static final int Down = m644constructorimpl(3);
    private static final int Start = m644constructorimpl(4);
    private static final int End = m644constructorimpl(5);

    /* JADX INFO: renamed from: androidx.compose.animation.f$a */
    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        /* JADX INFO: renamed from: getDown-DKzdypw, reason: not valid java name */
        public final int m650getDownDKzdypw() {
            return C0345f.Down;
        }

        /* JADX INFO: renamed from: getEnd-DKzdypw, reason: not valid java name */
        public final int m651getEndDKzdypw() {
            return C0345f.End;
        }

        /* JADX INFO: renamed from: getLeft-DKzdypw, reason: not valid java name */
        public final int m652getLeftDKzdypw() {
            return C0345f.Left;
        }

        /* JADX INFO: renamed from: getRight-DKzdypw, reason: not valid java name */
        public final int m653getRightDKzdypw() {
            return C0345f.Right;
        }

        /* JADX INFO: renamed from: getStart-DKzdypw, reason: not valid java name */
        public final int m654getStartDKzdypw() {
            return C0345f.Start;
        }

        /* JADX INFO: renamed from: getUp-DKzdypw, reason: not valid java name */
        public final int m655getUpDKzdypw() {
            return C0345f.Up;
        }

        private a() {
        }
    }

    private /* synthetic */ C0345f(int i2) {
        this.value = i2;
    }

    /* JADX INFO: renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ C0345f m643boximpl(int i2) {
        return new C0345f(i2);
    }

    /* JADX INFO: renamed from: constructor-impl, reason: not valid java name */
    public static int m644constructorimpl(int i2) {
        return i2;
    }

    /* JADX INFO: renamed from: equals-impl, reason: not valid java name */
    public static boolean m645equalsimpl(int i2, Object obj) {
        return (obj instanceof C0345f) && i2 == ((C0345f) obj).m649unboximpl();
    }

    /* JADX INFO: renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m646equalsimpl0(int i2, int i3) {
        return i2 == i3;
    }

    /* JADX INFO: renamed from: hashCode-impl, reason: not valid java name */
    public static int m647hashCodeimpl(int i2) {
        return Integer.hashCode(i2);
    }

    /* JADX INFO: renamed from: toString-impl, reason: not valid java name */
    public static String m648toStringimpl(int i2) {
        return m646equalsimpl0(i2, Left) ? "Left" : m646equalsimpl0(i2, Right) ? "Right" : m646equalsimpl0(i2, Up) ? "Up" : m646equalsimpl0(i2, Down) ? "Down" : m646equalsimpl0(i2, Start) ? "Start" : m646equalsimpl0(i2, End) ? "End" : "Invalid";
    }

    public boolean equals(Object obj) {
        return m645equalsimpl(this.value, obj);
    }

    public int hashCode() {
        return m647hashCodeimpl(this.value);
    }

    public String toString() {
        return m648toStringimpl(this.value);
    }

    /* JADX INFO: renamed from: unbox-impl, reason: not valid java name */
    public final /* synthetic */ int m649unboximpl() {
        return this.value;
    }
}
