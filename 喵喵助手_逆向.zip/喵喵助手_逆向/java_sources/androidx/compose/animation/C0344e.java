package androidx.compose.animation;

import androidx.compose.animation.core.v0;

/* JADX INFO: renamed from: androidx.compose.animation.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0344e implements InterfaceC0343d, InterfaceC0349j {
    private final /* synthetic */ InterfaceC0349j $$delegate_0;

    public C0344e(InterfaceC0349j interfaceC0349j) {
        this.$$delegate_0 = interfaceC0349j;
    }

    @Override // androidx.compose.animation.InterfaceC0343d, androidx.compose.animation.InterfaceC0349j
    public androidx.compose.ui.x animateEnterExit(androidx.compose.ui.x xVar, A a2, C c2, String str) {
        return this.$$delegate_0.animateEnterExit(xVar, a2, c2, str);
    }

    @Override // androidx.compose.animation.InterfaceC0343d, androidx.compose.animation.InterfaceC0349j
    public v0 getTransition() {
        return this.$$delegate_0.getTransition();
    }
}
