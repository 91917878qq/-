package androidx.compose.animation;

import android.view.ViewConfiguration;
import androidx.compose.animation.core.InterfaceC0341y;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.ui.platform.L0;
import e0.InterfaceC1307d;

/* JADX INFO: loaded from: classes.dex */
public abstract class T {
    private static final float platformFlingScrollFriction = ViewConfiguration.getScrollFriction();

    public static final float getPlatformFlingScrollFriction() {
        return platformFlingScrollFriction;
    }

    public static final <T> InterfaceC0341y rememberSplineBasedDecay(InterfaceC0768p interfaceC0768p, int i2) {
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventStart(904445851, i2, -1, "androidx.compose.animation.rememberSplineBasedDecay (SplineBasedFloatDecayAnimationSpec.android.kt:40)");
        }
        InterfaceC1307d interfaceC1307d = (InterfaceC1307d) interfaceC0768p.consume(L0.getLocalDensity());
        boolean zChanged = interfaceC0768p.changed(interfaceC1307d.getDensity());
        Object objRememberedValue = interfaceC0768p.rememberedValue();
        if (zChanged || objRememberedValue == InterfaceC0768p.Companion.getEmpty()) {
            objRememberedValue = androidx.compose.animation.core.A.generateDecayAnimationSpec(new S(interfaceC1307d));
            interfaceC0768p.updateRememberedValue(objRememberedValue);
        }
        InterfaceC0341y interfaceC0341y = (InterfaceC0341y) objRememberedValue;
        if (AbstractC0776s.isTraceInProgress()) {
            AbstractC0776s.traceEventEnd();
        }
        return interfaceC0341y;
    }
}
