package androidx.compose.animation;

import androidx.compose.animation.core.C0323n;
import androidx.compose.ui.graphics.s1;
import androidx.compose.ui.graphics.t1;

/* JADX INFO: renamed from: androidx.compose.animation.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0358t extends kotlin.jvm.internal.p implements h1.c {
    public static final C0358t INSTANCE = new C0358t();

    public C0358t() {
        super(1);
    }

    @Override // h1.c
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        return s1.m3502boximpl(m665invokeLIALnN8((C0323n) obj));
    }

    /* JADX INFO: renamed from: invoke-LIALnN8, reason: not valid java name */
    public final long m665invokeLIALnN8(C0323n c0323n) {
        return t1.TransformOrigin(c0323n.getV1(), c0323n.getV2());
    }
}
