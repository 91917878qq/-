package androidx.compose.animation;

import androidx.compose.ui.InterfaceC0849g;
import kotlin.jvm.internal.AbstractC1378g;

/* JADX INFO: renamed from: androidx.compose.animation.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0352m {
    public static final int $stable = 0;
    private final InterfaceC0849g alignment;
    private final androidx.compose.animation.core.F animationSpec;
    private final boolean clip;
    private final h1.c size;

    /* JADX INFO: renamed from: androidx.compose.animation.m$a */
    public static final class a extends kotlin.jvm.internal.p implements h1.c {
        public static final a INSTANCE = new a();

        public a() {
            super(1);
        }

        @Override // h1.c
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return e0.s.m5231boximpl(m661invokemzRDjE0(((e0.s) obj).m5243unboximpl()));
        }

        /* JADX INFO: renamed from: invoke-mzRDjE0, reason: not valid java name */
        public final long m661invokemzRDjE0(long j2) {
            long j3 = 0;
            return e0.s.m5234constructorimpl((j3 & 4294967295L) | (j3 << 32));
        }
    }

    public C0352m(InterfaceC0849g interfaceC0849g, h1.c cVar, androidx.compose.animation.core.F f2, boolean z2) {
        this.alignment = interfaceC0849g;
        this.size = cVar;
        this.animationSpec = f2;
        this.clip = z2;
    }

    public static /* synthetic */ C0352m copy$default(C0352m c0352m, InterfaceC0849g interfaceC0849g, h1.c cVar, androidx.compose.animation.core.F f2, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            interfaceC0849g = c0352m.alignment;
        }
        if ((i2 & 2) != 0) {
            cVar = c0352m.size;
        }
        if ((i2 & 4) != 0) {
            f2 = c0352m.animationSpec;
        }
        if ((i2 & 8) != 0) {
            z2 = c0352m.clip;
        }
        return c0352m.copy(interfaceC0849g, cVar, f2, z2);
    }

    public final InterfaceC0849g component1() {
        return this.alignment;
    }

    public final h1.c component2() {
        return this.size;
    }

    public final androidx.compose.animation.core.F component3() {
        return this.animationSpec;
    }

    public final boolean component4() {
        return this.clip;
    }

    public final C0352m copy(InterfaceC0849g interfaceC0849g, h1.c cVar, androidx.compose.animation.core.F f2, boolean z2) {
        return new C0352m(interfaceC0849g, cVar, f2, z2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0352m)) {
            return false;
        }
        C0352m c0352m = (C0352m) obj;
        return kotlin.jvm.internal.o.a(this.alignment, c0352m.alignment) && kotlin.jvm.internal.o.a(this.size, c0352m.size) && kotlin.jvm.internal.o.a(this.animationSpec, c0352m.animationSpec) && this.clip == c0352m.clip;
    }

    public final InterfaceC0849g getAlignment() {
        return this.alignment;
    }

    public final androidx.compose.animation.core.F getAnimationSpec() {
        return this.animationSpec;
    }

    public final boolean getClip() {
        return this.clip;
    }

    public final h1.c getSize() {
        return this.size;
    }

    public int hashCode() {
        return Boolean.hashCode(this.clip) + ((this.animationSpec.hashCode() + ((this.size.hashCode() + (this.alignment.hashCode() * 31)) * 31)) * 31);
    }

    public String toString() {
        return "ChangeSize(alignment=" + this.alignment + ", size=" + this.size + ", animationSpec=" + this.animationSpec + ", clip=" + this.clip + ')';
    }

    public /* synthetic */ C0352m(InterfaceC0849g interfaceC0849g, h1.c cVar, androidx.compose.animation.core.F f2, boolean z2, int i2, AbstractC1378g abstractC1378g) {
        this(interfaceC0849g, (i2 & 2) != 0 ? a.INSTANCE : cVar, f2, (i2 & 8) != 0 ? true : z2);
    }
}
