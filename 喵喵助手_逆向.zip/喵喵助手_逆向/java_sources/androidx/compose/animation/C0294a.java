package androidx.compose.animation;

/* JADX INFO: renamed from: androidx.compose.animation.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0294a {
    public static final int $stable;
    public static final C0294a INSTANCE = new C0294a();
    private static final int NbSamples = 100;
    private static final float[] SplinePositions;
    private static final float[] SplineTimes;

    /* JADX INFO: renamed from: androidx.compose.animation.a$a, reason: collision with other inner class name */
    public static final class C0009a {
        public static final int $stable = 0;
        private final float distanceCoefficient;
        private final float velocityCoefficient;

        public C0009a(float f2, float f3) {
            this.distanceCoefficient = f2;
            this.velocityCoefficient = f3;
        }

        public static /* synthetic */ C0009a copy$default(C0009a c0009a, float f2, float f3, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                f2 = c0009a.distanceCoefficient;
            }
            if ((i2 & 2) != 0) {
                f3 = c0009a.velocityCoefficient;
            }
            return c0009a.copy(f2, f3);
        }

        public final float component1() {
            return this.distanceCoefficient;
        }

        public final float component2() {
            return this.velocityCoefficient;
        }

        public final C0009a copy(float f2, float f3) {
            return new C0009a(f2, f3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0009a)) {
                return false;
            }
            C0009a c0009a = (C0009a) obj;
            return Float.compare(this.distanceCoefficient, c0009a.distanceCoefficient) == 0 && Float.compare(this.velocityCoefficient, c0009a.velocityCoefficient) == 0;
        }

        public final float getDistanceCoefficient() {
            return this.distanceCoefficient;
        }

        public final float getVelocityCoefficient() {
            return this.velocityCoefficient;
        }

        public int hashCode() {
            return Float.hashCode(this.velocityCoefficient) + (Float.hashCode(this.distanceCoefficient) * 31);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("FlingResult(distanceCoefficient=");
            sb.append(this.distanceCoefficient);
            sb.append(", velocityCoefficient=");
            return D0.d.p(sb, this.velocityCoefficient, ')');
        }
    }

    static {
        float[] fArr = new float[101];
        SplinePositions = fArr;
        float[] fArr2 = new float[101];
        SplineTimes = fArr2;
        Q.computeSplineInfo(fArr, fArr2, 100);
        $stable = 8;
    }

    private C0294a() {
    }

    public final double deceleration(float f2, float f3) {
        return Math.log(((double) (Math.abs(f2) * 0.35f)) / ((double) f3));
    }

    public final C0009a flingPosition(float f2) {
        float f3 = 0.0f;
        float f4 = 1.0f;
        float fN = j1.a.n(f2, 0.0f, 1.0f);
        float f5 = 100;
        int i2 = (int) (f5 * fN);
        if (i2 < 100) {
            float f6 = i2 / f5;
            int i3 = i2 + 1;
            float f7 = i3 / f5;
            float[] fArr = SplinePositions;
            float f8 = fArr[i2];
            float f9 = (fArr[i3] - f8) / (f7 - f6);
            float f10 = ((fN - f6) * f9) + f8;
            f3 = f9;
            f4 = f10;
        }
        return new C0009a(f4, f3);
    }
}
