package androidx.compose.animation;

import androidx.compose.ui.InterfaceC0849g;
import androidx.compose.ui.node.AbstractC1000k0;
import androidx.compose.ui.platform.C1065l1;

/* JADX INFO: loaded from: classes.dex */
final class SizeAnimationModifierElement extends AbstractC1000k0 {
    private final InterfaceC0849g alignment;
    private final androidx.compose.animation.core.F animationSpec;
    private final h1.e finishedListener;

    public SizeAnimationModifierElement(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, h1.e eVar) {
        this.animationSpec = f2;
        this.alignment = interfaceC0849g;
        this.finishedListener = eVar;
    }

    public static /* synthetic */ SizeAnimationModifierElement copy$default(SizeAnimationModifierElement sizeAnimationModifierElement, androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, h1.e eVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            f2 = sizeAnimationModifierElement.animationSpec;
        }
        if ((i2 & 2) != 0) {
            interfaceC0849g = sizeAnimationModifierElement.alignment;
        }
        if ((i2 & 4) != 0) {
            eVar = sizeAnimationModifierElement.finishedListener;
        }
        return sizeAnimationModifierElement.copy(f2, interfaceC0849g, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean all(h1.c cVar) {
        return super.all(cVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ boolean any(h1.c cVar) {
        return super.any(cVar);
    }

    public final androidx.compose.animation.core.F component1() {
        return this.animationSpec;
    }

    public final InterfaceC0849g component2() {
        return this.alignment;
    }

    public final h1.e component3() {
        return this.finishedListener;
    }

    public final SizeAnimationModifierElement copy(androidx.compose.animation.core.F f2, InterfaceC0849g interfaceC0849g, h1.e eVar) {
        return new SizeAnimationModifierElement(f2, interfaceC0849g, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SizeAnimationModifierElement)) {
            return false;
        }
        SizeAnimationModifierElement sizeAnimationModifierElement = (SizeAnimationModifierElement) obj;
        return kotlin.jvm.internal.o.a(this.animationSpec, sizeAnimationModifierElement.animationSpec) && kotlin.jvm.internal.o.a(this.alignment, sizeAnimationModifierElement.alignment) && kotlin.jvm.internal.o.a(this.finishedListener, sizeAnimationModifierElement.finishedListener);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldIn(Object obj, h1.e eVar) {
        return super.foldIn(obj, eVar);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ Object foldOut(Object obj, h1.e eVar) {
        return super.foldOut(obj, eVar);
    }

    public final InterfaceC0849g getAlignment() {
        return this.alignment;
    }

    public final androidx.compose.animation.core.F getAnimationSpec() {
        return this.animationSpec;
    }

    public final h1.e getFinishedListener() {
        return this.finishedListener;
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public int hashCode() {
        int iHashCode = (this.alignment.hashCode() + (this.animationSpec.hashCode() * 31)) * 31;
        h1.e eVar = this.finishedListener;
        return iHashCode + (eVar == null ? 0 : eVar.hashCode());
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void inspectableProperties(C1065l1 c1065l1) {
        c1065l1.setName("animateContentSize");
        c1065l1.getProperties().set("animationSpec", this.animationSpec);
        c1065l1.getProperties().set("alignment", this.alignment);
        c1065l1.getProperties().set("finishedListener", this.finishedListener);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0, androidx.compose.ui.v, androidx.compose.ui.x
    public /* bridge */ /* synthetic */ androidx.compose.ui.x then(androidx.compose.ui.x xVar) {
        return super.then(xVar);
    }

    public String toString() {
        return "SizeAnimationModifierElement(animationSpec=" + this.animationSpec + ", alignment=" + this.alignment + ", finishedListener=" + this.finishedListener + ')';
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public M create() {
        return new M(this.animationSpec, this.alignment, this.finishedListener);
    }

    @Override // androidx.compose.ui.node.AbstractC1000k0
    public void update(M m2) {
        m2.setAnimationSpec(this.animationSpec);
        m2.setListener(this.finishedListener);
        m2.setAlignment(this.alignment);
    }
}
