package a0;

import H0.c;

/* JADX INFO: renamed from: a0.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0293a {
    public static final void checkPrecondition(boolean z2, h1.a aVar) {
        if (z2) {
            return;
        }
        throwIllegalStateException((String) aVar.invoke());
    }

    public static final <T> T checkPreconditionNotNull(T t2, h1.a aVar) {
        if (t2 != null) {
            return t2;
        }
        throwIllegalStateExceptionForNullCheck((String) aVar.invoke());
        throw new c();
    }

    public static final void requirePrecondition(boolean z2, h1.a aVar) {
        if (z2) {
            return;
        }
        throwIllegalArgumentException((String) aVar.invoke());
    }

    public static final <T> T requirePreconditionNotNull(T t2, h1.a aVar) {
        if (t2 != null) {
            return t2;
        }
        throwIllegalArgumentExceptionForNullCheck((String) aVar.invoke());
        throw new c();
    }

    public static final void throwIllegalArgumentException(String str) {
        throw new IllegalArgumentException(str);
    }

    public static final Void throwIllegalArgumentExceptionForNullCheck(String str) {
        throw new IllegalArgumentException(str);
    }

    public static final void throwIllegalStateException(String str) {
        throw new IllegalStateException(str);
    }

    public static final Void throwIllegalStateExceptionForNullCheck(String str) {
        throw new IllegalStateException(str);
    }
}
