package A0;

import E0.d;
import U0.g;
import V0.B;
import V0.E;
import android.os.Bundle;
import androidx.compose.runtime.saveable.h;
import androidx.compose.ui.platform.Q0;
import b.AbstractActivityC1266o;
import com.miaomiao.assistant.MainActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.o;
import u1.N;
import u1.y;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f8a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f9b;

    public /* synthetic */ a(Object obj, int i2) {
        this.f8a = i2;
        this.f9b = obj;
    }

    @Override // E0.d
    public final Bundle a() {
        g[] gVarArr;
        switch (this.f8a) {
            case 0:
                b bVar = (b) this.f9b;
                LinkedHashMap linkedHashMap = bVar.f13d;
                o.e(linkedHashMap, "<this>");
                int size = linkedHashMap.size();
                Map linkedHashMap2 = B.f1525b;
                for (Map.Entry entry : (size != 0 ? size != 1 ? new LinkedHashMap(linkedHashMap) : E.P(linkedHashMap) : linkedHashMap2).entrySet()) {
                    bVar.a((String) entry.getKey(), ((N) ((y) entry.getValue())).getValue());
                }
                LinkedHashMap linkedHashMap3 = bVar.f11b;
                o.e(linkedHashMap3, "<this>");
                int size2 = linkedHashMap3.size();
                if (size2 != 0) {
                    linkedHashMap2 = size2 != 1 ? new LinkedHashMap(linkedHashMap3) : E.P(linkedHashMap3);
                }
                for (Map.Entry entry2 : linkedHashMap2.entrySet()) {
                    bVar.a((String) entry2.getKey(), ((d) entry2.getValue()).a());
                }
                LinkedHashMap linkedHashMap4 = bVar.f10a;
                if (linkedHashMap4.isEmpty()) {
                    gVarArr = new g[0];
                } else {
                    ArrayList arrayList = new ArrayList(linkedHashMap4.size());
                    for (Map.Entry entry3 : linkedHashMap4.entrySet()) {
                        arrayList.add(new g((String) entry3.getKey(), entry3.getValue()));
                    }
                    gVarArr = (g[]) arrayList.toArray(new g[0]);
                }
                return j1.a.d((g[]) Arrays.copyOf(gVarArr, gVarArr.length));
            case 1:
                return Q0.DisposableSaveableStateRegistry$lambda$0((h) this.f9b);
            default:
                return AbstractActivityC1266o.c((MainActivity) this.f9b);
        }
    }
}
