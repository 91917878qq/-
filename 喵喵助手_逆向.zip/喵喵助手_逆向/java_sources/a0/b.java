package A0;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.o;
import u1.N;
import u1.y;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f10a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f11b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f12c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f13d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a f14e;

    public b(Map initialState) {
        o.e(initialState, "initialState");
        this.f10a = new LinkedHashMap(initialState);
        this.f11b = new LinkedHashMap();
        this.f12c = new LinkedHashMap();
        this.f13d = new LinkedHashMap();
        this.f14e = new a(this, 0);
    }

    public final void a(String key, Object obj) {
        o.e(key, "key");
        this.f10a.put(key, obj);
        y yVar = (y) this.f12c.get(key);
        if (yVar != null) {
            ((N) yVar).j(obj);
        }
        y yVar2 = (y) this.f13d.get(key);
        if (yVar2 != null) {
            ((N) yVar2).j(obj);
        }
    }
}
