package a1;

/* JADX INFO: loaded from: classes.dex */
public abstract class h extends a {
    public h(Y0.c cVar) {
        super(cVar);
        if (cVar != null && cVar.getContext() != Y0.i.f1613b) {
            throw new IllegalArgumentException("Coroutines with restricted suspension must have EmptyCoroutineContext");
        }
    }

    @Override // Y0.c
    public Y0.h getContext() {
        return Y0.i.f1613b;
    }
}
