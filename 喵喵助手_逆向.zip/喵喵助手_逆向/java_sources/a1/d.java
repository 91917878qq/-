package a1;

/* JADX INFO: loaded from: classes.dex */
public interface d {
    d getCallerFrame();
}
