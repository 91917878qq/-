package a1;

import kotlin.jvm.internal.F;
import kotlin.jvm.internal.G;
import kotlin.jvm.internal.o;

/* JADX INFO: loaded from: classes.dex */
public abstract class i extends h implements kotlin.jvm.internal.j {
    private final int arity;

    public i(Y0.c cVar) {
        super(cVar);
        this.arity = 2;
    }

    @Override // kotlin.jvm.internal.j
    public int getArity() {
        return this.arity;
    }

    @Override // a1.a
    public String toString() {
        if (getCompletion() != null) {
            return super.toString();
        }
        F.f3119a.getClass();
        String strA = G.a(this);
        o.d(strA, "renderLambdaToString(...)");
        return strA;
    }
}
