package a1;

import kotlin.jvm.internal.F;
import kotlin.jvm.internal.G;
import kotlin.jvm.internal.o;

/* JADX INFO: loaded from: classes.dex */
public abstract class j extends c implements kotlin.jvm.internal.j {
    private final int arity;

    public j(int i2, Y0.c cVar) {
        super(cVar);
        this.arity = i2;
    }

    @Override // kotlin.jvm.internal.j
    public int getArity() {
        return this.arity;
    }

    @Override // a1.a
    public String toString() {
        if (getCompletion() != null) {
            return super.toString();
        }
        F.f3119a.getClass();
        String strA = G.a(this);
        o.d(strA, "renderLambdaToString(...)");
        return strA;
    }
}
