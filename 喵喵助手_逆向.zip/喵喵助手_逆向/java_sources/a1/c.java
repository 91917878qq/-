package a1;

import kotlin.jvm.internal.o;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends a {
    private final Y0.h _context;
    private transient Y0.c intercepted;

    public c(Y0.h hVar, Y0.c cVar) {
        super(cVar);
        this._context = hVar;
    }

    @Override // Y0.c
    public Y0.h getContext() {
        Y0.h hVar = this._context;
        o.b(hVar);
        return hVar;
    }

    public final Y0.c intercepted() {
        Y0.c cVarInterceptContinuation = this.intercepted;
        if (cVarInterceptContinuation == null) {
            Y0.e eVar = (Y0.e) getContext().get(Y0.d.f1612b);
            if (eVar == null || (cVarInterceptContinuation = eVar.interceptContinuation(this)) == null) {
                cVarInterceptContinuation = this;
            }
            this.intercepted = cVarInterceptContinuation;
        }
        return cVarInterceptContinuation;
    }

    @Override // a1.a
    public void releaseIntercepted() {
        Y0.c cVar = this.intercepted;
        if (cVar != null && cVar != this) {
            Y0.f fVar = getContext().get(Y0.d.f1612b);
            o.b(fVar);
            ((Y0.e) fVar).releaseInterceptedContinuation(cVar);
        }
        this.intercepted = b.f1628b;
    }

    public c(Y0.c cVar) {
        this(cVar != null ? cVar.getContext() : null, cVar);
    }
}
