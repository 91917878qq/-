package a1;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Y0.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f1628b = new b();

    @Override // Y0.c
    public final Y0.h getContext() {
        throw new IllegalStateException("This continuation is already complete");
    }

    @Override // Y0.c
    public final void resumeWith(Object obj) {
        throw new IllegalStateException("This continuation is already complete");
    }

    public final String toString() {
        return "This continuation is already complete";
    }
}
