package a1;

import a.AbstractC0292a;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kotlin.jvm.internal.o;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements Y0.c, d, Serializable {
    private final Y0.c completion;

    public a(Y0.c cVar) {
        this.completion = cVar;
    }

    public Y0.c create(Y0.c completion) {
        o.e(completion, "completion");
        throw new UnsupportedOperationException("create(Continuation) has not been overridden");
    }

    @Override // a1.d
    public d getCallerFrame() {
        Y0.c cVar = this.completion;
        if (cVar instanceof d) {
            return (d) cVar;
        }
        return null;
    }

    public final Y0.c getCompletion() {
        return this.completion;
    }

    public StackTraceElement getStackTraceElement() {
        int iIntValue;
        String strC;
        Method method;
        Object objInvoke;
        Method method2;
        Object objInvoke2;
        e eVar = (e) getClass().getAnnotation(e.class);
        String str = null;
        if (eVar == null || eVar.v() < 1) {
            return null;
        }
        try {
            Field declaredField = getClass().getDeclaredField("label");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(this);
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            iIntValue = (num != null ? num.intValue() : 0) - 1;
        } catch (Exception unused) {
            iIntValue = -1;
        }
        int i2 = iIntValue >= 0 ? eVar.l()[iIntValue] : -1;
        f fVar = g.f1633b;
        f fVar2 = g.f1632a;
        if (fVar == null) {
            try {
                f fVar3 = new f(Class.class.getDeclaredMethod("getModule", null), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", null), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", null));
                g.f1633b = fVar3;
                fVar = fVar3;
            } catch (Exception unused2) {
                g.f1633b = fVar2;
                fVar = fVar2;
            }
        }
        if (fVar != fVar2 && (method = (Method) fVar.f1629a) != null && (objInvoke = method.invoke(getClass(), null)) != null && (method2 = (Method) fVar.f1630b) != null && (objInvoke2 = method2.invoke(objInvoke, null)) != null) {
            Method method3 = (Method) fVar.f1631c;
            Object objInvoke3 = method3 != null ? method3.invoke(objInvoke2, null) : null;
            if (objInvoke3 instanceof String) {
                str = (String) objInvoke3;
            }
        }
        if (str == null) {
            strC = eVar.c();
        } else {
            strC = str + '/' + eVar.c();
        }
        return new StackTraceElement(strC, eVar.m(), eVar.f(), i2);
    }

    public abstract Object invokeSuspend(Object obj);

    public void releaseIntercepted() {
    }

    @Override // Y0.c
    public final void resumeWith(Object obj) {
        Y0.c cVar = this;
        while (true) {
            a aVar = (a) cVar;
            Y0.c cVar2 = aVar.completion;
            o.b(cVar2);
            try {
                obj = aVar.invokeSuspend(obj);
                if (obj == Z0.a.f1616b) {
                    return;
                }
            } catch (Throwable th) {
                obj = AbstractC0292a.m(th);
            }
            aVar.releaseIntercepted();
            if (!(cVar2 instanceof a)) {
                cVar2.resumeWith(obj);
                return;
            }
            cVar = cVar2;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Continuation at ");
        Object stackTraceElement = getStackTraceElement();
        if (stackTraceElement == null) {
            stackTraceElement = getClass().getName();
        }
        sb.append(stackTraceElement);
        return sb.toString();
    }

    public Y0.c create(Object obj, Y0.c completion) {
        o.e(completion, "completion");
        throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
    }
}
