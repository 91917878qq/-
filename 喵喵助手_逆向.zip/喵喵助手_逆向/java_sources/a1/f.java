package a1;

import android.text.TextPaint;
import android.util.SparseArray;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Set;
import m0.AbstractC1391d;
import v0.C1508d;
import v0.C1521q;
import v0.C1522r;
import v0.C1525u;
import v0.C1526v;
import v0.C1527w;
import v0.InterfaceC1519o;
import w0.C1534a;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f1629a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1630b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1631c;

    public f(Method method, Method method2, Method method3) {
        this.f1629a = method;
        this.f1630b = method2;
        this.f1631c = method3;
    }

    public boolean a(CharSequence charSequence, int i2, int i3, C1527w c1527w) {
        if ((c1527w.f3663c & 3) == 0) {
            C1508d c1508d = (C1508d) this.f1631c;
            C1534a c1534aC = c1527w.c();
            int iA = c1534aC.a(8);
            if (iA != 0) {
                ((ByteBuffer) c1534aC.f1586e).getShort(iA + c1534aC.f1583b);
            }
            c1508d.getClass();
            ThreadLocal threadLocal = C1508d.f3607b;
            if (threadLocal.get() == null) {
                threadLocal.set(new StringBuilder());
            }
            StringBuilder sb = (StringBuilder) threadLocal.get();
            sb.setLength(0);
            while (i2 < i3) {
                sb.append(charSequence.charAt(i2));
                i2++;
            }
            TextPaint textPaint = c1508d.f3608a;
            String string = sb.toString();
            int i4 = AbstractC1391d.f3172a;
            boolean zHasGlyph = textPaint.hasGlyph(string);
            int i5 = c1527w.f3663c & 4;
            c1527w.f3663c = zHasGlyph ? i5 | 2 : i5 | 1;
        }
        return (c1527w.f3663c & 3) == 2;
    }

    public Object b(CharSequence charSequence, int i2, int i3, int i4, boolean z2, InterfaceC1519o interfaceC1519o) {
        int i5;
        char c2;
        C1522r c1522r = new C1522r(((C1526v) this.f1630b).f3658c);
        int iCodePointAt = Character.codePointAt(charSequence, i2);
        boolean zE = true;
        int i6 = 0;
        int iCharCount = i2;
        loop0: while (true) {
            i5 = iCharCount;
            while (iCharCount < i3 && i6 < i4 && zE) {
                SparseArray sparseArray = c1522r.f3638c.f3654a;
                C1525u c1525u = sparseArray == null ? null : (C1525u) sparseArray.get(iCodePointAt);
                if (c1522r.f3636a == 2) {
                    if (c1525u != null) {
                        c1522r.f3638c = c1525u;
                        c1522r.f3641f++;
                    } else {
                        if (iCodePointAt == 65038) {
                            c1522r.a();
                        } else if (iCodePointAt != 65039) {
                            C1525u c1525u2 = c1522r.f3638c;
                            if (c1525u2.f3655b != null) {
                                if (c1522r.f3641f != 1) {
                                    c1522r.f3639d = c1525u2;
                                    c1522r.a();
                                } else if (c1522r.b()) {
                                    c1522r.f3639d = c1522r.f3638c;
                                    c1522r.a();
                                } else {
                                    c1522r.a();
                                }
                                c2 = 3;
                            } else {
                                c1522r.a();
                            }
                        }
                        c2 = 1;
                    }
                    c2 = 2;
                } else if (c1525u == null) {
                    c1522r.a();
                    c2 = 1;
                } else {
                    c1522r.f3636a = 2;
                    c1522r.f3638c = c1525u;
                    c1522r.f3641f = 1;
                    c2 = 2;
                }
                c1522r.f3640e = iCodePointAt;
                if (c2 == 1) {
                    iCharCount = Character.charCount(Character.codePointAt(charSequence, i5)) + i5;
                    if (iCharCount < i3) {
                        iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                    }
                } else if (c2 == 2) {
                    int iCharCount2 = Character.charCount(iCodePointAt) + iCharCount;
                    if (iCharCount2 < i3) {
                        iCodePointAt = Character.codePointAt(charSequence, iCharCount2);
                    }
                    iCharCount = iCharCount2;
                } else if (c2 == 3) {
                    if (z2 || !a(charSequence, i5, iCharCount, c1522r.f3639d.f3655b)) {
                        zE = interfaceC1519o.e(charSequence, i5, iCharCount, c1522r.f3639d.f3655b);
                        i6++;
                    }
                }
            }
            break loop0;
        }
        if (c1522r.f3636a == 2 && c1522r.f3638c.f3655b != null && ((c1522r.f3641f > 1 || c1522r.b()) && i6 < i4 && zE && (z2 || !a(charSequence, i5, iCharCount, c1522r.f3638c.f3655b)))) {
            interfaceC1519o.e(charSequence, i5, iCharCount, c1522r.f3638c.f3655b);
        }
        return interfaceC1519o.a();
    }

    public f(C1526v c1526v, C0.a aVar, C1508d c1508d, Set set) {
        this.f1629a = aVar;
        this.f1630b = c1526v;
        this.f1631c = c1508d;
        if (set.isEmpty()) {
            return;
        }
        Iterator it = set.iterator();
        while (it.hasNext()) {
            int[] iArr = (int[]) it.next();
            String str = new String(iArr, 0, iArr.length);
            b(str, 0, str.length(), 1, true, new C1521q(str, 0));
        }
    }
}
