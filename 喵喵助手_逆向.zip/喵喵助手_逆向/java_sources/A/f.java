package A;

import V0.r;
import androidx.compose.runtime.V0;
import java.util.Arrays;
import java.util.ListIterator;
import kotlin.jvm.internal.o;
import z.InterfaceC1594j;

/* JADX INFO: loaded from: classes.dex */
public final class f extends c {
    public static final int $stable = 8;
    private final Object[] root;
    private final int rootShift;
    private final int size;
    private final Object[] tail;

    public f(Object[] objArr, Object[] objArr2, int i2, int i3) {
        this.root = objArr;
        this.tail = objArr2;
        this.size = i2;
        this.rootShift = i3;
        if (!(size() > 32)) {
            V0.throwIllegalArgumentException("Trie-based persistent vector should have at least 33 elements, got " + size());
        }
        int size = size() - m.rootSize(size());
        int length = objArr2.length;
        F.a.m0assert(size <= (length <= 32 ? length : 32));
    }

    private final Object[] bufferFor(int i2) {
        if (rootSize() <= i2) {
            return this.tail;
        }
        Object[] objArr = this.root;
        for (int i3 = this.rootShift; i3 > 0; i3 -= 5) {
            Object[] objArr2 = objArr[m.indexSegment(i2, i3)];
            o.c(objArr2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArr = objArr2;
        }
        return objArr;
    }

    private final Object[] insertIntoRoot(Object[] objArr, int i2, int i3, Object obj, e eVar) {
        Object[] objArrCopyOf;
        int iIndexSegment = m.indexSegment(i3, i2);
        if (i2 == 0) {
            if (iIndexSegment == 0) {
                objArrCopyOf = new Object[32];
            } else {
                objArrCopyOf = Arrays.copyOf(objArr, 32);
                o.d(objArrCopyOf, "copyOf(...)");
            }
            r.P(objArr, objArrCopyOf, iIndexSegment + 1, iIndexSegment, 31);
            eVar.setValue(objArr[31]);
            objArrCopyOf[iIndexSegment] = obj;
            return objArrCopyOf;
        }
        Object[] objArrCopyOf2 = Arrays.copyOf(objArr, 32);
        o.d(objArrCopyOf2, "copyOf(...)");
        int i4 = i2 - 5;
        Object obj2 = objArr[iIndexSegment];
        String str = "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>";
        o.c(obj2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        objArrCopyOf2[iIndexSegment] = insertIntoRoot((Object[]) obj2, i4, i3, obj, eVar);
        int i5 = iIndexSegment + 1;
        while (i5 < 32 && objArrCopyOf2[i5] != null) {
            Object obj3 = objArr[i5];
            o.c(obj3, str);
            Object[] objArr2 = objArrCopyOf2;
            objArr2[i5] = insertIntoRoot((Object[]) obj3, i4, 0, eVar.getValue(), eVar);
            i5++;
            objArrCopyOf2 = objArr2;
            str = str;
        }
        return objArrCopyOf2;
    }

    private final f insertIntoTail(Object[] objArr, int i2, Object obj) {
        int size = size() - rootSize();
        Object[] objArrCopyOf = Arrays.copyOf(this.tail, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        if (size < 32) {
            r.P(this.tail, objArrCopyOf, i2 + 1, i2, size);
            objArrCopyOf[i2] = obj;
            return new f(objArr, objArrCopyOf, size() + 1, this.rootShift);
        }
        Object[] objArr2 = this.tail;
        Object obj2 = objArr2[31];
        r.P(objArr2, objArrCopyOf, i2 + 1, i2, size - 1);
        objArrCopyOf[i2] = obj;
        return pushFilledTail(objArr, objArrCopyOf, m.presizedBufferWith(obj2));
    }

    private final Object[] pullLastBuffer(Object[] objArr, int i2, int i3, e eVar) {
        Object[] objArrPullLastBuffer;
        int iIndexSegment = m.indexSegment(i3, i2);
        if (i2 == 5) {
            eVar.setValue(objArr[iIndexSegment]);
            objArrPullLastBuffer = null;
        } else {
            Object obj = objArr[iIndexSegment];
            o.c(obj, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArrPullLastBuffer = pullLastBuffer((Object[]) obj, i2 - 5, i3, eVar);
        }
        if (objArrPullLastBuffer == null && iIndexSegment == 0) {
            return null;
        }
        Object[] objArrCopyOf = Arrays.copyOf(objArr, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        objArrCopyOf[iIndexSegment] = objArrPullLastBuffer;
        return objArrCopyOf;
    }

    private final InterfaceC1594j pullLastBufferFromRoot(Object[] objArr, int i2, int i3) {
        if (i3 == 0) {
            if (objArr.length == 33) {
                objArr = Arrays.copyOf(objArr, 32);
                o.d(objArr, "copyOf(...)");
            }
            return new k(objArr);
        }
        e eVar = new e(null);
        Object[] objArrPullLastBuffer = pullLastBuffer(objArr, i3, i2 - 1, eVar);
        o.b(objArrPullLastBuffer);
        Object value = eVar.getValue();
        o.c(value, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        Object[] objArr2 = (Object[]) value;
        if (objArrPullLastBuffer[1] != null) {
            return new f(objArrPullLastBuffer, objArr2, i2, i3);
        }
        Object obj = objArrPullLastBuffer[0];
        o.c(obj, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        return new f((Object[]) obj, objArr2, i2, i3 - 5);
    }

    private final f pushFilledTail(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int size = size() >> 5;
        int i2 = this.rootShift;
        if (size <= (1 << i2)) {
            return new f(pushTail(objArr, i2, objArr2), objArr3, size() + 1, this.rootShift);
        }
        Object[] objArrPresizedBufferWith = m.presizedBufferWith(objArr);
        int i3 = this.rootShift + 5;
        return new f(pushTail(objArrPresizedBufferWith, i3, objArr2), objArr3, size() + 1, i3);
    }

    private final Object[] pushTail(Object[] objArr, int i2, Object[] objArr2) {
        Object[] objArrCopyOf;
        int iIndexSegment = m.indexSegment(size() - 1, i2);
        if (objArr != null) {
            objArrCopyOf = Arrays.copyOf(objArr, 32);
            o.d(objArrCopyOf, "copyOf(...)");
        } else {
            objArrCopyOf = new Object[32];
        }
        if (i2 == 5) {
            objArrCopyOf[iIndexSegment] = objArr2;
        } else {
            objArrCopyOf[iIndexSegment] = pushTail((Object[]) objArrCopyOf[iIndexSegment], i2 - 5, objArr2);
        }
        return objArrCopyOf;
    }

    private final Object[] removeFromRootAt(Object[] objArr, int i2, int i3, e eVar) {
        Object[] objArrCopyOf;
        int iIndexSegment = m.indexSegment(i3, i2);
        if (i2 == 0) {
            if (iIndexSegment == 0) {
                objArrCopyOf = new Object[32];
            } else {
                objArrCopyOf = Arrays.copyOf(objArr, 32);
                o.d(objArrCopyOf, "copyOf(...)");
            }
            r.P(objArr, objArrCopyOf, iIndexSegment, iIndexSegment + 1, 32);
            objArrCopyOf[31] = eVar.getValue();
            eVar.setValue(objArr[iIndexSegment]);
            return objArrCopyOf;
        }
        int iIndexSegment2 = objArr[31] == null ? m.indexSegment(rootSize() - 1, i2) : 31;
        Object[] objArrCopyOf2 = Arrays.copyOf(objArr, 32);
        o.d(objArrCopyOf2, "copyOf(...)");
        int i4 = i2 - 5;
        int i5 = iIndexSegment + 1;
        if (i5 <= iIndexSegment2) {
            while (true) {
                Object obj = objArrCopyOf2[iIndexSegment2];
                o.c(obj, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
                objArrCopyOf2[iIndexSegment2] = removeFromRootAt((Object[]) obj, i4, 0, eVar);
                if (iIndexSegment2 == i5) {
                    break;
                }
                iIndexSegment2--;
            }
        }
        Object obj2 = objArrCopyOf2[iIndexSegment];
        o.c(obj2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        objArrCopyOf2[iIndexSegment] = removeFromRootAt((Object[]) obj2, i4, i3, eVar);
        return objArrCopyOf2;
    }

    private final InterfaceC1594j removeFromTailAt(Object[] objArr, int i2, int i3, int i4) {
        int size = size() - i2;
        F.a.m0assert(i4 < size);
        if (size == 1) {
            return pullLastBufferFromRoot(objArr, i2, i3);
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.tail, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        int i5 = size - 1;
        if (i4 < i5) {
            r.P(this.tail, objArrCopyOf, i4, i4 + 1, size);
        }
        objArrCopyOf[i5] = null;
        return new f(objArr, objArrCopyOf, (i2 + size) - 1, i3);
    }

    private final int rootSize() {
        return m.rootSize(size());
    }

    private final Object[] setInRoot(Object[] objArr, int i2, int i3, Object obj) {
        int iIndexSegment = m.indexSegment(i3, i2);
        Object[] objArrCopyOf = Arrays.copyOf(objArr, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        if (i2 == 0) {
            objArrCopyOf[iIndexSegment] = obj;
        } else {
            Object obj2 = objArrCopyOf[iIndexSegment];
            o.c(obj2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArrCopyOf[iIndexSegment] = setInRoot((Object[]) obj2, i2 - 5, i3, obj);
        }
        return objArrCopyOf;
    }

    @Override // V0.AbstractC0276g, java.util.List
    public Object get(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        return bufferFor(i2)[i2 & 31];
    }

    @Override // V0.AbstractC0276g, V0.AbstractC0270a
    public int getSize() {
        return this.size;
    }

    @Override // V0.AbstractC0276g, java.util.List
    public ListIterator<Object> listIterator(int i2) {
        F.d.checkPositionIndex$runtime(i2, size());
        return new h(this.root, this.tail, i2, size(), (this.rootShift / 5) + 1);
    }

    @Override // A.c, z.InterfaceC1594j
    public InterfaceC1594j removeAt(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        int iRootSize = rootSize();
        return i2 >= iRootSize ? removeFromTailAt(this.root, iRootSize, this.rootShift, i2 - iRootSize) : removeFromTailAt(removeFromRootAt(this.root, this.rootShift, i2, new e(this.tail[0])), iRootSize, this.rootShift, 0);
    }

    @Override // A.c, V0.AbstractC0276g, java.util.List, z.InterfaceC1594j
    public InterfaceC1594j set(int i2, Object obj) {
        F.d.checkElementIndex$runtime(i2, size());
        if (rootSize() > i2) {
            return new f(setInRoot(this.root, this.rootShift, i2, obj), this.tail, size(), this.rootShift);
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.tail, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        objArrCopyOf[i2 & 31] = obj;
        return new f(this.root, objArrCopyOf, size(), this.rootShift);
    }

    @Override // A.c, java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j add(Object obj) {
        int size = size() - rootSize();
        if (size >= 32) {
            return pushFilledTail(this.root, this.tail, m.presizedBufferWith(obj));
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.tail, 32);
        o.d(objArrCopyOf, "copyOf(...)");
        objArrCopyOf[size] = obj;
        return new f(this.root, objArrCopyOf, size() + 1, this.rootShift);
    }

    @Override // A.c, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j removeAll(h1.c cVar) {
        g gVarBuilder = builder();
        gVarBuilder.removeAllWithPredicate(cVar);
        return gVarBuilder.build();
    }

    @Override // A.c, z.InterfaceC1594j, z.InterfaceC1592h
    public g builder() {
        return new g(this, this.root, this.tail, this.rootShift);
    }

    @Override // A.c, java.util.List, z.InterfaceC1594j
    public InterfaceC1594j add(int i2, Object obj) {
        F.d.checkPositionIndex$runtime(i2, size());
        if (i2 == size()) {
            return add(obj);
        }
        int iRootSize = rootSize();
        if (i2 >= iRootSize) {
            return insertIntoTail(this.root, i2 - iRootSize, obj);
        }
        e eVar = new e(null);
        return insertIntoTail(insertIntoRoot(this.root, this.rootShift, i2, obj, eVar), 0, eVar.getValue());
    }
}
