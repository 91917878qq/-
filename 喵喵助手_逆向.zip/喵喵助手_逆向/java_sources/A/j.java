package A;

/* JADX INFO: loaded from: classes.dex */
public final class j extends a {
    public static final int $stable = 8;
    private final Object element;

    public j(Object obj, int i2) {
        super(i2, 1);
        this.element = obj;
    }

    @Override // A.a, java.util.ListIterator, java.util.Iterator
    public Object next() {
        checkHasNext$runtime();
        setIndex(getIndex() + 1);
        return this.element;
    }

    @Override // java.util.ListIterator
    public Object previous() {
        checkHasPrevious$runtime();
        setIndex(getIndex() - 1);
        return this.element;
    }
}
