package A;

import java.util.ConcurrentModificationException;
import java.util.ListIterator;
import kotlin.jvm.internal.o;

/* JADX INFO: loaded from: classes.dex */
public final class i extends a implements ListIterator {
    public static final int $stable = 8;
    private final g builder;
    private int expectedModCount;
    private int lastIteratedIndex;
    private l trieIterator;

    public i(g gVar, int i2) {
        super(i2, gVar.size());
        this.builder = gVar;
        this.expectedModCount = gVar.getModCount$runtime();
        this.lastIteratedIndex = -1;
        setupTrieIterator();
    }

    private final void checkForComodification() {
        if (this.expectedModCount != this.builder.getModCount$runtime()) {
            throw new ConcurrentModificationException();
        }
    }

    private final void checkHasIterated() {
        if (this.lastIteratedIndex == -1) {
            throw new IllegalStateException();
        }
    }

    private final void reset() {
        setSize(this.builder.size());
        this.expectedModCount = this.builder.getModCount$runtime();
        this.lastIteratedIndex = -1;
        setupTrieIterator();
    }

    private final void setupTrieIterator() {
        Object[] root$runtime = this.builder.getRoot$runtime();
        if (root$runtime == null) {
            this.trieIterator = null;
            return;
        }
        int iRootSize = m.rootSize(this.builder.size());
        int index = getIndex();
        if (index > iRootSize) {
            index = iRootSize;
        }
        int rootShift$runtime = (this.builder.getRootShift$runtime() / 5) + 1;
        l lVar = this.trieIterator;
        if (lVar == null) {
            this.trieIterator = new l(root$runtime, index, iRootSize, rootShift$runtime);
        } else {
            o.b(lVar);
            lVar.reset$runtime(root$runtime, index, iRootSize, rootShift$runtime);
        }
    }

    @Override // A.a, java.util.ListIterator
    public void add(Object obj) {
        checkForComodification();
        this.builder.add(getIndex(), obj);
        setIndex(getIndex() + 1);
        reset();
    }

    @Override // A.a, java.util.ListIterator, java.util.Iterator
    public Object next() {
        checkForComodification();
        checkHasNext$runtime();
        this.lastIteratedIndex = getIndex();
        l lVar = this.trieIterator;
        if (lVar == null) {
            Object[] tail$runtime = this.builder.getTail$runtime();
            int index = getIndex();
            setIndex(index + 1);
            return tail$runtime[index];
        }
        if (lVar.hasNext()) {
            setIndex(getIndex() + 1);
            return lVar.next();
        }
        Object[] tail$runtime2 = this.builder.getTail$runtime();
        int index2 = getIndex();
        setIndex(index2 + 1);
        return tail$runtime2[index2 - lVar.getSize()];
    }

    @Override // java.util.ListIterator
    public Object previous() {
        checkForComodification();
        checkHasPrevious$runtime();
        this.lastIteratedIndex = getIndex() - 1;
        l lVar = this.trieIterator;
        if (lVar == null) {
            Object[] tail$runtime = this.builder.getTail$runtime();
            setIndex(getIndex() - 1);
            return tail$runtime[getIndex()];
        }
        if (getIndex() <= lVar.getSize()) {
            setIndex(getIndex() - 1);
            return lVar.previous();
        }
        Object[] tail$runtime2 = this.builder.getTail$runtime();
        setIndex(getIndex() - 1);
        return tail$runtime2[getIndex() - lVar.getSize()];
    }

    @Override // A.a, java.util.ListIterator, java.util.Iterator
    public void remove() {
        checkForComodification();
        checkHasIterated();
        this.builder.remove(this.lastIteratedIndex);
        if (this.lastIteratedIndex < getIndex()) {
            setIndex(this.lastIteratedIndex);
        }
        reset();
    }

    @Override // A.a, java.util.ListIterator
    public void set(Object obj) {
        checkForComodification();
        checkHasIterated();
        this.builder.set(this.lastIteratedIndex, obj);
        this.expectedModCount = this.builder.getModCount$runtime();
        setupTrieIterator();
    }
}
