package A;

import V0.AbstractC0276g;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import z.InterfaceC1588d;
import z.InterfaceC1591g;
import z.InterfaceC1592h;
import z.InterfaceC1593i;
import z.InterfaceC1594j;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends AbstractC0276g implements InterfaceC1594j {
    public static final int $stable = 8;

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean retainAll$lambda$3(Collection collection, Object obj) {
        return !collection.contains(obj);
    }

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public abstract /* synthetic */ InterfaceC1592h add(Object obj);

    @Override // java.util.List, z.InterfaceC1594j
    public abstract /* synthetic */ InterfaceC1594j add(int i2, Object obj);

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h, z.InterfaceC1594j
    public abstract /* synthetic */ InterfaceC1594j add(Object obj);

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public /* bridge */ /* synthetic */ InterfaceC1592h addAll(Collection collection) {
        return addAll((Collection<Object>) collection);
    }

    @Override // z.InterfaceC1594j, z.InterfaceC1592h
    public abstract /* synthetic */ InterfaceC1591g builder();

    @Override // z.InterfaceC1594j, z.InterfaceC1592h
    public abstract /* synthetic */ InterfaceC1593i builder();

    @Override // V0.AbstractC0270a, java.util.Collection, java.util.List
    public boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    @Override // V0.AbstractC0270a, java.util.Collection, java.util.List
    public boolean containsAll(Collection<?> collection) {
        Collection<?> collection2 = collection;
        if ((collection2 instanceof Collection) && collection2.isEmpty()) {
            return true;
        }
        Iterator<T> it = collection2.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // V0.AbstractC0276g, java.util.Collection, java.lang.Iterable, java.util.List
    public Iterator<Object> iterator() {
        return listIterator();
    }

    @Override // V0.AbstractC0276g, java.util.List
    public ListIterator<Object> listIterator() {
        return listIterator(0);
    }

    @Override // z.InterfaceC1594j, z.InterfaceC1592h
    public abstract /* synthetic */ InterfaceC1592h removeAll(h1.c cVar);

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public /* bridge */ /* synthetic */ InterfaceC1592h removeAll(Collection collection) {
        return removeAll((Collection<Object>) collection);
    }

    @Override // z.InterfaceC1594j, z.InterfaceC1592h
    public abstract /* synthetic */ InterfaceC1594j removeAll(h1.c cVar);

    @Override // z.InterfaceC1594j
    public abstract /* synthetic */ InterfaceC1594j removeAt(int i2);

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public /* bridge */ /* synthetic */ InterfaceC1592h retainAll(Collection collection) {
        return retainAll((Collection<Object>) collection);
    }

    @Override // V0.AbstractC0276g, java.util.List, z.InterfaceC1594j
    public abstract /* synthetic */ InterfaceC1594j set(int i2, Object obj);

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h, z.InterfaceC1594j
    public InterfaceC1594j addAll(Collection<Object> collection) {
        InterfaceC1593i interfaceC1593iBuilder = builder();
        interfaceC1593iBuilder.addAll(collection);
        return interfaceC1593iBuilder.build();
    }

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j clear() {
        return m.persistentVectorOf();
    }

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j remove(Object obj) {
        int iIndexOf = indexOf(obj);
        return iIndexOf != -1 ? removeAt(iIndexOf) : this;
    }

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h, z.InterfaceC1594j
    public InterfaceC1594j removeAll(Collection<Object> collection) {
        return removeAll((h1.c) new b(1, collection));
    }

    @Override // java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h, z.InterfaceC1594j
    public InterfaceC1594j retainAll(Collection<Object> collection) {
        return removeAll((h1.c) new b(0, collection));
    }

    @Override // V0.AbstractC0276g, java.util.List, z.InterfaceC1594j, z.InterfaceC1588d
    public InterfaceC1588d subList(int i2, int i3) {
        return super.subList(i2, i3);
    }

    @Override // java.util.List, z.InterfaceC1594j
    public InterfaceC1594j addAll(int i2, Collection<Object> collection) {
        InterfaceC1593i interfaceC1593iBuilder = builder();
        interfaceC1593iBuilder.addAll(i2, collection);
        return interfaceC1593iBuilder.build();
    }
}
