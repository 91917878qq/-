package A;

import androidx.compose.runtime.snapshots.B;
import androidx.compose.runtime.snapshots.w;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements h1.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f6b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Collection f7c;

    public /* synthetic */ b(int i2, Collection collection) {
        this.f6b = i2;
        this.f7c = collection;
    }

    @Override // h1.c
    public final Object invoke(Object obj) {
        switch (this.f6b) {
            case 0:
                return Boolean.valueOf(c.retainAll$lambda$3(this.f7c, obj));
            case 1:
                return Boolean.valueOf(this.f7c.contains(obj));
            case 2:
                return Boolean.valueOf(this.f7c.contains(obj));
            case 3:
                return Boolean.valueOf(w.retainAll$lambda$10(this.f7c, (List) obj));
            default:
                return Boolean.valueOf(B.retainAll$lambda$5(this.f7c, (Set) obj));
        }
    }
}
