package A;

import V0.C0273d;
import V0.r;
import androidx.compose.runtime.V0;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.jvm.internal.o;
import z.InterfaceC1593i;
import z.InterfaceC1594j;

/* JADX INFO: loaded from: classes.dex */
public final class g extends V0.k implements InterfaceC1593i {
    public static final int $stable = 8;
    private F.e ownership = new F.e();
    private Object[] root;
    private int rootShift;
    private int size;
    private Object[] tail;
    private InterfaceC1594j vector;
    private Object[] vectorRoot;
    private Object[] vectorTail;

    public g(InterfaceC1594j interfaceC1594j, Object[] objArr, Object[] objArr2, int i2) {
        this.vector = interfaceC1594j;
        this.vectorRoot = objArr;
        this.vectorTail = objArr2;
        this.rootShift = i2;
        this.root = this.vectorRoot;
        this.tail = this.vectorTail;
        this.size = this.vector.size();
    }

    private final Object[] bufferFor(int i2) {
        if (rootSize() <= i2) {
            return this.tail;
        }
        Object[] objArr = this.root;
        o.b(objArr);
        for (int i3 = this.rootShift; i3 > 0; i3 -= 5) {
            Object[] objArr2 = objArr[m.indexSegment(i2, i3)];
            o.c(objArr2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArr = objArr2;
        }
        return objArr;
    }

    private final Object[] copyToBuffer(Object[] objArr, int i2, Iterator<? extends Object> it) {
        while (i2 < 32 && it.hasNext()) {
            objArr[i2] = it.next();
            i2++;
        }
        return objArr;
    }

    private final Object[] insertIntoRoot(Object[] objArr, int i2, int i3, Object obj, e eVar) {
        Object obj2;
        int iIndexSegment = m.indexSegment(i3, i2);
        if (i2 == 0) {
            eVar.setValue(objArr[31]);
            Object[] objArrMakeMutable = makeMutable(objArr);
            r.P(objArr, objArrMakeMutable, iIndexSegment + 1, iIndexSegment, 31);
            objArrMakeMutable[iIndexSegment] = obj;
            return objArrMakeMutable;
        }
        Object[] objArrMakeMutable2 = makeMutable(objArr);
        int i4 = i2 - 5;
        Object obj3 = objArrMakeMutable2[iIndexSegment];
        o.c(obj3, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        objArrMakeMutable2[iIndexSegment] = insertIntoRoot((Object[]) obj3, i4, i3, obj, eVar);
        while (true) {
            iIndexSegment++;
            if (iIndexSegment >= 32 || (obj2 = objArrMakeMutable2[iIndexSegment]) == null) {
                break;
            }
            objArrMakeMutable2[iIndexSegment] = insertIntoRoot((Object[]) obj2, i4, 0, eVar.getValue(), eVar);
        }
        return objArrMakeMutable2;
    }

    private final void insertIntoTail(Object[] objArr, int i2, Object obj) {
        int iTailSize = tailSize();
        Object[] objArrMakeMutable = makeMutable(this.tail);
        if (iTailSize < 32) {
            r.P(this.tail, objArrMakeMutable, i2 + 1, i2, iTailSize);
            objArrMakeMutable[i2] = obj;
            this.root = objArr;
            this.tail = objArrMakeMutable;
            this.size = size() + 1;
            return;
        }
        Object[] objArr2 = this.tail;
        Object obj2 = objArr2[31];
        r.P(objArr2, objArrMakeMutable, i2 + 1, i2, 31);
        objArrMakeMutable[i2] = obj;
        pushFilledTail(objArr, objArrMakeMutable, mutableBufferWith(obj2));
    }

    private final boolean isMutable(Object[] objArr) {
        return objArr.length == 33 && objArr[32] == this.ownership;
    }

    private final ListIterator<Object[]> leafBufferIterator(int i2) {
        Object[] objArr = this.root;
        if (objArr == null) {
            throw new IllegalStateException("Invalid root");
        }
        int iRootSize = rootSize() >> 5;
        F.d.checkPositionIndex$runtime(i2, iRootSize);
        int i3 = this.rootShift;
        return i3 == 0 ? new j(objArr, i2) : new l(objArr, i2, iRootSize, i3 / 5);
    }

    private final Object[] makeMutable(Object[] objArr) {
        if (objArr == null) {
            return mutableBuffer();
        }
        if (isMutable(objArr)) {
            return objArr;
        }
        Object[] objArrMutableBuffer = mutableBuffer();
        int length = objArr.length;
        if (length > 32) {
            length = 32;
        }
        r.T(objArr, objArrMutableBuffer, 0, length, 6);
        return objArrMutableBuffer;
    }

    private final Object[] makeMutableShiftingRight(Object[] objArr, int i2) {
        if (isMutable(objArr)) {
            r.P(objArr, objArr, i2, 0, 32 - i2);
            return objArr;
        }
        Object[] objArrMutableBuffer = mutableBuffer();
        r.P(objArr, objArrMutableBuffer, i2, 0, 32 - i2);
        return objArrMutableBuffer;
    }

    private final Object[] mutableBuffer() {
        Object[] objArr = new Object[33];
        objArr[32] = this.ownership;
        return objArr;
    }

    private final Object[] mutableBufferWith(Object obj) {
        Object[] objArr = new Object[33];
        objArr[0] = obj;
        objArr[32] = this.ownership;
        return objArr;
    }

    private final Object[] nullifyAfter(Object[] objArr, int i2, int i3) {
        if (i3 < 0) {
            V0.throwIllegalArgumentException("shift should be positive");
        }
        if (i3 == 0) {
            return objArr;
        }
        int iIndexSegment = m.indexSegment(i2, i3);
        Object obj = objArr[iIndexSegment];
        o.c(obj, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        Object objNullifyAfter = nullifyAfter((Object[]) obj, i2, i3 - 5);
        if (iIndexSegment < 31) {
            int i4 = iIndexSegment + 1;
            if (objArr[i4] != null) {
                if (isMutable(objArr)) {
                    Arrays.fill(objArr, i4, 32, (Object) null);
                }
                Object[] objArrMutableBuffer = mutableBuffer();
                r.P(objArr, objArrMutableBuffer, 0, 0, i4);
                objArr = objArrMutableBuffer;
            }
        }
        if (objNullifyAfter == objArr[iIndexSegment]) {
            return objArr;
        }
        Object[] objArrMakeMutable = makeMutable(objArr);
        objArrMakeMutable[iIndexSegment] = objNullifyAfter;
        return objArrMakeMutable;
    }

    private final Object[] pullLastBuffer(Object[] objArr, int i2, int i3, e eVar) {
        Object[] objArrPullLastBuffer;
        int iIndexSegment = m.indexSegment(i3 - 1, i2);
        if (i2 == 5) {
            eVar.setValue(objArr[iIndexSegment]);
            objArrPullLastBuffer = null;
        } else {
            Object obj = objArr[iIndexSegment];
            o.c(obj, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArrPullLastBuffer = pullLastBuffer((Object[]) obj, i2 - 5, i3, eVar);
        }
        if (objArrPullLastBuffer == null && iIndexSegment == 0) {
            return null;
        }
        Object[] objArrMakeMutable = makeMutable(objArr);
        objArrMakeMutable[iIndexSegment] = objArrPullLastBuffer;
        return objArrMakeMutable;
    }

    private final void pullLastBufferFromRoot(Object[] objArr, int i2, int i3) {
        if (i3 == 0) {
            this.root = null;
            if (objArr == null) {
                objArr = new Object[0];
            }
            this.tail = objArr;
            this.size = i2;
            this.rootShift = i3;
            return;
        }
        e eVar = new e(null);
        o.b(objArr);
        Object[] objArrPullLastBuffer = pullLastBuffer(objArr, i3, i2, eVar);
        o.b(objArrPullLastBuffer);
        Object value = eVar.getValue();
        o.c(value, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        this.tail = (Object[]) value;
        this.size = i2;
        if (objArrPullLastBuffer[1] == null) {
            this.root = (Object[]) objArrPullLastBuffer[0];
            this.rootShift = i3 - 5;
        } else {
            this.root = objArrPullLastBuffer;
            this.rootShift = i3;
        }
    }

    private final Object[] pushBuffers(Object[] objArr, int i2, int i3, Iterator<Object[]> it) {
        if (!it.hasNext()) {
            V0.throwIllegalArgumentException("invalid buffersIterator");
        }
        if (!(i3 >= 0)) {
            V0.throwIllegalArgumentException("negative shift");
        }
        if (i3 == 0) {
            return it.next();
        }
        Object[] objArrMakeMutable = makeMutable(objArr);
        int iIndexSegment = m.indexSegment(i2, i3);
        int i4 = i3 - 5;
        objArrMakeMutable[iIndexSegment] = pushBuffers((Object[]) objArrMakeMutable[iIndexSegment], i2, i4, it);
        while (true) {
            iIndexSegment++;
            if (iIndexSegment >= 32 || !it.hasNext()) {
                break;
            }
            objArrMakeMutable[iIndexSegment] = pushBuffers((Object[]) objArrMakeMutable[iIndexSegment], 0, i4, it);
        }
        return objArrMakeMutable;
    }

    private final Object[] pushBuffersIncreasingHeightIfNeeded(Object[] objArr, int i2, Object[][] objArr2) {
        C0273d c0273dH = o.h(objArr2);
        int i3 = i2 >> 5;
        int i4 = this.rootShift;
        Object[] objArrPushBuffers = i3 < (1 << i4) ? pushBuffers(objArr, i2, i4, c0273dH) : makeMutable(objArr);
        while (c0273dH.hasNext()) {
            this.rootShift += 5;
            objArrPushBuffers = mutableBufferWith(objArrPushBuffers);
            int i5 = this.rootShift;
            pushBuffers(objArrPushBuffers, 1 << i5, i5, c0273dH);
        }
        return objArrPushBuffers;
    }

    private final void pushFilledTail(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int size = size() >> 5;
        int i2 = this.rootShift;
        if (size > (1 << i2)) {
            this.root = pushTail(mutableBufferWith(objArr), objArr2, this.rootShift + 5);
            this.tail = objArr3;
            this.rootShift += 5;
            this.size = size() + 1;
            return;
        }
        if (objArr == null) {
            this.root = objArr2;
            this.tail = objArr3;
            this.size = size() + 1;
        } else {
            this.root = pushTail(objArr, objArr2, i2);
            this.tail = objArr3;
            this.size = size() + 1;
        }
    }

    private final Object[] pushTail(Object[] objArr, Object[] objArr2, int i2) {
        int iIndexSegment = m.indexSegment(size() - 1, i2);
        Object[] objArrMakeMutable = makeMutable(objArr);
        if (i2 == 5) {
            objArrMakeMutable[iIndexSegment] = objArr2;
        } else {
            objArrMakeMutable[iIndexSegment] = pushTail((Object[]) objArrMakeMutable[iIndexSegment], objArr2, i2 - 5);
        }
        return objArrMakeMutable;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final int recyclableRemoveAll(h1.c cVar, Object[] objArr, int i2, int i3, e eVar, List<Object[]> list, List<Object[]> list2) {
        if (isMutable(objArr)) {
            list.add(objArr);
        }
        Object value = eVar.getValue();
        o.c(value, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        Object[] objArr2 = (Object[]) value;
        Object[] objArrRemove = objArr2;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (!((Boolean) cVar.invoke(obj)).booleanValue()) {
                if (i3 == 32) {
                    objArrRemove = !list.isEmpty() ? list.remove(list.size() - 1) : mutableBuffer();
                    i3 = 0;
                }
                objArrRemove[i3] = obj;
                i3++;
            }
        }
        eVar.setValue(objArrRemove);
        if (objArr2 != eVar.getValue()) {
            list2.add(objArr2);
        }
        return i3;
    }

    private final int removeAllFromTail(h1.c cVar, int i2, e eVar) {
        int iRemoveAll = removeAll(cVar, this.tail, i2, eVar);
        if (iRemoveAll == i2) {
            F.a.m0assert(eVar.getValue() == this.tail);
            return i2;
        }
        Object value = eVar.getValue();
        o.c(value, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        Object[] objArr = (Object[]) value;
        Arrays.fill(objArr, iRemoveAll, i2, (Object) null);
        this.tail = objArr;
        this.size = size() - (i2 - iRemoveAll);
        return iRemoveAll;
    }

    private final Object[] removeFromRootAt(Object[] objArr, int i2, int i3, e eVar) {
        int iIndexSegment = m.indexSegment(i3, i2);
        if (i2 == 0) {
            Object obj = objArr[iIndexSegment];
            Object[] objArrMakeMutable = makeMutable(objArr);
            r.P(objArr, objArrMakeMutable, iIndexSegment, iIndexSegment + 1, 32);
            objArrMakeMutable[31] = eVar.getValue();
            eVar.setValue(obj);
            return objArrMakeMutable;
        }
        int iIndexSegment2 = objArr[31] == null ? m.indexSegment(rootSize() - 1, i2) : 31;
        Object[] objArrMakeMutable2 = makeMutable(objArr);
        int i4 = i2 - 5;
        int i5 = iIndexSegment + 1;
        if (i5 <= iIndexSegment2) {
            while (true) {
                Object obj2 = objArrMakeMutable2[iIndexSegment2];
                o.c(obj2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
                objArrMakeMutable2[iIndexSegment2] = removeFromRootAt((Object[]) obj2, i4, 0, eVar);
                if (iIndexSegment2 == i5) {
                    break;
                }
                iIndexSegment2--;
            }
        }
        Object obj3 = objArrMakeMutable2[iIndexSegment];
        o.c(obj3, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        objArrMakeMutable2[iIndexSegment] = removeFromRootAt((Object[]) obj3, i4, i3, eVar);
        return objArrMakeMutable2;
    }

    private final Object removeFromTailAt(Object[] objArr, int i2, int i3, int i4) {
        int size = size() - i2;
        F.a.m0assert(i4 < size);
        if (size == 1) {
            Object obj = this.tail[0];
            pullLastBufferFromRoot(objArr, i2, i3);
            return obj;
        }
        Object[] objArr2 = this.tail;
        Object obj2 = objArr2[i4];
        Object[] objArrMakeMutable = makeMutable(objArr2);
        r.P(objArr2, objArrMakeMutable, i4, i4 + 1, size);
        objArrMakeMutable[size - 1] = null;
        this.root = objArr;
        this.tail = objArrMakeMutable;
        this.size = (i2 + size) - 1;
        this.rootShift = i3;
        return obj2;
    }

    private final Object[] retainFirst(Object[] objArr, int i2) {
        if (!((i2 & 31) == 0)) {
            V0.throwIllegalArgumentException("invalid size");
        }
        if (i2 == 0) {
            this.rootShift = 0;
            return null;
        }
        int i3 = i2 - 1;
        while (true) {
            int i4 = this.rootShift;
            if ((i3 >> i4) != 0) {
                return nullifyAfter(objArr, i3, i4);
            }
            this.rootShift = i4 - 5;
            Object[] objArr2 = objArr[0];
            o.c(objArr2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArr = objArr2;
        }
    }

    private final int rootSize() {
        if (size() <= 32) {
            return 0;
        }
        return m.rootSize(size());
    }

    private final Object[] setInRoot(Object[] objArr, int i2, int i3, Object obj, e eVar) {
        int iIndexSegment = m.indexSegment(i3, i2);
        Object[] objArrMakeMutable = makeMutable(objArr);
        if (i2 != 0) {
            Object obj2 = objArrMakeMutable[iIndexSegment];
            o.c(obj2, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArrMakeMutable[iIndexSegment] = setInRoot((Object[]) obj2, i2 - 5, i3, obj, eVar);
            return objArrMakeMutable;
        }
        if (objArrMakeMutable != objArr) {
            ((AbstractList) this).modCount++;
        }
        eVar.setValue(objArrMakeMutable[iIndexSegment]);
        objArrMakeMutable[iIndexSegment] = obj;
        return objArrMakeMutable;
    }

    private final Object[] shiftLeafBuffers(int i2, int i3, Object[][] objArr, int i4, Object[] objArr2) {
        if (this.root == null) {
            throw new IllegalStateException("root is null");
        }
        ListIterator<Object[]> listIteratorLeafBufferIterator = leafBufferIterator(rootSize() >> 5);
        while (listIteratorLeafBufferIterator.previousIndex() != i2) {
            Object[] objArrPrevious = listIteratorLeafBufferIterator.previous();
            r.P(objArrPrevious, objArr2, 0, 32 - i3, 32);
            objArr2 = makeMutableShiftingRight(objArrPrevious, i3);
            i4--;
            objArr[i4] = objArr2;
        }
        return listIteratorLeafBufferIterator.previous();
    }

    private final void splitToBuffers(Collection<Object> collection, int i2, Object[] objArr, int i3, Object[][] objArr2, int i4, Object[] objArr3) {
        Object[] objArrMutableBuffer;
        if (i4 < 1) {
            V0.throwIllegalArgumentException("requires at least one nullBuffer");
        }
        Object[] objArrMakeMutable = makeMutable(objArr);
        objArr2[0] = objArrMakeMutable;
        int i5 = i2 & 31;
        int size = ((collection.size() + i2) - 1) & 31;
        int i6 = (i3 - i5) + size;
        if (i6 < 32) {
            r.P(objArrMakeMutable, objArr3, size + 1, i5, i3);
        } else {
            int i7 = i6 - 31;
            if (i4 == 1) {
                objArrMutableBuffer = objArrMakeMutable;
            } else {
                objArrMutableBuffer = mutableBuffer();
                i4--;
                objArr2[i4] = objArrMutableBuffer;
            }
            int i8 = i3 - i7;
            r.P(objArrMakeMutable, objArr3, 0, i8, i3);
            r.P(objArrMakeMutable, objArrMutableBuffer, size + 1, i5, i8);
            objArr3 = objArrMutableBuffer;
        }
        Iterator<Object> it = collection.iterator();
        copyToBuffer(objArrMakeMutable, i5, it);
        for (int i9 = 1; i9 < i4; i9++) {
            objArr2[i9] = copyToBuffer(mutableBuffer(), 0, it);
        }
        copyToBuffer(objArr3, 0, it);
    }

    private final int tailSize(int i2) {
        return i2 <= 32 ? i2 : i2 - m.rootSize(i2);
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean add(Object obj) {
        ((AbstractList) this).modCount++;
        int iTailSize = tailSize();
        if (iTailSize < 32) {
            Object[] objArrMakeMutable = makeMutable(this.tail);
            objArrMakeMutable[iTailSize] = obj;
            this.tail = objArrMakeMutable;
            this.size = size() + 1;
        } else {
            pushFilledTail(this.root, this.tail, mutableBufferWith(obj));
        }
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean addAll(Collection<Object> collection) {
        if (collection.isEmpty()) {
            return false;
        }
        ((AbstractList) this).modCount++;
        int iTailSize = tailSize();
        Iterator<Object> it = collection.iterator();
        if (32 - iTailSize >= collection.size()) {
            this.tail = copyToBuffer(makeMutable(this.tail), iTailSize, it);
            this.size = collection.size() + size();
        } else {
            int size = ((collection.size() + iTailSize) - 1) / 32;
            Object[][] objArr = new Object[size][];
            objArr[0] = copyToBuffer(makeMutable(this.tail), iTailSize, it);
            for (int i2 = 1; i2 < size; i2++) {
                objArr[i2] = copyToBuffer(mutableBuffer(), 0, it);
            }
            this.root = pushBuffersIncreasingHeightIfNeeded(this.root, rootSize(), objArr);
            this.tail = copyToBuffer(mutableBuffer(), 0, it);
            this.size = collection.size() + size();
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public Object get(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        return bufferFor(i2)[i2 & 31];
    }

    public final int getModCount$runtime() {
        return ((AbstractList) this).modCount;
    }

    public final Object[] getRoot$runtime() {
        return this.root;
    }

    public final int getRootShift$runtime() {
        return this.rootShift;
    }

    @Override // V0.k
    public int getSize() {
        return this.size;
    }

    public final Object[] getTail$runtime() {
        return this.tail;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public Iterator<Object> iterator() {
        return listIterator();
    }

    @Override // java.util.AbstractList, java.util.List
    public ListIterator<Object> listIterator() {
        return listIterator(0);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean removeAll(Collection<?> collection) {
        return removeAllWithPredicate(new b(2, collection));
    }

    public final boolean removeAllWithPredicate(h1.c cVar) {
        boolean zRemoveAll = removeAll(cVar);
        if (zRemoveAll) {
            ((AbstractList) this).modCount++;
        }
        return zRemoveAll;
    }

    @Override // V0.k
    public Object removeAt(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        ((AbstractList) this).modCount++;
        int iRootSize = rootSize();
        if (i2 >= iRootSize) {
            return removeFromTailAt(this.root, iRootSize, this.rootShift, i2 - iRootSize);
        }
        e eVar = new e(this.tail[0]);
        Object[] objArr = this.root;
        o.b(objArr);
        removeFromTailAt(removeFromRootAt(objArr, this.rootShift, i2, eVar), iRootSize, this.rootShift, 0);
        return eVar.getValue();
    }

    @Override // java.util.AbstractList, java.util.List
    public Object set(int i2, Object obj) {
        F.d.checkElementIndex$runtime(i2, size());
        if (rootSize() > i2) {
            e eVar = new e(null);
            Object[] objArr = this.root;
            o.b(objArr);
            this.root = setInRoot(objArr, this.rootShift, i2, obj, eVar);
            return eVar.getValue();
        }
        Object[] objArrMakeMutable = makeMutable(this.tail);
        if (objArrMakeMutable != this.tail) {
            ((AbstractList) this).modCount++;
        }
        int i3 = i2 & 31;
        Object obj2 = objArrMakeMutable[i3];
        objArrMakeMutable[i3] = obj;
        this.tail = objArrMakeMutable;
        return obj2;
    }

    public final void setRootShift$runtime(int i2) {
        this.rootShift = i2;
    }

    private final boolean removeAll(h1.c cVar) {
        Object[] objArrPushBuffers;
        int iTailSize = tailSize();
        e eVar = new e(null);
        if (this.root == null) {
            return removeAllFromTail(cVar, iTailSize, eVar) != iTailSize;
        }
        ListIterator<Object[]> listIteratorLeafBufferIterator = leafBufferIterator(0);
        int iRemoveAll = 32;
        while (iRemoveAll == 32 && listIteratorLeafBufferIterator.hasNext()) {
            iRemoveAll = removeAll(cVar, listIteratorLeafBufferIterator.next(), 32, eVar);
        }
        if (iRemoveAll == 32) {
            F.a.m0assert(!listIteratorLeafBufferIterator.hasNext());
            int iRemoveAllFromTail = removeAllFromTail(cVar, iTailSize, eVar);
            if (iRemoveAllFromTail == 0) {
                pullLastBufferFromRoot(this.root, size(), this.rootShift);
            }
            return iRemoveAllFromTail != iTailSize;
        }
        int iPreviousIndex = listIteratorLeafBufferIterator.previousIndex() << 5;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int iRecyclableRemoveAll = iRemoveAll;
        while (listIteratorLeafBufferIterator.hasNext()) {
            iRecyclableRemoveAll = recyclableRemoveAll(cVar, listIteratorLeafBufferIterator.next(), 32, iRecyclableRemoveAll, eVar, arrayList2, arrayList);
            iPreviousIndex = iPreviousIndex;
        }
        int i2 = iPreviousIndex;
        int iRecyclableRemoveAll2 = recyclableRemoveAll(cVar, this.tail, iTailSize, iRecyclableRemoveAll, eVar, arrayList2, arrayList);
        Object value = eVar.getValue();
        o.c(value, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        Object[] objArr = (Object[]) value;
        Arrays.fill(objArr, iRecyclableRemoveAll2, 32, (Object) null);
        if (arrayList.isEmpty()) {
            objArrPushBuffers = this.root;
            o.b(objArrPushBuffers);
        } else {
            objArrPushBuffers = pushBuffers(this.root, i2, this.rootShift, arrayList.iterator());
        }
        int size = i2 + (arrayList.size() << 5);
        this.root = retainFirst(objArrPushBuffers, size);
        this.tail = objArr;
        this.size = size + iRecyclableRemoveAll2;
        return true;
    }

    private final int tailSize() {
        return tailSize(size());
    }

    @Override // z.InterfaceC1593i, z.InterfaceC1591g
    public InterfaceC1594j build() {
        InterfaceC1594j fVar;
        if (this.root == this.vectorRoot && this.tail == this.vectorTail) {
            fVar = this.vector;
        } else {
            this.ownership = new F.e();
            Object[] objArr = this.root;
            this.vectorRoot = objArr;
            Object[] objArr2 = this.tail;
            this.vectorTail = objArr2;
            if (objArr != null) {
                o.b(objArr);
                fVar = new f(objArr, this.tail, size(), this.rootShift);
            } else if (objArr2.length == 0) {
                fVar = m.persistentVectorOf();
            } else {
                Object[] objArrCopyOf = Arrays.copyOf(this.tail, size());
                o.d(objArrCopyOf, "copyOf(...)");
                fVar = new k(objArrCopyOf);
            }
        }
        this.vector = fVar;
        return fVar;
    }

    @Override // java.util.AbstractList, java.util.List
    public ListIterator<Object> listIterator(int i2) {
        F.d.checkPositionIndex$runtime(i2, size());
        return new i(this, i2);
    }

    private final void insertIntoRoot(Collection<Object> collection, int i2, int i3, Object[][] objArr, int i4, Object[] objArr2) {
        if (this.root != null) {
            int i5 = i2 >> 5;
            Object[] objArrShiftLeafBuffers = shiftLeafBuffers(i5, i3, objArr, i4, objArr2);
            int iRootSize = i4 - (((rootSize() >> 5) - 1) - i5);
            if (iRootSize < i4) {
                objArr2 = objArr[iRootSize];
                o.b(objArr2);
            }
            splitToBuffers(collection, i2, objArrShiftLeafBuffers, 32, objArr, iRootSize, objArr2);
            return;
        }
        throw new IllegalStateException("root is null");
    }

    @Override // java.util.AbstractList, java.util.List
    public void add(int i2, Object obj) {
        F.d.checkPositionIndex$runtime(i2, size());
        if (i2 == size()) {
            add(obj);
            return;
        }
        ((AbstractList) this).modCount++;
        int iRootSize = rootSize();
        if (i2 >= iRootSize) {
            insertIntoTail(this.root, i2 - iRootSize, obj);
            return;
        }
        e eVar = new e(null);
        Object[] objArr = this.root;
        o.b(objArr);
        insertIntoTail(insertIntoRoot(objArr, this.rootShift, i2, obj, eVar), 0, eVar.getValue());
    }

    @Override // java.util.AbstractList, java.util.List
    public boolean addAll(int i2, Collection<Object> collection) {
        Object[] objArrMutableBuffer;
        F.d.checkPositionIndex$runtime(i2, size());
        if (i2 == size()) {
            return addAll(collection);
        }
        if (collection.isEmpty()) {
            return false;
        }
        ((AbstractList) this).modCount++;
        int i3 = (i2 >> 5) << 5;
        int size = ((collection.size() + (size() - i3)) - 1) / 32;
        if (size == 0) {
            F.a.m0assert(i2 >= rootSize());
            int i4 = i2 & 31;
            int size2 = ((collection.size() + i2) - 1) & 31;
            Object[] objArr = this.tail;
            Object[] objArrMakeMutable = makeMutable(objArr);
            r.P(objArr, objArrMakeMutable, size2 + 1, i4, tailSize());
            copyToBuffer(objArrMakeMutable, i4, collection.iterator());
            this.tail = objArrMakeMutable;
            this.size = collection.size() + size();
            return true;
        }
        Object[][] objArr2 = new Object[size][];
        int iTailSize = tailSize();
        int iTailSize2 = tailSize(collection.size() + size());
        if (i2 >= rootSize()) {
            objArrMutableBuffer = mutableBuffer();
            splitToBuffers(collection, i2, this.tail, iTailSize, objArr2, size, objArrMutableBuffer);
        } else if (iTailSize2 > iTailSize) {
            int i5 = iTailSize2 - iTailSize;
            objArrMutableBuffer = makeMutableShiftingRight(this.tail, i5);
            insertIntoRoot(collection, i2, i5, objArr2, size, objArrMutableBuffer);
        } else {
            Object[] objArr3 = this.tail;
            objArrMutableBuffer = mutableBuffer();
            int i6 = iTailSize - iTailSize2;
            r.P(objArr3, objArrMutableBuffer, 0, i6, iTailSize);
            int i7 = 32 - i6;
            Object[] objArrMakeMutableShiftingRight = makeMutableShiftingRight(this.tail, i7);
            int i8 = size - 1;
            objArr2[i8] = objArrMakeMutableShiftingRight;
            insertIntoRoot(collection, i2, i7, objArr2, i8, objArrMakeMutableShiftingRight);
        }
        this.root = pushBuffersIncreasingHeightIfNeeded(this.root, i3, objArr2);
        this.tail = objArrMutableBuffer;
        this.size = collection.size() + size();
        return true;
    }

    private final int removeAll(h1.c cVar, Object[] objArr, int i2, e eVar) {
        Object[] objArrMakeMutable = objArr;
        int i3 = i2;
        boolean z2 = false;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (((Boolean) cVar.invoke(obj)).booleanValue()) {
                if (!z2) {
                    objArrMakeMutable = makeMutable(objArr);
                    z2 = true;
                    i3 = i4;
                }
            } else if (z2) {
                objArrMakeMutable[i3] = obj;
                i3++;
            }
        }
        eVar.setValue(objArrMakeMutable);
        return i3;
    }
}
