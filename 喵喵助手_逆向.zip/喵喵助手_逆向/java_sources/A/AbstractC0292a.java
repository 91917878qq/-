package a;

import G.v;
import M0.C0186b;
import O0.C0196b;
import O0.K;
import O0.M;
import O0.Y;
import T0.j;
import Y0.f;
import Y0.h;
import Y0.i;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.Process;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewParent;
import androidx.compose.foundation.text.modifiers.s;
import androidx.compose.material3.AbstractC0664c;
import androidx.compose.runtime.AbstractC0721c1;
import androidx.compose.runtime.AbstractC0776s;
import androidx.compose.runtime.B0;
import androidx.compose.runtime.C0765o;
import androidx.compose.runtime.InterfaceC0768p;
import androidx.compose.runtime.InterfaceC0811x1;
import androidx.compose.runtime.Q1;
import androidx.compose.runtime.V1;
import androidx.compose.runtime.Z;
import androidx.compose.runtime.d2;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.text.N;
import androidx.core.view.AbstractC1199c;
import androidx.core.view.AbstractC1220y;
import androidx.core.view.C1219x;
import androidx.lifecycle.u;
import b.C1247G;
import b.C1250J;
import b.InterfaceC1249I;
import c.C1285e;
import c.C1286f;
import c.C1287g;
import c.k;
import c.l;
import com.miaomiao.assistant.backdrop.R;
import e.C1298a;
import f.C1313b;
import f1.g;
import h1.e;
import j0.C1370c;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.H;
import kotlin.jvm.internal.o;
import o0.AbstractC1405b;
import q1.b;
import q1.c;
import r1.AbstractC1476z;
import r1.C1466o;
import r1.InterfaceC1474x;
import v0.C1526v;
import w0.C1535b;
import w1.r;

/* JADX INFO: renamed from: a.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0292a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static boolean f1626a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static Method f1627b;

    public static MappedByteBuffer A(Context context, Uri uri) {
        try {
            ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", null);
            if (parcelFileDescriptorOpenFileDescriptor == null) {
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                }
                return null;
            }
            try {
                FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                try {
                    FileChannel channel = fileInputStream.getChannel();
                    MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                    fileInputStream.close();
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return map;
                } finally {
                }
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    public static h D(f fVar, h context) {
        o.e(context, "context");
        return context == i.f1613b ? fVar : (h) context.fold(fVar, new M(17));
    }

    public static C1535b E(MappedByteBuffer mappedByteBuffer) throws IOException {
        long j2;
        ByteBuffer byteBufferDuplicate = mappedByteBuffer.duplicate();
        byteBufferDuplicate.order(ByteOrder.BIG_ENDIAN);
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
        int i2 = byteBufferDuplicate.getShort() & 65535;
        if (i2 > 100) {
            throw new IOException("Cannot read metadata.");
        }
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 6);
        int i3 = 0;
        while (true) {
            if (i3 >= i2) {
                j2 = -1;
                break;
            }
            int i4 = byteBufferDuplicate.getInt();
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            j2 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            if (1835365473 == i4) {
                break;
            }
            i3++;
        }
        if (j2 != -1) {
            byteBufferDuplicate.position(byteBufferDuplicate.position() + ((int) (j2 - ((long) byteBufferDuplicate.position()))));
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 12);
            long j3 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            for (int i5 = 0; i5 < j3; i5++) {
                int i6 = byteBufferDuplicate.getInt();
                long j4 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
                byteBufferDuplicate.getInt();
                if (1164798569 == i6 || 1701669481 == i6) {
                    byteBufferDuplicate.position((int) (j4 + j2));
                    C1535b c1535b = new C1535b();
                    byteBufferDuplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int iPosition = byteBufferDuplicate.position() + byteBufferDuplicate.getInt(byteBufferDuplicate.position());
                    c1535b.f1586e = byteBufferDuplicate;
                    c1535b.f1583b = iPosition;
                    int i7 = iPosition - byteBufferDuplicate.getInt(iPosition);
                    c1535b.f1584c = i7;
                    c1535b.f1585d = ((ByteBuffer) c1535b.f1586e).getShort(i7);
                    return c1535b;
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static final void F(Object[] objArr, int i2, int i3) {
        o.e(objArr, "<this>");
        while (i2 < i3) {
            objArr[i2] = null;
            i2++;
        }
    }

    public static final Object G(r rVar, r rVar2, e eVar) throws Throwable {
        Object c1466o;
        Object objK;
        try {
            H.c(2, eVar);
            c1466o = eVar.invoke(rVar2, rVar);
        } catch (Throwable th) {
            c1466o = new C1466o(false, th);
        }
        Z0.a aVar = Z0.a.f1616b;
        if (c1466o == aVar || (objK = rVar.K(c1466o)) == AbstractC1476z.f3417e) {
            return aVar;
        }
        if (objK instanceof C1466o) {
            throw ((C1466o) objK).f3389a;
        }
        return AbstractC1476z.y(objK);
    }

    public static final void H(Object obj) {
        if (obj instanceof U0.i) {
            throw ((U0.i) obj).f1513b;
        }
    }

    public static final long I(long j2, c unit) {
        o.e(unit, "unit");
        c sourceUnit = c.f3275c;
        o.e(sourceUnit, "sourceUnit");
        TimeUnit timeUnit = unit.f3278b;
        TimeUnit timeUnit2 = sourceUnit.f3278b;
        long jConvert = timeUnit.convert(4611686018426999999L, timeUnit2);
        if ((-jConvert) > j2 || j2 > jConvert) {
            c targetUnit = c.f3276d;
            o.e(targetUnit, "targetUnit");
            return p(j1.a.p(targetUnit.f3278b.convert(j2, timeUnit), -4611686018427387903L, 4611686018427387903L));
        }
        long jConvert2 = timeUnit2.convert(j2, timeUnit) << 1;
        int i2 = q1.a.f3273d;
        int i3 = b.f3274a;
        return jConvert2;
    }

    public static final void a(boolean z2, h1.a aVar, InterfaceC0768p interfaceC0768p, int i2) {
        int i3;
        int i4 = 3;
        int i5 = 2;
        int i6 = 4;
        int i7 = 0;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-361453782);
        if ((i2 & 6) == 0) {
            i3 = (interfaceC0768pStartRestartGroup.changed(z2) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= interfaceC0768pStartRestartGroup.changed(aVar) ? 32 : 16;
        }
        if ((i3 & 19) == 18 && interfaceC0768pStartRestartGroup.getSkipping()) {
            interfaceC0768pStartRestartGroup.skipToGroupEnd();
        } else {
            d2 d2VarRememberUpdatedState = Q1.rememberUpdatedState(aVar, interfaceC0768pStartRestartGroup, (i3 >> 3) & 14);
            interfaceC0768pStartRestartGroup.startReplaceableGroup(-971159753);
            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
            C0765o c0765o = InterfaceC0768p.Companion;
            if (objRememberedValue == c0765o.getEmpty()) {
                objRememberedValue = new c.h(z2, d2VarRememberUpdatedState);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            c.h hVar = (c.h) objRememberedValue;
            interfaceC0768pStartRestartGroup.endReplaceableGroup();
            interfaceC0768pStartRestartGroup.startReplaceableGroup(-971159481);
            boolean zChanged = interfaceC0768pStartRestartGroup.changed(hVar) | interfaceC0768pStartRestartGroup.changed(z2);
            Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
            if (zChanged || objRememberedValue2 == c0765o.getEmpty()) {
                objRememberedValue2 = new C1285e(hVar, z2);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            interfaceC0768pStartRestartGroup.endReplaceableGroup();
            Z.SideEffect((h1.a) objRememberedValue2, interfaceC0768pStartRestartGroup, 0);
            AbstractC0721c1 abstractC0721c1 = k.f2766a;
            interfaceC0768pStartRestartGroup.startReplaceableGroup(-2068013981);
            InterfaceC1249I interfaceC1249I = (InterfaceC1249I) interfaceC0768pStartRestartGroup.consume(k.f2766a);
            interfaceC0768pStartRestartGroup.startReplaceableGroup(1680121597);
            Context context = null;
            if (interfaceC1249I == null) {
                View view = (View) interfaceC0768pStartRestartGroup.consume(AndroidCompositionLocals_androidKt.getLocalView());
                o.e(view, "<this>");
                o1.c cVar = new o1.c(new g(i5, new N(12), new g(i6, C1250J.f2702e, new g(i4, C1250J.f2701d, new s(view, 7)))), (byte) 0);
                interfaceC1249I = (InterfaceC1249I) (!cVar.hasNext() ? null : cVar.next());
            }
            interfaceC0768pStartRestartGroup.endReplaceableGroup();
            if (interfaceC1249I == null) {
                Context baseContext = (Context) interfaceC0768pStartRestartGroup.consume(AndroidCompositionLocals_androidKt.getLocalContext());
                while (true) {
                    if (!(baseContext instanceof ContextWrapper)) {
                        break;
                    }
                    if (baseContext instanceof InterfaceC1249I) {
                        context = baseContext;
                        break;
                    }
                    baseContext = ((ContextWrapper) baseContext).getBaseContext();
                }
                interfaceC1249I = (InterfaceC1249I) context;
            }
            interfaceC0768pStartRestartGroup.endReplaceableGroup();
            if (interfaceC1249I == null) {
                throw new IllegalStateException("No OnBackPressedDispatcherOwner was provided via LocalOnBackPressedDispatcherOwner");
            }
            C1247G onBackPressedDispatcher = interfaceC1249I.getOnBackPressedDispatcher();
            u uVar = (u) interfaceC0768pStartRestartGroup.consume(AndroidCompositionLocals_androidKt.getLocalLifecycleOwner());
            interfaceC0768pStartRestartGroup.startReplaceableGroup(-971159120);
            boolean zChanged2 = interfaceC0768pStartRestartGroup.changed(onBackPressedDispatcher) | interfaceC0768pStartRestartGroup.changed(uVar) | interfaceC0768pStartRestartGroup.changed(hVar);
            Object objRememberedValue3 = interfaceC0768pStartRestartGroup.rememberedValue();
            if (zChanged2 || objRememberedValue3 == InterfaceC0768p.Companion.getEmpty()) {
                objRememberedValue3 = new C1286f(onBackPressedDispatcher, uVar, hVar, i7);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue3);
            }
            interfaceC0768pStartRestartGroup.endReplaceableGroup();
            Z.DisposableEffect(uVar, onBackPressedDispatcher, (h1.c) objRememberedValue3, interfaceC0768pStartRestartGroup, 0);
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768pStartRestartGroup.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new C1287g(z2, aVar, i2));
        }
    }

    public static final void b(InterfaceC0768p interfaceC0768p, int i2) {
        InterfaceC0768p interfaceC0768p2;
        InterfaceC0768p interfaceC0768pStartRestartGroup = interfaceC0768p.startRestartGroup(-70809494);
        if (interfaceC0768pStartRestartGroup.shouldExecute(i2 != 0, i2 & 1)) {
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventStart(-70809494, i2, -1, "com.miaomiao.assistant.ui.CrashReportDialog (CrashReportDialog.kt:30)");
            }
            Context context = (Context) interfaceC0768pStartRestartGroup.consume(AndroidCompositionLocals_androidKt.getLocalContext());
            Object objRememberedValue = interfaceC0768pStartRestartGroup.rememberedValue();
            C0765o c0765o = InterfaceC0768p.Companion;
            if (objRememberedValue == c0765o.getEmpty()) {
                Boolean bool = (Boolean) j.f1487e.getValue();
                bool.getClass();
                objRememberedValue = V1.mutableStateOf$default(bool, null, 2, null);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            B0 b02 = (B0) objRememberedValue;
            Object objRememberedValue2 = interfaceC0768pStartRestartGroup.rememberedValue();
            if (objRememberedValue2 == c0765o.getEmpty()) {
                objRememberedValue2 = Z.createCompositionCoroutineScope(i.f1613b, interfaceC0768pStartRestartGroup);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            InterfaceC1474x interfaceC1474x = (InterfaceC1474x) objRememberedValue2;
            C1313b c1313b = new C1313b();
            boolean zChangedInstance = interfaceC0768pStartRestartGroup.changedInstance(context) | interfaceC0768pStartRestartGroup.changedInstance(interfaceC1474x);
            Object objRememberedValue3 = interfaceC0768pStartRestartGroup.rememberedValue();
            if (zChangedInstance || objRememberedValue3 == c0765o.getEmpty()) {
                objRememberedValue3 = new Y(context, interfaceC1474x, b02, 0);
                interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue3);
            }
            l lVarS = j1.a.S(c1313b, (h1.c) objRememberedValue3, interfaceC0768pStartRestartGroup);
            if (((Boolean) b02.getValue()).booleanValue()) {
                interfaceC0768pStartRestartGroup.startReplaceGroup(-656187372);
                Object objRememberedValue4 = interfaceC0768pStartRestartGroup.rememberedValue();
                if (objRememberedValue4 == c0765o.getEmpty()) {
                    objRememberedValue4 = new C0186b(17, b02);
                    interfaceC0768pStartRestartGroup.updateRememberedValue(objRememberedValue4);
                }
                interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                AbstractC0664c.m2103AlertDialogOix01E0((h1.a) objRememberedValue4, v.rememberComposableLambda(-1867445443, true, new O0.Z(context, lVarS, interfaceC1474x, b02), interfaceC0768pStartRestartGroup, 54), null, v.rememberComposableLambda(-478151429, true, new C0196b(5, b02), interfaceC0768pStartRestartGroup, 54), null, K.f583c, K.f584d, null, 0L, 0L, 0L, 0L, 0.0f, null, interfaceC0768p2, 1772598, 0, 16276);
            } else {
                interfaceC0768p2 = interfaceC0768pStartRestartGroup;
                interfaceC0768p2.startReplaceGroup(-657744936);
            }
            interfaceC0768p2.endReplaceGroup();
            if (AbstractC0776s.isTraceInProgress()) {
                AbstractC0776s.traceEventEnd();
            }
        } else {
            interfaceC0768p2 = interfaceC0768pStartRestartGroup;
            interfaceC0768p2.skipToGroupEnd();
        }
        InterfaceC0811x1 interfaceC0811x1EndRestartGroup = interfaceC0768p2.endRestartGroup();
        if (interfaceC0811x1EndRestartGroup != null) {
            interfaceC0811x1EndRestartGroup.updateScope(new M0.o(i2, 3));
        }
    }

    public static final boolean c(Object[] objArr, int i2, int i3, List list) {
        if (i3 != list.size()) {
            return false;
        }
        for (int i4 = 0; i4 < i3; i4++) {
            if (!o.a(objArr[i2 + i4], list.get(i4))) {
                return false;
            }
        }
        return true;
    }

    public static final String d(Object[] objArr, int i2, int i3, V0.k kVar) {
        StringBuilder sb = new StringBuilder((i3 * 3) + 2);
        sb.append("[");
        for (int i4 = 0; i4 < i3; i4++) {
            if (i4 > 0) {
                sb.append(", ");
            }
            Object obj = objArr[i2 + i4];
            if (obj == kVar) {
                sb.append("(this Collection)");
            } else {
                sb.append(obj);
            }
        }
        sb.append("]");
        String string = sb.toString();
        o.d(string, "toString(...)");
        return string;
    }

    public static void e(Throwable th, Throwable exception) throws IllegalAccessException, InvocationTargetException {
        o.e(th, "<this>");
        o.e(exception, "exception");
        if (th != exception) {
            Integer num = d1.a.f2791a;
            if (num == null || num.intValue() >= 19) {
                th.addSuppressed(exception);
                return;
            }
            Method method = c1.a.f2768a;
            if (method != null) {
                method.invoke(th, exception);
            }
        }
    }

    public static void f(StringBuilder sb, Object obj, h1.c cVar) {
        if (cVar != null) {
            sb.append((CharSequence) cVar.invoke(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) obj.toString());
        }
    }

    public static int g(Context context) {
        return (Build.VERSION.SDK_INT >= 33 || !TextUtils.equals("android.permission.POST_NOTIFICATIONS", "android.permission.WRITE_EXTERNAL_STORAGE")) ? context.checkPermission("android.permission.WRITE_EXTERNAL_STORAGE", Process.myPid(), Process.myUid()) : new C1370c(context).f3104a.areNotificationsEnabled() ? 0 : -1;
    }

    public static void h(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    public static final void i(int i2, int i3) {
        if (i2 <= i3) {
            return;
        }
        throw new IndexOutOfBoundsException("toIndex (" + i2 + ") is greater than size (" + i3 + ").");
    }

    public static boolean j(File file, Resources resources, int i2) throws Throwable {
        InputStream inputStreamOpenRawResource;
        try {
            inputStreamOpenRawResource = resources.openRawResource(i2);
            try {
                boolean zK = k(file, inputStreamOpenRawResource);
                h(inputStreamOpenRawResource);
                return zK;
            } catch (Throwable th) {
                th = th;
                h(inputStreamOpenRawResource);
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            inputStreamOpenRawResource = null;
        }
    }

    public static boolean k(File file, InputStream inputStream) throws Throwable {
        FileOutputStream fileOutputStream;
        StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream2 = null;
        try {
            try {
                fileOutputStream = new FileOutputStream(file, false);
            } catch (IOException e2) {
                e = e2;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int i2 = inputStream.read(bArr);
                if (i2 == -1) {
                    h(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return true;
                }
                fileOutputStream.write(bArr, 0, i2);
            }
        } catch (IOException e3) {
            e = e3;
            fileOutputStream2 = fileOutputStream;
            Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
            h(fileOutputStream2);
            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            return false;
        } catch (Throwable th2) {
            th = th2;
            fileOutputStream2 = fileOutputStream;
            h(fileOutputStream2);
            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            throw th;
        }
    }

    public static Handler l(Looper looper) {
        if (Build.VERSION.SDK_INT >= 28) {
            return AbstractC1199c.a(looper);
        }
        try {
            return (Handler) Handler.class.getDeclaredConstructor(Looper.class, Handler.Callback.class, Boolean.TYPE).newInstance(looper, null, Boolean.TRUE);
        } catch (IllegalAccessException e2) {
            e = e2;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (InstantiationException e3) {
            e = e3;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (NoSuchMethodException e4) {
            e = e4;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (InvocationTargetException e5) {
            Throwable cause = e5.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException(cause);
        }
    }

    public static final U0.i m(Throwable exception) {
        o.e(exception, "exception");
        return new U0.i(exception);
    }

    public static androidx.lifecycle.N n(Class cls) throws InvocationTargetException {
        try {
            Constructor declaredConstructor = cls.getDeclaredConstructor(null);
            if (!Modifier.isPublic(declaredConstructor.getModifiers())) {
                throw new RuntimeException("Cannot create an instance of " + cls);
            }
            try {
                Object objNewInstance = declaredConstructor.newInstance(null);
                o.b(objNewInstance);
                return (androidx.lifecycle.N) objNewInstance;
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            }
        } catch (NoSuchMethodException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        }
    }

    public static boolean o(View view, KeyEvent keyEvent) {
        ArrayList arrayList;
        int size;
        int iIndexOfKey;
        int i2 = AbstractC1220y.f2603a;
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList arrayList2 = C1219x.f2599d;
        C1219x c1219x = (C1219x) view.getTag(R.id.tag_unhandled_key_event_manager);
        WeakReference weakReference = null;
        if (c1219x == null) {
            c1219x = new C1219x();
            c1219x.f2600a = null;
            c1219x.f2601b = null;
            c1219x.f2602c = null;
            view.setTag(R.id.tag_unhandled_key_event_manager, c1219x);
        }
        WeakReference weakReference2 = c1219x.f2602c;
        if (weakReference2 != null && weakReference2.get() == keyEvent) {
            return false;
        }
        c1219x.f2602c = new WeakReference(keyEvent);
        if (c1219x.f2601b == null) {
            c1219x.f2601b = new SparseArray();
        }
        SparseArray sparseArray = c1219x.f2601b;
        if (keyEvent.getAction() == 1 && (iIndexOfKey = sparseArray.indexOfKey(keyEvent.getKeyCode())) >= 0) {
            weakReference = (WeakReference) sparseArray.valueAt(iIndexOfKey);
            sparseArray.removeAt(iIndexOfKey);
        }
        if (weakReference == null) {
            weakReference = (WeakReference) sparseArray.get(keyEvent.getKeyCode());
        }
        if (weakReference == null) {
            return false;
        }
        View view2 = (View) weakReference.get();
        if (view2 == null || !view2.isAttachedToWindow() || (arrayList = (ArrayList) view2.getTag(R.id.tag_unhandled_key_listeners)) == null || (size = arrayList.size() - 1) < 0) {
            return true;
        }
        arrayList.get(size).getClass();
        throw new ClassCastException();
    }

    public static final long p(long j2) {
        long j3 = (j2 << 1) + 1;
        int i2 = q1.a.f3273d;
        int i3 = b.f3274a;
        return j3;
    }

    public static final b1.b q(Enum[] entries) {
        o.e(entries, "entries");
        return new b1.b(entries);
    }

    public static Object r(f fVar, Object obj, e operation) {
        o.e(operation, "operation");
        return operation.invoke(obj, fVar);
    }

    public static final E0.h s(View view) {
        o.e(view, "<this>");
        while (view != null) {
            Object tag = view.getTag(R.id.view_tree_saved_state_registry_owner);
            E0.h hVar = tag instanceof E0.h ? (E0.h) tag : null;
            if (hVar != null) {
                return hVar;
            }
            Object objV = v(view);
            view = objV instanceof View ? (View) objV : null;
        }
        return null;
    }

    public static f t(f fVar, Y0.g key) {
        o.e(key, "key");
        if (o.a(fVar.getKey(), key)) {
            return fVar;
        }
        return null;
    }

    public static Object u(String str, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 34) {
            return AbstractC1405b.a(str, bundle);
        }
        Parcelable parcelable = bundle.getParcelable(str);
        if (C1298a.class.isInstance(parcelable)) {
            return parcelable;
        }
        return null;
    }

    public static final ViewParent v(View view) {
        ViewParent parent = view.getParent();
        if (parent != null) {
            return parent;
        }
        Object tag = view.getTag(R.id.view_tree_disjoint_parent);
        if (tag instanceof ViewParent) {
            return (ViewParent) tag;
        }
        return null;
    }

    public static File w(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i2 = 0; i2 < 100; i2++) {
            File file = new File(cacheDir, str + i2);
            if (file.createNewFile()) {
                return file;
            }
        }
        return null;
    }

    public static int x(int i2) {
        if (i2 == 1) {
            return 0;
        }
        if (i2 == 2) {
            return 1;
        }
        if (i2 == 4) {
            return 2;
        }
        if (i2 == 8) {
            return 3;
        }
        if (i2 == 16) {
            return 4;
        }
        if (i2 == 32) {
            return 5;
        }
        if (i2 == 64) {
            return 6;
        }
        if (i2 == 128) {
            return 7;
        }
        if (i2 == 256) {
            return 8;
        }
        throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i2);
    }

    public static o1.f y(e eVar) {
        o1.f fVar = new o1.f();
        fVar.f3209d = j1.a.t(fVar, fVar, eVar);
        return fVar;
    }

    public static h z(f fVar, Y0.g key) {
        o.e(key, "key");
        return o.a(fVar.getKey(), key) ? i.f1613b : fVar;
    }

    public abstract void B(Throwable th);

    public abstract void C(C1526v c1526v);
}
