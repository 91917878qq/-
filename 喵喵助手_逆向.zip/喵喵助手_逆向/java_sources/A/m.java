package A;

import z.InterfaceC1594j;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {
    public static final int LOG_MAX_BUFFER_SIZE = 5;
    public static final int MAX_BUFFER_SIZE = 32;
    public static final int MAX_BUFFER_SIZE_MINUS_ONE = 31;
    public static final int MUTABLE_BUFFER_SIZE = 33;

    public static final int indexSegment(int i2, int i3) {
        return (i2 >> i3) & 31;
    }

    public static final <E> InterfaceC1594j persistentVectorOf() {
        return k.Companion.getEMPTY();
    }

    public static final Object[] presizedBufferWith(Object obj) {
        Object[] objArr = new Object[32];
        objArr[0] = obj;
        return objArr;
    }

    public static final int rootSize(int i2) {
        return (i2 - 1) & (-32);
    }
}
