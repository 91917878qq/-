package A;

/* JADX INFO: loaded from: classes.dex */
public final class h extends a {
    public static final int $stable = 8;
    private final Object[] tail;
    private final l trieIterator;

    public h(Object[] objArr, Object[] objArr2, int i2, int i3, int i4) {
        super(i2, i3);
        this.tail = objArr2;
        int iRootSize = m.rootSize(i3);
        this.trieIterator = new l(objArr, i2 > iRootSize ? iRootSize : i2, iRootSize, i4);
    }

    @Override // A.a, java.util.ListIterator, java.util.Iterator
    public Object next() {
        checkHasNext$runtime();
        if (this.trieIterator.hasNext()) {
            setIndex(getIndex() + 1);
            return this.trieIterator.next();
        }
        Object[] objArr = this.tail;
        int index = getIndex();
        setIndex(index + 1);
        return objArr[index - this.trieIterator.getSize()];
    }

    @Override // java.util.ListIterator
    public Object previous() {
        checkHasPrevious$runtime();
        if (getIndex() <= this.trieIterator.getSize()) {
            setIndex(getIndex() - 1);
            return this.trieIterator.previous();
        }
        Object[] objArr = this.tail;
        setIndex(getIndex() - 1);
        return objArr[getIndex() - this.trieIterator.getSize()];
    }
}
