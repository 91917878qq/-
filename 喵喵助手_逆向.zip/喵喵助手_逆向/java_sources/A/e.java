package A;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final int $stable = 8;
    private Object value;

    public e(Object obj) {
        this.value = obj;
    }

    public final Object getValue() {
        return this.value;
    }

    public final void setValue(Object obj) {
        this.value = obj;
    }
}
