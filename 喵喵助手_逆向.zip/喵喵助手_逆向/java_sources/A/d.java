package A;

import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class d extends a {
    public static final int $stable = 8;
    private final Object[] buffer;

    public d(Object[] objArr, int i2, int i3) {
        super(i2, i3);
        this.buffer = objArr;
    }

    @Override // A.a, java.util.ListIterator, java.util.Iterator
    public Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object[] objArr = this.buffer;
        int index = getIndex();
        setIndex(index + 1);
        return objArr[index];
    }

    @Override // java.util.ListIterator
    public Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        Object[] objArr = this.buffer;
        setIndex(getIndex() - 1);
        return objArr[getIndex()];
    }
}
