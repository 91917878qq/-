package A;

import V0.r;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import kotlin.jvm.internal.AbstractC1378g;
import kotlin.jvm.internal.o;
import z.InterfaceC1588d;
import z.InterfaceC1592h;
import z.InterfaceC1593i;
import z.InterfaceC1594j;

/* JADX INFO: loaded from: classes.dex */
public final class k extends c implements InterfaceC1588d {
    private final Object[] buffer;
    public static final a Companion = new a(null);
    public static final int $stable = 8;
    private static final k EMPTY = new k(new Object[0]);

    public static final class a {
        public /* synthetic */ a(AbstractC1378g abstractC1378g) {
            this();
        }

        public final k getEMPTY() {
            return k.EMPTY;
        }

        private a() {
        }
    }

    public k(Object[] objArr) {
        this.buffer = objArr;
        F.a.m0assert(objArr.length <= 32);
    }

    private final Object[] bufferOfSize(int i2) {
        return new Object[i2];
    }

    @Override // A.c, java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public /* bridge */ /* synthetic */ InterfaceC1592h addAll(Collection collection) {
        return addAll((Collection<Object>) collection);
    }

    @Override // V0.AbstractC0276g, java.util.List
    public Object get(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        return this.buffer[i2];
    }

    @Override // V0.AbstractC0276g, V0.AbstractC0270a
    public int getSize() {
        return this.buffer.length;
    }

    @Override // V0.AbstractC0276g, java.util.List
    public int indexOf(Object obj) {
        return r.d0(this.buffer, obj);
    }

    @Override // V0.AbstractC0276g, java.util.List
    public int lastIndexOf(Object obj) {
        Object[] objArr = this.buffer;
        o.e(objArr, "<this>");
        if (obj == null) {
            int length = objArr.length - 1;
            if (length < 0) {
                return -1;
            }
            while (true) {
                int i2 = length - 1;
                if (objArr[length] == null) {
                    return length;
                }
                if (i2 < 0) {
                    return -1;
                }
                length = i2;
            }
        } else {
            int length2 = objArr.length - 1;
            if (length2 < 0) {
                return -1;
            }
            while (true) {
                int i3 = length2 - 1;
                if (obj.equals(objArr[length2])) {
                    return length2;
                }
                if (i3 < 0) {
                    return -1;
                }
                length2 = i3;
            }
        }
    }

    @Override // V0.AbstractC0276g, java.util.List
    public ListIterator<Object> listIterator(int i2) {
        F.d.checkPositionIndex$runtime(i2, size());
        return new d(this.buffer, i2, size());
    }

    @Override // A.c, z.InterfaceC1594j
    public InterfaceC1594j removeAt(int i2) {
        F.d.checkElementIndex$runtime(i2, size());
        if (size() == 1) {
            return EMPTY;
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.buffer, size() - 1);
        o.d(objArrCopyOf, "copyOf(...)");
        r.P(this.buffer, objArrCopyOf, i2, i2 + 1, size());
        return new k(objArrCopyOf);
    }

    @Override // A.c, V0.AbstractC0276g, java.util.List, z.InterfaceC1594j
    public InterfaceC1594j set(int i2, Object obj) {
        F.d.checkElementIndex$runtime(i2, size());
        Object[] objArr = this.buffer;
        Object[] objArrCopyOf = Arrays.copyOf(objArr, objArr.length);
        o.d(objArrCopyOf, "copyOf(...)");
        objArrCopyOf[i2] = obj;
        return new k(objArrCopyOf);
    }

    @Override // A.c, java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j add(Object obj) {
        if (size() >= 32) {
            return new f(this.buffer, m.presizedBufferWith(obj), size() + 1, 0);
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.buffer, size() + 1);
        o.d(objArrCopyOf, "copyOf(...)");
        objArrCopyOf[size()] = obj;
        return new k(objArrCopyOf);
    }

    @Override // A.c, java.util.Collection, java.util.List, z.InterfaceC1594j, z.InterfaceC1592h, z.InterfaceC1594j
    public InterfaceC1594j addAll(Collection<Object> collection) {
        if (collection.size() + size() > 32) {
            InterfaceC1593i interfaceC1593iBuilder = builder();
            interfaceC1593iBuilder.addAll(collection);
            return interfaceC1593iBuilder.build();
        }
        Object[] objArrCopyOf = Arrays.copyOf(this.buffer, collection.size() + size());
        o.d(objArrCopyOf, "copyOf(...)");
        int size = size();
        Iterator<Object> it = collection.iterator();
        while (it.hasNext()) {
            objArrCopyOf[size] = it.next();
            size++;
        }
        return new k(objArrCopyOf);
    }

    @Override // A.c, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1593i builder() {
        return new g(this, null, this.buffer, 0);
    }

    @Override // A.c, z.InterfaceC1594j, z.InterfaceC1592h
    public InterfaceC1594j removeAll(h1.c cVar) {
        Object[] objArrCopyOf = this.buffer;
        int size = size();
        int size2 = size();
        boolean z2 = false;
        for (int i2 = 0; i2 < size2; i2++) {
            Object obj = this.buffer[i2];
            if (((Boolean) cVar.invoke(obj)).booleanValue()) {
                if (!z2) {
                    Object[] objArr = this.buffer;
                    objArrCopyOf = Arrays.copyOf(objArr, objArr.length);
                    o.d(objArrCopyOf, "copyOf(...)");
                    z2 = true;
                    size = i2;
                }
            } else if (z2) {
                objArrCopyOf[size] = obj;
                size++;
            }
        }
        return size == size() ? this : size == 0 ? EMPTY : new k(r.U(objArrCopyOf, 0, size));
    }

    @Override // A.c, java.util.List, z.InterfaceC1594j
    public InterfaceC1594j add(int i2, Object obj) {
        F.d.checkPositionIndex$runtime(i2, size());
        if (i2 == size()) {
            return add(obj);
        }
        if (size() < 32) {
            Object[] objArrBufferOfSize = bufferOfSize(size() + 1);
            r.T(this.buffer, objArrBufferOfSize, 0, i2, 6);
            r.P(this.buffer, objArrBufferOfSize, i2 + 1, i2, size());
            objArrBufferOfSize[i2] = obj;
            return new k(objArrBufferOfSize);
        }
        Object[] objArr = this.buffer;
        Object[] objArrCopyOf = Arrays.copyOf(objArr, objArr.length);
        o.d(objArrCopyOf, "copyOf(...)");
        r.P(this.buffer, objArrCopyOf, i2 + 1, i2, size() - 1);
        objArrCopyOf[i2] = obj;
        return new f(objArrCopyOf, m.presizedBufferWith(this.buffer[31]), size() + 1, 0);
    }

    @Override // A.c, java.util.List, z.InterfaceC1594j
    public InterfaceC1594j addAll(int i2, Collection<Object> collection) {
        F.d.checkPositionIndex$runtime(i2, size());
        if (collection.size() + size() <= 32) {
            Object[] objArrBufferOfSize = bufferOfSize(collection.size() + size());
            r.T(this.buffer, objArrBufferOfSize, 0, i2, 6);
            r.P(this.buffer, objArrBufferOfSize, collection.size() + i2, i2, size());
            Iterator<Object> it = collection.iterator();
            while (it.hasNext()) {
                objArrBufferOfSize[i2] = it.next();
                i2++;
            }
            return new k(objArrBufferOfSize);
        }
        InterfaceC1593i interfaceC1593iBuilder = builder();
        interfaceC1593iBuilder.addAll(i2, collection);
        return interfaceC1593iBuilder.build();
    }
}
